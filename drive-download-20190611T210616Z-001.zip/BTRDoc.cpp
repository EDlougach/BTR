// BTRDoc.cpp : implementation of the CBTRDoc class
//

#include "stdafx.h"
#include "BTR.h"
#include <math.h>
#include <ctype.h>
#include <windows.h>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <time.h>
#include "psapi.h"
#include "Wininet.h"

#include "config.h"
#include "BTRDoc.h"
#include "DataView.h"
#include "MainView.h"
#include "LoadView.h"
#include "SetView.h"
#include "partfld.h"
#include "RemnDlg.h"
#include "ReionDlg.h"
#include "NeutrDlg.h"
#include "IonSourceDlg.h"
#include "ResSmooth.h"
#include "ProjectBar.h"
#include "TaskDlg.h"
#include "CommentsDlg.h"
#include "GasDlg.h"
#include "MFDlg.h"
#include "MultiPlotDlg.h"
#include "PlotDlg.h"
#include "PreviewDlg.h"
#include "AskDlg.h"
#include "InjectDlg.h"
#include "SurfDlg.h"
#include "BeamDlg.h"
#include "FieldsDlg.h"
#include "NBIconfDlg.h" 
#include "ThinDlg.h"
#include "ThickDlg.h"
#include "ThreadsDlg.h"
#include "SendMail.h"
#include "LevelsDlg.h"
#include "RIDDlg.h"
#include "AtomDlg.h"
#include "PlasmaDlg.h"
#include "InputDlg.h"
#include "StartDlg.h"
#include "LimitsDlg.h"
#include "DefLoadDlg.h"
#include "StatOutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//using namespace System::Net::Mail;

CString FindFileName(CString S) 
{
	CString S1 = S;
	int pos = S.Find( "\\", 0);
	while (pos >= 0) {
		S1 = S.Mid(pos+1);
		pos = S.Find("\\", pos+1);
	}
	return S1;
}

int FindDataColumns(FILE * f)
{
	int N = 0;
	double x;
	char buf[1024];
	char *nptr, *endptr, Res;
	while (N < 2) {
		if (fgets(buf, 1024, f) == NULL) return 0;
	
		nptr = buf;
		N = 0;
		while (sscanf(nptr,"%f",&x) != EOF) {
			x = strtod(nptr,&endptr);
			if (nptr == endptr) break; //nptr++; //catch special case
			else nptr = endptr;
			N++;
		}
	}
	return N;
}

inline double GAUSS(double arg, double delta){	return exp(-arg*arg / (delta*delta)) / delta;}

extern HWND ProjectBar;
extern CLoadView * pLoadView;
extern CMainView * pMainView;
extern CDataView * pDataView;
extern CSetView * pSetView ;
char * MagFilename = "Arrmag.txt";

BOOL TaskRemnantField, TaskReionization, ThickNeutralization, TaskBeamInPlasma;
double Bremnant1 = 0, Bremnant2 =  0, Bremnant3 = 0, Xremnant1 = 0, Xremnant2 = 0, Xremnant3 = 0;
//double ReionPercent = 0;// ReionSigma = 3.2e-21; // m2;
double NeutrSigma = 0;
double DuctExitYmin, DuctExitYmax, DuctExitZmin, DuctExitZmax;
// BTR-fast parameters 
double AreaXmax;
double RIDXmin, RIDchannelWidth;
double RID_A;
double Part_V;

extern vector<tDistInfo> dists;

extern CArray<double, double> SumReiPowerX; /// array for Reion sum power deposited within StepX
extern CArray<double, double> SumAtomPowerX; /// array for Atom sum power deposited within StepX
extern double SumPowerStepX;// step for sum power

extern CArray<double, double> SumPowerAngle; // array for sum power deposited within Angle
extern double SumPowerAngleStep;// degrees, step for angular profile

double CPlate::AbsYmin = 1000; 
double CPlate::AbsYmax = -1000;
double CPlate::AbsZmin = 1000; 
double CPlate::AbsZmax = -1000;

double LevelStep, LevelMin, LevelMax;
BOOL LevelWrite;
int DefLoadNX = 10, DefLoadNY = 20; // default Load settings
double DefLoadStepX = 0.01;
double DefLoadStepY = 0.01;
BOOL DefLoadStepRound = TRUE; // round step to reduce digits
BOOL DefLoadOptN = TRUE; // Def Cells Number = ON

CArray <BEAMLET_ENTRY, BEAMLET_ENTRY> SourceArr; 
CArray <C3Point, C3Point> Exit_Array; // Beam Foot: X-Curr, Y-posY, Z-posZ
CArray <RECT_DIA, RECT_DIA> Dia_Array; // diaphragms array
int  NofCalculated; //traced beamlets
BOOL F_GotThrough(C3Point P1, C3Point P2);
CString  GetMachine();
CString  GetUser();

BOOL InvUser;
//////////////////////////////////////////////////////////////////////////////////////////////
// CBTRDoc

IMPLEMENT_DYNCREATE(CBTRDoc, CDocument)

BEGIN_MESSAGE_MAP(CBTRDoc, CDocument)
	//{{AFX_MSG_MAP(CBTRDoc)
	ON_COMMAND(ID_DATA_GET, OnDataGet_void)
	ON_COMMAND(ID_DATA_STORE, OnDataStore)
	ON_COMMAND(ID_OPTIONS_ACCOUNTOFREIONIZATION, OnOptionsAccountofreionization)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_ACCOUNTOFREIONIZATION, OnUpdateOptionsAccountofreionization)
	ON_COMMAND(ID_OPTIONS_STOPIONSAFTERNEUTRALISER, OnOptionsStopionsafterneutraliser)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_STOPIONSAFTERNEUTRALISER, OnUpdateOptionsStopionsafterneutraliser)
	ON_COMMAND(ID_OPTIONS_STOPREIONIZEDPARTICLES, OnOptionsStopreionizedparticles)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_STOPREIONIZEDPARTICLES, OnUpdateOptionsStopreionizedparticles)
	ON_COMMAND(ID_OPTIONS_STRAYFIELDONOFF, OnOptionsStrayfieldonoff)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_STRAYFIELDONOFF, OnUpdateOptionsStrayfieldonoff)
	ON_COMMAND(ID_OPTIONS_OPENCALORIMETER, OnOptionsOpencalorimeter)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_OPENCALORIMETER, OnUpdateOptionsOpencalorimeter)
	ON_COMMAND(ID_TASKS_MAGSHIELD, OnTasksMagshield)
	ON_UPDATE_COMMAND_UI(ID_TASKS_MAGSHIELD, OnUpdateTasksMagshield)
	ON_COMMAND(ID_TASKS_REIONIZATION, OnTasksReionization)
	ON_UPDATE_COMMAND_UI(ID_TASKS_REIONIZATION, OnUpdateTasksReionization)
	ON_COMMAND(ID_TASKS_NEUTRALISATION, OnTasksNeutralisation)
	ON_UPDATE_COMMAND_UI(ID_TASKS_NEUTRALISATION, OnUpdateTasksNeutralisation)
	ON_COMMAND(ID_RESULTS_READ, OnResultsRead)
	ON_COMMAND(ID_RESULTS_SAVEALL, OnResultsSaveall)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_REALIONSOURCESTRUCTURE, OnUpdateOptionsRealionsourcestructure)
	ON_COMMAND(ID_DATA_SAVE, OnDataSave)
	ON_COMMAND(ID_RESULTS_READALL, OnResultsReadall)
	ON_COMMAND(ID_DATA_ACTIVE, OnDataActive)
	ON_COMMAND(ID_OPTIONS_SINGAP, OnOptionsSingap)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_SINGAP, OnUpdateOptionsSingap)
	ON_COMMAND(ID_TASKS_RID, OnTasksRid)
	ON_UPDATE_COMMAND_UI(ID_TASKS_RID, OnUpdateTasksRid)
	//ON_COMMAND(ID_START, OnStart)
	ON_COMMAND(ID_Parallel, OnStartParallel)
	ON_COMMAND(ID_VIEW_FULLAREA, OnViewFullarea)
	ON_COMMAND(ID_VIEW_NEUTRALISER, OnViewNeutraliser)
	ON_COMMAND(ID_VIEW_RID, OnViewRid)
	ON_COMMAND(ID_TASKS_OTHER, OnTasksOther)
	ON_UPDATE_COMMAND_UI(ID_TASKS_OTHER, OnUpdateTasksOther)
	ON_COMMAND(ID_VIEW_FITONOFF, OnViewFitonoff)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FITONOFF, OnUpdateViewFitonoff)
	ON_COMMAND(ID_VIEW_BEAM, OnViewBeam)
	ON_UPDATE_COMMAND_UI(ID_VIEW_BEAM, OnUpdateViewBeam)
	ON_COMMAND(ID_VIEW_FIELDS, OnViewFields)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FIELDS, OnUpdateViewFields)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FULLAREA, OnUpdateViewFullarea)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NEUTRALISER, OnUpdateViewNeutraliser)
	ON_COMMAND(ID_VIEW_NUMBERING, OnViewNumbering)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NUMBERING, OnUpdateViewNumbering)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RID, OnUpdateViewRid)
	ON_COMMAND(ID_EDIT_COMMENTS, OnEditComments)
	ON_COMMAND(ID_EDIT_TITLE, OnEditTitle)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_STOP, OnStop)
	ON_COMMAND(ID_VIEW_PARTICLES, OnViewParticles)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PARTICLES, OnUpdateViewParticles)
	ON_COMMAND(ID_EDIT_GAS, OnEditGas)
	ON_COMMAND(ID_EDIT_MAGFIELD, OnEditMagfield)
	ON_COMMAND(ID_EDIT_MAGFIELD_7COLUMNS, OnEditMagfield_7columns)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MAGFIELD_7COLUMNS, OnUpdateEditMagfield_7columns)
	ON_COMMAND(ID_EDIT_MAGFIELD_4COLUMNS, OnEditMagfield_4columns)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MAGFIELD_4COLUMNS, OnUpdateEditMagfield_4columns)
	ON_COMMAND(ID_PLOT_SINGAPPOS, OnPlotSingappos)
	ON_UPDATE_COMMAND_UI(ID_PLOT_SINGAPPOS, OnUpdatePlotSingappos)
	ON_COMMAND(ID_PLOT_GASPROFILE, OnPlotGasprofile)
	ON_UPDATE_COMMAND_UI(ID_PLOT_GASPROFILE, OnUpdatePlotGasprofile)
	ON_COMMAND(ID_PLOT_MAGNETICFIELD, OnPlotMagneticfield)
	ON_UPDATE_COMMAND_UI(ID_PLOT_MAGNETICFIELD, OnUpdatePlotMagneticfield)
	ON_COMMAND(ID_PLOT_MAMUGPOSITIONS, OnPlotMamugpositions)
	ON_UPDATE_COMMAND_UI(ID_PLOT_MAMUGPOSITIONS, OnUpdatePlotMamugpositions)
	ON_COMMAND(ID_PLOT_3DLOAD, OnPlot3dload)
	ON_UPDATE_COMMAND_UI(ID_PLOT_3DLOAD, OnUpdatePlot3dload)
	ON_COMMAND(ID_PLOT_BEAMFOOT, OnPlotBeamfoot)
	ON_COMMAND(ID_PLOT_BEAMLETFOOT, OnPlotBeamletfoot)
	ON_COMMAND(ID_PLOT_BEAMLETCURR, OnPlotBeamletcurr)
	ON_COMMAND(ID_PLOT_LOADMAP, OnPlotLoadmap)
	ON_UPDATE_COMMAND_UI(ID_PLOT_LOADMAP, OnUpdatePlotLoadmap)
	ON_COMMAND(ID_PLOT_MAXPROFILES, OnPlotMaxprofiles)
	ON_UPDATE_COMMAND_UI(ID_PLOT_MAXPROFILES, OnUpdatePlotMaxprofiles)
	ON_COMMAND(ID_ASK, OnAsk)
	ON_UPDATE_COMMAND_UI(ID_ASK, OnUpdateAsk)
	ON_COMMAND(ID_OPTIONS_TRACENEUTRALSINPLASMA, OnOptionsTraceneutralsinplasma)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_TRACENEUTRALSINPLASMA, OnUpdateOptionsTraceneutralsinplasma)
	ON_COMMAND(ID_PLOT_NEUTREFFICIENCY, OnPlotNeutrefficiency)
	ON_COMMAND(ID_PLOT_CONTOURS, OnPlotContours)
	ON_UPDATE_COMMAND_UI(ID_PLOT_CONTOURS, OnUpdatePlotContours)
	ON_UPDATE_COMMAND_UI(ID_PLOT_NEUTREFFICIENCY, OnUpdatePlotNeutrefficiency)
	ON_UPDATE_COMMAND_UI(ID_APP_EXIT, OnUpdateAppExit)
	ON_COMMAND(ID_OPTIONS_SURFACES_ADD, OnOptionsSurfacesAdd)
	ON_COMMAND(ID_OPTIONS_BEAM, OnOptionsBeam)
	ON_COMMAND(ID_OPTIONS_FIELDS, OnOptionsFields)
	ON_COMMAND(ID_OPTIONS_NBICONFIG, OnOptionsNBIconfig)
	ON_COMMAND(ID_OPTIONS_SURFACES_ENABLEDISABLEALL, OnOptionsSurfacesEnabledisableall)
	ON_COMMAND(ID_TASKS_BEAMPLASMA, OnTasksBeamplasma)
	ON_COMMAND(ID_PLOT_PENETRATION, OnPlotPenetration)
	ON_COMMAND(ID_DATA_IMPORT_PDPSINGAP, OnDataImport_PDP_SINGAP)
	ON_COMMAND(ID_TASKS_PDPCODE, OnTasksPDP)
	ON_UPDATE_COMMAND_UI(ID_TASKS_PDPCODE, OnUpdateTasksPDP)
	ON_COMMAND(ID_RESULTS_PDPOUTPUT_TABLE, OnResultsPdpoutputTable)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_DATA_IMPORT_SINGAP, OnDataImportSingapBeam)
//	ON_COMMAND(ID_DATA_IMPORT_MAMUGBEAMLETS, OnDataImportMamugBeam)
	ON_COMMAND(ID_PDP_BEAMLETS, OnPdpBeamlets)
	ON_COMMAND(ID_DATA_EXPORT_PDPGEOM, OnDataExportPDPgeom)
	ON_COMMAND(ID_FILE_SEND_MAIL, OnFileSendMail)
	ON_UPDATE_COMMAND_UI(ID_FILE_SEND_MAIL, OnUpdateFileSendMail)
	ON_COMMAND(ID_DATA_EXPORT_REGULARBEAM, OnDataExportRegularBeam)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_PLOT_RE, &CBTRDoc::OnPlotReionPower)
	ON_COMMAND(ID_SURFACES_SORTINCR, &CBTRDoc::OnSurfacesSort)
	ON_UPDATE_COMMAND_UI(ID_PLOT_RE, &CBTRDoc::OnUpdatePlotReionPower)
	ON_UPDATE_COMMAND_UI(ID_PLATE_SELECT, &CBTRDoc::OnUpdatePlateSelect)
	ON_UPDATE_COMMAND_UI(ID_SURFACES_SORTINCR, &CBTRDoc::OnUpdateSurfacesSortincr)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_SURFACES_ADD, &CBTRDoc::OnUpdateOptionsSurfacesAdd)
	ON_COMMAND(ID_PLOT_COMBI, &CBTRDoc::OnPlotCombi)
	ON_COMMAND(ID_PLATE_CLEARSELECT, &CBTRDoc::OnPlateClearSelect)
	ON_COMMAND(ID_EDIT_FW_2D, &CBTRDoc::OnEditFW2D)
	ON_COMMAND(ID_SEND_BTRINPUT, &CBTRDoc::OnSendBtrInput)
	ON_COMMAND(ID_SEND_OTHER, &CBTRDoc::OnSendOther)
	ON_COMMAND(ID_PLASMA_TENE, &CBTRDoc::OnEditPlasmaTeNe)
	ON_COMMAND(ID_BEAMINPLASMA_VERTICALPLANE, &CBTRDoc::OnBeaminplasmaVerticalplane)
	ON_COMMAND(ID_BEAMINPLASMA_HORIZONTALPLANE, &CBTRDoc::OnBeaminplasmaHorizontalplane)
	ON_COMMAND(ID_DATA_SAVEADDSURF, &CBTRDoc::OnDataSaveaddsurf)
	ON_COMMAND(ID_DATA_READADDSURF, &CBTRDoc::OnDataReadaddsurf)
	ON_UPDATE_COMMAND_UI(ID_DATA_SAVEADDSURF, &CBTRDoc::OnUpdateDataSaveaddsurf)
	ON_COMMAND(ID_Plasma_PSI, &CBTRDoc::OnPlasmaPsi)
	ON_UPDATE_COMMAND_UI(ID_TASKS_BEAMPLASMA, &CBTRDoc::OnUpdateTasksBeamplasma)
	ON_UPDATE_COMMAND_UI(ID_PLOT_PENETRATION, &CBTRDoc::OnUpdatePlotPenetration)
	ON_COMMAND(ID_TRACEBIGPARTICLE_ATOM, &CBTRDoc::OnTraceBigAtom)
	ON_COMMAND(ID_TRACEBIGPARTICLE_ION, &CBTRDoc::OnTraceBigIon)
	ON_COMMAND(ID_TRACEBIGPARTICLE_ELECTRON, &CBTRDoc::OnTraceBigElectron)
	ON_COMMAND(ID_OPTIONS_PLASMA, &CBTRDoc::OnOptionsPlasma)
	ON_COMMAND(ID_RESULTS_SAVESUMMARY, &CBTRDoc::OnResultsSavesummary)
	ON_COMMAND(ID_GASPROFILE_X, &CBTRDoc::OnGasProf_X)
	ON_COMMAND(ID_GASPROFILE_X32907, &CBTRDoc::OnGasProf_XZ)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_NBICONFIG, &CBTRDoc::OnUpdateOptionsNbiconfig)
	ON_COMMAND(ID_INPUT_FREE, &CBTRDoc::OnInputFree)
	ON_COMMAND(ID_INPUT_STANDARD, &CBTRDoc::OnInputStandard)
	ON_UPDATE_COMMAND_UI(ID_INPUT_FREE, &CBTRDoc::OnUpdateInputFree)
	ON_UPDATE_COMMAND_UI(ID_INPUT_STANDARD, &CBTRDoc::OnUpdateInputStandard)
	ON_COMMAND(ID_SURFACES_READ, &CBTRDoc::OnSurfacesRead)
	
	ON_COMMAND(ID_OPTIONS_INPUT, &CBTRDoc::OnOptionsInput)
	ON_COMMAND(ID_PLATE_SELECT, &CBTRDoc::OnPlateSelect)
	ON_COMMAND(ID_PLATE_MODIFYSURF, &CBTRDoc::OnPlateModify)
	ON_COMMAND(ID_PLATE_DELETEALLFREE, &CBTRDoc::OnPlateDeleteAllFree)
	ON_COMMAND(ID_PLATE_FILE, &CBTRDoc::OnPlateShowFile)
	ON_COMMAND(ID_PLOT_REION, &CBTRDoc::OnPlotReionization)
	ON_UPDATE_COMMAND_UI(ID_PLOT_REION, &CBTRDoc::OnUpdatePlotReion)
	ON_COMMAND(ID_OPTIONS_THREADS, &CBTRDoc::OnOptionsThreads)
	ON_COMMAND(ID_PD_REIONS, &CBTRDoc::OnPlotSumReionX)
	ON_COMMAND(ID_PD_ATOMS, &CBTRDoc::OnPlotSumAtomX)
	ON_COMMAND(ID_PLOT_ANGULARDISTR, &CBTRDoc::OnPlotAngulardistr)
	ON_UPDATE_COMMAND_UI(ID_PLOT_ANGULARDISTR, &CBTRDoc::OnUpdatePlotAngulardistr)
	ON_COMMAND(ID_NEUTRALIZATION_CURRENTS, &CBTRDoc::OnNeutralizationCurrents)
	ON_COMMAND(ID_NEUTRALIZATION_RATES, &CBTRDoc::OnNeutralizationRates)
		ON_COMMAND(ID_LOG_VIEW, &CBTRDoc::OnLogView)
		ON_COMMAND(ID_LOG_SAVE, &CBTRDoc::OnLogSave)
		ON_COMMAND(ID_STATISTICS_VIEW, &CBTRDoc::OnStatisticsView)
		ON_COMMAND(ID_STATISTICS_SET, &CBTRDoc::OnStatisticsSet)
		ON_COMMAND(ID_SURFACES_MESH, &CBTRDoc::OnSurfacesMesh)
		ON_UPDATE_COMMAND_UI(ID_PLATE_FILE, &CBTRDoc::OnUpdatePlateFile)
		ON_COMMAND(ID_PLATE_LOADOPT, &CBTRDoc::OnPlateLoadOptRecalc)
		ON_COMMAND(ID_EDIT_CROSS, &CBTRDoc::OnEditCrossSect)
		END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBTRDoc construction/destruction

CBTRDoc::CBTRDoc()
{
		AskDlg = new CAskDlg(NULL);
	//	AskDlg->Create();
		EnableAsk = TRUE;
		SetColors();
}

CBTRDoc::~CBTRDoc()
{
	delete AskDlg;
	// dists.~vector();

	// delete BField3D;
	// delete GField;
	delete AddGField;
	delete RIDField;
}

CString  DataString(char * name, double value, int type)
{
	CString S, strval;
	char end = '\n';
	CString eq =  " = ";
	switch (type) {
	case 0: strval.Format("%7d", (int)value); break;
	case 1: strval.Format("%7.1f", value);  break;
	case 2: strval.Format("%12.4e", value);  break;
	} // switch
	S = name + eq + strval + end;
	return S;
}

void CBTRDoc:: ClearData()
{
	if (!DataSection.IsEmpty()) DataSection.RemoveAll();
	//DataSection.FreeExtra();
	if (!DataName.IsEmpty()) DataName.RemoveAll();	
	//DataName.FreeExtra();
	if (!DataComment.IsEmpty()) DataComment.RemoveAll();
	//DataComment.FreeExtra();
}

void CBTRDoc:: InitData()
{
	char buf[1024];
	::GetCurrentDirectory(1024, buf);
	TopDirName.Format("%s", buf);  
	//strcpy(SingapDirName, CurrentDirName);

	// here we detect number of processors present in the system (for unknown purposes)
	SYSTEM_INFO si;
	::GetSystemInfo(&si);
	int num_proc = si.dwNumberOfProcessors;
	ThreadNumber  =  num_proc;
	if (ThreadNumber > 8) ThreadNumber = 8; // set limit

	InitOptions();

//	AppertRadius = 0.007; // m
//	AppertCurrDensity = 203.; //A/m2 D-
	AreaLongMax = 26;//40;
	ReionPercent = 0;
		
	//ClearData();

//	DataSection.Add("SINGAP parameters");
	DataSection.Add("BEAM TRACING");
	DataSection.Add("NBI CONFIGURATION");
	DataSection.Add("TOKAMAK  area");
	DataSection.Add("BEAM ARRAY (regular)");// "MAMuG beam (regular array)");
	DataSectionSize = DataSection.GetSize();
	
//	NofActiveChannels = AddData("Total Number of Active Vert.Channels ", NAME(NofActiveChannels), 4., 0);
//	NofActiveRows = AddData("Total Number of Active Horiz.Rows ", NAME(NofActiveRows), 4., 0);
//	LoadStepX = 0.02; LoadStepY = 0.02;

// ------------- Beam Tracing Options
	int k = 0;
	DataBegin[k] = 0;
	InitBeam();
	DataEnd[k] = DataName.GetUpperBound();

	// NBI
	k++;
	DataBegin[k] = DataName.GetUpperBound()+1;
	
	//if (!OptFree) 
	InitNBI();
	DataEnd[k] = DataName.GetUpperBound();
	
	// Tokamak area
	k++;
	DataBegin[k] = DataName.GetUpperBound()+1;
	//if (!OptFree) 
	InitTokamak(); // Plasma must be called after SetBeam 

	DataEnd[k] = DataName.GetUpperBound();
	
	// MAMuG array
	k++;
	DataBegin[k] = DataName.GetUpperBound()+1;
	InitMamug();
	DataEnd[k] = DataName.GetUpperBound();
	
	MaxDataRead = DataName.GetUpperBound()+1;
	//AdjustAreaLimits();
	CalcLimitXmin = 0;
	CalcLimitXmax = AreaLong + 1;

	InitAddPlates();

	InitSumPower();
	
	SetBeam(); // MAMuG Channels/Beamlets, Aimings/Positions
	for (int i = 0; i < (int)NofChannelsHor; i++) ActiveCh[i] = TRUE;
	for (int j = 0; j < (int)NofChannelsVert; j++) ActiveRow[j] = TRUE;

	InitPlasma(); // must be called after SetBeam!!!

	SetStatus();// numbers of active channels/rows/totbeamlets
	if ((int) BeamSplitType == 0) SetPolarBeamletCommon(); //SetBeamletAt(0);
	else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 

	SetPlates();// calls AdjustAreaLimits();

	FormDataText(FALSE); //without internal names

	//ThreadNumber = 1;//num_proc; //4;

	SetSINGAPfromMAMUG();

	//SetDecayInPlasma();
	
}
void CBTRDoc:: InitOptions()
{
	//OptFree = FALSE;//TRUE; // free config

	STOP = TRUE; 
	TracksCalculated = 0;
	MemFallReserved = FALSE;
	PDPgeomLoaded = FALSE;
	FieldLoaded = FALSE;
	RIDFieldLoaded = FALSE;
	PressureLoaded = FALSE;
	SINGAPLoaded = FALSE;
	NofCalculated = 0;
	DataLoaded = FALSE;
	PressureDim = 0;
	MagFieldDim = 0;

	OptThickNeutralization = FALSE;
	OptReionAccount = FALSE;
	OptReionStop = TRUE;
	OptNeutrStop = TRUE;//FALSE;
	OptReflectRID = FALSE;
	OptTraceAtoms = TRUE;
	
	//OptStrayField = FALSE;
	OptCalOpen = TRUE;
	//OptIonPower = FALSE;
	OptAtomPower = TRUE;
	OptNegIonPower = TRUE;
	OptPosIonPower = TRUE;

	TaskRemnantField = FALSE;
	TaskReionization = FALSE;
	TaskRID = FALSE;
	ThickNeutralization = FALSE;
	LoadSelected = 0;
	ShowProfiles = TRUE;
	SmoothDegree = 0;
	OptDrawPart = TRUE;
	OptSINGAP = FALSE;
	OptIndBeamlets = FALSE;
	OptDeuterium = TRUE;
	OptPDP = FALSE;
	OptParallel = TRUE; //FALSE;
	OptCombiPlot = -1; ///-1 - no load, 0 - map is calculated, >0 - selected but not calculated 
	OptAddPressure = FALSE;
	
	TaskName = "";
	TaskComment = "";

	//MagFileName = "";
	//MF_7 = TRUE;
	GasFileName = "";//"Gas Pressure data";
	MagFieldFileName = "";//"MF data";
	PDPgeomFileName = ""; //"file";
	BeamFileName = "";//"Beam_Bert.TXT";
	FW2DFileName = "";//"Prof.txt"
	pMarkedPlate = &emptyPlate; // was new CPlate(), changed by jacob
	pTorCrossPlate = NULL;
	Progress = 0;
	MaxOptRead = 0;
	MaxDataRead = 0;
	MFcoeff = 0;
	GasCoeff = 0;
	DecilType = 1;
	LevelStep = 1; // MW/m2
	LevelMin = 0;
	LevelMax = 10; // MW/m2
	LevelWrite = FALSE;

	OptCalcNeutralizer = TRUE;
	OptCalcRID = TRUE;
	OptCalcDuct = TRUE;
	OptBeamInPlasma = TRUE;
	
}

void CBTRDoc:: InitBeam()
{
	AddData("Source Beam Current, A", NAME(IonBeamCurrent), IonBeamCurrent = 40, 1);
	AddData("Source Beam Energy, MeV", NAME(IonBeamEnergy), IonBeamEnergy = 1., 1);
	IonBeamPower = IonBeamCurrent * IonBeamEnergy; 
//	IonBeamPower = AddData("Ion Beam Power, MW", NAME(IonBeamPower),  IonPower, 1);
	AddData("Beamlet Radius at GG, m", NAME(BeamRadius), BeamRadius = 0, 1);
	AddData("Beamlet Focus dist from GG, m", NAME(BeamFocusX), BeamFocusX = 0, 1);
	AddData("Beamlet Splitting Type (0 - Polar, 1 - Cartesian)", NAME(BeamSplitType), BeamSplitType = 0, 0);
	AddData("Beamlet Polar Split Number (Polar Splitting)", NAME(PolarNumber), PolarNumber = 10, 0);	
	AddData("Beamlet Azimuth Split Number (Polar Splitting) (>3)", NAME(AzimNumber), AzimNumber = 12, 0); // one aperture
	AddData("Beamlet Hor. Split Number (Cartesian)  (>0)", NAME(BeamSplitNumberY), BeamSplitNumberY = 10, 0);
	AddData("Beamlet Vert. Split Number (Cartesian) (>0)", NAME(BeamSplitNumberZ), BeamSplitNumberZ = 10, 0);
	
//	DecilType = AddData("Beamlet Split Type (0-eq.curr; 1-eq.angle)", NAME(DecilType), 1., 0);	//  0 - equal current  1 - equal angle
//	BeamCoreDiverg = AddData("Beamlet Core Divergence, rad", NAME(BeamCoreDiverg), 0.005, 1);
	AddData("Beamlet Core Horizontal Diverg, rad  (>0)", NAME(BeamCoreDivY), BeamCoreDivY = 0.005, 1);
	AddData("Beamlet Core Vertical Diverg, rad  (>0)", NAME(BeamCoreDivZ), BeamCoreDivZ = 0.005, 1);
	AddData("Beamlet Halo Divergence, rad", NAME(BeamHaloDiverg), BeamHaloDiverg = 0.015, 1);
	AddData("Beamlet Halo Fraction", NAME(BeamHaloPart), BeamHaloPart = 0.15, 1);
	AddData("Beamlet Current Cut-Off ratio (<<1)", NAME(CutOffCurrent), CutOffCurrent = 5.e-2, 2);
	//TStepNeg = AddData("Time-Step for ions D-", NAME(TStepNeg), 2.1E-8, 2);
	//TStepPos = AddData("Time-Step for ions D+", NAME(TStepPos), 2.2E-8, 2);
	//TStepNeu = AddData("Time-Step for atoms Do", NAME(TStepNeu), 2.3E-8, 2);

	PartDimHor = 0; PartDimVert = 0; 
	TracePoints = 1000000;
	TraceOption = 1; // 0-time, 1-length

//	TracePartType = AddData("Source ions Type (0/1/2 for e/H/D)", NAME(TracePartType), 2., 0);
//	TracePartQ = AddData("Source ions Charge", NAME(TracePartQ), -1, 0);
//	TracePartNucl = AddData("Source ions Mass, nucl.", NAME(TracePartNucl), 2., 0);
	AddData("Source ions Trajectory Step, m", NAME(TraceStepL), TraceStepL = 0.1, 1);
//	TraceTimeStep = 1E-8;
	TracePartType = -2; // D-
/*	TracePartQ  = -1;	TracePartNucl = 1;*/
	SetTraceParticle(TracePartType); // -> TraceTimeStep also
	
	AddData("Cross-Section H- -> Ho, m2", NAME(NeutrSigma), NeutrSigma = 1.3e-20, 2);
	AddData("Cross-Section Ho -> H+, m2", NAME(ReionSigma), ReionSigma = 3.2e-21, 2);
	AddData("Cross-Section H- -> H+, m2", NAME(TwoStripSigma), TwoStripSigma = 7.0e-22, 2);
	AddData("Cross-Section H+ -> Ho, m2", NAME(PosExchSigma), PosExchSigma = 3.0e-23, 2);
	AddReionSigma = ReionSigma;

	AddData("Neutralization Start, m", NAME(NeutrXmin), NeutrXmin = 1.6, 1);
	AddData("Neutralization End, m", NAME(NeutrXmax), NeutrXmax = 4.6, 1);
	AddData("Neutralization Step, m", NAME(NeutrStepL), NeutrStepL = 0.5, 1);
	AddData("Neutral fraction (Neutr. Efficiency)", NAME(NeutrPart), NeutrPart = 0.6, 1);
	NeutrPower = IonBeamPower * NeutrPart;
	AddData("Residual Positive Ions fraction", NAME(PosIonPart), PosIonPart = 0.2, 1);
//	NeutrPower = AddData("Neutral power after Neutraliser, MW", NAME(NeutrPower), IonPower*(NeutrPart), 1);
//	InjectedPower = AddData("Injected Neutral Power, MW", NAME(InjectedPower),  0., 1);
	AddData("Re-ionization Start, m", NAME(ReionXmin), ReionXmin = 4.6, 1);
	AddData("Re-ionization End, m", NAME(ReionXmax), ReionXmax = 25, 1);
	AddData("Re-ionization Step, m", NAME(ReionStepL), ReionStepL = 0.1, 1);
	AddData("Reionized/Residual Ions Trajectory Step, m", NAME(IonStepL), IonStepL = 0.05, 1);
	//MinStepL = AddData("Min Step near Surfaces, m", NAME(MinStepL), 0.01, 1);
	IonStepLspec = IonStepL; Xspec0 = 0; Xspec1 = 0;
	ReionStepLspec = ReionStepL; RXspec0 = 0; RXspec1 = 0;

	char * strMisVert;
	char * strVertTilt;
	if (OptFree)
		strMisVert = "Beam Axis Vert.Tilt + Misalign Angle, rad";
	else
		strMisVert = "Beam Axis Vert. Misalign Angle, rad"; // standard
	if (OptFree)
		strVertTilt = "Beam Axis Vert.Inclination Angle, rad";
	else
		strVertTilt = "Beam Axis Vert. Tilting Angle, rad"; // standard
	AddData("Beam Axis Horiz. Misalign Angle, rad", NAME(BeamMisHor), BeamMisHor = 0, 1);
	//BeamMisVert = AddData("Beam Axis Vert. Misalign Angle, rad", NAME(BeamMisVert), 0, 1);
	//BeamVertTilt = AddData("Beam Axis Vert. Tilting Angle, rad", NAME(BeamVertTilt), 0, 1);
	AddData(strMisVert, NAME(BeamMisVert), BeamMisVert = 0, 1);
	AddData(strVertTilt, NAME(BeamVertTilt), BeamVertTilt = 0, 1);

	AddData("Calc. area Length, m", NAME(AreaLong), AreaLong = AreaLongMax, 1);
	AddData("Calc. area Horiz. min, m", NAME(AreaHorMin), AreaHorMin = -1, 1);
	AddData("Calc. area Horiz. max, m", NAME(AreaHorMax), AreaHorMax = 1, 1);
	AddData("Calc. area Bottom, m", NAME(AreaVertMin), AreaVertMin = -1.0, 1);
	AddData("Calc. area Top, m", NAME(AreaVertMax), AreaVertMax = 1.0, 1);
	        
}

void CBTRDoc:: InitNBI() // not active for free config
{
	AddData("NBL Axis Vert. Inclination Angle, rad", NAME(VertInclin), VertInclin = 0, 1);
	AddData("Neutralizer Channels number",  NAME(NeutrChannels), NeutrChannels = 4, 0);//4
	AddData("Neutralizer Entry Coord. X, m",  NAME(NeutrInX), NeutrInX = 1.6, 1);
	AddData("Neutralizer Exit Coord. X, m",  NAME(NeutrOutX), NeutrOutX = 4.6, 1);
	AddData("Neutralizer Height, m",  NAME(NeutrH), NeutrH = 1.7, 1);
	AddData("Neutralizer Channel Entry Width, m",  NAME(NeutrInW), NeutrInW = 0.105, 1);
	AddData("Neutralizer Channel Exit Width, m",  NAME(NeutrOutW), NeutrOutW = 0.095, 1);
	NeutrInW4 = NeutrInW; NeutrOutW4 = NeutrOutW;
	AddData("Neutralizer Panel Entry Thickness, m",  NAME(NeutrInTh), NeutrInTh = 0.04406, 1);
	AddData("Neutralizer Panel Exit Thickness, m",  NAME(NeutrOutTh), NeutrOutTh = 0.03355, 1);
	AddData("Neutralizer Entry Vertical Bias, m",  NAME(NeutrBiasInVert), NeutrBiasInVert = 0, 1);
	AddData("Neutralizer Exit Vertical Bias, m",  NAME(NeutrBiasOutVert), NeutrBiasOutVert = 0, 1);
	AddData("Neutralizer Entry Horizontal Bias, m",  NAME(NeutrBiasInHor), NeutrBiasInHor = 0, 1);
	AddData("Neutralizer Exit Horizontal Bias, m",  NAME(NeutrBiasOutHor), NeutrBiasOutHor = 0, 1);

	AddData("RID Channels number",  NAME(RIDChannels), RIDChannels = 4, 0);//4
	AddData("RID Entry Coord. X, m",  NAME(RIDInX), RIDInX = 5.3, 1);
	AddData("RID Exit Coord. X, m",  NAME(RIDOutX), RIDOutX = 7.1, 1);
	AddData("RID Height, m",  NAME(RIDH), RIDH = 1.7, 1);
	AddData("RID Channel Entry Width, m",  NAME(RIDInW), RIDInW = 0.10376, 1);
	AddData("RID Channel Exit Width, m",  NAME(RIDOutW), RIDOutW = 0.09145, 1);
	RIDInW4 = RIDInW; RIDOutW4 = RIDOutW;
	AddData("RID Panel Thickness, m",  NAME(RIDTh), RIDTh = 0.02, 1);
	AddData("RID Potential, kV",  NAME(RIDU), RIDU = -20, 0);
	AddData("RID Entry Vertical Shift, m",  NAME(RIDBiasInVert), RIDBiasInVert = 0, 1);
	AddData("RID Exit Vertical Shift, m",  NAME(RIDBiasOutVert), RIDBiasOutVert = 0, 1);
	AddData("RID Entry Horizontal Shift, m",  NAME(RIDBiasInHor), RIDBiasInHor = 0, 1);
	AddData("RID Exit Horizontal Shift, m",  NAME(RIDBiasOutHor), RIDBiasOutHor = 0, 1);

	AddData("Calorimeter Entry Coord. X, m",  NAME(CalInX), CalInX = 7.54, 1);
	AddData("Calorimeter Exit Coord. X, m",  NAME(CalOutX), CalOutX = 10.36, 1);
	AddData("Calorimeter Entry Width, m",  NAME(CalInW), CalInW = 0.52, 1);
	AddData("Calorimeter Exit Width, m",  NAME(CalOutW), CalOutW = 0.52, 1);
	AddData("Calorimeter Height, m",  NAME(CalH), CalH = 1.6, 1);

	//Scraper Entry -> Dia 5
	AddData("Dia 5 Dist X, m", NAME(PreDuctX), PreDuctX = 10.8,  1);
	AddData("Dia 5 Width, m", NAME(PreDuctW), PreDuctW = 0.45,  1);
	AddData("Dia 5 Height, m", NAME(PreDuctH), PreDuctH = 1.4,  1);
	AddData("Dia 5 Vertical Shift, m",  NAME(DiaBiasVert), DiaBiasVert = 0, 1);
	AddData("Dia 5 Horizontal Shift, m",  NAME(DiaBiasHor), DiaBiasHor = 0, 1);
	//Scraper Exit -> Dia 6
	AddData("Dia 6 Dist X, m", NAME(DDLinerInX), DDLinerInX = 11.73,  1);
	AddData("Dia 6 Width, m", NAME(DDLinerInW), DDLinerInW = 0.54,  1);
	AddData("Dia 6 Height, m", NAME(DDLinerInH), DDLinerInH = 1.4,  1);
	AddData("Dia 6 Vertical Shift, m",  NAME(LinerBiasInVert), LinerBiasInVert = 0, 1);
	AddData("Dia 6 Horizontal Shift, m",  NAME(LinerBiasInHor), LinerBiasInHor = 0, 1);
	// Duct0 -> Dia 7	
	AddData("Dia 7 Dist X, m", NAME(DDLinerOutX), DDLinerOutX = 12.83,  1);
	AddData("Dia 7 Width, m", NAME(DDLinerOutW), DDLinerOutW = 0.54,  1);
	AddData("Dia 7 Height, m", NAME(DDLinerOutH), DDLinerOutH = 1.1,  1);
	AddData("Dia 7 Vertical Shift, m",  NAME(LinerBiasOutVert), LinerBiasOutVert = 0, 1);
	AddData("Dia 7 Horizontal Shift, m",  NAME(LinerBiasOutHor), LinerBiasOutHor = 0, 1);
	// Duct1 -> Dia 8	
	AddData("Dia 8 Dist X, m ", NAME(Duct1X), Duct1X = 12.85,  1);//12.9
	AddData("Dia 8 Width, m", NAME(Duct1W), Duct1W = 0.56,  1);
	AddData("Dia 8 Height, m", NAME(Duct1H), Duct1H = 1.6,  1);//1.3
	AddData("Dia 8 Vertical Shift, m",  NAME(Duct1BiasVert), Duct1BiasVert = 0, 1);
	AddData("Dia 8 Horizontal Shift, m",  NAME(Duct1BiasHor), Duct1BiasHor = 0, 1);
	// Duct2 -> Dia 9	
	AddData("Dia 9 Dist X, m", NAME(Duct2X), Duct2X = 16.8, 1);//16.9
	AddData("Dia 9 Width, m", NAME(Duct2W), Duct2W = 0.56, 1);
	AddData("Dia 9 Height, m", NAME(Duct2H), Duct2H = 1.6, 1);//1.3
	AddData("Dia 9 Vertical Shift, m",  NAME(Duct2BiasVert), Duct2BiasVert = 0, 1);
	AddData("Dia 9 Horizontal Shift, m",  NAME(Duct2BiasHor), Duct2BiasHor = 0, 1);
	// Duct3 -> Dia 10	
	AddData("Dia 10 Dist X, m", NAME(Duct3X), Duct3X = 16.9,  1);//18.1
	AddData("Dia 10 Width, m", NAME(Duct3W), Duct3W = 0.54,  1);
	AddData("Dia 10 Height, m", NAME(Duct3H), Duct3H = 1.3,  1);//1.12
	AddData("Dia 10 Vertical Shift, m",  NAME(Duct3BiasVert), Duct3BiasVert = 0, 1);
	AddData("Dia 10 Horizontal Shift, m",  NAME(Duct3BiasHor), Duct3BiasHor = 0, 1);
	// Duct4 -> Dia 11	
	AddData("Dia 11 Dist X, m", NAME(Duct4X), Duct4X = 18.0,  1);//20.0
	AddData("Dia 11 Width, m", NAME(Duct4W), Duct4W = 0.54,  1);//0.52
	AddData("Dia 11 Height, m", NAME(Duct4H), Duct4H = 1.12,  1);//1.06
	AddData("Dia 11 Vertical Shift, m",  NAME(Duct4BiasVert), Duct4BiasVert = 0, 1);
	AddData("Dia 11 Horizontal Shift, m",  NAME(Duct4BiasHor), Duct4BiasHor = 0, 1);
	// Duct5 -> Dia 12	
	AddData("Dia 12 Dist X, m", NAME(Duct5X), Duct5X = 20.5, 1);//22.4
	AddData("Dia 12 Width, m", NAME(Duct5W), Duct5W = 0.52, 1);//0.52
	AddData("Dia 12 Height, m", NAME(Duct5H), Duct5H = 1.06, 1);//1.06
	AddData("Dia 12 Vertical Shift, m",  NAME(Duct5BiasVert), Duct5BiasVert = 0, 1);
	AddData("Dia 12 Horizontal Shift, m",  NAME(Duct5BiasHor), Duct5BiasHor = 0, 1);
	// Duct6 -> Dia 13	
	AddData("Dia 13 Dist X, m", NAME(Duct6X), Duct6X = 22.5, 1);//23.0
	AddData("Dia 13 Width, m", NAME(Duct6W), Duct6W = 0.52, 1);//0.52
	AddData("Dia 13 Height, m", NAME(Duct6H), Duct6H = 1.06, 1);
	AddData("Dia 13 Vertical Shift, m",  NAME(Duct6BiasVert), Duct6BiasVert = 0, 1);
	AddData("Dia 13 Horizontal Shift, m",  NAME(Duct6BiasHor), Duct6BiasHor = 0, 1);
	// Duct7 -> Dia 14	
	AddData("Dia 14 Dist X, m", NAME(Duct7X), Duct7X = 23.4, 1);
	AddData("Dia 14 Width, m", NAME(Duct7W), Duct7W = 0.52, 1);
	AddData("Dia 14 Height, m", NAME(Duct7H), Duct7H = 1.06, 1);
	AddData("Dia 14 Vertical Shift, m",  NAME(Duct7BiasVert), Duct7BiasVert = 0, 1);
	AddData("Dia 14 Horizontal Shift, m",  NAME(Duct7BiasHor), Duct7BiasHor = 0, 1);
	// Duct8 -> Dia 15	
	AddData("Dia 15 Dist X, m",   NAME(Duct8X), Duct8X = 25.5, 1);
	AddData("Dia 15 Width, m", NAME(Duct8W), Duct8W = 0.52, 1);
	AddData("Dia 15 Height, m", NAME(Duct8H), Duct8H = 1.08, 1);
	AddData("Dia 15 Vertical Shift, m",  NAME(Duct8BiasVert), Duct8BiasVert = 0, 1);
	AddData("Dia 15  Horizontal Shift, m",  NAME(Duct8BiasHor), Duct8BiasHor = 0, 1);

}

void CBTRDoc::InitTokamak()
{
	AddData("Tokamak Centre X in NBI frame, m", NAME(TorCentreX), TorCentreX = 23, 1);//31.952
	AddData("Tokamak Centre Y in NBI frame, m", NAME(TorCentreY), TorCentreY = -3, 1);//-5.31
	AddData("Tokamak Centre Z in NBI frame, m", NAME(TorCentreZ), TorCentreZ = 0, 1);//-1.443
	AddData("Tokamak Sectors Number", NAME(TorSegmentNumber), TorSegmentNumber = 36, 0);

	// target cross-sections
	AddData("Target Plane A Position X, m", NAME(MovX), MovX = 28.7, 1);
	AddData("Target Plane A Half-Width, m", NAME(MovHor), MovHor = 1.0, 1);
	AddData("Target Plane A Half-Height, m", NAME(MovVert), MovVert = 1.0, 1);
	AddData("Target Plane A Vertical Shift, m", NAME(MovShiftVert), MovShiftVert = 0, 1);

	AddData("Target Plane B Position X, m", NAME(Mov2X), Mov2X = 31.9, 1);
	AddData("Target Plane B Half-Width, m", NAME(Mov2Hor), Mov2Hor = 1.0, 1);
	AddData("Target Plane B Half-Height, m", NAME(Mov2Vert), Mov2Vert = 1.0, 1);
	AddData("Target Plane B Vertical Shift, m", NAME(Mov2ShiftVert), Mov2ShiftVert = 0, 1);

	AddData("Target Plane C Position X, m", NAME(Mov3X), Mov3X = 35.1, 1);
	AddData("Target Plane C Half-Width, m", NAME(Mov3Hor), Mov3Hor = 1.0, 1);
	AddData("Target Plane C Half-Height, m", NAME(Mov3Vert), Mov3Vert = 1.0, 1);
	AddData("Target Plane C Vertical Shift, m", NAME(Mov3ShiftVert), Mov3ShiftVert = 0, 1);

	AddData("Target Plane D Position X, m", NAME(Mov4X), Mov4X = 38.4, 1);
	AddData("Target Plane D Half-Width, m", NAME(Mov4Hor), Mov4Hor = 1.0, 1);
	AddData("Target Plane D Half-Height, m", NAME(Mov4Vert), Mov4Vert = 1.0, 1);
	AddData("Target Plane D Vertical Shift, m", NAME(Mov4ShiftVert), Mov4ShiftVert = 0, 1);
}

void CBTRDoc:: InitPlasma() //------------ BEAM + PLASMA ------------------
{
//	if (!OptBeamInPlasma) return;
	
	TorCentre.X = TorCentreX; //31.952; // horiz distance from GG centre to InjectPoint
	TorCentre.Y = TorCentreY; //- InjectAimR;
	TorCentre.Z = TorCentreZ; //-1.443;// vert distance from GG centre to Tokamak Center line
	FWdataLoaded = FALSE;
	PlasmaLoaded = FALSE;
	PSILoaded = FALSE;
	ProfLoaded = FALSE;

	PlasmaMajorR = 6.2; // ITER default tor R
	PlasmaMinorR = 2.2; // ITER default tor r
	FWRmin = 4.0; FWRmax = 8.4;// ITER
	
	
	if(IonBeamEnergy < 0.8) { //TIN TorCentreX < 25
		PlasmaMajorR = 3.2; // ITER default tor R
		PlasmaMinorR = 1.2; // ITER default tor r
		FWRmin = 2.0; FWRmax = 4.4;
	}

	MaxPlasmaDensity = 1e19; //1e20 TIN; //m-3
	MaxPlasmaTe = 20;//10 TIN; // keV 
	SigmaBase = 1e-20; // m2,  1e-20 - for 250 keV/amu; 3e-20 - for 500 keV/amu
	SigmaEnhancement = 0.01;
	SetPlasmaTarget();
	//SetPlasmaGeom();// set beam-tor geometry, plasma Rminor/Rmajor, Xmin/Xmax - called by SetPlasmaTarget()
	InitFWarray();// FW not loaded yet

	//PlasmaImpurA.RemoveAll();
	//PlasmaImpurW.RemoveAll();

	CSarray.RemoveAll();
	CSarray.Add(C3Point(10, 1.e-15, 0));//E[keV/nu] SigmaStop [cm2]
	CSarray.Add(C3Point(1000, 1.e-17, 0));//E[keV/nu] SigmaStop [cm2]
		
	PlasmaImpurA.SetSize(NofPlasmaImpurMax);
	PlasmaImpurW.SetSize(NofPlasmaImpurMax);
	PlasmaImpurA[0] = 2; // He
	PlasmaImpurA[1] = 3; // Li
	PlasmaImpurA[2] = 4; // Be
	PlasmaImpurA[3] = 5; // B
	PlasmaImpurA[4] = 6; // He
	PlasmaImpurA[5] = 7; // N
	PlasmaImpurA[6] = 8; // O
	PlasmaImpurA[7] = 26; // Fe
	
	NofPlasmaImpur = 0;
	PlasmaWeightH = 1;	PlasmaWeightD = 1; PlasmaWeightT = 1;
	
}

void CBTRDoc:: InitMamug()
{
	AddData("Beam Groups (""Segments""): Total Horiz. Number", NAME(NofChannelsHor), NofChannelsHor = 4, 0); // 4
	AddData("Beam Groups (""Segments""): Total Vert. Number", NAME(NofChannelsVert), NofChannelsVert = 4, 0);//4;
	AddData("Beam Groups (""Segments""): Horiz. Step, m", NAME(SegmStepHor), SegmStepHor = 0.160, 1);
	AddData("Beam Groups (""Segments""): Vert. Step, m", NAME(SegmStepVert), SegmStepVert = 0.396, 1);
	AddData("Beam Groups (""Segments""): Horiz. Aiming Dist, m", NAME(BeamAimHor), BeamAimHor = 25.5, 1); 
	AddData("Beam Groups (""Segments""): Vert. Aiming Dist, m", NAME(BeamAimVert), BeamAimVert = 25.5, 1);
	
	AddData("Beamlets: Horiz. Number per Segment", NAME(NofBeamletsHor), NofBeamletsHor = 5, 0);//5;
	AddData("Beamlets: Vert. Number per Segment", NAME(NofBeamletsVert), NofBeamletsVert = 16, 0);//16;
	AddData("Beamlets: Horiz. Step, m", NAME(AppertStepHor), AppertStepHor = 0.020, 1);
	AddData("Beamlets: Vert. Step, m", NAME(AppertStepVert), AppertStepVert = 0.022, 1);
	AddData("Beamlets: Horiz. Aiming Dist, m", NAME(AppertAimHor), AppertAimHor = 7.1, 1); 
	AddData("Beamlets: Vert. Aiming Dist, m", NAME(AppertAimVert), AppertAimVert = 999, 1);//11.75
	
	NofBeamletsTotal =  (int)((NofBeamletsHor) * (NofBeamletsVert) * (NofChannelsHor) * (NofChannelsVert));
	NofBeamlets = NofBeamletsTotal;
	
}

void CBTRDoc:: InitFWarray()
{
	FWdata.RemoveAll();
	int Nf = 18;
	double df = 2* PI /Nf;
	double r0, R0, dr, Z, fi;
	R0 = PlasmaMajorR;
	r0 = PlasmaMinorR;
	C3Point P;
	for (int i = 0; i <= Nf; i++) {
		fi = i * df;
		dr = r0 * cos(fi);
		Z = r0 * sin(fi);
		P = C3Point(R0 + dr, Z, 0);
		FWdata.Add(P);
	}
}
void CBTRDoc:: InitSumPower()
{
	//AfxMessageBox("InitSumPower");
	int kmax = (int)(AreaLong/SumPowerStepX);
	for (int k = 0; k < kmax; k++) {
		SumReiPowerX.Add(0);
		SumAtomPowerX.Add(1);
	}

	int lmax = (int)(90 / SumPowerAngleStep); // 90 deg
	for (int l = 0; l < lmax; l++) {
		SumPowerAngle.Add(0);
	}
}

void CBTRDoc:: ClearSumPower()
{
	SumReiPowerX.RemoveAll();
	SumAtomPowerX.RemoveAll();
	int kmax = (int)(AreaLong/SumPowerStepX);
	for (int k = 0; k < kmax; k++) {
		SumReiPowerX.Add(0);
		SumAtomPowerX.Add(0);
	}
	SumPowerAngle.RemoveAll();
	int lmax = (int) (90 / SumPowerAngleStep);
	for (int l = 0; l < lmax; l++) {
		SumPowerAngle.Add(0);
	}
}

void CBTRDoc:: InitTaskRID()
{
	AreaLong = RIDOutX + 0.5;//7.4;
	BeamSplitType = 0;
	PolarNumber = 20;
	AzimNumber = 24;
//	BeamSplitNumberY = 10;
//	BeamSplitNumberZ = 10;

	TraceStepL = 0.2;
	IonStepL = 0.01;
	TraceTimeStep = 5.0E-9;
	SetTraceParticle(TracePartType);

	CPlate::DefStepX2 = 0.05;
	CPlate::DefStepY2 = 0.05;
	OptReionAccount = FALSE;
	OptReionStop = FALSE;
	OptNeutrStop = FALSE;
	OptTraceAtoms = FALSE;
	OptReflectRID = TRUE;
	OptCalOpen = FALSE;
	//OptIonPower = TRUE;
	OptNegIonPower = TRUE;
	OptPosIonPower = TRUE;
	OptAtomPower = FALSE;
	
//	RIDField->Set();
	if ((int)BeamSplitType == 0) SetPolarBeamletCommon();//SetBeamletAt(0);
	else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 
//	SetSINGAP();
//	SetStatus();
}

void CBTRDoc:: InitTaskReionization()
{
	AreaLong = ReionXmax; //AreaLongMax;
	PolarNumber = 10;
	AzimNumber = 12;
	BeamSplitNumberY = 10;
	BeamSplitNumberZ = 10;
//	*TStepNeg = 5.E-8;
//	*TStepPos = 1.1E-8;
//	*TStepNeu = 1.E-8;
	CPlate::DefStepX2 = 0.05;
	CPlate::DefStepY2 = 0.05;
	OptReionAccount = TRUE;
	OptReionStop = FALSE;
	OptNeutrStop = TRUE;
	OptTraceAtoms = TRUE;
	OptReflectRID = FALSE;
	//OptIonPower = TRUE;
	//OnOptionsAccountofreionization();// OptReionAccount -> TRUE 
	OnOptionsStopreionizedparticles();// OptReionStop -> FALSE;
	OptCalOpen = TRUE;
	if (CalOutW < 1.e-6) CalOutW = CalInW;
//	for (int i = 0; i < NofChannelsHor; i++) ActiveCh[i] = TRUE; 
//	for (int j = 0; j < NofChannelsVert; j++) ActiveRow[j] = TRUE;
	
//	RIDField->Set();
	if ((int)BeamSplitType == 0) SetPolarBeamletCommon();//SetBeamletAt(0);
	else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 
//	SetSINGAP();
//	SetStatus();
}

void CBTRDoc:: InitTaskTransport()
{
	AreaLong = AreaLongMax;
	PolarNumber = 10;
	AzimNumber = 24;
	BeamSplitNumberY = 60;
	BeamSplitNumberZ = 60;
//	TStepNeg = 1.E-8;
//	TStepPos = 1.1E-8;
//	TStepNeu = 1.2E-8;
	CPlate::DefStepX1 = 0.02;
	CPlate::DefStepY1 = 0.02;
	CPlate::DefStepX2 = 0.05;
	CPlate::DefStepY2 = 0.05;
	OptReionAccount = FALSE;
	OptReionStop = TRUE;
	OptNeutrStop = TRUE;
	OptTraceAtoms = TRUE;
	OptReflectRID = FALSE;
	OptCalOpen = TRUE;
	//OptIonPower = FALSE;
	OptNegIonPower = FALSE;
	OptPosIonPower = FALSE;
	OptAtomPower = TRUE;
	if (CalOutW < 1.e-6) CalOutW = CalInW;
//	for (int i = 0; i < NofChannelsHor; i++) ActiveCh[i] = TRUE; 
//	for (int j = 0; j < NofChannelsVert; j++) ActiveRow[j] = TRUE;
	
//	RIDField->Set();
	if ((int)BeamSplitType ==0) SetPolarBeamletCommon(); //SetBeamletAt(0);
	else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 
//	SetSINGAP();
//	SetStatus();
}

BOOL CBTRDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	SetDocument(this);
	OptStart = 0;
	OptFree = FALSE;
	OptTraceSingle = FALSE;
	CString s;
	int res;
	
	pPlasma = new CPlasma();
	InitData();

	GField.reset(new CGasField());
	AddGField = new CGasField();
	GFieldXZ.reset(new CGasFieldXZ());
	RIDField = new CRIDField();
	BField.reset(new CMagField());
	BField3D.reset(new CMagField3D());
	

	CStartDlg sdlg;
	sdlg.m_Start = OptStart;
	if (sdlg.DoModal() != IDOK) return FALSE;
	OptStart = sdlg.m_Start; // 0 - New; 1 - Results; 2 - Demo

	switch (OptStart) {
	case 0: {// New task
		InputDlg dlg;
		dlg.m_Mode = 0;// standard geom
		if (dlg.DoModal() != IDOK) return FALSE;
		OptFree = (dlg.m_Mode != 0);

		//InitData(); // NBL inclination -> beam tilting

		s.Format("Can you specify the path to Config-file? \n\n (NO will set default configuration)");
		res = AfxMessageBox(s, MB_ICONQUESTION | MB_YESNOCANCEL);
		switch (res) {
		case IDYES:
			if (OnDataGet() == 0)
				SetPlates();
			break;
		case IDNO:
			break;
		case IDCANCEL:
			return FALSE;
		} //switch res

		if (OptFree) { // add surfaces
			BOOL finished = FALSE;
			SetPlates();
			while (!finished) {
				s.Format("Free mode is active\n\n Please specify the path to Surf-file \n\n NO -> add no surf and Continue");
				res = AfxMessageBox(s, MB_ICONQUESTION | MB_YESNOCANCEL);
				switch (res) {
				case IDYES:
					OnDataReadaddsurf();
					break;
				case IDNO:
					finished = TRUE;
					break;
				case IDCANCEL:
					return FALSE;
					break;
				} //switch res
			} // finished to add surf = TRUE
		} // add surf to free config

		break;
			} // New task

	case 1: {// View results
		OnResultsReadall();
		break;
			}
	case 2: break; //if (OptStart == 2) // Demo	AfxMessageBox("DEMO is not ready,\n SORRY"); 
	} // switch OptStart
	return TRUE;
}

void CBTRDoc::AddData(char *  comment, char* name, double& value, int type)
{
	int len, n;

	CString Comment = comment;
	len = Comment.GetLength();
	if (len < 50) {
		n = 50 - len;
		//for (int i = 0; i < n; i++) Comment += "_";
	}			
	DataComment.Add(Comment);

	CString Name = name;
	len = Name.GetLength();
	if (len < 20) {
		n = 20 - len;
		//for (int i = 0; i < n; i++) Name += "_";
	}
	DataName.Add(Name);

	DataType.Add(type);

//	double val = value;
	/*double * pVal = new double;// &value;(double*)&value;//
	*pVal = value;*/
	DataValue.Add(&value);
//	DataValue.Add(&val);
}

void CBTRDoc:: FormDataText(bool fullinfo)// full - for config file, not full - for data view
{
	//AfxMessageBox("FormDataText");
	CString s0, strval, strcomm, strname;
//	int DataN = DataName.GetUpperBound(); 
	
	double value;
	int type;
//	int len;
	CString MFname;
	//if (MF_7) 
	MFname = MagFieldFileName;
	//else MFname = MFManFileName;

	m_Text = "";// .Empty();

	CTime tm = CTime::GetCurrentTime();
	//StartTime = tm;	StopTime = tm;
	CString CurrDate, CurrTime;
	CString Date, Time;
	CurrDate.Format("%02d:%02d:%04d", tm.GetDay(), tm.GetMonth(), tm.GetYear());
	CurrTime.Format("%02d:%02d:%02d", tm.GetHour(), tm.GetMinute(), tm.GetSecond());

	if (!fullinfo) { // on the screen
		if (DataLoaded) {	Date = TaskDate; Time = TaskTime;}
		else { Date = CurrDate; Time = CurrTime;}
	}
	else { // write to file
		Date = CurrDate; Time = CurrTime;
	}

//	s0.Format(" ACTIVE TASK SETTINGS and PARAMETERS (%d + %d) \t DATE %s\t TIME %s \n", MaxOptRead, MaxDataRead, Date, Time);
	s0.Format(" BTR INPUT    date %s\t  time %s \n", Date, Time);
					
/*	s0.Format("\t  ACTIVE TASK SETTINGS and PARAMETERS \t DATE  %02d:%02d:%04d \t TIME  %02d:%02d:%02d \n\n",
					tm.GetDay(), tm.GetMonth(), tm.GetYear(),
					tm.GetHour(), tm.GetMinute(), tm.GetSecond());*/

	m_Text += s0;
	//TaskName += " > " + GetTitle();
	s0.Format(" TITLE: %s\n", TaskName);
	m_Text += s0; //s0.Format(" TITLE:   %s\n", TaskName);
	s0.Format(" COMMENTS:  %s\n", TaskComment); m_Text += s0;
//	s0.Format(" Current Directory:  %s \n", CurrentDirName); 
	m_Text += "-------------------------------------------------\n"; //s0;
	if (OptSINGAP) {
		s0.Format(" Source Beam:  SINGAP /"); m_Text += s0;
		if (OptIndBeamlets) m_Text += " individual optics \n";
		else m_Text += " common optics \n";
	}
	else {
		s0.Format(" Source Beam:  MAMuG \n");
		m_Text += s0;
	}

	s0.Format(" OPTIONS:  \n\t Magnetic Field:"); m_Text += s0;
	    if (FieldLoaded)  s0.Format(" file <%s>-", MFname); 
		else s0.Format(" <%s> NOT LOADED, " , MFname);
		m_Text += s0;
		if (fabs(MFcoeff) > 0) s0.Format(" ON");
		else s0.Format(" OFF");
		m_Text += s0;
		if (FieldLoaded)
		{ 
			s0.Format(" * %g", MFcoeff); 
			m_Text += s0;
		}
		m_Text += "\n";
		
		if (PressureLoaded) s0.Format("\t Gas Profile: file  <%s>\n", GasFileName);
		else s0.Format("\t Gas Profile: <%s> NOT LOADED \n", GasFileName);
		m_Text += s0;
	
		if (FWdataLoaded) s0.Format("\t Tokamak First Wall: file  <%s>\n", FW2DFileName);
		else s0.Format("\t First Wall 2D-profile: <%s> NOT LOADED \n", FW2DFileName);
		m_Text += s0;

		if (PDPgeomLoaded) s0.Format("\t PDP-input: file  <%s>\n", PDPgeomFileName);
		else s0.Format("\t PDP-input: file  <%s> NOT LOADED \n", PDPgeomFileName);
		m_Text += s0;
		
		if (SINGAPLoaded) s0.Format("\t Beamlets: file  <%s>\n", BeamFileName);
		else s0.Format("\t Beamlets: file  <%s> NOT LOADED \n", BeamFileName);
		m_Text += s0;

		s0.Format("\t Source Particle:  ");  m_Text += s0;
		switch (TracePartType) {
		case 0: s0.Format("e \n"); break;
		case 1: s0.Format("H+ \n"); break;
		case 2: s0.Format("D+ \n"); break;
		case -1: s0.Format("H- \n"); break;
		case -2: s0.Format("D- \n"); break;
		case 10: s0.Format("Ho \n"); break;
		case 20: s0.Format("Do \n"); break;
		default:  s0.Format("NOT IDENTIFIED \n"); break;
		}
		m_Text += s0;
		
		if (OptThickNeutralization) s0.Format("\t Neutralization: THICK \n");
		else s0.Format("\t Neutralization: THIN \n");
		m_Text += s0;
		if (OptNeutrStop) s0.Format("\t Residual Ions tracing after Neutralization: OFF \n");
		else s0.Format("\t Residual Ions tracing after Neutralization: ON \n");
		m_Text += s0;
		if (OptTraceAtoms) s0.Format("\t Atoms tracing after Neutralization: ON \n");
		else s0.Format("\t Atoms tracing after Neutralization: OFF \n");
		m_Text += s0;
		if (OptReflectRID) s0.Format("\t Reflected ions tracing in RID: ON \n");
		else s0.Format("\t Reflected ions tracing in RID: OFF \n");
		m_Text += s0;
		if (OptReionAccount) s0.Format("\t Re-ionization: ON - %3.1f %% \n", ReionPercent);
		else s0.Format("\t Re-ionization: OFF \n");
		m_Text += s0;
		if (OptReionStop) s0.Format("\t Re-ionized particles tracing: OFF \n");
		else s0.Format("\t Re-ionized particles tracing: ON \n");
		m_Text += s0;

		/*if (OptIonPower) s0.Format("\t Solid surfaces accept: IONIC power\n");
		else s0.Format("\t Solid Surfaces accept: TOTAL power\n");
		m_Text += s0;*/

				
		s0.Format("\t Active rows :    "); 
		m_Text += s0;
		if (OptSINGAP) { s0.Format("ALL"); m_Text += s0; }
		else
			for (int n = 0; n < (int)NofChannelsVert; n++) {
			s0.Format("   %d", n+1);
			if (ActiveRow[n]) m_Text += s0;
		} // n
		m_Text += "  \n";
		s0.Format("\t Active channels : "); 
		m_Text += s0;
			if (OptSINGAP) { s0.Format("ALL"); m_Text += s0; }
		else
			for (int k = 0; k < (int)NofChannelsHor; k++) {
			s0.Format("   %d", k+1);
			if (ActiveCh[k])  m_Text += s0;
		} // k
		m_Text += "   \n";
		

/*	if (fullinfo)	s0.Format("%-60s\t\t %-20s\t %-15s \n", "PARAMETER", "    NAME", "  VALUE");
	else			s0.Format("%-60s\t\t %-15s \n", "PARAMETER", "  VALUE");
	m_Text += s0;*/

	char end = '\n';
	CString eq =  '='; //"  = ";
	CString div =  '\t';
	CString stars = " .................. ";
//	char buf[1024];
	CString sresult;
//	len = stars.GetLength();
//	stars.Insert(len+1, div);

//	int CommentSize = 70;
//	int NameSize = 20;

	DataLineN.RemoveAll();
	int k = 0;
	for (int sect = 0; sect < 4; sect++) {
		if (OptFree && sect == 1) continue; // skip NBI geometry
		if (!OptBeamInPlasma && sect == 2) continue; // skip tokamak
		
		m_Text += end + stars + DataSection[sect] + stars + end;
	
		int ibegin = DataBegin[sect];
		int iend = DataEnd[sect];

	for (int i = ibegin; i <= iend; i++) {
		type =  DataType[i];
		value = *DataValue[i];
		switch (type) {
//			case -1: {	m_Text += stars + DataComment[i] + stars + end; break;}// Data Section name
			case 0: strval.Format(" %-15d", (int)value); break;
			case 1: strval.Format(" %-15g", value);  break;
			case 2: strval.Format(" %-15.2e", value);  break;
			} // switch

				if (DataName[i].Find("BeamVerTilt") >=0) {
					if (OptFree) DataComment[i] = "Beam Axis Vert. Inclination Angle, rad";
					else DataComment[i] = "Beam Axis Vert. Tilting Angle, rad"; 
				}
				if (DataName[i].Find("BeamMisVert") >=0) {
					if (OptFree) DataComment[i] = "Beam Axis Vert. Tilt + Misalign Angle, rad";
					else DataComment[i] = "Beam Axis Vert. Misalign Angle, rad";
				}
			strcomm.Format("%-50s", DataComment[i]);
			strname.Format("%-20s", DataName[i]);
			//if (fullinfo) 
				sresult = strcomm + div + strname + div  + eq + strval;
			//else sresult = strcomm + div + eq + strval;
	
	/*		strcomm = DataComment[i]; 
			len = strcomm.GetLength(); 
			if (len < CommentSize) 	for (k = len+1; k < CommentSize; k++) strcomm.Insert(k, '.');
			strname = DataName[i]; 
			len = strname.GetLength(); 
		//	if (len < NameSize) for (k = len+1; k < NameSize; k++) strname.Insert(k, '.');
			sresult = strcomm;
			sresult.Insert(81, " =  ");
			sresult.Insert(90, strname);
	*/	
		
		//if (fullinfo)	m_Text += strcomm + div + strname + div  + eq + strval + end;
		//else			m_Text += strcomm + div + eq + strval + end;

		m_Text += sresult + end;
		DataLineN.Add(k);
		k++;

	} // section end
	} // data end
}

int CBTRDoc:: SetData(CString & Line, int i)
{
	int pos = Line.Find("="); // parameters
	if (pos < 1) return 0;

	CString name = DataName[i];//Line.Left(pos);
	CString valstr = Line.Mid(pos+1);
	double Value = atof(valstr);
		
/*	if (!DataLoaded) { // not read from file
			*DataValue[i] = Value;
			return (1);
		}
	
	else // loaded from file
	{*/
		int Nmax = DataName.GetUpperBound();
		for (int k = 0; k <= Nmax; k++) { // search name in data list
				if (Line.Find(DataName[k], 0) >= 0) {
				*DataValue[k] = Value;
				if (DataName[k].Find("BeamVerTilt") >=0) {
					if (OptFree) DataComment[k] = "Beam Axis Vert. Inclination Angle, rad";
					else DataComment[k] = "Beam Axis Vert. Tilting Angle, rad"; 
				}
				if (DataName[k].Find("BeamMisVert") >=0) {
					if (OptFree) DataComment[k] = "Beam Axis Vert. Tilt + Misalign Angle, rad";
					else DataComment[k] = "Beam Axis Vert. Misalign Angle, rad";
				}
				
			//	DataChanged = TRUE;
				return (1);
			} // find
		} // nmax
	//} // else

	return 0;

}


int CBTRDoc:: SetOption(CString & Line)
{
	int pos, pos1, pos2;
	pos = Line.Find(":"); // parameters
	if (pos < 1) return (0);
	CString name = Line.Left(pos);
	CString valstr = Line.Mid(pos+1);

//	for (k = 0; k < NofChannelsHor; k++) ActiveCh[k] = FALSE;
//	for (n = 0; n < NofChannelsVert; n++) ActiveRow[n] = FALSE;

	
//	Line.MakeUpper();
	pos1 = Line.Find("DATE");
	if (pos1 < 0) pos1 = Line.Find("date");
	if (pos1 >=0) { // DATE/TIME
		valstr = Line.Mid(pos1+4);
		valstr.TrimLeft();
		//valstr.TrimRight();
		pos2 = valstr.Find("TIME");
		if (pos2 < 0) pos2 = valstr.Find("time");
		if (pos2 >= 0) {
			TaskDate = valstr.Left(pos2);
			if (TaskDate.GetLength() > 10) TaskDate.SetAt(10,'\0'); 
		    pos2 = Line.Find("TIME");
			if (pos2 < 0) pos2 = Line.Find("time");
			valstr = Line.Mid(pos2+4);
			valstr.TrimLeft();
			valstr.TrimRight();
			TaskTime = valstr;
		}

		return (1);//1
	}
	
	if (name.Find("TITLE") > 0) {
		valstr.TrimLeft();
		TaskName = valstr;
		return(1);//2
	}
	if (name.Find("COMMENT") > 0) {
		valstr.TrimLeft();
		TaskComment = valstr;
		return(1);//3
	}
	if (name.Find("Source") > 0 && name.Find("Beam") > 0) {
		valstr.MakeUpper();
		if (valstr.Find("SINGAP") > 0) OptSINGAP = TRUE;
		else OptSINGAP = FALSE;
		if (OptSINGAP && valstr.Find("INDIVIDUAL") > 0) OptIndBeamlets = TRUE;
		else OptIndBeamlets = FALSE;
		return(1);//4
	}
/*	if (name.Find("Direct") > 0) {
		strcpy(CurrentDirName, valstr);
		::SetCurrentDirectory(CurrentDirName);
		return(1);//5
	}*/
	if (name.Find("First") > 0 || name.Find("Wall") > 0){
		pos1 = valstr.Find("<");
		if (pos1 >= 0) {
			CString filename = valstr.Mid(pos1+1);
			pos2 = filename.Find(">");
			if (pos2>=0) FW2DFileName = filename.Left(pos2);
		}

		return(1);//12
	}
	if (name.Find("Magnetic") > 0) {
		valstr.MakeUpper();
		if (valstr.Find(" ON") > 0) MFcoeff = 1;
		else MFcoeff = 0;
		pos1 = valstr.Find("<");
		if (pos1 >= 0) { // file name
			CString filename = valstr.Mid(pos1+1);
			pos2 = filename.Find(">");
			if (pos2>=0) MagFieldFileName = filename.Left(pos2);
		}
		//MFcoeff = 1;
		pos = valstr.Find("*");
		if (pos > 0) {
			CString s = valstr.Mid(pos+1);
			double Value = atof(s);
			MFcoeff = Value;
		} 
			return(1);//6
		}
	
	if (name.Find("Pressure") > 0 || name.Find("Profile") > 0){
		/*if (valstr.Find("NOT") > 0) PressureLoaded = FALSE;
			else PressureLoaded = TRUE;*/
		pos1 = valstr.Find("<");
		if (pos1 >= 0) {
			CString filename = valstr.Mid(pos1+1);
			pos2 = filename.Find(">");
			if (pos2>=0) GasFileName = filename.Left(pos2);
		}
		return(1);//7
	}

	if (name.Find("PDP") > 0) {
		pos1 = valstr.Find("<");
		if (pos1 >= 0) {
			CString filename = valstr.Mid(pos1+1);
			pos2 = filename.Find(">");
			if (pos2>=0) PDPgeomFileName = filename.Left(pos2);
		}
		return(1);//7
	}

	if (name.Find("Beamlets") > 0) {
		pos1 = valstr.Find("<");
		if (pos1 >= 0) {
			CString filename = valstr.Mid(pos1+1);
			pos2 = filename.Find(">");
			if (pos2>=0) BeamFileName = filename.Left(pos2);
		}
		return(1);//7
	}

	if (name.Find("Source") > -1 && name.Find("Particle") > -1) {
		OptDeuterium  = FALSE; // new data version
		valstr.MakeUpper();
		if (valstr.Find("E") >= 0) TracePartType = 0;
		if (valstr.Find("H-") >= 0) TracePartType = -1;
		if (valstr.Find("H+") >= 0) TracePartType = 1;
		if (valstr.Find("D-") >= 0) {TracePartType = -2; OptDeuterium = TRUE;}
		if (valstr.Find("D+") >= 0) TracePartType = 2; 
		if (valstr.Find("H0") >= 0 || valstr.Find("HO") >= 0) TracePartType = 10;
		if (valstr.Find("D0") >= 0 || valstr.Find("DO") >= 0) TracePartType = 20;
		
	//	else OptDeuterium = TRUE; // old data version
		return(1);//4
	}
	
	if (name.Find("Re-ionization") > -1) {
		valstr.MakeUpper();
		if (valstr.Find("ON") > 0) OptReionAccount = TRUE;
		else OptReionAccount = FALSE;
		return(1);//8
	}
	if (name.Find("Re-ionized") > -1) {
		valstr.MakeUpper();
		if (valstr.Find("OFF") > 0) OptReionStop = TRUE;
		else OptReionStop = FALSE;
		return(1);//9
	}
	if (name.Find("Residual") > -1) {
		valstr.MakeUpper();
		if (valstr.Find("OFF") > -1) OptNeutrStop = TRUE; //AfxMessageBox("Residual STOPPED");}
		else OptNeutrStop = FALSE; //AfxMessageBox("Residual TRACED"); }
		
		return(1);//10
	}
	if (name.Find("Atoms") > -1) {
		valstr.MakeUpper();
		if (valstr.Find("OFF") > 0) OptTraceAtoms = FALSE; //AfxMessageBox("Atoms STOPPED");}
	else OptTraceAtoms = TRUE; //AfxMessageBox("Atoms TRACED"); }
		return(1);//11
	}

	if (name.Find("Neutralization") > -1) {
		valstr.MakeUpper();
		if (valstr.Find("THICK") > 0) OptThickNeutralization = TRUE;
		else OptThickNeutralization = FALSE;
		//AfxMessageBox("Neutralization SET");
		return(1);//8
	}

	if (name.Find("Reflected") > -1) {
		valstr.MakeUpper();
		if (valstr.Find("OFF") > 0) OptReflectRID = FALSE;
		else OptReflectRID = TRUE;
		//AfxMessageBox("Neutralization SET");
		return(1);//8
	}
	/*if (name.Find("Solid") > -1 && name.Find("surfaces") > -1) {
		valstr.MakeUpper();
		if (valstr.Find("IONIC") > 0) OptIonPower = TRUE;
		else OptIonPower = FALSE;
		return(1);//11
	}*/
	

/*	if (name.Find("Calorimeter") > 0) {
		valstr.MakeUpper();
		if (valstr.Find("OPEN") > 0) OptCalOpen = TRUE;
		else OptCalOpen = FALSE;
		return(1);//12
	}
*/	
	if (name.Find("Active rows") > -1) {
		valstr.MakeUpper();
	//	if (!OptSINGAP){
			if (valstr.Find("1") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[0] = TRUE;
			else ActiveRow[0] = FALSE;
			if (valstr.Find("2") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[1] = TRUE;
			else ActiveRow[1] = FALSE;
			if (valstr.Find("3") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[2] = TRUE;
			else ActiveRow[2] = FALSE;
			if (valstr.Find("4") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[3] = TRUE;
			else ActiveRow[3] = FALSE;
			if (valstr.Find("5") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[4] = TRUE;
			else ActiveRow[4] = FALSE;
			if (valstr.Find("6") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[5] = TRUE;
			else ActiveRow[5] = FALSE;
			if (valstr.Find("7") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[6] = TRUE;
			else ActiveRow[6] = FALSE;
			if (valstr.Find("8") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[7] = TRUE;
			else ActiveRow[7] = FALSE;
			if (valstr.Find("9") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[8] = TRUE;
			else ActiveRow[8] = FALSE;
			if (valstr.Find("10") >= 0 || valstr.Find("ALL") >= 0) ActiveRow[9] = TRUE;
			else ActiveRow[9] = FALSE;
	//	}
		return(1); //13
	} // rows

	if (name.Find("Active channels") > 0) {
		valstr.MakeUpper();
//	if (!OptSINGAP){
			if (valstr.Find("1") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[0] = TRUE;
			else ActiveCh[0] = FALSE;
			if (valstr.Find("2") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[1] = TRUE;
			else ActiveCh[1] = FALSE;
			if (valstr.Find("3") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[2] = TRUE;
			else ActiveCh[2] = FALSE;
			if (valstr.Find("4") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[3] = TRUE;
			else ActiveCh[3] = FALSE;
			if (valstr.Find("5") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[4] = TRUE;
			else ActiveCh[4] = FALSE;
			if (valstr.Find("6") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[5] = TRUE;
			else ActiveCh[5] = FALSE;
			if (valstr.Find("7") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[6] = TRUE;
			else ActiveCh[6] = FALSE;
			if (valstr.Find("8") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[7] = TRUE;
			else ActiveCh[7] = FALSE;
			if (valstr.Find("9") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[8] = TRUE;
			else ActiveCh[8] = FALSE;
			if (valstr.Find("10") >= 0 || valstr.Find("ALL") >= 0) ActiveCh[9] = TRUE;
			else ActiveCh[9] = FALSE;
	//	}
		return(1);	//14
	} // channels

	return(0);

}

void CBTRDoc:: UpdateDataArray()
{
//	m_Text.Empty();// = '\0';
	TaskName.Empty();// = "...";
	int k,n;
//	for (k=0; k < NofChannelsHor; k++) ActiveCh[k] = FALSE;
//	for (k=0; k < NofChannelsVert; k++) ActiveRow[k] = FALSE;

	CString text = m_Text; 
	//if (m_Text.Find("NB") >=0 && m_Text.Find("CONFIG") >= 0) OptFree = FALSE;// standard NBI
	//else OptFree = TRUE;

	CString line;
	MaxOptRead = 0;
	MaxDataRead = 0;
	int opt = 0, data = 0;// numbers or successfully read options/data 
	int pos; // current position of symbol \n
	int i = 0; // attempt reading data
	while (text.GetLength() > 0) {
		pos =  text.FindOneOf("\n\0");// text.Find("\n", n);
		if (pos>0) {
			line = text.Left(pos) ;
			if (line.Find("=",0) > 0 && data <= DataName.GetUpperBound()) {
				int res = SetData(line, data);
				if (res > 0) data++;
				i++;
				//maxopt = 12; // options are before parameters
			}
			else if (line.Find(":") > 0 && data == 0)
				opt += SetOption(line);

			text.Delete(0, pos);
		} // pos>0
		else // pos =0
			 text.Delete(0,1);	
		
	} // textLength >0
	MaxOptRead = opt;
	MaxDataRead = data;

/*	for (k=0; k < NofChannelsHor; k++) {
		if (Active[k] == TRUE) Nmax++;
	}*/
	if (MaxOptRead < 2) { //(Nmax==0) {
		for (k=0; k < (int)NofChannelsHor; k++) ActiveCh[k] = TRUE;
		for (n=0; n < (int)NofChannelsVert; n++) ActiveRow[n] = TRUE;
		TaskComment = "Options not found or contain forbidden symbols <=>";
	} 

	//AreaLong = AreaLongMax;
	CheckData();
	
	DataLoaded = TRUE;

}


void CBTRDoc:: CheckData()
{
	CString S, S1;

/*	if (AreaLong > TorCentreX  && !FWdataLoaded) {
		S = FW2DFileName;	S1 = FindFileName(S);
		AfxMessageBox("To do:\n Tokamak First Wall profile should be defined \n\n" + S1);
	}*/
	if (fabs(MFcoeff) > 0 && !FieldLoaded) {
		S = MagFieldFileName; //MFManFileName; //MagFieldFileName;	
		S1 = FindFileName(S);
		//AfxMessageBox("To do:\n MF should be defined \n\n" + S1); 
		MFcoeff = 0;
	}

	if (OptThickNeutralization && (!PressureLoaded || GasCoeff < 1.e-6)) {
		//S = GasFileName;	S1 = FindFileName(S);
		//AfxMessageBox("To do:\n Gas profile should be defined \n (for THICK neutralization)\n\n" + S1); 
		OptThickNeutralization = FALSE;
	}

	if (OptReionAccount && (!PressureLoaded || GasCoeff < 1.e-6)) OptReionAccount = FALSE;

	if (!OptReionAccount && !OptReionStop) OptReionStop = TRUE;
	/*if ((OptReionAccount || !OptReionStop)  && !PressureLoaded) {
		S = GasFileName;	S1 = FindFileName(S);
		//AfxMessageBox("To do:\n Gas profile should be defined \n (for Re-ionization)\n\n" + S1);
		OptReionAccount = FALSE;
		OptReionStop = TRUE;
	}

	if (PressureLoaded && GasCoeff > 1.e-6 && !OptReionStop) OptReionAccount = TRUE;
	*/
	
	if (!OptReionStop && !FieldLoaded) {
		S = MagFieldFileName; //MFManFileName; //	
		S1 = FindFileName(S);
		//AfxMessageBox("To do:\n MF should be defined\n (to trace Re-ionized particles)\n\n" + S1);
		OptReionStop = TRUE;
	}

	if ((int)AzimNumber < 4 && (int)PolarNumber > 0) {
		AfxMessageBox("ErrInput:\n Azimuth Number should be > 3\n Otherwise Polar Splitting Number is set to 0");
		PolarNumber = 0;
	}

	if ((int)BeamSplitNumberY < 1) {
		AfxMessageBox("CErrInput:\n Cartesian Splitting Numbers should be > 0!\n Number is set to 1");
		BeamSplitNumberY = 1;
	}

	if ((int)BeamSplitNumberZ <1) {
		AfxMessageBox("CErrInput:\n Cartesian Splitting Numbers should be > 0!\n Number is set to 1");
		BeamSplitNumberZ = 1;
	}

	if (BeamCoreDivY < 1.e-16) {
		AfxMessageBox("ErrInput:\n Beam Core Divergence should be > 0!\n Value is set to 0.001 rad");
		BeamCoreDivY = 0.001;
	}

	if (BeamCoreDivZ < 1.e-16) {
		AfxMessageBox("ErrInput:\n Beam Core Divergence should be > 0!\n Value is set to 0.001 rad");
		BeamCoreDivZ = 0.001;
	}

	if (!OptThickNeutralization) {// THIN neutralization
	if (NeutrPart >= 1) {
		AfxMessageBox("Neutral fraction = 1\n Positive & Negative Fractions are set to 0");
		NeutrPart = 1; PosIonPart = 0;
	}

	if (NeutrPart < 1 &&  (1.00001 - NeutrPart - PosIonPart < 1.e-10)) {
	//	double posfr = 1 - NeutrPart;
		S.Format("Neutral + Positive fractions > 1!\n Positive Fraction is set to 0\n (Negative Fraction = 1 - Neutral - Positive)");
		AfxMessageBox(S);
		PosIonPart = 0;
	}
	}// THIN neutralization

	if (OptThickNeutralization) {// THICK neutralization
	if (NeutrStepL < IonStepL) {//THICK neutralization
		AfxMessageBox("Ion trajectory step should not exceed Neutralization step");
		IonStepL = NeutrStepL;
	}
	}

	//if (IonStepLspec > IonStepL)	IonStepLspec = IonStepL;

	//if (NeutrXmax > ReionXmin) ReionXmin = NeutrXmax;

/*	if (CalOutW < 1.e-6) OptCalOpen = FALSE;
	else OptCalOpen = TRUE;*/

///////// Beam Groups
	if ((int)NofChannelsHor > 1 && fabs(SegmStepHor) < 1.e-6) {
		S.Format("ErrInput:\n Beam Groups Horizontal Step must be non-zero!");
		AfxMessageBox(S);
	}
	if ((int)NofChannelsHor > 1 && fabs(BeamAimHor) < 1.e-6) {
		S.Format("ErrInput:\n Beam Groups Horizontal Aiming Distance must be non-zero!");
		AfxMessageBox(S);
	}
	if ((int)NofChannelsVert > 1 && fabs(SegmStepVert) < 1.e-6) {
		S.Format("ErrInput:\n Beam Groups Vertical Step must be non-zero!");
		AfxMessageBox(S);
	}
	if ((int)NofChannelsVert > 1 && fabs(BeamAimVert) < 1.e-6) {
		S.Format("ErrInput:\n Beam Groups Vertical Aiming Distance must be non-zero!");
		AfxMessageBox(S);
	}
////////// Beamlets
	if ((int)NofBeamletsHor > 1 && fabs(AppertStepHor) < 1.e-6) {
		S.Format("ErrInput:\n Beamlets Horizontal Step must be non-zero!");
		AfxMessageBox(S);
	}
	if ((int)NofBeamletsHor > 1 && fabs(AppertAimHor) < 1.e-6) {
		S.Format("ErrInput:\n Beamlets Horizontal Aiming Distance must be non-zero!");
		AfxMessageBox(S);
	}
	if ((int)NofBeamletsVert > 1 && fabs(AppertStepVert) < 1.e-6) {
		S.Format("ErrInput:\n Beamlets Vertical Step must be non-zero!");
		AfxMessageBox(S);
	}
	if ((int)NofBeamletsVert > 1 && fabs(AppertAimVert) < 1.e-6) {
		S.Format("ErrInput:\n Beamlets Vertical Aiming Distance must be non-zero!");
		AfxMessageBox(S);
	}

	double Ymin, Ymax, Zmin, Zmax;
	GetBeamFootLimits(AreaLong, Ymin, Ymax, Zmin, Zmax);
/*	
	AreaHorMin = Min(-1.0, Ymin);
	AreaHorMax = Max(1.0, Ymax);
	AreaVertMin = Min(-1.0, Zmin);
	AreaVertMax = Max(1.0, Zmax);
	AreaLong = AreaLongMax;
*/
	
}

void  CBTRDoc::	RotateVert(double angle, double & X,  double & /* Y */,  double & Z)// rotate velocity vector
{
	double alfa = angle, x = X, z = Z;
	//X = x * cos(alfa) + z * sin(alfa);
	//Z = -x * sin(alfa) + z * cos(alfa);
	X = x * cos(alfa) - z * sin(alfa);
	Z = x * sin(alfa) + z * cos(alfa);
	return;
}

void  CBTRDoc::	RotateHor(double angle, double & X,  double & Y,  double & /* Z */)// rotate velocity vector
{
	double  x = X, y = Y;
	double alfa = angle;
	//X = x * cos(alfa) + y * sin(alfa);
	//Y = -x * sin(alfa) + y * cos(alfa);
	X = x * cos(alfa) - y * sin(alfa);
	Y = x * sin(alfa) + y * cos(alfa);
	return;
}

C3Point  CBTRDoc:: CentralCS(C3Point  P0, int segmHor, int segmVert) //returns appert pos in Central CS
{
	//P0 - in local (segment) CS
	C3Point P, Centre;
	Centre.X = 0;
	Centre.Y =  SegmCentreHor[segmHor]; 
	Centre.Z =  SegmCentreVert[segmVert];
	P = P0 + Centre;
	return P;
}

C3Point  CBTRDoc:: LocalCS(C3Point  P0, int channel)
{
	if (channel == 0) return P0;
	C3Point P = P0;
/*	double alfa = channel * PI* (*AimBeam) /180.;
	double X0 = *SideIScentreX;
	double Y0 = (*AimDistX - *SideIScentreX)*tan(alfa);
	P.X = (P0.X - X0) * cos(alfa) - (P0.Y-Y0) * sin(alfa);
	P.Y =  (P0.X - X0) * sin(alfa) + (P0.Y-Y0) * cos(alfa);
	P.Z = P0.Z;*/
	return P;
}

void  CBTRDoc::SetTraceParticle(int nucl, int q) // 0:e, 1:H+, 2:D+, -1:H-, -2:D-, 10:H0, 20:H0
{
	switch (nucl) { // 0(e), 1(H-), 2(D-)
	case 0: SetTraceParticle(0); break;
	case 1: 
		switch (q) {
		case 0: SetTraceParticle(10); break; // Ho
		case 1: SetTraceParticle(1); break; // H+
		case -1: SetTraceParticle(-1); break; // H-
		default: SetTraceParticle(-1); break; // H-
		}
		break;
	case 2: 
		switch (q) {
		case 0: SetTraceParticle(20); break; // Do
		case 1: SetTraceParticle(2); break; // D+
		case -1: SetTraceParticle(-2); break; // D-
		default: SetTraceParticle(-2); break; // D-
		}
		break;
	}
}


void  CBTRDoc::SetTraceParticle(int type) // 0:e, 1:H+, 2:D+, -1:H-, -2:D-, 10:H0, 20:H0
{
	switch (type) { // 0(e), 1(H-), 2(D-)
	case 0:	// electron
			TracePartType = type;
			TracePartMass = Me;
			TracePartQ = -1; 
			TracePartNucl = 0;
			break;
	
	case 1:	// H+
			TracePartType = type; 
			TracePartMass = Mp;
			TracePartNucl = 1;
			TracePartQ = 1;
			break;
	case 2: // D+
			TracePartType = type; 
			TracePartMass = Mp * 2;
			TracePartNucl = 2;
			TracePartQ = 1;
			break;

	case -1:// H-
			TracePartType = type; 
			TracePartMass = Mp;
			TracePartNucl = 1;
			TracePartQ = -1;
			break;
	case -2: // D-
			TracePartType = type; 
			TracePartMass = Mp * 2;
			TracePartNucl = 2;
			TracePartQ = -1;
			break;

	case 10: // H0
			TracePartType = type; 
			TracePartMass = Mp;
			TracePartNucl = 1;
			TracePartQ = 0;
			break;

	case 20: // D0
			TracePartType = type; 
			TracePartMass = Mp * 2;
			TracePartNucl = 2;
			TracePartQ = 0;
			break;

	default: // H+ //any ion Z+ or Z-
			TracePartType = type; 
			TracePartMass = Mp;
			TracePartNucl = 1;
			TracePartQ = 1;
			break;
				
	}


	double EeV = IonBeamEnergy * 1000000;
	
	double V;
	if (type == 0) V = RelV(IonBeamEnergy); // MeV // electron
	else 	V = sqrt(2.* EeV * Qe / TracePartMass); // {m/c}
	
	if (TraceOption == 0) TraceStepL = TraceTimeStep * V;
	else  TraceTimeStep = TraceStepL / V;
					 
}

void CBTRDoc::SetStatus() // numbers of active channels/rows/ totbeamlets / tot particles to trace
{
	int N; // apertures per one Segm
	
	if (OptSINGAP) {
		NofBeamlets = BeamEntry_Array.GetSize(); 
		NofActiveChannels = (int)NofChannelsHor;
		NofActiveRows = (int)NofChannelsVert;
	}
	
	else {// MAMuG
		
		N = (int)NofBeamletsHor * (int)NofBeamletsVert;
		NofActiveChannels = 0;
		NofActiveRows = 0;
	
	for (int k = 0; k < (int)NofChannelsHor; k++) 
		if (ActiveCh[k]) NofActiveChannels += 1;
	for (int n = 0; n < (int)NofChannelsVert; n++) 
		if (ActiveRow[n]) NofActiveRows += 1;

		//NofBeamlets = N *(NofActiveChannels)*(NofActiveRows); // * NofChannelsVert;

		if (!SINGAPLoaded) SetSINGAPfromMAMUG();//NofBeamlets = BeamEntry_Array.GetSize(); 
	
	} // MAMuG

//	if (NofBeamlets > 0) InitTracers();
	MultCoeff = 1;
	int Kneutr = 0, Kpos = 0, Kreion = 0; // new born
	if (!OptNeutrStop) {// Ions are traced in RID
		if (OptThickNeutralization) { 
			Kneutr = NeutrArray.GetSize();
			Kpos = Kneutr;
		}
		else { Kneutr = 1; Kpos = 1; } // THIN
	} // Ions are traced in RID
	else { // residual ions are stopped
		Kpos = 0;
		if (OptThickNeutralization) Kneutr = NeutrArray.GetSize();
		else Kneutr = 1; // THIN
	}

	if (!OptReionStop)  // Reions are traced
		Kreion = ReionArray.GetSize();
	else Kreion = 0;

	if (TracePartQ == 0) 	MultCoeff = 1 + Kreion;
	else MultCoeff = 1 + Kneutr + Kpos + Kneutr * Kreion;
	
	//NofCalculated = 0;

	GetMemState();

}

bool CBTRDoc::SelectPlate(CPlate* plate)
{
	bool flag;
	plate->Selected = TRUE; // !(plate->Selected);
	//plate->Loaded = !(plate->Loaded); // Mark / Unmark for Load
	flag = TRUE; // plate->Selected;
		
	SetNullLoad(plate);//plate->ApplyLoad(flag, 0,0); // *LoadStepX, *LoadStepY);
	SetLoadArray(plate, flag);
	
	return flag;
} 

bool CBTRDoc:: SelectPlate(CPlate* plate, double hx, double hy)
{
	bool flag;
	plate->Selected = TRUE;
	//plate->Loaded = TRUE;//!(plate->Loaded); // Mark / Unmark for Load
	flag = plate->Selected; //Loaded;
	//plate->Touched = FALSE;
	plate->ApplyLoad(flag, hx,hy); // *LoadStepX, *LoadStepY);
	SetLoadArray(plate, flag);

	return flag;
}

void CBTRDoc:: SetAreaMinMax()
{
	AbsHorMin = Min(AreaHorMin, -(NeutrInW + NeutrInTh) * NeutrChannels);
	AbsHorMax = Max(AreaHorMax, (NeutrInW + NeutrInTh) * NeutrChannels);
	AbsVertMin = Min(AreaVertMin, - NeutrH * 0.5);
	AbsVertMax = Max(AreaVertMax, NeutrH * 0.5);

	AbsHorMin = Min(AbsHorMin, -(RIDInW + RIDTh) * RIDChannels);
	AbsHorMax = Max(AbsHorMax,  (RIDInW + RIDTh) * RIDChannels);
	AbsVertMin = Min(AbsVertMin, - RIDH * 0.5);
	AbsVertMax = Max(AbsVertMax, RIDH * 0.5);

	AbsHorMin = Min(AbsHorMin, -CalInW * 0.5);
	AbsHorMax = Max(AbsHorMax,  CalInW * 0.5);
	AbsVertMin = Min(AbsVertMin, -CalH * 0.5);
	AbsVertMax = Max(AbsVertMax,  CalH * 0.5);

	AbsHorMin = Min(AbsHorMin, -DDLinerInW * 0.5);
	AbsHorMax = Max(AbsHorMax,  DDLinerInW * 0.5);
	AbsVertMin = Min(AbsVertMin, -DDLinerInH * 0.5);
	AbsVertMax = Max(AbsVertMax,  DDLinerInH * 0.5);

	AbsHorMin = Min(AbsHorMin, -DDLinerOutW * 0.5);
	AbsHorMax = Max(AbsHorMax,  DDLinerOutW * 0.5);
	AbsVertMin = Min(AbsVertMin, -DDLinerOutH * 0.5);
	AbsVertMax = Max(AbsVertMax,  DDLinerOutH * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct1W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct1W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct1H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct1H * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct2W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct2W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct2H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct2H * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct3W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct3W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct3H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct3H * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct4W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct4W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct4H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct4H * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct5W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct5W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct5H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct5H * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct6W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct6W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct6H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct6H * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct7W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct7W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct7H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct7H * 0.5);

	AbsHorMin = Min(AbsHorMin, -Duct8W * 0.5);
	AbsHorMax = Max(AbsHorMax,  Duct8W * 0.5);
	AbsVertMin = Min(AbsVertMin, -Duct8H * 0.5);
	AbsVertMax = Max(AbsVertMax,  Duct8H * 0.5);

	//AbsHorMax = Max(AbsHorMax,  FWRmax + TorCentre.Y);
	
}

void CBTRDoc:: AdjustAreaLimits()
{
/*	AreaHorMin = -0.6;
	AreaHorMax = 0.6;
	AreaVertMin = -1;
	AreaVertMax = 1;
*/
	double VertMin = AreaVertMin;
	double VertMax = AreaVertMax;
	// double HorMin = AreaHorMin;
	// double HorMax = AreaHorMax;


	double VInclin = 0;
	if (!OptFree) VInclin = VertInclin;
	//double TotVertAngle = BeamMisVert + VInclin + BeamVertTilt;
	//double VertShift = tan(TotVertAngle) * AreaLong;
	//if (VertShift > AreaVertMax * 0.7) VertMax += VertShift; 
	//if (VertShift < AreaVertMin * 0.7) VertMin += VertShift; 
	AreaVertMin = Min(VertMin, AreaVertMin);
	AreaVertMax = Max(VertMax, AreaVertMax);

	double BeamMaxHor = NofChannelsHor * SegmSizeHor * 0.7;
	double BeamMaxVert = NofChannelsVert * SegmSizeVert * 0.7;

	AreaHorMin = Min(AreaHorMin, -BeamMaxHor);
	AreaHorMax = Max(AreaHorMax, BeamMaxHor);
	AreaVertMin = Min(AreaVertMin, -BeamMaxVert);
	AreaVertMax = Max(AreaVertMax, BeamMaxVert);

	if (!OptFree) SetAreaMinMax();
	
	AreaHorMin = Min(AreaHorMin, AbsHorMin);
	AreaHorMax = Max(AreaHorMax, AbsHorMax);
	AreaVertMin = Min(AreaVertMin, AbsVertMin);
	AreaVertMax = Max(AreaVertMax, AbsVertMax);

	AreaLong = Max(AreaLong, Duct5X); 
	AreaLong = Max(AreaLong, Duct6X); 
	AreaLong = Max(AreaLong, Duct7X); 
	AreaLong = Max(AreaLong, Duct8X); 
	AreaLong += 0.5;

	CalcLimitXmin = 0;
	CalcLimitXmax = AreaLong + 1;
	
}

void CBTRDoc:: SetChannelWidth()
{
	int N = (int)NeutrChannels;
	double Wmin = 0.01; // min width
	switch (N) {
	case 0: NeutrChannels = 1; // 1 channel
		//NeutrInW = 4 * NeutrInW4 + 3 *(NeutrInTh); //NeutrOutW = 4 * NeutrOutW4 + 3 *(NeutrOutTh);
		NeutrInW = SegmSizeHor + NeutrOutTh;
		NeutrOutW = NeutrInW;
		if ((int)NofChannelsHor > 1) { 
			NeutrInW = NofChannelsHor * SegmStepHor * (BeamAimHor - NeutrInX) / BeamAimHor; 
			NeutrOutW = NofChannelsHor * SegmStepHor * (BeamAimHor - NeutrOutX) / BeamAimHor; 
		}
		if (NeutrInW < Wmin) NeutrInW = Wmin;
		if (NeutrOutW < Wmin) NeutrOutW = Wmin;
		break; 
	case 1: // 1 channel
		//NeutrInW = 4 * NeutrInW4 + 3 *(NeutrInTh);//NeutrOutW = 4 * NeutrOutW4 + 3 *(NeutrOutTh);
		NeutrInW = SegmSizeHor + NeutrOutTh;
		NeutrOutW = NeutrInW;
		if ((int)NofChannelsHor > 1) { 
			NeutrInW = NofChannelsHor * SegmStepHor * (BeamAimHor - NeutrInX) / BeamAimHor; 
			NeutrOutW = NofChannelsHor * SegmStepHor * (BeamAimHor - NeutrOutX) / BeamAimHor; 
		}
		if (NeutrInW < Wmin) NeutrInW = Wmin;
		if (NeutrOutW < Wmin) NeutrOutW = Wmin;
	
		break; 
	case 2: // 2 channels
		//NeutrInW = 2 * NeutrInW4 + (NeutrInTh); //NeutrOutW = 2 * NeutrOutW4 + (NeutrOutTh); 
		NeutrInW = SegmStepHor * (BeamAimHor - NeutrInX) / BeamAimHor - NeutrInTh;
		NeutrOutW = SegmStepHor * (BeamAimHor - NeutrOutX) / BeamAimHor - NeutrOutTh;
		if ((int)NofChannelsHor == 4) { 
			NeutrInW = 2 * SegmStepHor * (BeamAimHor - NeutrInX) / BeamAimHor - NeutrInTh; 
			NeutrOutW = 2 * SegmStepHor * (BeamAimHor - NeutrOutX) / BeamAimHor - NeutrOutTh; 
		}
		if (NeutrInW < Wmin) NeutrInW = Wmin;
		if (NeutrOutW < Wmin) NeutrOutW = Wmin;
		break; 
	case 3: // 3 channels
		//NeutrInW = 1.5 * NeutrInW4 + (NeutrInTh); //NeutrOutW = 1.5 * NeutrOutW4 + (NeutrOutTh); 
		NeutrInW = SegmStepHor * (BeamAimHor - NeutrInX) / BeamAimHor - NeutrInTh;
		NeutrOutW = SegmStepHor * (BeamAimHor - NeutrOutX) / BeamAimHor - NeutrOutTh;
		if (NeutrInW < Wmin) NeutrInW = Wmin;
		if (NeutrOutW < Wmin) NeutrOutW = Wmin;
		break; 
	case 4: 
		//NeutrInW = NeutrInW4; //NeutrOutW = NeutrOutW4; 
		NeutrInW = (SegmStepHor) * (BeamAimHor - NeutrInX) / (BeamAimHor) - NeutrInTh;
		NeutrOutW = (SegmStepHor ) * (BeamAimHor - NeutrOutX) / (BeamAimHor) - NeutrOutTh;
		if (NeutrInW < Wmin) NeutrInW = Wmin;
		if (NeutrOutW < Wmin) NeutrOutW = Wmin;
		break;
	default: 
		NeutrInW = (SegmStepHor) * (BeamAimHor - NeutrInX) / (BeamAimHor) - NeutrInTh;
		NeutrOutW = (SegmStepHor) * (BeamAimHor - NeutrOutX) / (BeamAimHor) - NeutrOutTh;
		if (NeutrInW < Wmin) NeutrInW = Wmin;
		if (NeutrOutW < Wmin) NeutrOutW = Wmin;
		//NeutrInW = NeutrInW4; NeutrOutW = NeutrOutW4; 
		break;
	}

	int R = (int)RIDChannels;
	switch (R) {
	case 0: RIDChannels = 1; // 1 channel
		//RIDInW = 4 * RIDInW4 + 3 *(RIDInTh); //RIDOutW = 4 * RIDOutW4 + 3 *(RIDOutTh);
		RIDInW = SegmSizeHor + RIDTh;
		RIDOutW = RIDInW;
		if ((int)NofChannelsHor > 1) { 
			RIDInW = (NofChannelsHor) * (SegmStepHor) * (BeamAimHor - RIDInX) / (BeamAimHor); 
			RIDOutW = (NofChannelsHor) * (SegmStepHor) * (BeamAimHor - RIDOutX) / (BeamAimHor); 
		}
		if (RIDInW < Wmin) RIDInW = Wmin;
		if (RIDOutW < Wmin) RIDOutW = Wmin;
		break; 
	case 1: // 1 channel
		//RIDInW = 4 * RIDInW4 + 3 *(RIDInTh);//RIDOutW = 4 * RIDOutW4 + 3 *(RIDOutTh);
		RIDInW = SegmSizeHor + RIDTh;
		RIDOutW = RIDInW;
		if ((int)NofChannelsHor > 1) { 
			RIDInW = (NofChannelsHor) * (SegmStepHor) * (BeamAimHor - RIDInX) / (BeamAimHor); 
			RIDOutW = (NofChannelsHor) * (SegmStepHor) * (BeamAimHor - RIDOutX) / (BeamAimHor); 
		}
		if (RIDInW < Wmin) RIDInW = Wmin;
		if (RIDOutW < Wmin) RIDOutW = Wmin;
		break; 
	case 2: // 2 channels
		//RIDInW = 2 * RIDInW4 + (RIDInTh); //RIDOutW = 2 * RIDOutW4 + (RIDOutTh); 
		RIDInW = (SegmStepHor) * (BeamAimHor - RIDInX) / (BeamAimHor) - RIDTh;
		RIDOutW = (SegmStepHor) * (BeamAimHor - RIDOutX) / (BeamAimHor) - RIDTh;
		if ((int)NofChannelsHor == 4) { 
			RIDInW = 2 * (SegmStepHor) * (BeamAimHor - RIDInX) / (BeamAimHor) - RIDTh; 
			RIDOutW = 2 * (SegmStepHor) * (BeamAimHor - RIDOutX) / (BeamAimHor) - RIDTh; 
		}
		if (RIDInW < Wmin) RIDInW = Wmin;
		if (RIDOutW < Wmin) RIDOutW = Wmin;
		break; 
	case 3: // 3 channels
		//RIDInW = 1.5 * RIDInW4 + (RIDInTh); //RIDOutW = 1.5 * RIDOutW4 + (RIDOutTh); 
		RIDInW = (SegmStepHor) * (BeamAimHor - RIDInX) / (BeamAimHor) - RIDTh;
		RIDOutW = (SegmStepHor) * (BeamAimHor - RIDOutX) / (BeamAimHor) - RIDTh;
		if (RIDInW < Wmin) RIDInW = Wmin;
		if (RIDOutW < Wmin) RIDOutW = Wmin;
		break; 
	case 4: 
		//RIDInW = RIDInW4; //RIDOutW = RIDOutW4; 
		RIDInW = (SegmStepHor) * (BeamAimHor - RIDInX) / (BeamAimHor) - RIDTh;
		RIDOutW = (SegmStepHor) * (BeamAimHor - RIDOutX) / (BeamAimHor) - RIDTh;
		if (RIDInW < Wmin) RIDInW = Wmin;
		if (RIDOutW < Wmin) RIDOutW = Wmin;
		break;
	default: 
		RIDInW = (SegmStepHor) * (BeamAimHor - RIDInX) / (BeamAimHor) - RIDTh;
		RIDOutW = (SegmStepHor) * (BeamAimHor - RIDOutX) / (BeamAimHor) - RIDTh;
		if (RIDInW < Wmin) RIDInW = Wmin;
		if (RIDOutW < Wmin) RIDOutW = Wmin;
		//RIDInW = RIDInW4; RIDOutW = RIDOutW4; 
		break;
	}


}

void  CBTRDoc::SetPlatesNeutraliser()// -------------  NEUTRALIZER -------------------------------
{
	CString S;
	CPlate * pPlate;
	
	C3Point p0_, p1_, p2_, p3_; // in local CS of Side Channel
	C3Point p0, p1, p2, p3; // in Central Channel CS
	int N = (int)NeutrChannels; // vert channels
	double StepIn = NeutrInW + NeutrInTh; // inlet step between adjacent channels axes (= between panels)
	double StepOut = NeutrOutW + NeutrOutTh;// outlet step between adjacent channels axes
	double YminIn = - StepIn * N * 0.5; // right-most panel Y  
	double YminOut = - StepOut * N * 0.5;// right-most panel Y  
	double Yin, Yout;

	/* pPlate = new CPlate(); // Source exit 
	 p0 = C3Point(0.5, YminIn - 0.1, -NeutrH * 0.5 - 0.1);
	 p3 = C3Point(0.5, -YminIn + 0.1,  NeutrH * 0.5 + 0.1);
	 pPlate->SetFromLimits(p0, p3); 
	 pPlate->Shift(0, NeutrBiasInHor, VShiftNeutr + NeutrBiasInVert);
	// pPlate->ShiftVert(VShiftNeutr + NeutrVBiasIn, VShiftNeutr + NeutrVBiasOut);
	 pPlate->Solid = FALSE;
	 pPlate->Visible = FALSE;
	 S.Format("Source Exit plane X = %g m", 0.5);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);
	 if (TaskRID)  SelectPlate(pPlate);*/

	 pPlate = new CPlate(); // Entry 
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(NeutrInX - 0.2, YminIn - 0.1, -NeutrH * 0.5 - 0.1);
	 p3 = C3Point(NeutrInX - 0.2, -YminIn + 0.1,  NeutrH * 0.5 + 0.1);
	 pPlate->OrtDirect = -1;
	 pPlate->SetFromLimits(p0, p3); 
	 pPlate->Shift(0, NeutrBiasInHor, VShiftNeutr + NeutrBiasInVert);
	// pPlate->ShiftVert(VShiftNeutr + NeutrVBiasIn, VShiftNeutr + NeutrVBiasOut);
	 pPlate->Solid = FALSE;
	 pPlate->Visible = FALSE;
	 S.Format("NEUTRALIZER Entry plane X = %g m", NeutrInX - 0.2);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);
	// if (TaskRID) SelectPlate(pPlate);
	
	 pPlate = new CPlate(); // Exit 
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(NeutrOutX + 0.2, YminOut - 0.1, -NeutrH * 0.5 - 0.1);
	 p3 = C3Point(NeutrOutX + 0.2, -YminOut + 0.1,  NeutrH * 0.5 + 0.1);
	 pPlate->OrtDirect = -1;
	 pPlate->SetFromLimits(p0, p3); 
	 pPlate->Shift(0, NeutrBiasOutHor, VShiftNeutr + NeutrBiasOutVert);
	// pPlate->ShiftVert(VShiftNeutr + NeutrVBiasIn, VShiftNeutr + NeutrVBiasOut);
	 pPlate->Solid = FALSE;
	 pPlate->Visible = FALSE;
	 S.Format("NEUTRALIZER Exit plane X = %g m", NeutrOutX + 0.2);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);
	// if (TaskRID)  SelectPlate(pPlate);

	 int i;
	 for (i = 0; i <= N; i++) {
		 Yin = YminIn + i*StepIn;
		 Yout = YminOut + i*StepOut;
	 pPlate = new CPlate(); //  In 
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(NeutrInX, Yin - NeutrInTh *0.5  , -NeutrH * 0.5 );
	 p1 = C3Point(NeutrInX, Yin + NeutrInTh *0.5  , -NeutrH * 0.5 );
	 p2 = C3Point(NeutrInX, Yin - NeutrInTh *0.5  , NeutrH * 0.5 );
	 p3 = C3Point(NeutrInX, Yin + NeutrInTh *0.5  , NeutrH * 0.5 );
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3); //pPlate->SetFromLimits(p0, p3);
	 //pPlate->ShiftVert(VShiftNeutr + NeutrVBiasIn, VShiftNeutr + NeutrVBiasOut);
	 pPlate->Shift(0, NeutrBiasInHor, VShiftNeutr + NeutrBiasInVert);
	 //pPlate->Shift(0,0, VShiftNeutr);
	 S.Format("NEUTRALIZER: Leading Edge of panel %d", i+1);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);
 	
 	 pPlate = new CPlate(); // right
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(NeutrInX,  Yin - NeutrInTh *0.5  , -NeutrH * 0.5 );
	 p1 = C3Point(NeutrOutX, Yout - NeutrOutTh *0.5  , -NeutrH * 0.5 );
	 p2 = C3Point(NeutrInX,  Yin - NeutrInTh *0.5  , NeutrH * 0.5 );
	 p3 = C3Point(NeutrOutX, Yout -NeutrOutTh *0.5, NeutrH * 0.5 );
	 pPlate->SetLocals(p0, p1, p2, p3);
	 //pPlate->Shift(0, NeutrHBias, VShiftNeutr + NeutrVBias);
	 //pPlate->Shift(0,0, VShiftNeutr);
	 pPlate->ShiftVert(VShiftNeutr + NeutrBiasInVert, VShiftNeutr + NeutrBiasOutVert);
	 pPlate->ShiftHor(NeutrBiasInHor,  NeutrBiasOutHor);
	 S.Format("NEUTRALIZER: left wall of channel %d", i);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);
	
	 pPlate = new CPlate(); // left
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(NeutrInX,  Yin +NeutrInTh *0.5  , -NeutrH * 0.5 );
	 p1 = C3Point(NeutrOutX,  Yout +NeutrOutTh *0.5  , -NeutrH * 0.5 );
	 p2 = C3Point(NeutrInX,  Yin +NeutrInTh *0.5  , NeutrH * 0.5 );
	 p3 = C3Point(NeutrOutX,  Yout +NeutrOutTh *0.5  , NeutrH * 0.5 );
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 //pPlate->Shift(0, NeutrHBias, VShiftNeutr + NeutrVBias);
	 //pPlate->Shift(0,0, VShiftNeutr);
	 pPlate->ShiftVert(VShiftNeutr + NeutrBiasInVert, VShiftNeutr + NeutrBiasOutVert);
	 pPlate->ShiftHor(NeutrBiasInHor,  NeutrBiasOutHor);
	 S.Format("NEUTRALIZER: right wall of channel %d", i+1);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);
	 
	 pPlate = new CPlate(); //  Out 
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(NeutrOutX, Yout -NeutrOutTh *0.5  , -NeutrH * 0.5 );
	 p1 = C3Point(NeutrOutX, Yout +NeutrOutTh *0.5  , -NeutrH * 0.5 );
	 p2 = C3Point(NeutrOutX, Yout -NeutrOutTh *0.5  ,  NeutrH * 0.5 );
	 p3 = C3Point(NeutrOutX, Yout + NeutrOutTh *0.5  , NeutrH * 0.5 );
	 pPlate->SetLocals(p0, p1, p2, p3);//pPlate->SetFromLimits(p0, p3);
	 pPlate->Shift(0, NeutrBiasOutHor, VShiftNeutr + NeutrBiasOutVert);
	 //pPlate->Shift(0, NeutrHBias, VShiftNeutr + NeutrVBias);
	 //pPlate->Shift(0,0, VShiftNeutr);
	 S.Format("NEUTRALIZER: Back of panel %d", i+1);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);

	 } // i

	 pPlate = new CPlate(); //  Bottom 
	 //PlateCounter++;
	 pPlate->Number = 501;//PlateCounter; 
	 p0 = C3Point(NeutrInX, YminIn - NeutrInTh *0.5, -NeutrH * 0.5 );
	 p1 = C3Point(NeutrOutX, YminOut - NeutrOutTh *0.5, -NeutrH * 0.5 );
	 p2 = C3Point(NeutrInX, -YminIn + NeutrInTh *0.5  , -NeutrH * 0.5 );
	 p3 = C3Point(NeutrOutX, -YminOut + NeutrOutTh *0.5 , -NeutrH * 0.5 );
	 pPlate->SetLocals(p0, p1, p2, p3);//pPlate->SetFromLimits(p0, p3);
	 pPlate->ShiftVert(VShiftNeutr + NeutrBiasInVert, VShiftNeutr + NeutrBiasOutVert);
	 pPlate->ShiftHor(NeutrBiasInHor,  NeutrBiasOutHor);
	 //pPlate->Shift(0, NeutrBiasOutHor, VShiftNeutr + NeutrBiasOutVert);
	 //pPlate->Shift(0, NeutrHBias, VShiftNeutr + NeutrVBias);
	 //pPlate->Shift(0,0, VShiftNeutr);
	 pPlate->Fixed = 1; // side view
	 S.Format("NEUTRALIZER: Bottom/Top %d", pPlate->Number);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);

	 pPlate = new CPlate(); //  Top
	 //PlateCounter++;
	 pPlate->Number = 502;//PlateCounter; 
	 p0 = C3Point(NeutrInX, YminIn - NeutrInTh *0.5, NeutrH * 0.5 );
	 p1 = C3Point(NeutrOutX, YminOut - NeutrOutTh *0.5, NeutrH * 0.5 );
	 p2 = C3Point(NeutrInX, -YminIn + NeutrInTh *0.5  , NeutrH * 0.5 );
	 p3 = C3Point(NeutrOutX, -YminOut + NeutrOutTh *0.5 , NeutrH * 0.5 );
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);//pPlate->SetFromLimits(p0, p3);
	 pPlate->ShiftVert(VShiftNeutr + NeutrBiasInVert, VShiftNeutr + NeutrBiasOutVert);
	 pPlate->ShiftHor(NeutrBiasInHor,  NeutrBiasOutHor);
	 //pPlate->Shift(0, NeutrBiasOutHor, VShiftNeutr + NeutrBiasOutVert);
	 //pPlate->Shift(0, NeutrHBias, VShiftNeutr + NeutrVBias);
	 //pPlate->Shift(0,0, VShiftNeutr);
	 pPlate->Fixed = 1; // side view
	 S.Format("NEUTRALIZER: Top/Bottom %d", pPlate->Number);
	 pPlate->Comment = S; 
	 PlatesList.AddTail(pPlate);

	 RECT_DIA diaphragm;
	 YminIn = - StepIn * (N-1) * 0.5;
	 for (i = 0; i < N; i++) {
		Yin = YminIn + i*StepIn;
		pPlate = new CPlate(); //  In 
		p0 = C3Point(NeutrInX, Yin - NeutrInW *0.5  , -NeutrH * 0.5 );
		p3 = C3Point(NeutrInX, Yin + NeutrInW *0.5  , NeutrH * 0.5 );
		//p0 = C3Point(NeutrInX, -0.2, -0.5); p3 = C3Point(NeutrInX, 0.2, 0.5);
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, NeutrBiasInHor, VShiftNeutr + NeutrBiasInVert);
		for (int k = 0; k < 4; k++) diaphragm.Corn[k] = pPlate->Corn[k];
		diaphragm.Number = 1;
		diaphragm.Channel = i+1;
		Dia_Array.Add(diaphragm);
		delete pPlate;
	 }//i

	 YminOut = - StepOut * (N-1) * 0.5;
	 for (i = 0; i < N; i++) {
		Yout = YminOut + i*StepOut;
		pPlate = new CPlate(); //  Out 
		p0 = C3Point(NeutrOutX, Yout - NeutrOutW *0.5  , -NeutrH * 0.5 );
		p3 = C3Point(NeutrOutX, Yout + NeutrOutW *0.5  , NeutrH * 0.5 );
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, NeutrBiasOutHor, VShiftNeutr + NeutrBiasOutVert);
		for (int k = 0; k < 4; k++) diaphragm.Corn[k] = pPlate->Corn[k];
		diaphragm.Number = 2;
		diaphragm.Channel = i+1;
		Dia_Array.Add(diaphragm);
		delete pPlate;
	 } // i

	VOLUME vol;
	C3Point lb0, ru0, lb1, ru1;
/*	lb0 = C3Point(0, AreaHorMin, AreaVertMin);
	ru0 = C3Point(0, AreaHorMax, AreaVertMax);
	lb1 = C3Point(NeutrXmin, AreaHorMin, AreaVertMin);
	ru1 = C3Point(NeutrXmin, AreaHorMax, AreaVertMax);
	vol = VOLUME(lb0, ru0, lb1, ru1, 1); // GG-Neutralizer gap
	VolumeVector.push_back(vol);*/
	for (i = 0; i < N; i++) {
		Yin = YminIn + i*StepIn;
		pPlate = new CPlate(); 
		p0 = C3Point(NeutrInX, Yin - NeutrInW *0.5  , -NeutrH * 0.5 );
		p3 = C3Point(NeutrInX, Yin + NeutrInW *0.5  , NeutrH * 0.5 );
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, NeutrBiasInHor, VShiftNeutr + NeutrBiasInVert);
		lb0 = pPlate->Corn[0]; ru0 = pPlate->Corn[2];
		Yout = YminOut + i*StepOut;
		p0 = C3Point(NeutrOutX, Yout - NeutrOutW *0.5  , -NeutrH * 0.5 );
		p3 = C3Point(NeutrOutX, Yout + NeutrOutW *0.5  , NeutrH * 0.5 );
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, NeutrBiasOutHor, VShiftNeutr + NeutrBiasOutVert);
		lb1 = pPlate->Corn[0]; ru1 = pPlate->Corn[2];
		vol = VOLUME(lb0, ru0, lb1, ru1, 1);
		VolumeVector.push_back(vol);
		delete pPlate;
	 }//i
	
}

void  CBTRDoc::SetPlatesRID()// -------------  RID -------------------------------
{
	CString S;
	CPlate * pPlate;
//	RECT_DIA diaphragm;
	C3Point p0_, p1_, p2_, p3_; // in local CS of Side Channel
	C3Point p0, p1, p2, p3; // in Central Channel CS
	int N = (int)RIDChannels; // vert channels
	double StepIn = RIDInW + RIDTh; // inlet step between adjacent channels axes (= between panels)
	double StepOut = RIDOutW + RIDTh;// outlet step between adjacent channels axes
	double YminIn = - StepIn * N * 0.5; // right-most panel Y  
	double YminOut = - StepOut * N * 0.5;// right-most panel Y  
	double Yin, Yout;

	 pPlate = new CPlate(); // Exit
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(RIDOutX + 0.2, YminOut - 0.15, -RIDH * 0.5 - 0.1);
	 p3 = C3Point(RIDOutX + 0.2, -YminOut + 0.15,  RIDH * 0.5 + 0.1);
	 pPlate->OrtDirect = -1;
	 pPlate->SetFromLimits(p0, p3); 
	 pPlate->Shift(0, RIDBiasInHor, VShiftRID + RIDBiasInVert);
	 //pPlate->Shift(0,0, VShiftRID);
	 pPlate->Solid = FALSE;
	 pPlate->Visible = FALSE;
	 S.Format("RID Exit plane X = %g m", RIDOutX + 0.2);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);
	// if (TaskRID)  SelectPlate(pPlate);

	 int i;
	 for (i = 0; i <= N; i++) {
		 Yin = YminIn + i*StepIn;
		 Yout = YminOut + i*StepOut;
	 pPlate = new CPlate(); //  In 
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(RIDInX, Yin - RIDTh *0.5  , -RIDH * 0.5 );
	 p3 = C3Point(RIDInX, Yin + RIDTh *0.5  , RIDH * 0.5 );
	 pPlate->OrtDirect = -1;
	 pPlate->SetFromLimits(p0, p3);
	 pPlate->Shift(0, RIDBiasInHor, VShiftRID + RIDBiasInVert);
	 //pPlate->Shift(0,0, VShiftRID);
	 S.Format("RID: Leading Edge of panel %d", i+1);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);
 	
 	 pPlate = new CPlate(); // right
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(RIDInX,  Yin - RIDTh *0.5  , -RIDH * 0.5 );
	 p1 = C3Point(RIDOutX, Yout - RIDTh *0.5  , -RIDH * 0.5 );
	 p2 = C3Point(RIDInX,  Yin - RIDTh *0.5  , RIDH * 0.5 );
	 p3 = C3Point(RIDOutX, Yout -RIDTh *0.5  , RIDH * 0.5 );
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(VShiftRID + RIDBiasInVert, VShiftRID + RIDBiasOutVert);
	 pPlate->ShiftHor(RIDBiasInHor,  RIDBiasOutHor);
	 //pPlate->Shift(0, RIDHBias, VShiftRID + RIDVBias);
	 //pPlate->Shift(0,0, VShiftRID);
	 S.Format("RID: left wall of channel %d", i);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);
	 //if (TaskRID)  SelectPlate(pPlate);

	 pPlate = new CPlate(); // left
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(RIDInX,  Yin +RIDTh *0.5  , -RIDH * 0.5 );
	 p1 = C3Point(RIDOutX,  Yout +RIDTh *0.5  , -RIDH * 0.5 );
	 p2 = C3Point(RIDInX,  Yin +RIDTh *0.5  , RIDH * 0.5 );
	 p3 = C3Point(RIDOutX,  Yout +RIDTh *0.5  , RIDH * 0.5 );
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(VShiftRID + RIDBiasInVert, VShiftRID + RIDBiasOutVert);
	 pPlate->ShiftHor(RIDBiasInHor,  RIDBiasOutHor);
	 //pPlate->Shift(0, RIDHBias, VShiftRID + RIDVBias);
	 //pPlate->Shift(0,0, VShiftRID);
	 S.Format("RID: right wall of channel %d", i+1);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);
	// if (TaskRID)  SelectPlate(pPlate);

	 pPlate = new CPlate(); // Out 
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(RIDOutX, Yout -RIDTh *0.5  , -RIDH * 0.5 );
	 p3 = C3Point(RIDOutX, Yout + RIDTh *0.5  , RIDH * 0.5 );
	 pPlate->SetFromLimits(p0, p3);
	 pPlate->Shift(0, RIDBiasOutHor, VShiftRID + RIDBiasOutVert);
	 //pPlate->Shift(0, RIDHBias, VShiftRID + RIDVBias);
	 //pPlate->Shift(0,0, VShiftRID);
	 S.Format("RID: Back of panel %d", i+1);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);

	 }

	 RECT_DIA diaphragm;
	 YminIn = - StepIn * (N-1) * 0.5;
	 for (i = 0; i < N; i++) {
		Yin = YminIn + i*StepIn;
		pPlate = new CPlate(); //  In 
		p0 = C3Point(RIDInX, Yin - RIDInW *0.5  , -RIDH * 0.5 );
		p3 = C3Point(RIDInX, Yin + RIDInW *0.5  , RIDH * 0.5 );
		//p0 = C3Point(NeutrInX, -0.2, -0.5); p3 = C3Point(NeutrInX, 0.2, 0.5);
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, RIDBiasInHor, VShiftRID + RIDBiasInVert);
		for (int k = 0; k < 4; k++) diaphragm.Corn[k] = pPlate->Corn[k];
		diaphragm.Number = 3;
		diaphragm.Channel = i+1;
		Dia_Array.Add(diaphragm);
		delete pPlate;
	 }//i

	 YminOut = - StepOut * (N-1) * 0.5;
	 for (i = 0; i < N; i++) {
		Yout = YminOut + i*StepOut;
		pPlate = new CPlate(); //  Out 
		p0 = C3Point(RIDOutX, Yout - RIDOutW *0.5  , -RIDH * 0.5 );
		p3 = C3Point(RIDOutX, Yout + RIDOutW *0.5  , RIDH * 0.5 );
		//p0 = C3Point(NeutrOutX, -0.2, -0.5); p3 = C3Point(NeutrOutX, 0.2, 0.5);
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, RIDBiasOutHor, VShiftRID + RIDBiasOutVert);
		for (int k = 0; k < 4; k++) diaphragm.Corn[k] = pPlate->Corn[k];
		diaphragm.Number = 4;
		diaphragm.Channel = i+1;
		Dia_Array.Add(diaphragm);
		delete pPlate;
	 } // i

	VOLUME vol;
	C3Point lb0, ru0, lb1, ru1;
	for (i = 0; i < N; i++) {
		Yin = YminIn + i*StepIn;
		pPlate = new CPlate(); 
		p0 = C3Point(RIDInX, Yin - RIDInW *0.5  , -RIDH * 0.5 );
		p3 = C3Point(RIDInX, Yin + RIDInW *0.5  , RIDH * 0.5 );
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, RIDBiasInHor, VShiftRID + RIDBiasInVert);
		lb0 = pPlate->Corn[0]; ru0 = pPlate->Corn[2];
		Yout = YminOut + i*StepOut;
		p0 = C3Point(RIDOutX, Yout - RIDOutW *0.5  , -RIDH * 0.5 );
		p3 = C3Point(RIDOutX, Yout + RIDOutW *0.5  , RIDH * 0.5 );
		pPlate->SetFromLimits(p0, p3);
		pPlate->Shift(0, RIDBiasOutHor, VShiftRID + RIDBiasOutVert);
		lb1 = pPlate->Corn[0]; ru1 = pPlate->Corn[2];
		vol = VOLUME(lb0, ru0, lb1, ru1, 1);
		VolumeVector.push_back(vol);
		delete pPlate;
	 }//i
}


C3Point CBTRDoc::GetStartPoint(double f, double axisR)
{
	C3Point P = FWdata[0];
	int N = (int)FWdata.GetSize();
	double f0, f1;
	C3Point P0, P1;
	P0 = FWdata[0];
	f0 = atan2(P0.Y, (P0.X - axisR));
	int i1;
	for (int i = 1; i < N; i++) {
		i1 = i + 1;
		if (i1 == N) i1 = 0;
		P1 = FWdata[i1];
		f1 = atan2(P1.Y, (P1.X - axisR));
		if ((f-f0)*(f-f1) <=0) return (P0 + P1)*0.5;
		P0 = P1;
		f0 = f1;
	}
	return P;
}

C3Point CBTRDoc::GetNextFWcoord(C3Point prev, double dl) // positive shift along FWdata by step dl
{
	C3Point next = prev;
	int N = (int)FWdata.GetSize();
	int i0, i1, iprev = 0;
	double d0, d1, d01, sumL;
	C3Point P0, P1;

	for (int i = 0; i < N; i++) {// locate prev point -> iprev
		i0 = i;
		i1 = i + 1;
		if (i1 == N) i1 = 0;
		P0 = FWdata[i0];
		P1 = FWdata[i1];
		d01 = GetDistBetween(P0, P1);
		if (d01 < 1.e-6) continue;
		d0 = GetDistBetween(P0, prev);
		d1 = GetDistBetween(P1, prev);
		if (d0 < d01 && d1 <= d01) break; // i0, i1 found
	}//find iprev

	sumL = 0;
	next = prev;

	if (dl <= d1)
		next = prev + (P1 - prev)* dl / d1;

	else while (dl > sumL)
		{
			sumL += d1;// move to next node
			P0 = P1;
			i0 = i1;
			i1++;
			if (i1 == N) i1 = 0;
			P1 = FWdata[i1];
			d01 = GetDistBetween(P0, P1);
			if (d01 < 1.e-3) {
				d1 = 0;
				continue;
			}
			if (dl - sumL < d01) {
				next = P0 + (P1 - P0) * (dl - sumL) / d01;
				sumL = dl * 1.1; // to stop
				break;
			}
			else {
				next = P1;
				d1 = d01; // jump to next node 
			}
		} // while dl < sumL
		

	return next;
}

void  CBTRDoc::SetPlatesTor()
{
	//AfxMessageBox("Enter SetPlatesTor");
	//if (!OptBeamInPlasma) return;
	CPlate * Plate;
	C3Point p0, p1, p2, p3;
	double r0, z0, r1, z1, Teta0, Teta1, f0, f1;
	double x00, x01, x10, x11, y00, y01, y10, y11;
	int Ntor = (int) TorSegmentNumber;//36; // along tor teta
	int Nf = FWdata.GetUpperBound(); // last point = 1st
	if (Nf < 1) return;

	double Ymin = AreaHorMin;
	double Ymax = AreaHorMax;
	double Zmin = AreaVertMin;
	double Zmax = AreaVertMax;
/*	C3Point Av = GetBeamFootLimits(PlasmaXmax, Ymin, Ymax, Zmin, Zmax); //already called in SetPlates
	//double Yav = 0.5 * (Ymin + Ymax); Zav = 0.5 * (Zmin + Zmax);
	Ymin = Min(Ymin, AreaHorMin);
	Ymax = Max(Ymax, AreaHorMax);
	Zmin = Min(Zmin, AreaVertMin);
	Zmax = Max(Zmax, AreaVertMax);*/
	double sizeY = fabs(Ymax - Ymin);// beam foot size
	double sizeZ = fabs(Zmax - Zmin);
	double Yav = 0.5 * (Ymin + Ymax);
	double Zav = 0.5 * (Zmin + Zmax);
	double Tav = atan2((Yav - TorCentreY), (PlasmaXmax - TorCentreX)); // -Pi..Pi
	double Fav = atan2((Zav - TorCentreZ), (PlasmaXmax - TorCentreX));
	//if (Fav > PI / 2) Fav -= PI; 
	double FWdR = 0.5*(FWRmax - FWRmin);// = PlasmaMinorR if circle
	double TorR = FWRmin + FWdR; // = PlasmaMajorR if circle

	double TetaMax =  Tav + atan2(sizeY, FWRmax);// -pi/2...pi/2
	double TetaMin =  Tav - atan2(sizeY, FWRmax); // - 
	
	double Fmin = -PI * 0.5;// atan2((FWZmin), FWRmax);
	double Fmax = PI * 0.5; // atan2((FWZmax), FWRmax);
	//double Fmax = Fav + 2*atan2(sizeZ, FWRmax);   //atan((Zmax - TorCentre.Z)/FWdR);//
	//double Fmin = Fav - 2*atan2(sizeZ, FWRmax);   //atan((Zmin - TorCentre.Z)/FWdR); //
	
	double dTeta = 2 * PI / Ntor;// step of tor segments
	double T0 = dTeta * 0.5;
	double step = sizeZ * 0.3; // step along FW profile (poloidal)

	double Fsum = 0; //sum rotation
	C3Point P0 = GetStartPoint(Fmin, TorR);//returns FWdata[0] if not found!!!
	C3Point P1 = P0;
	f1 = Fmin;
		
	double LimXmin = TorCentreX + FWRmax * cos(TetaMin) + 0.2; // start
	double LimXmax = TorCentreX + FWRmax * cos(TetaMax) + 0.2; // fin
	
	double LimYmin = Ymin;
	double LimYmax = Ymax;
	double LimZmin = Zmin;
	double LimZmax = Zmax;
		
	while (Fsum < 2*PI) {
		P0 = P1;
		r0 = P0.X; // FWdata[i].X;
		z0 = TorCentreZ + P0.Y;
		f0 = f1; // atan(FWdata[i].Y / (r0 - TorRmin));
		P1 = GetNextFWcoord(P0, step);
		r1 = P1.X; // FWdata[i + 1].X;
		z1 = TorCentreZ + P1.Y; // TorCentre.Z + FWdata[i + 1].Y;
		f1 = atan2(z1, (r1 - TorR)); // atan(FWdata[i+1].Y/(r1 - TorRmin));
		if (f0 > 0 && f1 < 0) f1 += 2 * PI;
		
		Fsum += f1 - f0;
		//if (f1 < 0) f1 += 2 * PI;
		//if (f0 > Fmax) continue;
		if (r0 - TorR < 0 || r1 - TorR < 0) continue;
		//if (0.5 * (z0 + z1) > Zmax || 0.5 * (z0 + z1) < Zmin) continue;
		
		for (int j = 0; j < Ntor; j++) { // along toroidal coord - Teta
			Teta0 = T0 + dTeta * j; Teta1 = T0 + dTeta * (j+1);
			if (Teta0 > TetaMax || Teta1 < TetaMin) continue;
			x00 = TorCentreX + r0 * cos(Teta0); x01 = TorCentreX + r0 * cos(Teta1);
			x10 = TorCentreX + r1 * cos(Teta0); x11 = TorCentreX + r1 * cos(Teta1);
			//if (x00 < TorCentre.X || x11 < TorCentre.X) break; 
			y00 = TorCentreY + r0 * sin(Teta0); y01 = TorCentreY + r0 * sin(Teta1);
			y10 = TorCentreY + r1 * sin(Teta0); y11 = TorCentreY + r1 * sin(Teta1);
			//if (Min(y00, y11) > Ymax || Max(y00, y11) < Ymin) continue;
			//if (Min(y01, y10) > Ymax || Max(y01, y10) < Ymin) continue;
			
			p0 = C3Point(x00, y00, z0);
			p1 = C3Point(x01, y01, z0); // r0, z0, Teta1
			p2 = C3Point(x10, y10, z1); // r1, y1, Teta0
			p3 = C3Point(x11, y11, z1);
			Plate = new CPlate(); // FW tile 
			PlateCounter++;
			Plate->Number = PlateCounter;
			Plate->OrtDirect = -1;
			Plate->SetLocals(p0, p1, p2, p3);
			Plate->Solid = FALSE;// TRUE;
			Plate->Comment = "First Wall";
			Plate->Fixed = 1; // side view
			PlatesList.AddTail(Plate);
		} // j
	} //i

	p0 = C3Point(LimXmin, LimYmin, LimZmin);
	p1 = C3Point(LimXmax, LimYmax, LimZmin); //
	p2 = C3Point(LimXmin, LimYmin, LimZmax); // r1, y1, Teta0
	p3 = C3Point(LimXmax, LimYmax, LimZmax);
	Plate = new CPlate(); // FW 
	PlateCounter++;
	Plate->Number = PlateCounter;
	Plate->OrtDirect = 1;
	Plate->SetLocals(p0, p1, p2, p3);
	Plate->Solid =  TRUE;
	Plate->Comment = "FW combo";
	Plate->Fixed = -1; // side view
	PlatesList.AddTail(Plate);
	AreaLong = LimXmin + 1;
}

void  CBTRDoc::SetPlatesDuct()
{
	SetDuctDia();
}

void  CBTRDoc::SetPlatesDuctFull()
{
	//AfxMessageBox("Enter SetPlatesDuct");
	CString S;
	CPlate * pPlate;
	C3Point p0_, p1_, p2_, p3_; // 
	C3Point p0, p1, p2, p3; // in Central Channel CS
	RECT_DIA diaphragm;
	VOLUME vol;
	C3Point lb0, ru0, lb1, ru1;
		
	// ------------- Pre-Duct Dia (Scraper1)  -------------------------------
	diaphragm.Number = 5; // PreDuct
	 pPlate = new CPlate(); //Pre-Duct Diafragm
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX, -PreDuctW * 0.5, AreaVertMin);
	 p1 = C3Point(PreDuctX,  PreDuctW * 0.5, AreaVertMin);	
	 p2 = C3Point(PreDuctX, -PreDuctW * 0.5, -PreDuctH * 0.5);
	 p3 = C3Point(PreDuctX,  PreDuctW * 0.5, -PreDuctH * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->Shift(0, DiaBiasHor, VShiftDia + DiaBiasVert);
	 pPlate->Corn[0].Z = AreaVertMin; pPlate->Corn[1].Z = AreaVertMin;
	 pPlate->SetLocals(pPlate->Corn[0], pPlate->Corn[1], pPlate->Corn[3], pPlate->Corn[2]);
	 //pPlate->Shift(0,0, VShiftDia);
	 pPlate->Solid = TRUE;
	 pPlate->Comment = "SCRAPER 1: lower wing";
	 pPlate->Fixed = 1; // side view
	 PlatesList.AddTail(pPlate);
	 diaphragm.Corn[0] = pPlate->Corn[3]; //p2
	// diaphragm.Corn[1] = pPlate->Corn[0];

	 pPlate = new CPlate(); //Pre-Duct Diafragm
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX, -PreDuctW * 0.5, PreDuctH * 0.5);
	 p1 = C3Point(PreDuctX,  PreDuctW * 0.5, PreDuctH * 0.5);
	 p2 = C3Point(PreDuctX,  -PreDuctW * 0.5, AreaVertMax);
	 p3 = C3Point(PreDuctX,  PreDuctW * 0.5, AreaVertMax);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->Shift(0, DiaBiasHor, VShiftDia + DiaBiasVert);
	 pPlate->Corn[2].Z = AreaVertMax; pPlate->Corn[3].Z = AreaVertMax;
	 pPlate->SetLocals(pPlate->Corn[0], pPlate->Corn[1], pPlate->Corn[3], pPlate->Corn[2]);
	 //pPlate->Shift(0,0, VShiftDia);
	 pPlate->Solid = TRUE;
	 pPlate->Comment = "SCRAPER 1: upper wing";
	 pPlate->Fixed = 1; // side view
	 PlatesList.AddTail(pPlate);
	 diaphragm.Corn[2] = pPlate->Corn[1];//p1
	// diaphragm.Corn[3] = pPlate->Corn[0];

	 pPlate = new CPlate(); //Pre-Duct Diafragm
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX, AreaHorMin, AreaVertMin);
	 p1 = C3Point(PreDuctX,  -PreDuctW * 0.5, AreaVertMin);
	 p2 = C3Point(PreDuctX, AreaHorMin, AreaVertMax);
	 p3 = C3Point(PreDuctX,  -PreDuctW * 0.5, AreaVertMax);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->Shift(0, DiaBiasHor, VShiftDia + DiaBiasVert);
	 pPlate->Corn[0].Z = AreaVertMin; pPlate->Corn[1].Z = AreaVertMin;
	 pPlate->Corn[2].Z = AreaVertMax; pPlate->Corn[3].Z = AreaVertMax;
	 pPlate->SetLocals(pPlate->Corn[0], pPlate->Corn[1], pPlate->Corn[3], pPlate->Corn[2]);
	 //pPlate->Shift(0,0, VShiftDia);
	 pPlate->Solid = TRUE;
	 pPlate->Comment = "SCRAPER 1: right wing";
	 PlatesList.AddTail(pPlate);

	 pPlate = new CPlate(); //Pre-Duct Diafragm
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX, PreDuctW * 0.5, AreaVertMin);
	 p1 = C3Point(PreDuctX, AreaHorMax, AreaVertMin);
	 p2 = C3Point(PreDuctX, PreDuctW * 0.5, AreaVertMax);
	 p3 = C3Point(PreDuctX, AreaHorMax, AreaVertMax);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->Shift(0, DiaBiasHor, VShiftDia + DiaBiasVert);
	 pPlate->Corn[0].Z = AreaVertMin; pPlate->Corn[1].Z = AreaVertMin;
	 pPlate->Corn[2].Z = AreaVertMax; pPlate->Corn[3].Z = AreaVertMax;
	 pPlate->SetLocals(pPlate->Corn[0], pPlate->Corn[1], pPlate->Corn[3], pPlate->Corn[2]);
	 //pPlate->Shift(0,0, VShiftDia);
	 pPlate->Solid = TRUE;
 	 pPlate->Comment = "SCRAPER 1: left wing";
	 PlatesList.AddTail(pPlate);

	 Dia_Array.Add(diaphragm);//5

	 lb0 = diaphragm.Corn[0]; ru0 = diaphragm.Corn[2];
	
	//--------- SCRAPER 2 -------------------------
	 // PreDuct -> Scr1
	 // DDLinerIn -> Scr2
	 diaphragm.Number = 6; // DDLinerIn

	 pPlate = new CPlate(); // left
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX,  PreDuctW * 0.5, - PreDuctH * 0.5);
	 p1 = C3Point(DDLinerInX, DDLinerInW * 0.5, - DDLinerInH * 0.5);
	 p2 = C3Point(PreDuctX,  PreDuctW * 0.5,  PreDuctH * 0.5);
	 p3 = C3Point(DDLinerInX, DDLinerInW * 0.5,  DDLinerInH * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(DiaBiasVert + VShiftDia, LinerBiasInVert + VShiftLinerIn);
	 pPlate->ShiftHor(DiaBiasHor, LinerBiasOutHor);
	 //pPlate->Shift(0, LinerHBias, VShiftLinerIn + LinerVBias);
	 pPlate->Solid = TRUE;
	 pPlate->Comment = "SCRAPER 2: left wall";
	 PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate); //{ pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }
	 diaphragm.Corn[2] = pPlate->Corn[2];//p3

	pPlate = new CPlate(); // right
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX,  -PreDuctW * 0.5, - PreDuctH * 0.5);
	 p1 = C3Point(DDLinerInX, -DDLinerInW * 0.5, - DDLinerInH * 0.5);
	 p2 = C3Point(PreDuctX,  -PreDuctW * 0.5,  PreDuctH * 0.5);
	 p3 = C3Point(DDLinerInX, -DDLinerInW * 0.5,  DDLinerInH * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(DiaBiasVert + VShiftDia, LinerBiasInVert + VShiftLinerIn);
	 pPlate->ShiftHor(DiaBiasHor, LinerBiasOutHor);
	 //pPlate->Shift(0, LinerHBias, VShiftLinerIn + LinerVBias);
	 pPlate->Solid = TRUE;
	 pPlate->Comment = "SCRAPER 2: right wall";
	 PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate); //{ pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }
	 diaphragm.Corn[0] = pPlate->Corn[1];//p1
	 Dia_Array.Add(diaphragm);//6

	 lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol); //5-6
	 lb0 = lb1; ru0 = ru1;

	 pPlate = new CPlate(); // upper
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX,  -PreDuctW * 0.5, PreDuctH * 0.5);
	 p1 = C3Point(DDLinerInX, -DDLinerInW * 0.5, DDLinerInH * 0.5);
	 p2 = C3Point(PreDuctX,  PreDuctW * 0.5,  PreDuctH * 0.5);
	 p3 = C3Point(DDLinerInX, DDLinerInW * 0.5,  DDLinerInH * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(DiaBiasVert + VShiftDia, LinerBiasInVert + VShiftLinerIn);
	 pPlate->ShiftHor(DiaBiasHor, LinerBiasOutHor);
	 //pPlate->Shift(0, LinerHBias, VShiftLinerIn + LinerVBias);
	 pPlate->Solid = TRUE;
	 pPlate->Fixed = 1; // side view
	 pPlate->Comment = "SCRAPER 2: top wall";
	 PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate); //{ pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }

	 pPlate = new CPlate(); // lower
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(PreDuctX,  -PreDuctW * 0.5, -PreDuctH * 0.5);
	 p1 = C3Point(DDLinerInX, -DDLinerInW * 0.5, -DDLinerInH * 0.5);
	 p2 = C3Point(PreDuctX,  PreDuctW * 0.5,  -PreDuctH * 0.5);
	 p3 = C3Point(DDLinerInX, DDLinerInW * 0.5,  -DDLinerInH * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(DiaBiasVert + VShiftDia, LinerBiasInVert + VShiftLinerIn);
	 pPlate->ShiftHor(DiaBiasHor, LinerBiasOutHor);
	 //pPlate->Shift(0, LinerHBias, VShiftLinerIn + LinerVBias);
	 pPlate->Solid = TRUE;
	 pPlate->Fixed = 1; // side view
	 pPlate->Comment = "SCRAPER 2: bottom wall";
	 PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate); //{ pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }


	//--------- DDLiner ----------------------------
/*	 pPlate = new CPlate(); // before Liner
	 p0 = C3Point(DDLinerInX - 0.1, -DDLinerInW * 0.5 - 0.1, - DDLinerInH * 0.5 - 0.1 );
	 p3 = C3Point(DDLinerInX - 0.1, DDLinerInW * 0.5 + 0.1,  DDLinerInH * 0.5 + 0.1);
	 pPlate->SetFromLimits(p0, p3);
	 pPlate->Shift(0, LinerBiasInHor, VShiftLinerIn + LinerBiasInVert);
	 //pPlate->Shift(0,0, VShiftDia);
	 pPlate->Solid = FALSE;
	 pPlate->Visible = FALSE;
	 S.Format("Cross-plane before Liner, X = %g m", DDLinerInX - 0.1);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);
*/
	 diaphragm.Number = 7; // DDLinerOut
	 pPlate = new CPlate(); // right
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerInX,  DDLinerInW * 0.5, - DDLinerInH * 0.5);
	 p1 = C3Point(DDLinerOutX,  DDLinerOutW * 0.5, - DDLinerOutH * 0.5);
	 p2 = C3Point(DDLinerInX,  DDLinerInW * 0.5,  DDLinerInH * 0.5);
	 p3 = C3Point(DDLinerOutX,  DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasInVert + VShiftLinerIn, LinerBiasOutVert + VShiftLinerOut);
	 pPlate->ShiftHor(LinerBiasInHor, LinerBiasOutHor);
	 //pPlate->Shift(0, LinerHBias, VShiftLinerIn + LinerVBias);
	 pPlate->Solid = TRUE;
	 pPlate->Comment = "AV: left wall";
	 PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate); //{ pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }
	 diaphragm.Corn[2] = pPlate->Corn[2];//p3

	 pPlate = new CPlate(); // left
	 PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerInX,  -DDLinerInW * 0.5, - DDLinerInH * 0.5);
	 p1 = C3Point(DDLinerOutX,  -DDLinerOutW * 0.5, - DDLinerOutH * 0.5);
	 p2 = C3Point(DDLinerInX,  -DDLinerInW * 0.5,  DDLinerInH * 0.5);
	 p3 = C3Point(DDLinerOutX,  -DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasInVert + VShiftLinerIn, LinerBiasOutVert + VShiftLinerOut);
	 pPlate->ShiftHor(LinerBiasInHor, LinerBiasOutHor);
	 //pPlate->ShiftVert(VShiftLinerIn, VShiftLinerOut);
	 pPlate->Solid = TRUE;
	 pPlate->Comment = "AV: right wall";
	 PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);//{ pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }
	 diaphragm.Corn[0] = pPlate->Corn[1];//p1
	 Dia_Array.Add(diaphragm);//7

	 lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//6-7
	 lb0 = lb1; ru0 = ru1;
	
	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerInX, - DDLinerInW * 0.5,  DDLinerInH * 0.5);
	 p2 = C3Point(DDLinerInX,  DDLinerInW * 0.5, DDLinerInH * 0.5);
	 p1 = C3Point(DDLinerOutX, - DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 p3 = C3Point(DDLinerOutX,  DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasInVert + VShiftLinerIn, LinerBiasOutVert + VShiftLinerOut);
	 pPlate->ShiftHor(LinerBiasInHor, LinerBiasOutHor);
	 //pPlate->ShiftVert(VShiftLinerIn, VShiftLinerOut);
	pPlate->Solid = TRUE;
	pPlate->Comment = "AV: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);//{ pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerInX, - DDLinerInW * 0.5,  - DDLinerInH * 0.5);
	 p2 = C3Point(DDLinerInX,  DDLinerInW * 0.5,  - DDLinerInH * 0.5);
	 p1 = C3Point(DDLinerOutX, - DDLinerOutW * 0.5, - DDLinerOutH * 0.5);
	 p3 = C3Point(DDLinerOutX,  DDLinerOutW * 0.5,  - DDLinerOutH * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasInVert + VShiftLinerIn, LinerBiasOutVert + VShiftLinerOut);
	 pPlate->ShiftHor(LinerBiasInHor, LinerBiasOutHor);
	 //pPlate->ShiftVert(VShiftLinerIn, VShiftLinerOut);
	pPlate->Solid = TRUE;
	pPlate->Comment = "AV: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate); // { pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); }

//--------- DUCT0 ----------------------------
// DDLinerOut -> Duct0
	diaphragm.Number = 8; // Duct1
	pPlate = new CPlate(); // left
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerOutX,  DDLinerOutW * 0.5, - DDLinerOutH * 0.5);
	 p1 = C3Point(Duct1X,  Duct1W * 0.5, - Duct1H * 0.5);
	 p2 = C3Point(DDLinerOutX,  DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 p3 = C3Point(Duct1X,  Duct1W * 0.5, Duct1H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasOutVert + VShiftLinerOut, Duct1BiasVert + VShiftDuct1);
	 pPlate->ShiftHor(LinerBiasOutHor, Duct1BiasHor);
	 //pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT0: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // right
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerOutX,  - DDLinerOutW * 0.5, - DDLinerOutH * 0.5);
	 p1 = C3Point(Duct1X,  - Duct1W * 0.5, - Duct1H * 0.5);
	 p2 = C3Point(DDLinerOutX, - DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 p3 = C3Point(Duct1X, - Duct1W * 0.5, Duct1H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasOutVert + VShiftLinerOut, Duct1BiasVert + VShiftDuct1);
	 pPlate->ShiftHor(LinerBiasOutHor, Duct1BiasHor);
	 //pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT0: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//8

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//7-8
	 lb0 = lb1; ru0 = ru1;

	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerOutX,  -DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 p1 = C3Point(Duct1X, -Duct1W * 0.5, Duct1H * 0.5);
	 p2 = C3Point(DDLinerOutX,  DDLinerOutW * 0.5,  DDLinerOutH * 0.5);
	 p3 = C3Point(Duct1X,  Duct1W * 0.5, Duct1H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasOutVert + VShiftLinerOut, Duct1BiasVert + VShiftDuct1);
	 pPlate->ShiftHor(LinerBiasOutHor, Duct1BiasHor);
	 //pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT0: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(DDLinerOutX, -DDLinerOutW * 0.5, -DDLinerOutH * 0.5);
	 p1 = C3Point(Duct1X, -Duct1W * 0.5, -Duct1H * 0.5);
	 p2 = C3Point(DDLinerOutX, DDLinerOutW * 0.5, -DDLinerOutH * 0.5);
	 p3 = C3Point(Duct1X,  Duct1W * 0.5, -Duct1H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(LinerBiasOutVert + VShiftLinerOut, Duct1BiasVert + VShiftDuct1);
	 pPlate->ShiftHor(LinerBiasOutHor, Duct1BiasHor);
	 //pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT0: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);



//--------- DUCT1 ----------------------------
	diaphragm.Number = 9; // Duct2
	
	pPlate = new CPlate(); // right
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct1X,  Duct1W * 0.5, - Duct1H * 0.5);
	 p1 = C3Point(Duct2X,  Duct2W * 0.5, - Duct2H * 0.5);
	 p2 = C3Point(Duct1X,  Duct1W * 0.5,  Duct1H * 0.5);
	 p3 = C3Point(Duct2X,  Duct2W * 0.5,  Duct2H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct1BiasVert + VShiftDuct1, Duct2BiasVert + VShiftDuct2);
	 pPlate->ShiftHor(Duct1BiasHor, Duct2BiasHor);
	 //pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT1: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // left
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct1X,  -Duct1W * 0.5, - Duct1H * 0.5);
	 p1 = C3Point(Duct2X,  -Duct2W * 0.5, - Duct2H * 0.5);
	 p2 = C3Point(Duct1X,  -Duct1W * 0.5,  Duct1H * 0.5);
	 p3 = C3Point(Duct2X,  -Duct2W * 0.5,  Duct2H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct1BiasVert + VShiftDuct1, Duct2BiasVert + VShiftDuct2);
	 pPlate->ShiftHor(Duct1BiasHor, Duct2BiasHor);
	 //pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT1: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//9

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//8-9
	 lb0 = lb1; ru0 = ru1;
	
	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct1X, - Duct1W * 0.5,  Duct1H * 0.5);
	 p2 = C3Point(Duct1X,  Duct1W * 0.5, Duct1H * 0.5);
	 p1 = C3Point(Duct2X, - Duct2W * 0.5,  Duct2H * 0.5);
	 p3 = C3Point(Duct2X,  Duct2W * 0.5,  Duct2H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct1BiasVert + VShiftDuct1, Duct2BiasVert + VShiftDuct2);
	 pPlate->ShiftHor(Duct1BiasHor, Duct2BiasHor);
	 //pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT1: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct1X, - Duct1W * 0.5,  -Duct1H * 0.5);
	 p2 = C3Point(Duct1X,  Duct1W * 0.5, -Duct1H * 0.5);
	 p1 = C3Point(Duct2X, - Duct2W * 0.5,  -Duct2H * 0.5);
	 p3 = C3Point(Duct2X,  Duct2W * 0.5,  -Duct2H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct1BiasVert + VShiftDuct1, Duct2BiasVert + VShiftDuct2);
	 pPlate->ShiftHor(Duct1BiasHor, Duct2BiasHor);
	// pPlate->ShiftVert(VShiftDuct1, VShiftDuct2);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT1: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	//--------- DUCT2 ----------------------------
	diaphragm.Number = 10; // Duct3

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct2X,  Duct2W * 0.5, - Duct2H * 0.5);
	 p1 = C3Point(Duct3X,  Duct3W * 0.5, - Duct3H * 0.5);
	 p2 = C3Point(Duct2X,  Duct2W * 0.5,  Duct2H * 0.5);
	 p3 = C3Point(Duct3X,  Duct3W * 0.5,  Duct3H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct2BiasVert + VShiftDuct2, Duct3BiasVert + VShiftDuct3);
	 pPlate->ShiftHor(Duct2BiasHor, Duct3BiasHor);
	// pPlate->ShiftVert(VShiftDuct2, VShiftDuct3);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT2: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct2X,  -Duct2W * 0.5, - Duct2H * 0.5);
	 p1 = C3Point(Duct3X,  -Duct3W * 0.5, - Duct3H * 0.5);
	 p2 = C3Point(Duct2X,  -Duct2W * 0.5,  Duct2H * 0.5);
	 p3 = C3Point(Duct3X,  -Duct3W * 0.5,  Duct3H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct2BiasVert + VShiftDuct2, Duct3BiasVert + VShiftDuct3);
	 pPlate->ShiftHor(Duct2BiasHor, Duct3BiasHor);
	// pPlate->ShiftVert(VShiftDuct2, VShiftDuct3);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT2: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//10

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//9-10
	 lb0 = lb1; ru0 = ru1;

	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct2X, - Duct2W * 0.5,  Duct2H * 0.5);
	 p1 = C3Point(Duct2X,  Duct2W * 0.5, Duct2H * 0.5);
	 p2 = C3Point(Duct3X,  Duct3W * 0.5,  Duct3H * 0.5);
	 p3 = C3Point(Duct3X, - Duct3W * 0.5,  Duct3H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct2BiasVert + VShiftDuct2, Duct3BiasVert + VShiftDuct3);
	 pPlate->ShiftHor(Duct2BiasHor, Duct3BiasHor);
	 //pPlate->ShiftVert(VShiftDuct2, VShiftDuct3);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT2: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct2X, - Duct2W * 0.5,  -Duct2H * 0.5);
	 p1 = C3Point(Duct2X,  Duct2W * 0.5, -Duct2H * 0.5);
	 p2 = C3Point(Duct3X,  Duct3W * 0.5,  -Duct3H * 0.5);
	 p3 = C3Point(Duct3X, - Duct3W * 0.5,  -Duct3H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct2BiasVert + VShiftDuct2, Duct3BiasVert + VShiftDuct3);
	 pPlate->ShiftHor(Duct2BiasHor, Duct3BiasHor);
	 //pPlate->ShiftVert(VShiftDuct2, VShiftDuct3);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT2: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

//--------- DUCT3 ----------------------------
	diaphragm.Number = 11; // Duct4

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct3X,  Duct3W * 0.5, - Duct3H * 0.5);
	 p1 = C3Point(Duct4X,  Duct4W * 0.5, - Duct4H * 0.5);
	 p2 = C3Point(Duct3X,  Duct3W * 0.5,  Duct3H * 0.5);
	 p3 = C3Point(Duct4X,  Duct4W * 0.5,  Duct4H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct3BiasVert + VShiftDuct3, Duct4BiasVert + VShiftDuct4);
	 pPlate->ShiftHor(Duct3BiasHor, Duct4BiasHor);
	// pPlate->ShiftVert(VShiftDuct3, VShiftDuct4);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT3: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct3X,  -Duct3W * 0.5, - Duct3H * 0.5);
	 p1 = C3Point(Duct4X,  -Duct4W * 0.5, - Duct4H * 0.5);
	 p2 = C3Point(Duct3X,  -Duct3W * 0.5,  Duct3H * 0.5);
	 p3 = C3Point(Duct4X,  -Duct4W * 0.5,  Duct4H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct3BiasVert + VShiftDuct3, Duct4BiasVert + VShiftDuct4);
	 pPlate->ShiftHor(Duct3BiasHor, Duct4BiasHor);
	// pPlate->ShiftVert(VShiftDuct3, VShiftDuct4);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT3: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//11

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//10-11
	 lb0 = lb1; ru0 = ru1;

	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct3X, - Duct3W * 0.5,  Duct3H * 0.5);
	 p2 = C3Point(Duct3X,  Duct3W * 0.5, Duct3H * 0.5);
	 p1 = C3Point(Duct4X, - Duct4W * 0.5,  Duct4H * 0.5);
	 p3 = C3Point(Duct4X,  Duct4W * 0.5,  Duct4H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct3BiasVert + VShiftDuct3, Duct4BiasVert + VShiftDuct4);
	 pPlate->ShiftHor(Duct3BiasHor, Duct4BiasHor);
	// pPlate->ShiftVert(VShiftDuct3, VShiftDuct4);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT3: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct3X, - Duct3W * 0.5,  -Duct3H * 0.5);
	 p2 = C3Point(Duct3X,  Duct3W * 0.5, -Duct3H * 0.5);
	 p1 = C3Point(Duct4X, - Duct4W * 0.5,  -Duct4H * 0.5);
	 p3 = C3Point(Duct4X,  Duct4W * 0.5,  -Duct4H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct3BiasVert + VShiftDuct3, Duct4BiasVert + VShiftDuct4);
	 pPlate->ShiftHor(Duct3BiasHor, Duct4BiasHor);
	// pPlate->ShiftVert(VShiftDuct3, VShiftDuct4);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT3: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	//--------- DUCT4 ----------------------------
	diaphragm.Number = 12; // Duct5

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct4X,  Duct4W * 0.5, - Duct4H * 0.5);
	 p1 = C3Point(Duct5X,  Duct5W * 0.5, - Duct5H * 0.5);
	 p2 = C3Point(Duct4X,  Duct4W * 0.5,  Duct4H * 0.5);
	 p3 = C3Point(Duct5X,  Duct5W * 0.5,  Duct5H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct4BiasVert + VShiftDuct4, Duct5BiasVert + VShiftDuct5);
	 pPlate->ShiftHor(Duct4BiasHor, Duct5BiasHor);
	// pPlate->ShiftVert(VShiftDuct4, VShiftDuct5);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT4: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct4X,  -Duct4W * 0.5, - Duct4H * 0.5);
	 p1 = C3Point(Duct5X,  -Duct5W * 0.5, - Duct5H * 0.5);
	 p2 = C3Point(Duct4X,  -Duct4W * 0.5,  Duct4H * 0.5);
	 p3 = C3Point(Duct5X,  -Duct5W * 0.5,  Duct5H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct4BiasVert + VShiftDuct4, Duct5BiasVert + VShiftDuct5);
	 pPlate->ShiftHor(Duct4BiasHor, Duct5BiasHor);
	// pPlate->ShiftVert(VShiftDuct4, VShiftDuct5);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT4: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//12

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//11-12
	 lb0 = lb1; ru0 = ru1;

	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct4X, - Duct4W * 0.5,  Duct4H * 0.5);
	 p2 = C3Point(Duct4X,  Duct4W * 0.5, Duct4H * 0.5);
	 p1 = C3Point(Duct5X, - Duct5W * 0.5,  Duct5H * 0.5);
	 p3 = C3Point(Duct5X,  Duct5W * 0.5,  Duct5H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct4BiasVert + VShiftDuct4, Duct5BiasVert + VShiftDuct5);
	 pPlate->ShiftHor(Duct4BiasHor, Duct5BiasHor);
	// pPlate->ShiftVert(VShiftDuct4, VShiftDuct5);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT4: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct4X, - Duct4W * 0.5,  -Duct4H * 0.5);
	 p2 = C3Point(Duct4X,  Duct4W * 0.5, -Duct4H * 0.5);
	 p1 = C3Point(Duct5X, - Duct5W * 0.5,  -Duct5H * 0.5);
	 p3 = C3Point(Duct5X,  Duct5W * 0.5,  -Duct5H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct4BiasVert + VShiftDuct4, Duct5BiasVert + VShiftDuct5);
	 pPlate->ShiftHor(Duct4BiasHor, Duct5BiasHor);
	// pPlate->ShiftVert(VShiftDuct4, VShiftDuct5);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT4: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	//--------- DUCT5 ----------------------------
	diaphragm.Number = 13; // Duct6

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct5X,  Duct5W * 0.5, - Duct5H * 0.5);
	 p1 = C3Point(Duct6X,  Duct6W * 0.5, - Duct6H * 0.5);
	 p2 = C3Point(Duct5X,  Duct5W * 0.5,  Duct5H * 0.5);
	 p3 = C3Point(Duct6X,  Duct6W * 0.5,  Duct6H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct5BiasVert + VShiftDuct5, Duct6BiasVert + VShiftDuct6);
	 pPlate->ShiftHor(Duct5BiasHor, Duct6BiasHor);
	// pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT5: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct5X,  -Duct5W * 0.5, - Duct5H * 0.5);
	 p1 = C3Point(Duct6X,  -Duct6W * 0.5, - Duct6H * 0.5);
	 p2 = C3Point(Duct5X,  -Duct5W * 0.5,  Duct5H * 0.5);
	 p3 = C3Point(Duct6X,  -Duct6W * 0.5,  Duct6H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct5BiasVert + VShiftDuct5, Duct6BiasVert + VShiftDuct6);
	 pPlate->ShiftHor(Duct5BiasHor, Duct6BiasHor);
	 //pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT5: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//13

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//12-13
	 lb0 = lb1; ru0 = ru1;

	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct5X, - Duct5W * 0.5,  Duct5H * 0.5);
	 p2 = C3Point(Duct5X,  Duct5W * 0.5, Duct5H * 0.5);
	 p1 = C3Point(Duct6X, - Duct6W * 0.5,  Duct6H * 0.5);
	 p3 = C3Point(Duct6X,  Duct6W * 0.5,  Duct6H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct5BiasVert + VShiftDuct5, Duct6BiasVert + VShiftDuct6);
	 pPlate->ShiftHor(Duct5BiasHor, Duct6BiasHor);
	// pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT5: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct5X, - Duct5W * 0.5,  -Duct5H * 0.5);
	 p2 = C3Point(Duct5X,  Duct5W * 0.5, -Duct5H * 0.5);
	 p1 = C3Point(Duct6X, - Duct6W * 0.5,  -Duct6H * 0.5);
	 p3 = C3Point(Duct6X,  Duct6W * 0.5,  -Duct6H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct5BiasVert + VShiftDuct5, Duct6BiasVert + VShiftDuct6);
	 pPlate->ShiftHor(Duct5BiasHor, Duct6BiasHor);
	 //pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT5: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	//--------- DUCT6 ----------------------------
	diaphragm.Number = 14; // Duct7

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct6X,  Duct6W * 0.5, - Duct6H * 0.5);
	 p1 = C3Point(Duct7X,  Duct7W * 0.5, - Duct7H * 0.5);
	 p2 = C3Point(Duct6X,  Duct6W * 0.5,  Duct6H * 0.5);
	 p3 = C3Point(Duct7X,  Duct7W * 0.5,  Duct7H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct6BiasVert + VShiftDuct6, Duct7BiasVert + VShiftDuct7);
	 pPlate->ShiftHor(Duct6BiasHor, Duct7BiasHor);
	// pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT6: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct6X,  -Duct6W * 0.5, - Duct6H * 0.5);
	 p1 = C3Point(Duct7X,  -Duct7W * 0.5, - Duct7H * 0.5);
	 p2 = C3Point(Duct6X,  -Duct6W * 0.5,  Duct6H * 0.5);
	 p3 = C3Point(Duct7X,  -Duct7W * 0.5,  Duct7H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct6BiasVert + VShiftDuct6, Duct7BiasVert + VShiftDuct7);
	 pPlate->ShiftHor(Duct6BiasHor, Duct7BiasHor);
	 //pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT6: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//14

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//13-14
	 lb0 = lb1; ru0 = ru1;

	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct6X, - Duct6W * 0.5,  Duct6H * 0.5);
	 p2 = C3Point(Duct6X,  Duct6W * 0.5, Duct6H * 0.5);
	 p1 = C3Point(Duct7X, - Duct7W * 0.5,  Duct7H * 0.5);
	 p3 = C3Point(Duct7X,  Duct7W * 0.5,  Duct7H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct6BiasVert + VShiftDuct6, Duct7BiasVert + VShiftDuct7);
	 pPlate->ShiftHor(Duct6BiasHor, Duct7BiasHor);
	// pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT6: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct6X, - Duct6W * 0.5,  -Duct6H * 0.5);
	 p2 = C3Point(Duct6X,  Duct6W * 0.5, -Duct6H * 0.5);
	 p1 = C3Point(Duct7X, - Duct7W * 0.5,  -Duct7H * 0.5);
	 p3 = C3Point(Duct7X,  Duct7W * 0.5,  -Duct7H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct6BiasVert + VShiftDuct6, Duct7BiasVert + VShiftDuct7);
	 pPlate->ShiftHor(Duct6BiasHor, Duct7BiasHor);
	 //pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT6: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	//--------- DUCT7 ----------------------------
	diaphragm.Number = 15; // Duct8

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct7X,  Duct7W * 0.5, - Duct7H * 0.5);
	 p1 = C3Point(Duct8X,  Duct8W * 0.5, - Duct8H * 0.5);
	 p2 = C3Point(Duct7X,  Duct7W * 0.5,  Duct7H * 0.5);
	 p3 = C3Point(Duct8X,  Duct8W * 0.5,  Duct8H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct7BiasVert + VShiftDuct7, Duct8BiasVert + VShiftDuct8);
	 pPlate->ShiftHor(Duct7BiasHor, Duct8BiasHor);
	// pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT7: left wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[2] = pPlate->Corn[2];

	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct7X,  -Duct7W * 0.5, - Duct7H * 0.5);
	 p1 = C3Point(Duct8X,  -Duct8W * 0.5, - Duct8H * 0.5);
	 p2 = C3Point(Duct7X,  -Duct7W * 0.5,  Duct7H * 0.5);
	 p3 = C3Point(Duct8X,  -Duct8W * 0.5,  Duct8H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct7BiasVert + VShiftDuct7, Duct8BiasVert + VShiftDuct8);
	 pPlate->ShiftHor(Duct7BiasHor, Duct8BiasHor);
	 //pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT7: right wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);
	diaphragm.Corn[0] = pPlate->Corn[1];
	Dia_Array.Add(diaphragm);//15

	lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	 vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	 VolumeVector.push_back(vol);//14-15
	 lb0 = lb1; ru0 = ru1;

	pPlate = new CPlate(); // upper
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct7X, - Duct7W * 0.5,  Duct7H * 0.5);
	 p2 = C3Point(Duct7X,  Duct7W * 0.5, Duct7H * 0.5);
	 p1 = C3Point(Duct8X, - Duct8W * 0.5,  Duct8H * 0.5);
	 p3 = C3Point(Duct8X,  Duct8W * 0.5,  Duct8H * 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct7BiasVert + VShiftDuct7, Duct8BiasVert + VShiftDuct8);
	 pPlate->ShiftHor(Duct8BiasHor, Duct8BiasHor);
	// pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT7: top wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // lower
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct7X, - Duct7W * 0.5,  -Duct7H * 0.5);
	 p2 = C3Point(Duct7X,  Duct7W * 0.5, -Duct7H * 0.5);
	 p1 = C3Point(Duct8X, - Duct8W * 0.5,  -Duct8H * 0.5);
	 p3 = C3Point(Duct8X,  Duct8W * 0.5,  -Duct8H * 0.5);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->ShiftVert(Duct7BiasVert + VShiftDuct7, Duct8BiasVert + VShiftDuct8);
	 pPlate->ShiftHor(Duct7BiasHor, Duct8BiasHor);
	 //pPlate->ShiftVert(VShiftDuct5, VShiftDuct6);
	pPlate->Solid = TRUE;
	pPlate->Comment = "DUCT7: bottom wall";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	DuctExitYmin = -Duct8W * 0.5 + Duct8BiasHor;
	DuctExitYmax = Duct8W * 0.5 + Duct8BiasHor;
	DuctExitZmin = -Duct8H * 0.5 + VShiftDuct8 + Duct8BiasVert;
	DuctExitZmax = Duct8H * 0.5 + VShiftDuct8 + Duct8BiasVert; 

	 pPlate = new CPlate(); // at Duct Exit
	 PlateCounter++;
	 pPlate->Number = PlateCounter; 
	 p0 = C3Point(Duct8X + 0.02, -Duct8W * 0.5, -Duct8H * 0.5);
	 p3 = C3Point(Duct8X + 0.02, Duct8W * 0.5, Duct8H * 0.5);
	// pPlate->SetFromLimits(p0, p3);
	 p0 = C3Point(Duct8X + 0.02, - Duct8W, -Duct8H);
	 p1 = C3Point(Duct8X + 0.02,  Duct8W,  -Duct8H);
	 p2 = C3Point(Duct8X + 0.02, - Duct8W, Duct8H);
	 p3 = C3Point(Duct8X + 0.02,  Duct8W,  Duct8H);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 pPlate->Shift(0, Duct8BiasHor, VShiftDuct8 + Duct8BiasVert);
	 //pPlate->Shift(0,0, VShiftDia);
	 pPlate->Solid = FALSE;
	 pPlate->Visible = FALSE;
	 S.Format("Duct Exit Cross-plane, X = %g m", Duct8X + 0.01);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);
}
void CBTRDoc::SetDuctDia() // duct crosses
{
	C3Point p0, p1, p2, p3;
	CString S;
	CPlate * pPlate;
	
	//diaphragm.Number = 5; // PreDuct
	pPlate = new CPlate(); //Pre-Duct Diafragm
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(PreDuctX, AreaHorMin, AreaVertMin);
	p1 = C3Point(PreDuctX, AreaHorMax, AreaVertMin);
	p2 = C3Point(PreDuctX, AreaHorMin, AreaVertMax);
	p3 = C3Point(PreDuctX, AreaHorMax, AreaVertMax);
	pPlate->OrtDirect = -1;
	pPlate->SetLocals(p0, p1, p2, p3);
	//pPlate->Shift(0, DiaBiasHor, VShiftDia + DiaBiasVert);
	//pPlate->Corn[0].Z = AreaVertMin; pPlate->Corn[1].Z = AreaVertMin;
	//pPlate->SetLocals(pPlate->Corn[0], pPlate->Corn[1], pPlate->Corn[3], pPlate->Corn[2]);
	//pPlate->Shift(0,0, VShiftDia);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia5 (Scraper1)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
	//diaphragm.Corn[0] = pPlate->Corn[3]; //p2
	
	//diaphragm.Number = 6; // DDLinerIn
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(DDLinerInX, AreaHorMin, AreaVertMin);
	p1 = C3Point(DDLinerInX, AreaHorMax, AreaVertMin);
	p2 = C3Point(DDLinerInX, AreaHorMin, AreaVertMax);
	p3 = C3Point(DDLinerInX, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	//pPlate->ShiftVert(DiaBiasVert + VShiftDia, LinerBiasInVert + VShiftLinerIn);
	//pPlate->ShiftHor(DiaBiasHor, LinerBiasOutHor);
	//pPlate->Shift(0, LinerHBias, VShiftLinerIn + LinerVBias);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia6 (Scraper2)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
	//diaphragm.Corn[2] = pPlate->Corn[2];//p3
	
	//diaphragm.Number = 7; //DDLinerOutX
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(DDLinerOutX, AreaHorMin, AreaVertMin);
	p1 = C3Point(DDLinerOutX, AreaHorMax, AreaVertMin);
	p2 = C3Point(DDLinerOutX, AreaHorMin, AreaVertMax);
	p3 = C3Point(DDLinerOutX, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia7 (DDL)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);

	//diaphragm.Number = 8; //Duct1X
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(Duct1X, AreaHorMin, AreaVertMin);
	p1 = C3Point(Duct1X, AreaHorMax, AreaVertMin);
	p2 = C3Point(Duct1X, AreaHorMin, AreaVertMax);
	p3 = C3Point(Duct1X, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia8 (Duct)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);

	//diaphragm.Number = 9; //Duct2X
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(Duct2X, AreaHorMin, AreaVertMin);
	p1 = C3Point(Duct2X, AreaHorMax, AreaVertMin);
	p2 = C3Point(Duct2X, AreaHorMin, AreaVertMax);
	p3 = C3Point(Duct2X, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia9 (Duct)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);

	//diaphragm.Number = 10; //Duct3X
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(Duct3X, AreaHorMin, AreaVertMin);
	p1 = C3Point(Duct3X, AreaHorMax, AreaVertMin);
	p2 = C3Point(Duct3X, AreaHorMin, AreaVertMax);
	p3 = C3Point(Duct3X, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia10 (Duct)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);

	//diaphragm.Number = 11; //Duct4X
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(Duct4X, AreaHorMin, AreaVertMin);
	p1 = C3Point(Duct4X, AreaHorMax, AreaVertMin);
	p2 = C3Point(Duct4X, AreaHorMin, AreaVertMax);
	p3 = C3Point(Duct4X, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia11 (Duct)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);

	//diaphragm.Number = 12; //Duct5X
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(Duct5X, AreaHorMin, AreaVertMin);
	p1 = C3Point(Duct5X, AreaHorMax, AreaVertMin);
	p2 = C3Point(Duct5X, AreaHorMin, AreaVertMax);
	p3 = C3Point(Duct5X, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia12 (Duct)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);

	//diaphragm.Number = 13; //Duct6X
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(Duct6X, AreaHorMin, AreaVertMin);
	p1 = C3Point(Duct6X, AreaHorMax, AreaVertMin);
	p2 = C3Point(Duct6X, AreaHorMin, AreaVertMax);
	p3 = C3Point(Duct6X, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia13 (Duct)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);

	//diaphragm.Number = 14; //Duct7X
	pPlate = new CPlate(); // 
	PlateCounter++;
	pPlate->Number = PlateCounter;
	p0 = C3Point(Duct7X, AreaHorMin, AreaVertMin);
	p1 = C3Point(Duct7X, AreaHorMax, AreaVertMin);
	p2 = C3Point(Duct7X, AreaHorMin, AreaVertMax);
	p3 = C3Point(Duct7X, AreaHorMax, AreaVertMax);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	pPlate->Comment = "Dia14 (Duct)";
	pPlate->Fixed = 1; // side view
	PlatesList.AddTail(pPlate);
	
	/*lb1 = diaphragm.Corn[0]; ru1 = diaphragm.Corn[2];
	vol = VOLUME(lb0, ru0, lb1, ru1, 1);
	VolumeVector.push_back(vol);//14-15
	lb0 = lb1; ru0 = ru1;*/

	pPlate = new CPlate(); // Duct8X,  Duct Exit
	PlateCounter++;
	pPlate->Number = PlateCounter;
	//p0 = C3Point(Duct8X, -Duct8W * 0.5, -Duct8H * 0.5);
	//p3 = C3Point(Duct8X, Duct8W * 0.5, Duct8H * 0.5);
	// pPlate->SetFromLimits(p0, p3);
	p0 = C3Point(Duct8X, -Duct8W, -Duct8H);
	p1 = C3Point(Duct8X, Duct8W, -Duct8H);
	p2 = C3Point(Duct8X, -Duct8W, Duct8H);
	p3 = C3Point(Duct8X, Duct8W, Duct8H);
	pPlate->OrtDirect = -1;
	pPlate->SetLocals(p0, p1, p2, p3);
	//pPlate->Shift(0, Duct8BiasHor, VShiftDuct8 + Duct8BiasVert);
	pPlate->Solid = FALSE;
	pPlate->Visible = FALSE;
	//S.Format("Duct Exit Cross-plane, X = %g m", Duct8X + 0.01);
	pPlate->Comment = "Dia15 (Exit)";
	PlatesList.AddTail(pPlate);

	DuctExitYmin = -Duct8W * 0.5 + Duct8BiasHor;
	DuctExitYmax = Duct8W * 0.5 + Duct8BiasHor;
	DuctExitZmin = -Duct8H * 0.5 + VShiftDuct8 + Duct8BiasVert;
	DuctExitZmax = Duct8H * 0.5 + VShiftDuct8 + Duct8BiasVert;
}

void  CBTRDoc:: ModifyArea(bool fixed)
{
	//AfxMessageBox("Enter ModifyArea");
	double Ymin, Ymax, Zmin, Zmax;
	if (!fixed) {
		GetBeamFootLimits(AreaLong, Ymin, Ymax, Zmin, Zmax);
		AreaHorMin = Min(CPlate::AbsYmin, Ymin);
		AreaHorMax = Max(CPlate::AbsYmax, Ymax);
		AreaVertMin = Min(CPlate::AbsZmin, Zmin);
		AreaVertMax = Max(CPlate::AbsZmax, Zmax);
	}

	CPlate * plate;
	C3Point p0, p1, p2, p3; 
	POSITION pos = PlatesList.GetHeadPosition();
	while (pos != NULL) {
		plate = PlatesList.GetNext(pos);
		if (plate->Number == 1 && plate->Comment.Find("Target") >= 0 && plate->Comment.Find("Plane") >=0) {
			p0 = C3Point(AreaLong, AreaHorMin, AreaVertMin);
			p1 = C3Point(AreaLong, AreaHorMax, AreaVertMin);
			p2 = C3Point(AreaLong, AreaHorMin, AreaVertMax);
			p3 = C3Point(AreaLong, AreaHorMax, AreaVertMax);
			
			if (plate->Loaded) {
				if (AfxMessageBox("Keep the existing load on the Target Plane?", MB_YESNO) == IDNO) {
					plate->Load->Clear(); 
					plate->Loaded = FALSE;
					plate->SetLocals(p0, p1, p2, p3);
					SetLoadArray(plate, FALSE);
				}
			}
			else plate->SetLocals(p0, p1, p2, p3);
		}
		if (plate->Number == 2 && plate->Comment.Find("Right") >= 0 && plate->Comment.Find("Limit") >=0) {
			p0 = C3Point(0, AreaHorMin, AreaVertMin);
			p1 = C3Point(AreaLong, AreaHorMin, AreaVertMin);
			p2 = C3Point(0, AreaHorMin, AreaVertMax);
			p3 = C3Point(AreaLong, AreaHorMin, AreaVertMax);
			
			if (plate->Loaded) {
				if (AfxMessageBox("Keep the existing load on the Right Limit?", MB_YESNO) == IDNO) {
					plate->Load->Clear(); 
					plate->Loaded = FALSE;
					plate->SetLocals(p0, p1, p2, p3);
					SetLoadArray(plate, FALSE);
				}
			}
			else plate->SetLocals(p0, p1, p2, p3);
			
		}
		if (plate->Number == 3 && plate->Comment.Find("Left") >= 0 && plate->Comment.Find("Limit") >=0) {
			p0 = C3Point(0, AreaHorMax, AreaVertMin);
			p1 = C3Point(AreaLong, AreaHorMax, AreaVertMin);
			p2 = C3Point(0, AreaHorMax, AreaVertMax);
			p3 = C3Point(AreaLong, AreaHorMax, AreaVertMax);
			
			if (plate->Loaded) {
				if (AfxMessageBox("Keep the existing load on the Left Limit?", MB_YESNO) == IDNO) {
					plate->Load->Clear(); 
					plate->Loaded = FALSE;
					plate->SetLocals(p0, p1, p2, p3);
					SetLoadArray(plate, FALSE);
				}
			}
			else plate->SetLocals(p0, p1, p2, p3);
			
		}
		if (plate->Number == 4 && plate->Comment.Find("Bottom") >= 0 && plate->Comment.Find("Limit") >=0) {
			p0 = C3Point(0, AreaHorMin, AreaVertMin);
			p1 = C3Point(AreaLong, AreaHorMin, AreaVertMin);
			p2 = C3Point(0, AreaHorMax, AreaVertMin);
			p3 = C3Point(AreaLong, AreaHorMax, AreaVertMin);
			
			if (plate->Loaded) {
				if (AfxMessageBox("Keep the existing load on the Bottom limit?", MB_YESNO) == IDNO) {
					plate->Load->Clear(); 
					plate->Loaded = FALSE;
					plate->SetLocals(p0, p1, p2, p3);
					SetLoadArray(plate, FALSE);
				}
			}
			else plate->SetLocals(p0, p1, p2, p3);
			
		}
		if (plate->Number == 5 && plate->Comment.Find("Top") >= 0 && plate->Comment.Find("Limit") >=0) {
			p0 = C3Point(0, AreaHorMin, AreaVertMax);
			p1 = C3Point(AreaLong, AreaHorMin, AreaVertMax);
			p2 = C3Point(0, AreaHorMax, AreaVertMax);
			p3 = C3Point(AreaLong, AreaHorMax, AreaVertMax);
			
			if (plate->Loaded) {
				if (AfxMessageBox("Keep the existing load on the Top Limit?", MB_YESNO) == IDNO) {
					plate->Load->Clear(); 
					plate->Loaded = FALSE;
					plate->SetLocals(p0, p1, p2, p3);
					SetLoadArray(plate, FALSE);
				}
			}
			else plate->SetLocals(p0, p1, p2, p3);
			
			break;
		}
		if (plate->Number < 5) continue;
	} // pos
	CalcLimitXmax = AreaLong + 1;

}

void  CBTRDoc::SetPlates() // free
{
	//AfxMessageBox("Enter SetPlates");
	CPlate * pPlate;
	CString S;
	PlateCounter = 0;
	C3Point p0, p1, p2, p3; // in Central Channel CS
		
	while (!PlatesList.IsEmpty()) {
		delete PlatesList.RemoveHead();// delete plate (head)
	}

	Sorted_Load_Ind.RemoveAll();
	SetLoadArray(NULL, FALSE);
	LoadSelected = 0;
	SmoothDegree = 0;
	OptCombiPlot = -1; ///-1 - no load, 0 - map is calculated, >0 - selected but not calculated 
	Dia_Array.RemoveAll();
	VolumeVector.clear();
	ExitArray.RemoveAll();
	ClearSumPower();
	
	CPlate::InitAbsLimits();
	//CPlate::AbsYmin = 1000; CPlate::AbsYmax = -1000;
	//CPlate::AbsZmin = 1000; CPlate::AbsZmax = -1000;

	double Ymin, Ymax, Zmin, Zmax;
	GetBeamFootLimits(AreaLong, Ymin, Ymax, Zmin, Zmax);
	AreaHorMin = Min(AreaHorMin, Ymin);
	AreaHorMax = Max(AreaHorMax, Ymax);
	AreaVertMin = Min(AreaVertMin, Zmin);
	AreaVertMax = Max(AreaVertMax, Zmax);

	CalcLimitXmax = AreaLong + 1;

	pPlate = new CPlate(); // Xmax
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(AreaLong, AreaHorMin, AreaVertMin);
	 p1 = C3Point(AreaLong, AreaHorMax, AreaVertMin);
	 p2 = C3Point(AreaLong, AreaHorMin, AreaVertMax);
	 p3 = C3Point(AreaLong, AreaHorMax, AreaVertMax);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
//	 pPlate->SetFromLimits(p0, p3);
	 pPlate->Solid = TRUE;
	 pPlate->Visible = FALSE;
	 S.Format("Area Target Plane X = %g m", AreaLong);
	 pPlate->Comment = S;
//	 SelectPlate(pPlate);//pPlate->Selected = TRUE; SetLoadArray(pPlate, TRUE); 
	PlatesList.AddTail(pPlate);

	pPlate = new CPlate(); // Right (HorMin) limit
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(0, AreaHorMin, AreaVertMin);
	 p1 = C3Point(AreaLong, AreaHorMin, AreaVertMin);
	 p2 = C3Point(0, AreaHorMin, AreaVertMax);
	 p3 = C3Point(AreaLong, AreaHorMin, AreaVertMax);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	// pPlate->SetFromLimits(p0, p3);
	 pPlate->Solid = TRUE;
	 pPlate->Visible = FALSE;
	 S.Format("Right Vertical Limit Y = %g m", AreaHorMin);
	 pPlate->Comment = S;
	PlatesList.AddTail(pPlate);

	pPlate = new CPlate(); // Left (HorMax) limit
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(0, AreaHorMax, AreaVertMin);
	 p1 = C3Point(AreaLong, AreaHorMax, AreaVertMin);
	 p2 = C3Point(0, AreaHorMax, AreaVertMax);
	 p3 = C3Point(AreaLong, AreaHorMax, AreaVertMax);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 //pPlate->SetFromLimits(p0, p3);
	 pPlate->Solid = TRUE;
	 pPlate->Visible = FALSE;
	 S.Format("Left Vertical Limit Y = %g m", AreaHorMax);
	 pPlate->Comment = S;
	PlatesList.AddTail(pPlate);

	pPlate = new CPlate(); // Bottom (VertMin)
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(0, AreaHorMin, AreaVertMin);
	 p1 = C3Point(AreaLong, AreaHorMin, AreaVertMin);
	 p2 = C3Point(0, AreaHorMax, AreaVertMin);
	 p3 = C3Point(AreaLong, AreaHorMax, AreaVertMin);
	 pPlate->SetLocals(p0, p1, p2, p3);
	 //pPlate->SetFromLimits(p0, p3);
	 pPlate->Solid = TRUE;
	 pPlate->Visible = FALSE;
	 S.Format("Bottom Horizontal Limit Z = %g m", AreaVertMin);
	 pPlate->Fixed = 1; // side view
	 pPlate->Comment = S;
	PlatesList.AddTail(pPlate); 

	pPlate = new CPlate();// Top (VertMax)
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(0, AreaHorMin, AreaVertMax);
	 p1 = C3Point(AreaLong, AreaHorMin, AreaVertMax);
	 p2 = C3Point(0, AreaHorMax, AreaVertMax);
	 p3 = C3Point(AreaLong, AreaHorMax, AreaVertMax);
	 pPlate->OrtDirect = -1;
	 pPlate->SetLocals(p0, p1, p2, p3);
	 //pPlate->SetFromLimits(p0, p3);
	 pPlate->Solid = TRUE;
	 pPlate->Visible = FALSE;
	 S.Format("Top Horizontal Limit Z = %g m", AreaVertMax);
	 pPlate->Fixed = 1; // side view
	 pPlate->Comment = S;
	PlatesList.AddTail(pPlate);

	
	if (!OptFree) {
		SetPlatesNBI(); // standard config
		/*AreaHorMin = Min(CPlate::AbsYmin, AreaHorMin);
		AreaHorMax = Max(CPlate::AbsYmax, AreaHorMax);
		AreaVertMin = Min(CPlate::AbsZmin, AreaVertMin);
		AreaVertMax = Max(CPlate::AbsZmax, AreaVertMax);*/
		ModifyArea(TRUE);
	} // adjust area limits

	
	if (AddPlatesNumber > 0)
	{
		AfxMessageBox("Appending Add Plates");
		AppendAddPlates();
		//PlateCounter+= AddPlatesNumber;
		CString S;
		S.Format("added %d, total %d", AddPlatesNumber, PlateCounter);
		ModifyArea(TRUE);
	}

	pMarkedPlate = &emptyPlate;// NULL;
	//AfxMessageBox("Exit SetPlates");
	S.Format("SetPlates: %d TOTAL COUNT ", PlateCounter);
	AfxMessageBox(S);
	
}

void  CBTRDoc::SetPlatesNBI() // NBI config
{
	//AfxMessageBox("Enter SetPlatesNBI");
	CWaitCursor wait;
	CString S;
	C3Point p0_, p1_, p2_, p3_; // in local CS of Side Channel
	C3Point p0, p1, p2, p3; // in Central Channel CS
	CPlate * pPlate;
	
	/*while (!PlatesList.IsEmpty()) {
		delete PlatesList.RemoveHead();// delete plate (head)
	}*/
	
	SetVShifts();

//	pMarkedPlate = NULL;

	//SetLoadArray(NULL, FALSE);
	
//	AdjustAreaLimits();
	/* RECT_DIA diaphragm;
	diaphragm.Corn[0] = C3Point(0.001, AreaHorMin, AreaVertMin);
	diaphragm.Corn[1] = C3Point(0.001, AreaHorMax, AreaVertMin);
	diaphragm.Corn[2] = C3Point(0.001, AreaHorMax, AreaVertMax);
	diaphragm.Corn[3] = C3Point(0.001, AreaHorMin, AreaVertMax);
	diaphragm.Number = 0;
	Dia_Array.Add(diaphragm);*/

	SetPlatesNeutraliser();
	SetPlatesRID();
	

// ----------Calorimeter -------------------------------------------
//	!OptCalOpen ? CalOutW = 0.0 : CalOutW = CalInW;
	if (!OptCalOpen) CalOutW = 0.0;
	
	pPlate = new CPlate(); // left
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(CalInX,  CalInW * 0.5, -CalH * 0.5);
	 p1 = C3Point(CalOutX, CalOutW * 0.5, -CalH * 0.5);
	 p2 = C3Point(CalInX,  CalInW * 0.5, CalH * 0.5);
	 p3 = C3Point(CalOutX, CalOutW * 0.5, CalH * 0.5);
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Shift(0,0, VShiftCal);
	pPlate->Comment = "Calorimeter Left Wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);


	pPlate = new CPlate(); // right
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(CalInX,  -CalInW * 0.5, -CalH * 0.5);
	 p1 = C3Point(CalOutX, -CalOutW * 0.5, -CalH * 0.5);
	 p2 = C3Point(CalInX,  -CalInW * 0.5, CalH * 0.5);
	 p3 = C3Point(CalOutX, -CalOutW * 0.5, CalH * 0.5);	
	 pPlate->OrtDirect = -1;
	pPlate->SetLocals(p0, p1, p2, p3);
	pPlate->Shift(0,0, VShiftCal);
	pPlate->Comment = "Calorimeter Right Wall";
	PlatesList.AddTail(pPlate);
//	if (TaskReionization)  SelectPlate(pPlate);

	pPlate = new CPlate(); // Exit 
	PlateCounter++;
	pPlate->Number = PlateCounter; 
	 p0 = C3Point(CalOutX + 0.01, -CalOutW * 0.5 - 0.5, -CalH * 0.5 - 0.5);
	 p3 = C3Point(CalOutX + 0.01, CalOutW * 0.5 + 0.5,  CalH * 0.5 + 0.5);
	 pPlate->OrtDirect = -1;
	 pPlate->SetFromLimits(p0, p3); 
	 //pPlate->Shift(0, RIDBiasOutHor, VShiftRID + RIDBiasOutVert);
	 pPlate->Shift(0,0, VShiftCal);
	 pPlate->Solid = FALSE;
	 pPlate->Visible = FALSE;
	 S.Format("Calorimeter Exit plane X = %g m", CalOutX + 0.2);
	 pPlate->Comment = S;
	 PlatesList.AddTail(pPlate);
//	 if (TaskRID)  SelectPlate(pPlate);


//-------------------------------------------------------
	SetPlatesDuct();
	SetPlasmaGeom();
	if (!FWdataLoaded) 
		InitFWarray();

//  ------------- AREA -----removed--------------------------------

	// Movable Target Plates -------------------------
	double Ymin, Ymax, Zmin, Zmax;
	double shiftY, shiftZ;
	C3Point P;
	//if (!OptBeamInPlasma) return;
	if (MovX < AreaLong - 0.1) {
		pPlate = new CPlate();
		PlateCounter++;
		pPlate->Number = PlateCounter;
		p0 = C3Point(MovX, -MovHor, -MovVert);
		p1 = C3Point(MovX, MovHor, -MovVert);
		p2 = C3Point(MovX, -MovHor, MovVert);
		p3 = C3Point(MovX, MovHor, MovVert);
		pPlate->OrtDirect = -1;
		pPlate->SetLocals(p0, p1, p2, p3);
		// pPlate->Shift(0, 0, MovShiftVert);
		P = GetBeamFootLimits(MovX, Ymin, Ymax, Zmin, Zmax);
		shiftY = P.Y; //0.5 * (Ymin + Ymax);
		shiftZ = P.Z; //0.5 * (Zmin + Zmax);
		pPlate->Shift(0, shiftY, shiftZ);
		pPlate->Solid = FALSE;
		pPlate->Visible = FALSE;
		S.Format("Mov1 Target plane X = %g m", MovX);
		pPlate->Comment = S;
		// pPlate->Fixed = 1; // side view
		PlatesList.AddTail(pPlate);
	}

	if (Mov2X < AreaLong - 0.1) {
		pPlate = new CPlate();
		PlateCounter++;
		pPlate->Number = PlateCounter;
		p0 = C3Point(Mov2X, -Mov2Hor, -Mov2Vert);
		p1 = C3Point(Mov2X, Mov2Hor, -Mov2Vert);
		p2 = C3Point(Mov2X, -Mov2Hor, Mov2Vert);
		p3 = C3Point(Mov2X, Mov2Hor, Mov2Vert);
		pPlate->OrtDirect = -1;
		pPlate->SetLocals(p0, p1, p2, p3);
		// pPlate->Shift(0, 0, Mov2ShiftVert);
		P = GetBeamFootLimits(Mov2X, Ymin, Ymax, Zmin, Zmax);
		shiftY = P.Y; //0.5 * (Ymin + Ymax);
		shiftZ = P.Z;//0.5 * (Zmin + Zmax);
		pPlate->Shift(0, shiftY, shiftZ);
		pPlate->Solid = FALSE;
		pPlate->Visible = FALSE;
		S.Format("Mov2 Target plane X = %g m", Mov2X);
		pPlate->Comment = S;
		// pPlate->Fixed = 1; // side view
		PlatesList.AddTail(pPlate);
	}

	if (Mov3X < AreaLong - 0.1) {
		pPlate = new CPlate();
		PlateCounter++;
		pPlate->Number = PlateCounter;
		p0 = C3Point(Mov3X, -Mov3Hor, -Mov3Vert);
		p1 = C3Point(Mov3X, Mov3Hor, -Mov3Vert);
		p2 = C3Point(Mov3X, -Mov3Hor, Mov3Vert);
		p3 = C3Point(Mov3X, Mov3Hor, Mov3Vert);
		pPlate->OrtDirect = -1;
		pPlate->SetLocals(p0, p1, p2, p3);
		//pPlate->Shift(0, 0, Mov3ShiftVert);
		P = GetBeamFootLimits(Mov3X, Ymin, Ymax, Zmin, Zmax);
		shiftY = P.Y; //0.5 * (Ymin + Ymax);
		shiftZ = P.Z; //0.5 * (Zmin + Zmax);
		pPlate->Shift(0, shiftY, shiftZ);
		pPlate->Solid = FALSE;
		pPlate->Visible = FALSE;
		S.Format("Mov3 Target plane X = %g m", Mov3X);
		pPlate->Comment = S;
		//pPlate->Fixed = 1; // side view
		PlatesList.AddTail(pPlate);
	}

	if (MovX < AreaLong - 0.1) {
		pPlate = new CPlate();
		PlateCounter++;
		pPlate->Number = PlateCounter;
		p0 = C3Point(Mov4X, -Mov4Hor, -Mov4Vert);
		p1 = C3Point(Mov4X, Mov4Hor, -Mov4Vert);
		p2 = C3Point(Mov4X, -Mov4Hor, Mov4Vert);
		p3 = C3Point(Mov4X, Mov4Hor, Mov4Vert);
		pPlate->OrtDirect = -1;
		pPlate->SetLocals(p0, p1, p2, p3);
		//pPlate->Shift(0, 0, Mov4ShiftVert);
		P = GetBeamFootLimits(Mov4X, Ymin, Ymax, Zmin, Zmax);
		shiftY = P.Y; //0.5 * (Ymin + Ymax);
		shiftZ = P.Z; //0.5 * (Zmin + Zmax);
		pPlate->Shift(0, shiftY, shiftZ);
		pPlate->Solid = FALSE;
		pPlate->Visible = FALSE;
		S.Format("Mov4 Target plane X = %g m", Mov4X);
		pPlate->Comment = S;
		// pPlate->Fixed = 1; // side view
		PlatesList.AddTail(pPlate);
	}

	if (PlasmaXmax - PlasmaXmin < 1.e-6) return; // beam misses plasma

	double Y0min, Y0max, Z0min, Z0max, Y1min, Y1max, Z1min, Z1max;
	C3Point P0, P1;
	P0 = GetBeamFootLimits(PlasmaXmin-1, Y0min, Y0max, Z0min, Z0max);
	P1 = GetBeamFootLimits(PlasmaXmax+1, Y1min, Y1max, Z1min, Z1max);
	Ymin = Min(Y0min, Y1min); Ymax = Max(Y0max, Y1max);
	Zmin = Min(Z0min, Z1min); Zmax = Max(Z0max, Z1max);

	//C3Point p0, p1, p2, p3;
	p0 = C3Point(PlasmaXmin-1, Ymin - 0.05, 0.); //AreaHorMin
	p1 = C3Point(PlasmaXmax+1, Ymin - 0.05, 0.); //AreaHorMin
	p2 = C3Point(PlasmaXmin-1, Ymax + 0.05, 0.); //AreaHorMax
	p3 = C3Point(PlasmaXmax+1, Ymax + 0.05, 0.); //AreaHorMax
	pBeamHorPlane = new CPlate(p0, p1, p2, p3);
	pBeamHorPlane->Number = 2000;
	pBeamHorPlane->Solid = FALSE;
	pBeamHorPlane->Comment = "NB in plasma - Horizontal plane";
	pBeamHorPlane->ApplyLoad(TRUE, 0.1, 0.05);

	p0 = C3Point(PlasmaXmin-1, 0., Zmin); //AreaVertMin);
	p1 = C3Point(PlasmaXmax-1, 0., Zmin); //AreaVertMin);
	p2 = C3Point(PlasmaXmin+1, 0., Zmax); //AreaVertMax);
	p3 = C3Point(PlasmaXmax+1, 0., Zmax); //AreaVertMax);
	pBeamVertPlane = new CPlate(p0, p1, p2, p3);
	pBeamVertPlane->Number = 2000;
	pBeamVertPlane->Solid = FALSE;
	pBeamVertPlane->Comment = "NB in plasma - Vertical plane";
	pBeamVertPlane->ApplyLoad(TRUE, 0.1, 0.05);

	if (OptBeamInPlasma && AreaLong >= TorCentreX) SetPlatesTor();
	
	//AppendAddPlates();
	//AfxMessageBox("Exit SetPlatesNBI");

}

void  CBTRDoc::InitAddPlates() // remove all
{
	//AfxMessageBox("InitAddPlates");
	while (!AddPlatesList.IsEmpty()) {
		delete AddPlatesList.RemoveHead();// delete plate (head)
	}
//	C3Point p0, p1, p2, p3; // in Central Channel CS
//	CPlate * pPlate;

//	 AddPlatesList.AddTail(pPlate);
	AddPlatesNumber = 0;//900;
}

CPlate* CBTRDoc::AddPlate(bool isSolid, C3Point p0, C3Point p1, C3Point p2, C3Point p3)
{
	CPlate * pPlate = new CPlate(); // new Plate
	 pPlate->SetArbitrary(p0, p1, p2, p3);
	// pPlate->SetFromLimits(p0, p3);
	 pPlate->Solid = isSolid;
	 pPlate->Visible = isSolid;
	 if (isSolid) pPlate->Comment = "Solid surface"; 
	 else pPlate->Comment = "Transparent surface"; 
	
	// AddPlate(pPlate);
	 AddPlatesList.AddTail(pPlate);
	 AddPlatesNumber++;
	 return (pPlate);
}

void CBTRDoc::AddPlate(CPlate * plate)
{
	AddPlatesList.AddTail(plate);
	AddPlatesNumber++;
}

void CBTRDoc::AppendAddPlates()
{
	CPlate * plate;
	CPlate * pPlate;
	POSITION pos = AddPlatesList.GetHeadPosition();
	C3Point p0, p1, p2, p3;
	CString S;
	int add = AddPlatesList.GetCount();
	S.Format("%d plates total %d to add", PlateCounter, add);
	AfxMessageBox(S);
	
	while (pos != NULL) {
		PlateCounter++;
		plate = AddPlatesList.GetNext(pos);
		//PlatesList.AddTail(plate);
		pPlate = new CPlate(); // new Plate - copy
		pPlate->Number = PlateCounter;
		p0 = C3Point(plate->Corn[0]);
		p1 = C3Point(plate->Corn[1]);
		p2 = C3Point(plate->Corn[3]);
		p3 = C3Point(plate->Corn[2]);
		pPlate->SetLocals(p0, p1, p2, p3);
		/*pPlate->Orig = plate->Orig;
		pPlate->OrtX = plate->OrtX;
		pPlate->OrtY = plate->OrtY;
		pPlate->OrtZ = plate->OrtZ;
		pPlate->Xmax = plate->Xmax;
		pPlate->Ymax = plate->Ymax;
		pPlate->MassCentre =plate->MassCentre;*/
		pPlate->Solid = plate->Solid;
		pPlate->Visible = pPlate->Solid;
		//pPlate->Loaded = plate->Loaded;
		pPlate->Fixed = -1;// plate->Fixed;// 0 - plan, 1 - side
		//pPlate->Selected = plate->Selected;
		//pPlate->Load = plate->Load;
		//pPlate->SmLoad = plate->SmLoad;
		//pPlate->SmoothDegree = plate->SmoothDegree;
		//pPlate->Number = plate->Number;
		//for (int i = 0; i < 4; i++)	pPlate->Corn[i] = plate->Corn[i];
		pPlate->Comment = "Add"; //plate->Comment;
		PlatesList.AddTail(pPlate);
		
		S.Format("%d plates total", PlateCounter);
		//AfxMessageBox(S);
		
	}
	
}

void CBTRDoc:: SelectAllPlates()
{
	CPlate * plate;
	POSITION pos = PlatesList.GetHeadPosition();

	if (LoadSelected > 0) { // list not empty -> unselect all delete loads
		while (pos != NULL) {
			plate = PlatesList.GetNext(pos);
			if (plate->Loaded) {
				//plate->Load->Clear();
				delete plate->Load;
				if (plate->SmLoad != NULL) delete plate->SmLoad;
				plate->AngularProfile.RemoveAll();
				plate->Loaded = FALSE;
				plate->Selected = FALSE;
				plate->Touched = FALSE;
				//SelectPlate(plate); // -
			}// loaded
		}
	SetLoadArray(NULL, FALSE);//+
	//InitAddPlates();
	
	}
	
	else { // empty -> select all
		while (pos != NULL) {
		plate = PlatesList.GetNext(pos);
		SelectPlate(plate);// make selected = true
		}
	
	}
	pLoadView->ShowLoad = FALSE;
	pMainView->InvalidateRect(NULL, TRUE);
	ShowStatus();

}
CPlate * CBTRDoc::GetPlateByNumber(int N)
{
	CPlate * plate;
	POSITION pos = PlatesList.GetHeadPosition();
	while (pos != NULL) {
		plate = PlatesList.GetNext(pos);
		if (plate->Number == N) return plate;
	}
	return NULL;
}

void CBTRDoc:: ClearAllPlates() // clear loads
{
	CPlate * plate;
	POSITION pos = PlatesList.GetHeadPosition();
	while (pos != NULL) {
		plate = PlatesList.GetNext(pos);
		plate->Touched = FALSE;
		if (plate->Loaded) {
			//plate->Load->Clear();
			delete (plate->Load); //->Clear(); 
			if (plate->SmLoad != NULL) delete plate->SmLoad;
		}
		plate->Loaded = FALSE;
		plate->Selected = FALSE;
		plate->Load = NULL;

	}
	ClearSumPower();
	SetLoadArray(NULL, FALSE);
	Load_Arr.RemoveAll();
	LoadSelected = 0;
	pLoadView->ShowLoad = FALSE;
	pMainView->InvalidateRect(NULL, TRUE);

	//ShowNothing();
}


void CBTRDoc::ReadPressure()
{
	//ReadGas();
	PressureLoaded = TRUE;
}

int CBTRDoc:: ReadMF_4col(char * name) // x bx by bz
{
	int lines = BField->ReadData(name);
	MagFieldDim = 1;
	return lines;
}

int CBTRDoc:: ReadMF_7col(char * name) // x  y  z  bx by bz babs
{
	int lines = BField3D->ReadData(name);
	MagFieldDim = 3;
	return lines;
}

int CBTRDoc:: ReadGas_2col(char * name, int add)
{
	int lines;
	if (add != 0) { 
		lines = AddGField->ReadData(name); 
		return lines; 
	} // addit profile

	lines = GField->ReadData(name);
	PressureDim = 1;
	return lines;
}

int CBTRDoc:: ReadGas_3col(char * name)
{
	int lines = GFieldXZ->ReadData(name);
	PressureDim = 2;
	return lines;
} 

void CBTRDoc::ReadRIDfield()
{
	char name[1024];
	CFileDialog dlg(TRUE, "dat; txt | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"E-field data (*.txt);(*.dat)  | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
	
	if (dlg.DoModal() == IDOK) {
			strcpy(name, dlg.GetPathName());
		
		/*	CPreviewDlg pdlg;
			pdlg.m_Filename = name;
			if (pdlg.DoModal() == IDCANCEL) {
				if (!RIDFieldLoaded) // not loaded before
					AfxMessageBox("No Field accepted from file\n default flat model is applied",
						MB_ICONINFORMATION | MB_OK);
				return;
			}
		*/
			RIDFieldLoaded = FALSE;
			int res = RIDField->ReadFullField(name);
			if (res < 1)	{
				AfxMessageBox("Invalid format",	MB_ICONSTOP | MB_OK); 
			}
			else RIDFieldLoaded = TRUE;

			return;
	} // IDOK
	
	else {
		if (!RIDFieldLoaded) // not loaded before
		AfxMessageBox("No Field accepted from file\n default flat model is applied", 
			MB_ICONINFORMATION | MB_OK);
		return;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBTRDoc serialization

void CBTRDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CBTRDoc diagnostics

#ifdef _DEBUG
void CBTRDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBTRDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBTRDoc commands

void CBTRDoc::OnDataActive() 
{
	DataLoaded = FALSE;
 	pDataView->OnDataActive();
//	SetTitle(TaskName);
 }

void CBTRDoc::OnDataGet_void()
{
	OnDataGet();
	OnShow();
}

int CBTRDoc::OnDataGet() // load config; finally calls BTRDoc::ReadData() 
{
	STOP = TRUE;
	OnStop();
//	OptParallel = FALSE;
	//OptFree = FALSE; // by default read standard NBI geom
	
	DataLoaded = FALSE;
	CWaitCursor wait; 
	
	// default settings (used when reading old data)
	OptDeuterium = TRUE;
	OptIndBeamlets = FALSE;
	OptThickNeutralization = FALSE;
	BeamSplitType = 0;
	VertInclin = 0;
	//OptIonPower = FALSE;
	OptNegIonPower = TRUE;
	OptPosIonPower = TRUE;
	OptAtomPower = TRUE;
	/// end ////////////

	if (ReadData() == 0) { // file -> m_Text 
		AfxMessageBox("Not read"); return 0; 
	} 

	if (m_Text.Find("NBI",0) > 0 
		&& m_Text.Find("CONFIG",0) > 0 
		&& m_Text.Find("Dia",0) > 0) OptFree = FALSE;
	else {
		OptFree = TRUE;
		AfxMessageBox("Free Surf option is ON");
	}

	ActiveCh.SetSize(10);
	ActiveRow.SetSize(10);
	//CString S = m_Text;

	UpdateDataArray(); // SetData // CheckData 
	TaskName += " -> " + GetTitle();

/*	pDataView->m_rich.SetWindowText(m_Text);
	pDataView->m_rich.SetModify(FALSE);
*/	

	if (MaxDataRead <2) { 
		AfxMessageBox("Problem with data format\n Without internal names?", MB_ICONSTOP | MB_OK);
		DataLoaded = FALSE;
	}
		if (!DataLoaded) {
		AfxMessageBox("Configuration is not changed!", MB_ICONSTOP | MB_OK); 
		//pDataView->OnDataActive();
		return(0); // not a Configuration File
	}

//	RIDField->Set();

	SetBeam(); // Aimings, IS positions
	InitPlasma();
	//SetPlasma();
	//SetDecayInPlasma();
	//	PlasmaMajorR = 6.2; // default tor R
	//	PlasmaMinorR = 2.2; // default tor r
	//  PlasmaMajorR = (FWRmin + FWRmax) * 0.5;
	//  PlasmaMinorR = (FWRmax - FWRmin) * 0.5;
/*	if (TorCentreX > 25) { //ITER
		FWRmin = 4.0; FWRmax = 8.4;//ITER
	}
	else {//TIN
		FWRmin = 2.0; FWRmax = 4.4;
	}
	*/
	SetPlates();//SetPlasma is called from SetPlatesNBI
	SetStatus();
	
	if (NofActiveChannels < 1) {
		for (int k=0; k < (int)NofChannelsHor; k++) ActiveCh[k] = TRUE;
		SetStatus();
	}
	if (NofActiveRows < 1) {
		for (int n=0; n < (int)NofChannelsVert; n++) ActiveRow[n] = TRUE;
		SetStatus();
	}

	if (OptDeuterium) TracePartType = -2;
	SetTraceParticle(TracePartType);
	SetNeutrCurrents();

	if (OptSINGAP)//	SetSINGAP(); // form BEAMLET_ENTRY array (apply midalign, active chan)
		OnPdpBeamlets(); //	SetStatus();

	if ((int)BeamSplitType ==0) SetPolarBeamletCommon(); //SetBeamletAt(0);
	else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 


	SetReionPercent();
	
	Progress = 0;

				//InitAddPlates();
	OnShow();
	return 1;
}

void CBTRDoc::OnDataImport_PDP_SINGAP() 
{
	if (!STOP) {
		AfxMessageBox("Stop calculations before reading new data! \n (Red cross on the Toolbar)");
		return;
	}
	
	int res;
	char name[1024];
//	char buf[1024];
	CFileDialog dlg(TRUE, "txt; bak | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"PDP INPUT file (*.txt); (*.bak) | *.txt; *.TXT; *.bak; *.BAK | All Files (*.*) | *.*||", NULL);
	if (dlg.DoModal() == IDOK) {
		strcpy(name, dlg.GetPathName());

		AddCommentToPDP(name);
	//	SetTitle(name);
	
		CPreviewDlg pdlg;
		pdlg.m_Filename = name;
		if (pdlg.DoModal() == IDCANCEL) return;

		if (ReadPDPinput(name) == 0) {
			res = AfxMessageBox("Data scan failed or not complete\n Do you want to edit the file?", 3); 
			if (res == IDYES) {
				ShowFileText(name); 
			} // edit file
			return; 
		} //fail
	
		else { // data loaded
			PDPgeomLoaded = TRUE; // scanned
			CheckData();
			if (!OptFree) { AdjustAreaLimits();	SetPlates();}
			SetReionPercent();
			SetNeutrCurrents();
		//	ShowFileText(name);
			OnShow();

		/*	res = AfxMessageBox("NBI geometry is accepted.\n\n Do you want to take the beam from file?",3);
			if (res == IDYES) OnPdpBeamlets();
			else { // NO -> MAMuG default */
				SetBeam(); // calculate ->IonBeam Power, Neutr Power NofBeamletsTotal
				for (int i = 0; i < (int)NofChannelsHor; i++) ActiveCh[i] = TRUE;
				for (int j = 0; j < (int)NofChannelsVert; j++) ActiveRow[j] = TRUE;
				SetStatus(); 
				if ((int)BeamSplitType ==0) SetPolarBeamletCommon(); //SetBeamletAt(0);
				else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ);
				OnShow();

				res = AfxMessageBox("To set MAMuG beam configuration use the Green Panel.\n"
					"SINGAP beam is to be taken from file\n (Menu -> PDP -> Beam) ");
		} // data loaded
	
	}//OK
}

void CBTRDoc::OnDataStore() // Update without save
{
	/*if (!STOP) {
		AfxMessageBox("Stop calculations before updating the data! \n (Red cross on the Toolbar)");
		return ;
	}*/

	STOP = TRUE;	//
	//OnStop();
	CWaitCursor wait; 
	DataLoaded = FALSE;
//	pDataView->OnDataStore();

	double NCH = NofChannelsHor;
	double NCV = NofChannelsVert;
	double SSH = SegmStepHor;
	double SSV = SegmStepVert;
	double BAH = BeamAimHor; 
	double BAV = BeamAimVert;
	
	double NBH = NofBeamletsHor;
	double NBV = NofBeamletsVert;
	double ASH = AppertStepHor;
	double ASV = AppertStepVert;
	double AAH = AppertAimHor; 
	double AAV = AppertAimVert;

	m_Text.Empty();
	CString S;
	pDataView->m_rich.GetWindowText(S); //pDoc->m_Text);
	m_Text = S; // S -> m_Text;
	if (m_Text.Find("BTR") <= 0 && m_Text.Find("INPUT") <= 0){
		OnDataActive();
		//OnShow();
		//return;
	}
	
	ActiveCh.SetSize(10);
	ActiveRow.SetSize(10);	
	
	UpdateDataArray();

	pDataView->m_rich.SetFont(&pDataView->font, TRUE);
	pDataView->m_rich.SetBackgroundColor(FALSE, RGB(210,250,200));
	pDataView->m_rich.SetWindowText(m_Text);
	pDataView->m_rich.SetModify(FALSE);

	BOOL MAMuGchanged = FALSE;
	if (fabs(NCH - NofChannelsHor) > 1.e-6 || fabs(NCV - NofChannelsVert) > 1.e-6 
		|| fabs(SSH - SegmStepHor) > 1.e-6 || fabs(SSV - SegmStepVert) > 1.e-6 
		|| fabs(BAH - BeamAimHor) > 1.e-3 || fabs(BAV - BeamAimVert) > 1.e-3
		|| fabs(NBH - NofBeamletsHor) > 1.e-6 || fabs(NBV - NofBeamletsVert) > 1.e-6
		|| fabs(ASH - AppertStepHor) > 1.e-6 || fabs(ASV - AppertStepVert) > 1.e-6
		|| fabs(AAH - AppertAimHor)  > 1.e-3 || fabs(AAV - AppertAimVert)  > 1.e-3) 
	{
	//	AfxMessageBox("Active beam option - MAMuG"); 
		OptSINGAP = FALSE;
		MAMuGchanged = TRUE;
	//	for (int i = 0; i < (int)NofChannelsHor; i++) ActiveCh[i] = TRUE;
	//	for (int j = 0; j < (int)NofChannelsVert; j++) ActiveRow[j] = TRUE;
	}

	SetTraceParticle(TracePartType); // -> TraceTimeStep
	SetBeam(); // Mamug Aimings, IS positions */
	if (OptSINGAP)	SetSINGAP(); // form BEAMLET_ENTRY array (apply midalign, active chan)

	if (MAMuGchanged) {
		for (int i = 0; i < (int)NofChannelsHor; i++) ActiveCh[i] = TRUE;
		for (int j = 0; j < (int)NofChannelsVert; j++) ActiveRow[j] = TRUE;
	}
		
	int Ntot;
	if ((int)BeamSplitType ==0) {
		SetPolarBeamletCommon(); //SetBeamletAt(0);
		Ntot = (int)(PolarNumber * AzimNumber);
		//AfxMessageBox("SetPolarBeamletCommon");
	}
	else {
		SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 
		Ntot = (int)(BeamSplitNumberY * BeamSplitNumberZ);
	}

	if (Attr_Array.GetSize() * 3 < Ntot && Attr_Array.GetSize() > 1) {
		AfxMessageBox("Warning:\n Number of Model Particles is too small (for active Cut-off Current)",
						MB_ICONEXCLAMATION);  
	}
	if (Ntot > 1 && Attr_Array.GetSize() <= 1) {
		AfxMessageBox("ErrInput:\n Zero Number of Model Particles!\n Cut-off Current must be decreased!",
						MB_ICONEXCLAMATION);  
	}

	

    int res;// = IDNO; // ask to update geometry
	//res = AfxMessageBox("Keep the existing Surfaces?",3);//MB_ICONQUESTION | MB_YESNO);
	//if (res == IDNO) SetPlates(); 
	/*if (TorCentreX > 25) { //ITER
		FWRmin = 4.0; FWRmax = 8.4;//ITER
	}
	else {//TIN
		FWRmin = 2.0; FWRmax = 4.4;
	}*/
	ClearAllPlates();
	InitPlasma();
	if (!OptFree) SetPlates(); // create again//SetPlasma() is called from SetPlatesNBI;
	else ModifyArea(TRUE); // change 
	
	SetReionPercent();
	if (OptThickNeutralization) SetNeutrCurrents();
	//SetDecayInPlasma();

	ClearArrays();// attr vectors

	SetStatus(); // NofBeamlets, Nofactive channels, InitTracers
	ShowStatus();
	OnShow();
	
}
void CBTRDoc::ShowStatus()
{
	//CLoadView * pLV = (CLoadView *)pLoadView;
	pLoadView->Load = NULL;
	pLoadView->ShowLoad = FALSE;
	pLoadView->InvalidateRect(NULL, TRUE);

	pMainView->ShowNBLine();
	pMainView->ShowCoord();

	
	if (STOP) pDataView->OnDataActive();
	//else if (NofCalculated < NofBeamlets) ShowLogFile(50);
	else ShowLogFile(50); // show log

	pSetView->Load = NULL;
	pSetView->InvalidateRect(NULL, TRUE);

}

void CBTRDoc:: OnShow() 
{
//	char old[128];
//	::GetWindowText(NULL, old, 20);
	//SetTitle(CurrentDirName);//(TaskName);
	
	if (pDataView == NULL) return;
	if (pLoadView == NULL) return;
	if (pSetView == NULL) return;
	if (pMainView == NULL) return;
	if (STOP) SetTitle("STOPPED");
	
	pDataView->OnDataActive();//OnDataActive();
	
	pLoadView->Load = NULL;
	pLoadView->ShowLoad = FALSE;
	pLoadView->InvalidateRect(NULL, TRUE);
	
	pSetView->Load = NULL;
	pSetView->InvalidateRect(NULL, TRUE);

	pMainView->InvalidateRect(NULL, TRUE);
	

}

void   CBTRDoc::SaveData()
{
	char name[1024];
	FormDataText(TRUE);// include internal names of parameters
	CFileDialog dlg(FALSE, "dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"BTR Output file (*.dat) | *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
		if (dlg.DoModal() == IDOK) {
			FILE * fout;
			strcpy(name, dlg.GetPathName());
			fout = fopen(name, "w");
			fprintf(fout, m_Text);
			fclose(fout);
			SetTitle(name);// + TaskName);
		}
		delete dlg;

		if (AddPlatesNumber > 0) {
			int reply = AfxMessageBox("Save the List of Additional Surfaces?", 3);
			if (reply != IDYES) return;

		CFileDialog dlg1(FALSE, "dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Additional Surfaces data file (*.dat) | *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
		if (dlg1.DoModal() == IDOK) {
			strcpy(name, dlg1.GetPathName());
			WriteAddPlates(name);
		}

		}

}

int   CBTRDoc::ReadData() // load text from config file to m_text
{
	DataLoaded = FALSE;
	char name[1024];
	char buf[1024];
	char dirname[1024];
	CString S;
	CString FileName, FilePath, FileDir;
	CFileDialog dlg(TRUE, "dat | * ", "", OFN_EXPLORER,// OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"BTR Input file (*.dat) | *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
		if (dlg.DoModal() == IDOK) {
			FileName = dlg.GetFileName();
			FilePath = dlg.GetPathName();
			strcpy(name, FilePath);
			int pos = FilePath.Find(FileName, 0);
			if (pos > 1) FileDir = FilePath.Left(pos-1);
			else { AfxMessageBox("Bad FileDir"); return 0; }
		//strcpy(dirname, dlg.GetFolderPath());
		//::GetCurrentDirectory(1024, CurrentDirName);
	
		CPreviewDlg pdlg;
		pdlg.m_Filename = FilePath;//name;
		if (pdlg.DoModal() == IDCANCEL) return 0;

		FILE * fin;
		fin = fopen(name, "r");		//fprintf(fout, m_Text);
		DWORD error = ::GetLastError();
		if (fin == NULL || error != 0) { AfxMessageBox("fin = NULL"); return 0;}
		//else AfxMessageBox("open file");
		m_Text = "";
		while (!feof(fin)) {
			fgets(buf, 1024, fin);
			if (!feof(fin))	m_Text += buf;
		}
		//if (m_Text.GetLength() < 1) { AfxMessageBox("Length = 0"); return 0;} 
		fclose(fin);
		//AfxMessageBox("Closed file");
		//char OpenDirName[1024]; 	::GetCurrentDirectory(1024, OpenDirName);
		//S.Format("GetCurrentDir OK\n OpenDirName %s", OpenDirName);	AfxMessageBox(S);
		//error = ::GetLastError();
		CurrentDirName = FileDir;//dirname; //dlg.GetFolderPath();//OpenDirName;
		::SetCurrentDirectory(CurrentDirName);	
		//S.Format("Set DirName %s", CurrentDirName);	AfxMessageBox(S);
		//SetTitle(OpenDirName);
		SetTitle(name); //AfxMessageBox("SetTitle OK");
		DataLoaded = TRUE; //AfxMessageBox("Loaded OK");
		return 1; //success
	}

		//AfxMessageBox("NOT Loaded");
		return 0;
}

void  CBTRDoc:: WritePDPinput(char * name)
{

	FILE * fout;
	CString S;

		fout = fopen(name, "w"); //("PDP_input.dat", "w");
		fprintf(fout, "NBI geometry (for PDP-code), created by BTR 1.7 \n");

/*"1st line - ""Source"": Eo, Iacc, Ac, Ah "					 									
"        Eo=Beam energy, MeV,"														
"        Iacc=Beam Current, A"														
"        Ah=Beam ""halo"" angle, mrad"														
"        Ch=Part of D- current in ""halo"""	*/
		 
		fprintf(fout, "%g  %g  %g  %g \t\t !#1 Eo,MeV (Energy);   Iacc,A (Current);   Ah,mrad (halo angle)   Ch (halo fraction) \n", 
			IonBeamEnergy, IonBeamCurrent, BeamHaloDiverg *1000, BeamHaloPart); 

/*"2nd line - ""Numbers"": Lch, Nach, LchR "														
        LchN - number of channels in Neutraliser													
       Nach - number of beamlets per channel													
       LchR- number of channels in RID	*/	

		int BeamletsPerSegment = NofBeamletsTotal / (int)NofChannelsHor;
		fprintf(fout, "%d  %d  %d  \t\t\t !#2  LchN (Neutr. channels);   Nach (beamlets per segment);  LchR (RID channels)\n", 
			(int)NeutrChannels, BeamletsPerSegment, (int)RIDChannels);
		
/*"3d line  YSo(l), mm -horiz.coord.of segment column axis at X=0"	*/	
		
		double ys1=0, ys2=0, ys3=0, ys4=0;
		if ((int)NofChannelsHor > 4){
			S.Format("Number of Beam Segments in BTR (= %d)\n exceeds PDP Channels Limit(=4)!\n Horiz. centers are not transferred (line 3)", 
			(int)NofChannelsHor);
			AfxMessageBox(S); 
		}
		else { 
			if ((int)NofChannelsHor > 0)  ys1 = SegmCentreHor[0]*1000; 
			if ((int)NofChannelsHor > 1)  ys2 = SegmCentreHor[1]*1000; 
			if ((int)NofChannelsHor > 2)  ys3 = SegmCentreHor[2]*1000;
			if ((int)NofChannelsHor > 3)  ys4 = SegmCentreHor[3]*1000; 
		}
		fprintf(fout, "%g  %g  %g  %g  \t\t  !#3  YSo,mm (horiz.coord.of segment column axis at X=0)\n", ys1, ys2, ys3, ys4);

/*"4th line -  Xd(id), m -distance to an ""id""-set of channels diaphragms"													
"             (id=1�2 - neutralizer;  id=3...4 - RID, id=5 - scraper)"	*/
		
		
		fprintf(fout, "%g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g \t !#4  Xd,m (channels diaphragms X)\n",
			//"%4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  %4.2f  \t !(4)  Xd,m (channels diaphragms X)\n",
				NeutrInX, NeutrOutX, RIDInX, RIDOutX, PreDuctX, DDLinerInX, DDLinerOutX,
				Duct1X, Duct2X, Duct3X, Duct4X, Duct5X, Duct6X, Duct7X, Duct8X); 

/*"5th line - Wd(id), mm - horiz.width of diaphragms"*/	

		fprintf(fout, "%g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g \t  !#5  Wd, mm (horiz.width of diaphragms)\n",
			NeutrInW *1000, NeutrOutW *1000, RIDInW *1000, RIDOutW *1000, 
			PreDuctW *1000, DDLinerInW *1000, DDLinerOutW *1000,
			Duct1W *1000, Duct2W *1000, Duct3W *1000, Duct4W *1000,
			Duct5W *1000, Duct6W *1000, Duct7W *1000, Duct8W *1000);


/*"6th line - Hd(id), m - vert.hight of diaphragms"	*/	
		
		fprintf(fout, "%g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g \t  !#6  Hd, m (vert. height of diaphragms)\n",
			NeutrH, NeutrH, RIDH, RIDH, PreDuctH, DDLinerInH, DDLinerOutH,
			Duct1H, Duct2H, Duct3H, Duct4H,	Duct5H, Duct6H, Duct7H, Duct8H);

/*"7th line -  DPLY(id), mm -horiz.displacement of diaphragms axes (misalignement)"	*/	

		fprintf(fout, "%g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g \t  !#7  DPLY, mm (horiz. bias of diaphragms)\n",
			NeutrBiasInHor *1000, NeutrBiasOutHor *1000, RIDBiasInHor *1000, RIDBiasOutHor *1000, 
			DiaBiasHor *1000, LinerBiasInHor *1000, LinerBiasOutHor *1000,
			Duct1BiasHor *1000, Duct2BiasHor *1000, Duct3BiasHor *1000, Duct4BiasHor *1000,
		    Duct5BiasHor *1000, Duct6BiasHor *1000, Duct7BiasHor *1000, Duct8BiasHor *1000);
		
		
/*"8th line DPLZ(id), mm -vertic.displacement of diaphragms axes (misalignement)"*/	
		
		fprintf(fout, "%g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g  %g \t  !#8  DPLZ, mm (vert. bias of diaphragms)\n",
			NeutrBiasInVert *1000, NeutrBiasOutVert *1000, RIDBiasInVert *1000, RIDBiasOutVert *1000, 
			DiaBiasVert *1000, LinerBiasInVert *1000, LinerBiasOutVert *1000,
			Duct1BiasVert *1000, Duct2BiasVert *1000, Duct3BiasVert *1000, Duct4BiasVert *1000,
		    Duct5BiasVert *1000, Duct6BiasVert *1000, Duct7BiasVert *1000, Duct8BiasVert *1000);
		

/*"9th line - ""NBL"" : AYmis,AZmis,XHaim,Reion,Fr,Ainc,Atil"													
"        AYmis=Horiz.beam angular misalignment, mrad"													
"        AZmis=Vertical beam angular misalignment, mrad"													
"        XHaim=Gorizontal aiming of channels and plates, m"													
"     //   Reion=Reionization, "													
        Fr=Neutralisation efficiency														
"       Ainc=Beam (Duct) average axis inclination angle, mrad"														
"       Atil= beam vertical tilting angle, mrad"*/

		fprintf(fout, "%g  %g  %g  %g  %g  %g  \t\t !#9 AYmis, mrad; AZmis, mrad; XHaim, m; Fr(Neutr. Eff); Ainc, mrad; Atil, mrad\n",
			BeamMisHor *1000, BeamMisVert *1000, BeamAimHor,//	ReionPercent, 
			NeutrPart, VertInclin *1000, BeamVertTilt *1000); 
		
	/*	if (ReionPercent < 1.e-6){
			S.Format("Warning:\nPressure not defined\nReionization = 0");
			AfxMessageBox(S); 
		}*/

/*10th line - For information only: Th1, Th2, Th3
	Th1=Thickness of the neutraliser entry plates, mm
	Th2=Thickness of the neutraliser exit plates, mm
"       Th3=Thickness of the RID plates, mm"*/	

		fprintf(fout, "%g   %g   %g   %g   %g  \t\t !#10  Panel Thickness, mm (Neutralizer Entry/Exit, RID), AppertAimHor,BeamAimVert \n",
			NeutrInTh *1000, NeutrOutTh *1000, RIDTh *1000, AppertAimHor, BeamAimVert );
		
		fclose(fout);
		
}

void CBTRDoc:: AddCommentToPDP(char * name)
{
	int res;
	char buf[1024];
	unsigned long Size1 = MAX_COMPUTERNAME_LENGTH + 1;
	unsigned long Size2 = MAX_COMPUTERNAME_LENGTH + 1;
	char user[MAX_COMPUTERNAME_LENGTH + 1];
	char machine[MAX_COMPUTERNAME_LENGTH + 1];
	CString CompName = "";
	CString UserName = "";
	
	CString text = ""; // rewrite file
	CString line = "";
	CString left = "";

	CString Fname = name;
	Fname.MakeUpper();
	if (Fname.Find("_BTR") <= 0 && Fname.Find("BTR.txt") <= 0) return; // corrected name!
	
	BOOL doit = TRUE;
	BOOL day = FALSE; // friday?
	BOOL askAK = FALSE; // quest to AK

	CTime tm = CTime::GetCurrentTime();
	if (Odd(tm.GetDay())) doit = TRUE; //1,3,5..
	else doit = FALSE; // 2,4,6...
	//if (tm.GetMonth() == 6) doit = FALSE; // dont do in june
	
	if (doit == FALSE) return; // 2,4,6... or June
	
	if (tm.GetDayOfWeek() == 6) day = TRUE; // 1 - Sunday

	if (::GetComputerName(machine, &Size1)!= 0) {
		CompName = machine; CompName.MakeUpper();}
		
	if  (::GetUserName(user, &Size2) != 0) {
		UserName = user;	UserName.MakeUpper(); }
		
		if (CompName.Find("PANAS")>=0 || UserName.Find("PANAS")>=0) return;
		if (CompName.Find("PAA")>=0 || UserName.Find("PAA")>=0) return;

		askAK = FALSE;
		if (CompName.Find("KRYLOV")>=0 || UserName.Find("KRYLOV")>=0) askAK = TRUE;
		if (CompName.Find("AK-OFF")>=0 || UserName.Find("AK-OFF")>=0) askAK = TRUE;
	//	if (CompName.Find("DED")>=0 || UserName.Find("DED")>=0) askAK = TRUE;
		
		if (askAK && day) {
			res = AfxMessageBox("Warning:\n Are you sure this is Valid name for PDP-input file?", 
							MB_ICONQUESTION | MB_YESNOCANCEL); 
			if (res == IDYES)  AfxMessageBox("Up to YOU!", MB_ICONSTOP | MB_OK); 
			else AfxMessageBox("Correct it and read the file again, SVP!", MB_ICONSTOP | MB_OK); 
		}
	
//	CString CurrDate, CurrTime;
//	CString Date, Time;
//	CurrDate.Format("%02d:%02d:%04d", tm.GetDay(), tm.GetMonth(), tm.GetYear());
//	CurrTime.Format("%02d:%02d:%02d", tm.GetHour(), tm.GetMinute(), tm.GetSecond());


	FILE * fin;
	fin = fopen(name, "r");
		if (fin==NULL){
			AfxMessageBox("problem 1 opening PDP-input file", MB_ICONSTOP | MB_OK);
			return;
		}

		text = ""; // rewrite file
		line = "";
		left = "";
		int l = 0;
		res = 0;
		double v1, v2, v3, v4;
		while (!feof(fin)) {
			fgets(buf, 1024, fin);
			text += buf;
			if (res < 1 && !feof(fin) ) res = sscanf(buf, "%le %le %le %le", &v1, &v2, &v3, &v4); // PDP format?
			l++;
		}
	fclose(fin);


	FILE * fout;

	if (text.Find("!#") > 0) return; // BTR generated PDP-input
		
	int posak = text.Find("PDP");
	
	if (posak < 0 && res == 4)  { // string "PDP" not found and true PDP format 

		line = "AK:  PDP\n";
	/*	int pos = text.Find("Input");
		//if (pos <= 0) pos = text.Find("file");
		if (pos <= 0) { // "Input file" not found
			line = "AK:  PDP \n";
			left = text; // data
		}

		if (pos > 100) {
			line = "AK:  PDP \n" + text.Mid(pos);
			left = text.Left(pos);
		}
		*/
		
	//	if (pos <= 0 || pos > 100) {
			fout = fopen(name, "w");
			if (fout == NULL){
				AfxMessageBox("problem 2 opening PDP-input file", MB_ICONSTOP | MB_OK);	
				return;
			}
			fprintf(fout, line); fprintf(fout, text);
			//fprintf(fout, left);
			fclose(fout);
	//	} // "Input file" found at the end
	
	}// "PDP" not found
}

int CBTRDoc::OldPDPinput(char * name)
{
	char buf[1024];
	FILE * fin;

	int result;

	fin = fopen(name, "r");
	if (fin==NULL){
		AfxMessageBox("PDP-input not found!", MB_ICONSTOP | MB_OK);
		return -1;
	}
	
	// line 1
	double Eo, Iacc, Ah, Ch, add;
	if (fgets(buf,1024,fin) == NULL) { AfxMessageBox("Problem 0 with file");fclose(fin); return -1; }
	result = sscanf(buf, "%lf %lf %lf %lf", &Eo, &Iacc, &Ah, &Ch); 
		if (result != 4) {
			while (!feof(fin) && result !=4) {
				fgets(buf, 1024, fin);
				result = sscanf(buf, "%lf %lf %lf %lf", &Eo, &Iacc, &Ah, &Ch);
			}
			if (feof(fin)) { AfxMessageBox("ErrInput:\n1st line data not found"); fclose(fin); return -1;}
			else {
				result = sscanf(buf, "%lf %lf %lf %lf %lf", &Eo, &Iacc, &Ah, &Ch, &add);
				if (result == 5) { AfxMessageBox("ErrInput:\n1st line contains Extra Data\n Invalid PDP-input format"); fclose(fin); return -1;}
			}
		}
		else {
			result = sscanf(buf, "%lf %lf %lf %lf %lf", &Eo, &Iacc, &Ah, &Ch, &add);
			if (result == 5) { AfxMessageBox("ErrInput:\n1st line contains Extra Data\n Invalid PDP-input format"); fclose(fin); return -1;}
		}

		// lines 2-8
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//2
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//3
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//4
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//5
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//6
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//7
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//8
		
		// line 9
		double AYmis, AZmis, XHaim, Reion, Fr, Ainc, Atil;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//9
		result = sscanf(buf, " %lf %lf %lf %lf %lf %lf %lf", 
			&AYmis,&AZmis,&XHaim,&Reion,&Fr,&Ainc,&Atil);
		if (result == 7) {//OLD (Reionization included to line 9) PDP-10
			fclose(fin);
			return 1;// old
		}
		else { // <7
			result = sscanf(buf, " %lf %lf %lf %lf %lf %lf", 
			&AYmis,&AZmis,&XHaim,&Fr,&Ainc,&Atil); // no reion
			if (result != 6) {
				fclose(fin);
				return -1;// invalid
			}
		}

		// line 10
		double Th1, Th2, Th3, XBHaim, XVaim;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return -1; }//10
		result = sscanf(buf, " %lf %lf %lf %lf %lf", &Th1, &Th2, &Th3, &XBHaim, &XVaim);
		if (result != 5) {
			result = sscanf(buf, " %lf %lf %lf", &Th1, &Th2, &Th3);
			if (result != 3) {//invalid
				fclose(fin);
				return -1; 
			}
			else {
				fclose(fin);
				return 1; // old
			}
		}
		
		fclose(fin);
	//	AfxMessageBox("OldPDPiput complete - NEW");
		return 0; // new version
}


int   CBTRDoc::ReadPDPinput_old(char * name) //used  for ITER before 2018 // config file for PDP *.txt
{  
//AfxMessageBox("ReadPDPiput begin");
//	DataLoaded = FALSE;
//	char name[1024];
	char buf[1024];
	FILE * fin;
	CString quest = "Read next data anyhow?";

	int result, reply;

	/*	fin = fopen(name, "r");
		if (fin==NULL){
			AfxMessageBox("PDP-input not found!", MB_ICONSTOP | MB_OK);
			return 0;
		}
*/
		int OldInput = OldPDPinput(name);
		if (OldInput < 0)  return 0;

		fin = fopen(name, "r");

//while (!feof(fin)) {
											
/*"1st line - ""Source"": Eo ,Iacc,  Ah ,  Ch "					 								
"        Eo=Beam energy, MeV,"													
"        Iacc=Beam Current, A"													
"        Ah=Beam ""halo"" angle, mrad"													
"        Ch=Part of D- current in ""halo"""	*/

		double Eo, Iacc, Ah, Ch;
		if (fgets(buf,1024,fin) == NULL) { AfxMessageBox("Problem 0 with file");fclose(fin); return 0; }
		result = sscanf(buf, "%lf %lf %lf %lf", &Eo, &Iacc, &Ah, &Ch); 
		if (result != 4) {
			while (!feof(fin) && result !=4) {
				fgets(buf, 1024, fin);
				result = sscanf(buf, "%lf %lf %lf %lf", &Eo, &Iacc, &Ah, &Ch);
			}
			if (feof(fin)) { AfxMessageBox("ErrInput:\n1st line data not found"); fclose(fin); return 0;}

		}
		
		if (Eo < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Source Beam Energy < 1 eV!\n Maybe NOT geometry file (PDP-input)?  \n" + quest, MB_YESNOCANCEL);
			if (reply != IDYES) { fclose(fin); return 0;}
		}
		IonBeamEnergy = Eo;
		if (Iacc < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Beam current < 1.e-6 A\n" + quest, MB_YESNOCANCEL);
			if (reply != IDYES) { fclose(fin); return 0;}
		}
		IonBeamCurrent = Iacc;
		if (Ah < 1.e-3) {
			reply = AfxMessageBox("Warning:\n Beam halo div < 1.e-3 mrad\n"+ quest, MB_YESNOCANCEL);
			if (reply != IDYES) { fclose(fin); return 0;}
		}
		BeamHaloDiverg = Ah * 0.001; 
	/*	if (Ch < 1.e-6) {
			reply = AfxMessageBox(" Beam halo part < 1.e-6 \n Continue?", MB_YESNOCANCEL);
			if (reply != IDYES) { fclose(fin); return 0;}
		}*/
		if (Ch > 1) {
			reply = AfxMessageBox("Warning:\n Beam halo part > 1 \n"+ quest, MB_YESNOCANCEL);
			if (reply != IDYES) { fclose(fin); return 0;}
		}
		BeamHaloPart = Ch; 

		if ((int)BeamSplitType ==0) SetPolarBeamletCommon(); //SetBeamletAt(0);
		else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 
		
//AfxMessageBox("ReadPDPiput line 1 complete");

/*"2nd line - ""Numbers"": Lch, Nach "													
        LchN - number of channels in Neutraliser													
       Nach - number of beamlets per channel													
       LchR- number of channels in RID */		
		int LchN, Nach, LchR;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %d %d %d", &LchN, &Nach, &LchR); 
		if (result != 3) {
			reply = AfxMessageBox("Warning:\nProblem with 2nd line! Not all data found.\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		
		if (LchN < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Zero Number of Neutralizer channels\n" + quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
			NeutrChannels = 0;
		}
		NeutrChannels = LchN; 
		// Nach not used in BTR
		if (LchR < 1.e-6) {
			reply = AfxMessageBox("Warning:\nZero Number of RID channels\n" + quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
			RIDChannels = 0;
		}
		RIDChannels = LchR;


/*"3d line  YSo(l), mm -horiz.coord.of segment column axis at X=0" */													

		double ys0, ys1, ys2, ys3;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le %le", &ys0, &ys1, &ys2, &ys3); 
		if (result != 4) {
			reply = AfxMessageBox("Warning:\nProblem with 3rd line! Not all data found\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}

		if (fabs(ys0) < 1.e-6 && fabs(ys1) + fabs(ys2) + fabs(ys3)  > 1.e-6 ) {
			reply = AfxMessageBox(" Zero 1st channel Position!  \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
/*
		SegmCentreHor[0] =  ys0 * 0.001; SegmCentreHor[1] =  ys1 * 0.001; 
		SegmCentreHor[2] =  ys2 * 0.001; SegmCentreHor[3] =  ys3 * 0.001; 
		double step1 = ys1 - ys0;
		double step2 = ys2 - ys1;
		double step3 = ys3 - ys2;
		if (fabs(step2 - step1) >1.e-6 || fabs(step3 - step2) >1.e-6) { 
			reply = AfxMessageBox(" Horiztal steps between beam groups are not equal!\n Continue?", 3);
			if (reply != IDYES) { fclose(fin); return 0;}
		//	SegmStepHor = 0;
		}
	//	else SegmStepHor = step1 * 0.001;
	//	SetBeam(); // Aimings, IS positions
	//  SetSINGAP();
	*/

/*"4th line -  Xd(id), m -distance to an ""id""-set of channels diaphragms"													
"             (id=1�2 - neutralizer;  id=3...4 - RID, id=5 - scraper)"
		max.number of diaphragms in the beamline = 15)*/		
 
		double xd1, xd2, xd3, xd4, xd5, xd6, xd7, xd8, xd9, xd10, xd11, xd12, xd13, xd14, xd15;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le", 
				&xd1, &xd2, &xd3, &xd4, &xd5, &xd6, &xd7, &xd8, &xd9, 
				&xd10, &xd11, &xd12, &xd13, &xd14, &xd15);
		if (result != 15) {
			reply = AfxMessageBox("Warning:\nProblem with line 4! Not all data found.\n" + quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		if (xd1 * xd2 < 1.e-6) {
			reply = AfxMessageBox("Warning:\nZero X-limits for Neutralizer!  \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		if (xd1 > xd2) {
			reply = AfxMessageBox("Warning:\nNeutralizer Entrance is set AFTER Neutralizer Exit!  \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		NeutrInX = xd1; 
		NeutrOutX = xd2;
		NeutrXmax = xd2 + 0.01;
		NeutrXmin = Max(0.0, xd1-0.1);
	
		if (xd3 * xd4 < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Zero X-limit for RID \n"+ quest, 3);
			if (reply != IDYES) {  fclose(fin);return 0;}
		}
		if (xd3 > xd4) {
			reply = AfxMessageBox("Warning:\nRID Entrance is set AFTER RID Exit!  \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		RIDInX = xd3; 
		RIDOutX = xd4;
		if (xd5 < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Zero X for Scraper! \n"+ quest, 3);
			if (reply != IDYES) {  fclose(fin);return 0;}
		}
		PreDuctX = xd5; 
		if (xd6 * xd7 < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Zero X-limit for Liner! \n"+ quest, 3);
			if (reply != IDYES) {  fclose(fin);return 0;}
		}
		DDLinerInX = xd6; 
		DDLinerOutX = xd7; 
		if (xd8 * xd9 * xd10 * xd11 * xd12 * xd13 * xd14 * xd15 < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Zero position X for one of Duct sections! \n"+ quest, 3);
			if (reply != IDYES) {  fclose(fin);return 0;}
		}
		Duct1X = xd8; Duct2X = xd9; Duct3X = xd10;// 10 - used
		Duct4X = xd11; Duct5X = xd12; Duct6X = xd13; 
		Duct7X = xd14; Duct8X = xd15;
		AreaLong = xd15;
		
		ReionXmin = NeutrXmax;
		ReionXmax = AreaLong;

//"5th line - Wd(id), mm - horiz.width of diaphragms"
		double wd1, wd2, wd3, wd4, wd5, wd6, wd7, wd8, wd9, wd10, wd11, wd12, wd13, wd14, wd15;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le", 
				&wd1, &wd2, &wd3, &wd4, &wd5, &wd6, &wd7, &wd8, &wd9, &wd10, &wd11, &wd12, &wd13, &wd14, &wd15);
		if (result != 15) {
			reply = AfxMessageBox("Warning:\n Problem with line 5! Not all data found.\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		if (wd1 * wd2 < 1.e-6) {
			reply = AfxMessageBox("Warning:\n Zero Neutralizer Width! \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		NeutrInW = wd1 * 0.001; 
		NeutrOutW = wd2 * 0.001;
		if (wd3 * wd4 < 1.e-6) {
			reply = AfxMessageBox(" Zero RID Width! \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		RIDInW = wd3 * 0.001; 
		RIDOutW = wd4 * 0.001;
		if (wd5 < 1.e-6) {
			reply = AfxMessageBox(" Zero Scraper Width!\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		PreDuctW = wd5 * 0.001; 
		if (wd6 * wd7 < 1.e-6) {
			reply = AfxMessageBox(" Zero Liner Width! \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		DDLinerInW = wd6 * 0.001; 
		DDLinerOutW = wd7 * 0.001; 
		if (wd8 * wd9 * wd10 * wd11 * wd12 * wd13 * wd14 * wd15 < 1.e-6) {
			reply = AfxMessageBox(" Zero width of Duct section! \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		Duct1W = wd8 * 0.001;  Duct2W = wd9 * 0.001;  Duct3W = wd10 * 0.001;// 10 - used now
		Duct4W = wd11 * 0.001; Duct5W = wd12 * 0.001; Duct6W = wd13 * 0.001; 
		Duct7W = wd14 * 0.001; Duct8W = wd15 * 0.001;
		//AreaLong = wd14;
//AfxMessageBox("ReadPDPiput line 5 complete");
	
//"6th line - Hd(id), m -vert.hight of diaphragms"
		double hd1, hd2, hd3, hd4, hd5, hd6, hd7, hd8, hd9, hd10, hd11, hd12, hd13, hd14, hd15;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le", 
				&hd1, &hd2, &hd3, &hd4, &hd5, &hd6, &hd7, &hd8, &hd9, 
				&hd10, &hd11, &hd12, &hd13, &hd14, &hd15);
		if (result != 15) {
			reply = AfxMessageBox("Problem with line 6! Not all data found.\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		if (hd1 * hd2 < 1.e-6) {
			reply = AfxMessageBox("Zero Neutralizer Height! \n "+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		NeutrH = hd1; 
		//NeutrOutH = hd2;
		if (hd3 * hd4 < 1.e-6) {
			reply = AfxMessageBox("Zero RID Height! \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		RIDH = hd3; 
	//	RIDOutH = hd4;
		if (hd5 < 1.e-6) {
			reply = AfxMessageBox("Zero Scraper Height! \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		PreDuctH = hd5; 
		if (hd6 * hd7 < 1.e-6) {
			reply = AfxMessageBox("Zero height for liner \n"+ quest, 3);
			if (reply != IDYES) {fclose(fin);return 0;}
		}
		DDLinerInH = hd6; 
		DDLinerOutH = hd7; 
		if (hd8 * hd9 * hd10 * hd11 * hd12 * hd13 * hd14 * hd15< 1.e-6) {
			reply = AfxMessageBox("Zero X-position of Duct section! \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		Duct1H = hd8; Duct2H = hd9; Duct3H = hd10;// 10 -  used
		Duct4H = hd11; Duct5H = hd12; Duct6H = hd13;
		Duct7H = hd14; Duct8H = hd15;
	//	AreaLong = hd14;
//AfxMessageBox("ReadPDPiput line 6 complete");

//"7th line -  DPLY(id), mm -horiz.displacement of diaphragms axes (misalignement)"	
	//	if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
	//	double hd1, hd2, hd3, hd4, hd5, hd6, hd7, hd8, hd9, hd10, hd11, hd12, hd13, hd14;
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le", 
				&hd1, &hd2, &hd3, &hd4, &hd5, &hd6, &hd7, &hd8, &hd9, &hd10,
				&hd11, &hd12, &hd13, &hd14, &hd15);
		if (result != 15) {
			reply = AfxMessageBox("Problem with line 7! Not all data found.\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		
		NeutrBiasInHor = hd1 * 0.001; NeutrBiasOutHor = hd2 * 0.001; 
		RIDBiasInHor = hd3 * 0.001; RIDBiasOutHor = hd4 * 0.001; 
	
		DiaBiasHor = hd5 * 0.001; 
	
		LinerBiasInHor = hd6 * 0.001; LinerBiasOutHor = hd7 * 0.001; 
		 
		Duct1BiasHor = hd8 * 0.001; Duct2BiasHor = hd9 * 0.001; 
		Duct3BiasHor = hd10 * 0.001;// 10 -  used
		Duct4BiasHor = hd11 * 0.001; Duct5BiasHor = hd12 * 0.001; 
		Duct6BiasHor = hd13 * 0.001; Duct7BiasHor = hd14 * 0.001;
		Duct8BiasHor = hd15 * 0.001;
//AfxMessageBox("ReadPDPiput line 7 complete");

//"8th line DPLZ(id), mm -vertic.displacement of diaphragms axes (misalignement)"
	//	if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }

		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le", 
				&hd1, &hd2, &hd3, &hd4, &hd5, &hd6, &hd7, &hd8, &hd9, &hd10, 
				&hd11, &hd12, &hd13, &hd14, &hd15);
		if (result != 15) {
			reply = AfxMessageBox("Problem with line 8! Not all data found.\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		
		NeutrBiasInVert = hd1 * 0.001; NeutrBiasOutVert = hd2 * 0.001; 
		RIDBiasInVert = hd3; RIDBiasOutVert = hd4; 
	
		DiaBiasVert = hd5 * 0.001; 
	
		LinerBiasInVert = hd6 * 0.001; LinerBiasOutVert = hd7 * 0.001; 
		 
		Duct1BiasVert = hd8 * 0.001; Duct2BiasVert = hd9 * 0.001; 
		Duct3BiasVert = hd10 * 0.001;// 10 -  used
		Duct4BiasVert = hd11 * 0.001; Duct5BiasVert = hd12 * 0.001; 
		Duct6BiasVert = hd13 * 0.001; Duct7BiasVert = hd14 * 0.001;
		Duct8BiasVert = hd15 * 0.001;

//AfxMessageBox("ReadPDPiput line 8 complete");

		double AYmis, AZmis, XHaim, Wrpl, Reion, Fr, Ainc, Atil;
//if (OldInput == 0) {// New PDP-11
/*"9th line - "NBL" : AYmis,AZmis,XHaim,(Reion),Fr,Ainc,Atil"													
"       AYmis=Horiz.beam angular misalignment, mrad"													
"       AZmis=Vertical beam angular misalignment, mrad"													
        XHaim=Distance to channels horiz.aiming, m
"       /// Wrpl=Thickness of the RID plates, mm"	- removed 26.03.07												
"       ///Reion=Reionization, " removed from PDP-11													
        Fr=Neutralisation efficiency													
"       Ainc=Beam (Duct) average axis inclination angle, mrad"														
"       Atil= beam vertical tilting angle, mrad"
*/		

		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %lf %lf %lf %lf %lf %lf", 
				&AYmis, &AZmis, &XHaim, &Fr, &Ainc, &Atil);
		if (result != 6) {
			reply = AfxMessageBox("Problem with line 9! Not all data found. \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		BeamMisHor = AYmis * 0.001;
		BeamMisVert = AZmis * 0.001;
		BeamAimHor = XHaim;
		//RIDTh = Wrpl * 0.001;
		
	/*	if (Reion > 10) {
			reply = AfxMessageBox("Reionization is > 10%! \n Old PDP format?\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		ReionPercent = Reion;*/

		NeutrPart = Fr;
		VertInclin = Ainc * 0.001;
		BeamVertTilt = Atil * 0.001;


	// removed by PAA request
		/*	if (NeutrChannels != 4 || RIDChannels != 4) {
			reply = AfxMessageBox("Recalculate Channels Width for Neutralizer and RID?", 3);
			if (reply == IDYES)  SetChannelWidth();
		}*/ 
//}// NEW PDP-11 input
/*	
	else {//OLD input PDP-10

	"9th line - "NBL" : AYmis,AZmis,XHaim,Wrpl,Reion,Fr,Ainc,Atil"													
"       AYmis=Horiz.beam angular misalignment, mrad"													
"       AZmis=Vertical beam angular misalignment, mrad"													
        XHaim=Distance to channels horiz.aiming, m
"       ///Wrpl=Thickness of the RID plates, mm"	- removed 26.03.07 (before PDP-10)												
"       Reion=Reionization, "													
        Fr=Neutralisation efficiency													
"       Ainc=Beam (Duct) average axis inclination angle, mrad"														
"       Atil= beam vertical tilting angle, mrad"
	
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le %le %le %le %le", 
				&AYmis, &AZmis, &XHaim, &Reion, &Fr, &Ainc, &Atil);
		if (result != 7) {
			reply = AfxMessageBox("Problem with line 9! Not all data found. \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		BeamMisHor = AYmis * 0.001;
		BeamMisVert = AZmis * 0.001;
		BeamAimHor = XHaim;
	//	RIDTh = Wrpl * 0.001; // before PDP-10
		
		if (Reion > 10) {
			reply = AfxMessageBox("Reionization value is > 10%! \n Too Old PDP format maybe?\n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}
		ReionPercent = Reion;
		NeutrPart = Fr;
		VertInclin  = Ainc * 0.001;
		BeamVertTilt = Atil * 0.001;

	}//OLD input PDP-10*/	
//AfxMessageBox("ReadPDPiput line 9 complete");

double Th1=0, Th2=0, Th3=0, XBHaim = 0, XVaim = 0;
if (OldInput == 0) {// New PDP
	/*10th line - For information only: Th1, Th2, Th3, XBHaim, XVaim 
	Th1=Thickness of the neutraliser entry plates, mm
	Th2=Thickness of the neutraliser exit plates, mm
"   Th3=Thickness of the RID plates, mm"
	Xbh aim=Horizontal aiming of beamlets in the channel														
    Xvaim=Vertical aiming of segments	*/
		
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %lf %lf %lf %lf %lf", &Th1, &Th2, &Th3, &XBHaim, &XVaim);
		if (result != 5) {
			reply = AfxMessageBox("Problem with line 10!\n Old PDP format? \n" + quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}

		if (Th1 > 1.e-3) NeutrInTh = Th1 * 0.001; 
		if (Th2 > 1.e-3) NeutrOutTh = Th2 * 0.001;
		if (Th3 > 1.e-3) RIDTh = Th3 * 0.001;
		AppertAimHor = XBHaim;
		BeamAimVert = XVaim;
}

else { // Old PDP
/*10th line - For information only: Th1, Th2, Th3 - this line isded from PDP-10 version
	Th1=Thickness of the neutraliser entry plates, mm
	Th2=Thickness of the neutraliser exit plates, mm
"      Th3=Thickness of the RID plates, mm"*/
		
		if (fgets(buf,1024,fin) == NULL) { fclose(fin); return 0; }
		result = sscanf(buf, " %le %le %le", &Th1, &Th2, &Th3);
		if (result != 3) {
			reply = AfxMessageBox("Problem with line 10!\n Old PDP format? \n"+ quest, 3);
			if (reply != IDYES) { fclose(fin);return 0;}
		}

		if (Th1 > 1.e-3) NeutrInTh = Th1 * 0.001; 
		if (Th2 > 1.e-3) NeutrOutTh = Th2 * 0.001;
		if (Th3 > 1.e-3) RIDTh = Th3 * 0.001;
} // old PDP
//AfxMessageBox("ReadPDPiput line 10 complete");
	
	fclose(fin);
	
		char OpenDirName[1024];
		::GetCurrentDirectory(1024, OpenDirName);
		CurrentDirName = OpenDirName; 
		
		PDPgeomFileName  = name;
		SetTitle(PDPgeomFileName);
	
	//	AfxMessageBox("ReadPDPiput complete");
		return 1;
}

int CBTRDoc::ReadPDPinput(char * name)
{
	char buf[1024];
	FILE * fin;
	CString quest = "Read next data anyhow?";

	int result, reply;
	fin = fopen(name, "r");
	
/*1st line : "Source" : Eo, Iacc, Acy, Acz, Ah, Ch, dYa, dZa
		Eo - Beam energy, MeV,
		Iacc - Beam Current, A
		Acy - Beam core horizontal divergence angle, mrad,
		Acz - Beam core vertical divergence angle, mrad,
		Ah - Beam "halo" angle, mrad
		Ch - Part of beam current in "halo"
		dYa - horizontal step between aperture axes in beam group, mm
		dZa - vertical step between aperture rows in beam group, mm*/
	double Eo, Iacc, Acy, Acz, Ah, Ch, dYa, dZa;
	if (fgets(buf, 1024, fin) == NULL) { AfxMessageBox("Problem 0 with file"); fclose(fin); return 0; }
	result = sscanf(buf, "%lf %lf %lf %lf %lf %lf %lf %lf", 
						&Eo, &Iacc, &Acy, &Acz, &Ah, &Ch, &dYa, &dZa);
	if (result < 8) { AfxMessageBox("Problem in line 1"); fclose(fin); return 0; }
	IonBeamEnergy = Eo;
	IonBeamCurrent = Iacc;
	BeamCoreDivY = Acy * 0.001;
	BeamCoreDivZ = Acz * 0.001;
	BeamHaloDiverg = Ah * 0.001;
	BeamHaloPart = Ch;
	AppertStepHor = dYa * 0.001;
	AppertStepVert = dZa * 0.001;
		

/*2nd line : "Numbers" : Lch, Kbg, Nach, Mach, Nrch, Idm
		Lch - number of neutraliser channels
		Kbg - number of beam groups in column
		Na - number of apertures columns in a beam group
		Ma - number of apertures rows in a beam group
		Nrch - number of RID channels(equal Lch or 1)
		Idm - total number of diaphragms(not more 20)*/
	double Lch, Kbg, Nach, Mach, Nrch, Idm;
	if (fgets(buf, 1024, fin) == NULL) { AfxMessageBox("Problem 1 with file"); fclose(fin); return 0; }
	result = sscanf(buf, "%lf %lf %lf %lf %lf %lf", &Lch, &Kbg, &Nach, &Mach, &Nrch, &Idm);
	if (result < 6) { AfxMessageBox("Problem in line 2"); fclose(fin); return 0; }
	NeutrChannels = Lch;
	NofChannelsHor = Lch;
	NofChannelsVert = Kbg;
	
	NofBeamletsHor = Nach;
	NofBeamletsVert = Mach;
	RIDChannels = Nrch;

//3th line : YSo(l), mm - horiz.coordinate of beam group column axis at X = 0
	double ys0, ys1, ys2, ys3;
	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le", &ys0, &ys1, &ys2, &ys3);
	if (result < 4) result = sscanf(buf, " %le %le", &ys0, &ys1);
	if (result !=4 && result !=2) { AfxMessageBox("Problem in line 3"); fclose(fin); return 0; }
	SegmStepHor = (ys1 - ys0) * 0.001;

//4nd line : ZSo(k), mm - vertic.coordinate of beam group axis at X = 0
	double zs0, zs1, zs2, zs3;
	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le", &zs0, &zs1, &zs2, &zs3);
	if (result != 4) { AfxMessageBox("Problem in line 4"); fclose(fin); return 0; }
	SegmStepVert = (zs1 - zs0) * 0.001;
	

//5th line : Xd(id), m - distance to an "id" diaphragm
//	(id = 1...2 - neutralizer;  id = 3...4 - RID; id = 5...6 - scraper; id = 7...Idm - Duct)
	double xd1, xd2, xd3, xd4, xd5, xd6, xd7, xd8, xd9, xd10, xd11, xd12, xd13, xd14, xd15;
	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le",
		&xd1, &xd2, &xd3, &xd4, &xd5, &xd6, &xd7, &xd8, &xd9,
		&xd10, &xd11, &xd12, &xd13, &xd14, &xd15);

	NeutrInX = xd1;
	NeutrOutX = xd2;
	NeutrXmax = xd2 + 0.01;
	NeutrXmin = Max(0.0, xd1 - 0.1);
	RIDInX = xd3;
	RIDOutX = xd4;
	PreDuctX = xd5;
	DDLinerInX = xd6;
	DDLinerOutX = xd7;
	Duct1X = xd8; Duct2X = xd9; Duct3X = xd10;// 10 - used
	Duct4X = xd11; Duct5X = xd12; Duct6X = xd13;
	Duct7X = xd14; Duct8X = xd15;
	AreaLong = xd15;
	ReionXmin = NeutrXmax;
	ReionXmax = AreaLong;

//6th line : Wd(id), mm - horiz.width of diaphragms
/*	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le",
		&xd1, &xd2, &xd3, &xd4, &xd5, &xd6, &xd7, &xd8, &xd9,
		&xd10, &xd11, &xd12, &xd13, &xd14, &xd15);*/
	double wd1, wd2, wd3, wd4, wd5, wd6, wd7, wd8, wd9, wd10, wd11, wd12, wd13, wd14, wd15;
	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le",
		&wd1, &wd2, &wd3, &wd4, &wd5, &wd6, &wd7, &wd8, &wd9, &wd10, &wd11, &wd12, &wd13, &wd14, &wd15);
	
	NeutrInW = wd1 * 0.001;
	NeutrOutW = wd2 * 0.001;
	RIDInW = wd3 * 0.001;
	RIDOutW = wd4 * 0.001;
	PreDuctW = wd5 * 0.001;
	DDLinerInW = wd6 * 0.001;
	DDLinerOutW = wd7 * 0.001;
	Duct1W = wd8 * 0.001;  Duct2W = wd9 * 0.001;  Duct3W = wd10 * 0.001;// 10 - used now
	Duct4W = wd11 * 0.001; Duct5W = wd12 * 0.001; Duct6W = wd13 * 0.001;
	Duct7W = wd14 * 0.001; Duct8W = wd15 * 0.001;

//7th line : Hd(id), m - vert.hight of diaphragms
	/*if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le",
		&xd1, &xd2, &xd3, &xd4, &xd5, &xd6, &xd7, &xd8, &xd9,
		&xd10, &xd11, &xd12, &xd13, &xd14, &xd15);*/
	double hd1, hd2, hd3, hd4, hd5, hd6, hd7, hd8, hd9, hd10, hd11, hd12, hd13, hd14, hd15;
	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le",
		&hd1, &hd2, &hd3, &hd4, &hd5, &hd6, &hd7, &hd8, &hd9,
		&hd10, &hd11, &hd12, &hd13, &hd14, &hd15);
	
	NeutrH = hd1;
	//NeutrOutH = hd2;
	RIDH = hd3;
	//	RIDOutH = hd4;
	PreDuctH = hd5;
	DDLinerInH = hd6;
	DDLinerOutH = hd7;
	Duct1H = hd8; Duct2H = hd9; Duct3H = hd10;// 10 -  used
	Duct4H = hd11; Duct5H = hd12; Duct6H = hd13;
	Duct7H = hd14; Duct8H = hd15;

//8th line : DPLY(id), mm - horiz.displacement of diaphragms axes
	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le",
		&xd1, &xd2, &xd3, &xd4, &xd5, &xd6, &xd7, &xd8, &xd9,
		&xd10, &xd11, &xd12, &xd13, &xd14, &xd15);

//9th line : DPLZ(id), mm - vertic.displacement of diaphragms axes
	if (fgets(buf, 1024, fin) == NULL) { fclose(fin); return 0; }
	result = sscanf(buf, " %le %le %le %le %le %le %le %le %le %le %le %le %le %le %le",
		&xd1, &xd2, &xd3, &xd4, &xd5, &xd6, &xd7, &xd8, &xd9,
		&xd10, &xd11, &xd12, &xd13, &xd14, &xd15);

/*10th line : AYmis, AZmis, XYaim, XZaim, XBYaim, XBZaim, Trpl, Ainc, Atil, Fr
		AYmis - Horizontal beam angular misalignment, mrad
		AZmis - Vertical beam angular misalignment, mrad
		XYaim - Distance to channels horizontal aiming, m
		XZaim - Distance to segments vertical aiming, m
		XBYaim - Distance to beamlets horizontal aiming, m
		XBZaim - Distance to beamlets vertical aiming, m
		Trpl - Thickness of the RID plates, mm
		Ainc - Beam(Duct) nominal axis inclination angle, mrad
		Atil - Beam vertical tilting angle, mrad
		Fr - Neutralisation efficiency*/
	double AYmis, AZmis, XYaim, XZaim, XBYaim, XBZaim, Trpl, Ainc, Atil, Fr;
	if (fgets(buf, 1024, fin) == NULL) { AfxMessageBox("Problem 10 with file"); fclose(fin); return 0; }
	result = sscanf(buf, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf", 
		&AYmis, &AZmis, &XYaim, &XZaim, &XBYaim, &XBZaim, &Trpl, &Ainc, &Atil, &Fr);
	if (result < 10) { AfxMessageBox("Problem in line 10"); fclose(fin); return 0; }

	BeamMisHor = AYmis * 0.001;
	BeamMisVert = AZmis * 0.001;
	BeamAimHor = XYaim;
	BeamAimVert = XZaim;
	AppertAimHor = XBYaim;
	AppertAimVert = XBZaim;
	RIDTh = Trpl * 0.001;
	VertInclin = Ainc * 0.001;
	BeamVertTilt = Atil * 0.001;
	NeutrPart = Fr;

	fclose(fin);

	char OpenDirName[1024];
	::GetCurrentDirectory(1024, OpenDirName);
	CurrentDirName = OpenDirName;

	PDPgeomFileName = name;
	SetTitle(PDPgeomFileName);
	
/*	if ((int)BeamSplitType == 0) SetPolarBeamletCommon(); //SetBeamletAt(0);
	else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ);
	SetBeam(); // Aimings, IS positions
			   //SetSINGAP()
	SetStatus();
	SetPlates();*/
	return 1;
}


void CBTRDoc:: ShowPlatePoints()
{
	MSG message;
	vector <minATTR> & arr = m_GlobalVector;// m_AttrVector[MaxThreadNumber - 1];
	pSetView->Load = NULL;
	pSetView->InvalidateRect(NULL, TRUE);

	CLoadView * pLV = (CLoadView *) pLoadView;
	pLV->Load = NULL;
	pLV->ShowLoad = FALSE;
	pLV->STOP = FALSE;
	//pLV->InvalidateRect(NULL, TRUE);
	
	
	C3Point Pgl, Ploc;
	double power;
	CPlate * plate = pMarkedPlate;
	if (plate == NULL) return;
		
	int x, y;
	CDC * pDC = pLV->GetDC();
	pLV->ShowPlateBound(pDC);
	COLORREF color;
	CPen * pen = &pMainView->BlackPen;
	CPen * pOldPen = pDC->SelectObject(pen);
	//for (int k = 0; k < ThreadNumber; k++) {
		//arr = m_AttrVector[k];
		for (int i = 0; i < (int)arr.size(); i++) {
			minATTR &tattr = arr[i];
			if (tattr.Nfall == plate->Number) {
				if (!OptAtomPower && tattr.Charge == 0) continue;
				if (!OptNegIonPower && tattr.Charge < 0 ) continue;
				if (!OptPosIonPower && tattr.Charge > 0) continue;
				power = tattr.PowerW;
				Ploc.X = tattr.Xmm * 0.001;// plate->GetLocal(Pgl);
				Ploc.Y = tattr.Ymm * 0.001;
				Ploc.Z = 0;
				x = pLV->OrigX + (int)(Ploc.X * pLV->ScaleX);
				y = pLV->OrigY - (int)(Ploc.Y * pLV->ScaleY);
				switch (tattr.Charge) {
					case -1: //pen = &pMainView->GreenPen; 
						color = RGB(0,255,0); break;
					case 0: //pen = &pMainView->BluePen; 
						color = RGB(0,0, 255);break;
					case 1: //pen = &pMainView->RosePen; 
						color = RGB(255,0, 0);break;
					default : //pen = &pMainView->BlackPen; 
						color = RGB(0,0,0);
				}
				//if (!pen.CreatePen(PS_SOLID, 1, color)) return;
				pDC->SelectObject(pen);
				pDC->SetPixel(x, y, color);
				//pDC->Ellipse(x-1, y-1, x+1, y+1);
				//plate->Load->Distribute(Ploc.X, Ploc.Y, power);
				
			} // equal numbers
			if (::PeekMessage(&message, NULL, 0,0, PM_REMOVE)) {
				::TranslateMessage(&message);
				::DispatchMessage(&message);
			}
			if (pLV->STOP) break;
		} // i
		//if (pLV->STOP) break;
	//} //k
	pDC->SelectObject(pOldPen);
	pLV->ReleaseDC(pDC);
	pMainView->ShowNBLine();
	pMainView->ShowCoord();

}

void  CBTRDoc:: SetLoadArray(CPlate* plate, bool flag)
{
	CPlate* pl;
	int i, N;
	if (plate == NULL && !flag)  { // Unselect all plates
		Load_Arr.RemoveAll();
		LoadSelected = 0;
		return;
	}
	if (plate == NULL && flag)  {
		for (i = 0; i <LoadSelected; i++) { // calculate Max load for all selected plates
			pl = Load_Arr[i];
			//pl->Load->SetSumMax();
		}
		SortLoadArrayAlongX();
		return;
	}
	if (plate != NULL && flag)  { // Add the plate to Selected List
		//if (plate->Number > 0 && plate->Number <= LoadSelected) return; 
		
		Load_Arr.Add(plate); LoadSelected++;
		//plate->Number = LoadSelected;
		for (int i = 0; i < LoadSelected; i++) {
			pl = Load_Arr[i];
			/*if (pl->Number == plate->Number) {
				Load_Arr.RemoveAt(i, 1);
				LoadSelected--;
				break;
			}*/
		}
		SortLoadArrayAlongX();
		
		//N = plate->Number;
		//int ind = 0; // pos to insert
		/*if (LoadSelected == 0) Load_Arr.Add(plate);
		else if (Load_Arr[LoadSelected-1]->Number < plate->Number) Load_Arr.Add(plate);
		else {
		for (int i = 0; i < LoadSelected; i++) {
			pl = Load_Arr[i];
			if (pl->Number > plate->Number) {
				Load_Arr.InsertAt(i, plate, 1);
				break;
			}
		}
		}*/
		


		// sort plates on x
	/*	for (i = N-1; i >0; i--) {
			pl = Load_Arr[i-1];//.GetAt(i-1);
			if (plate->Orig.X < pl->Orig.X) 
			{ 
				plate->Number = i; 
				pl->Number = i+1; 
				Load_Arr[i-1] = plate;
				Load_Arr[i] = pl;
			} 
		}*/
		return;
	}

	if (plate != NULL && !flag)  {  // Remove the plate from the Selected List
		if (LoadSelected == 0) return;
		for (int i = 0; i < LoadSelected; i++) {
			pl = Load_Arr[i];
			if (pl->Number == plate->Number) {
				Load_Arr.RemoveAt(i, 1);
				LoadSelected--;
				break;
			}
		}
		SortLoadArrayAlongX();
		
	//	Load_Arr.RemoveAt(plate->Number - 1);
	/*	N = plate->Number; // remove plate
		pl =  Load_Arr[N-1];//.GetAt(N-1);
		//pl->Number = 0;
		pl->filename = "";
		for (i = N-1; i < LoadSelected-1; i++) { // shift numbers after
			pl = Load_Arr[i+1];//.GetAt(i+1);
			//Number--;
			Load_Arr[i] = pl;//.SetAt(i, pl);
		}
		Load_Arr.SetSize(--LoadSelected);*/
		
		//SortLoadArrayAlongX();
		return;
	}
}

void  CBTRDoc::SortLoadArrayAlongX()
{
	if (Sorted_Load_Ind.GetSize() > 1) // sorted already
	{
		Sorted_Load_Ind.RemoveAll(); // unsort
		//OnShow();
		//return;
	}

	int maxind = Load_Arr.GetUpperBound();
	if (maxind < 0) return;
	int ind = 0;
	CPlate * pl, * pl0;
	double x0, x;
	BOOL found;
	Sorted_Load_Ind.Add(ind);
	pl = Load_Arr[0];
	int n, sortn;
	
	for (int k = 1; k <= maxind; k++) {
		ind = k;
		pl = Load_Arr[k];
		n = pl->Number;
		found = FALSE;
		while (!found && ind > 0) {
			ind--;
			sortn = Load_Arr[Sorted_Load_Ind[ind]]->Number;
			//if (pl->Orig.X >= Load_Arr[Sorted_Load_Ind[ind]]->Orig.X) {
			if (n >= sortn) {
				found = TRUE;
				if (n > sortn) Sorted_Load_Ind.InsertAt(ind+1, k, 1);
				else { Load_Arr.RemoveAt(k, 1); LoadSelected--; } // n == sortn
			}
		}
		if (!found) Sorted_Load_Ind.InsertAt(0, k, 1);
	}
	//OnShow();

}

void CBTRDoc:: DetachLoadFiles()
{
	CPlate * plate;
	for (int i = 0; i < LoadSelected; i++) {
			plate = Load_Arr[i];
			plate->filename = "";
		}
}

void CBTRDoc::SaveLoads(bool free)
{
//	CWaitCursor wait; 
	CPlate * plate;

	LPSECURITY_ATTRIBUTES  sec = NULL;//SEC_ATTRS;

	::SetCurrentDirectory(CurrentDirName);
	CTime t = StopTime; // CTime::GetCurrentTime();
	CString DirName;
	DirName.Format("BTR%02d%02d%02d", t.GetHour(), t.GetMinute(), t.GetSecond()); 
		::CreateDirectory(DirName, sec);
		::SetCurrentDirectory(DirName);

	FILE * fout;
	CString name;
	CString  sn;
	// Save Loads --------------------------------
	if (free) {
		POSITION pos = PlatesList.GetHeadPosition();
		while (pos != NULL) {
			plate = PlatesList.GetNext(pos);
			sn.Format("%d",plate->Number);
			name = "load" + sn + ".dat"; 
			fout = fopen(name, "w");
			plate->WriteLoadAdd(fout); // free
			plate->filename = name;
			fclose(fout);
		}
	} // free
	else { //standard
	for (int i = 0; i < LoadSelected; i++) {
		plate = Load_Arr[i];
		//CString  sn;
		sn.Format("%d",plate->Number);
		name = "load" + sn + ".dat"; 
		fout = fopen(name, "w");
		//if (free) plate->WriteLoadAdd(fout);
		plate->WriteLoad(fout);
		plate->filename = name;
		fclose(fout);
	}
	}// standard

	// Save Config File --------------------------------
		CurrentDirName =  DirName;
		FormDataText(TRUE);// include internal names of parameters
	
		name = "Config.dat";
		fout = fopen(name, "w");
		fprintf(fout, m_Text);
		fclose(fout);

		WriteSumReiPowerX("Sum_ReiX.dat", -1, 100);
		WriteSumAtomPowerX("Sum_AtomX.dat", -1, 100);

		//WriteSumPowerAngle("Sum_Angle.dat");
			
		// WriteExitVector();
		//WriteFallVector();
	
		::SetCurrentDirectory(CurrentDirName);//("..\\");
		SetTitle(DirName);// +" - " + TaskName);
		OnDataActive();
	
		if (free) AfxMessageBox("FREE geometry and PD results are stored in Folder " + DirName, 
					MB_ICONINFORMATION | MB_OK);
		else AfxMessageBox("STANDARD geometry and PD results are stored in Folder " + DirName, 
					MB_ICONINFORMATION | MB_OK);
}

void CBTRDoc:: WriteSumReiPowerX(char * name, float xmin, float xmax)
{
	FILE * fout;
	fout= fopen(name, "w");
	if (fout == NULL) {
			AfxMessageBox("failed to create file", MB_ICONSTOP | MB_OK);
			return;
	}
	fprintf(fout, "ReIon Power deposition via X-coordinate \n");
	fprintf(fout, " X \t Power, W \n");

	double x, power, Sum = 0, SumN = 0, SumRID = 0, SumCal = 0, SumDuct = 0;
	for (int k = 0; k < SumReiPowerX.GetSize(); k++) {
		x = SumPowerStepX * (k + 0.5);
		power = SumReiPowerX[k];
		if (x >= xmin && x <= xmax)
			fprintf(fout, " %g \t %g \n", x, power);
		Sum += power;
		if (OptFree) continue; // skip sums
		if (x >= NeutrInX && x <= NeutrOutX) SumN += power; 
		if (x >= RIDInX && x <= RIDOutX) SumRID += power; 
		if (x >= CalInX && x <= CalOutX) SumCal += power; 
		if (x >= PreDuctX && x <= Duct8X) SumDuct += power; 
	}
	fprintf(fout, "Total reionized power = %e W   (X = 0 - %g m)\n", Sum, AreaLong);
	if (!OptFree) fprintf(fout, "Neutralizer = %e W   (X = %g - %g m)\n", SumN, NeutrInX, NeutrOutX);
	if (!OptFree) fprintf(fout, "RID  = %e W     (X = %g - %g m)\n", SumRID, RIDInX, RIDOutX);
	if (!OptFree) fprintf(fout, "Calorimeter = %e W  (X = %g - %g m)\n", SumCal, CalInX, CalOutX);
	if (!OptFree) fprintf(fout, "DUCT = %e W     (X = %g - %g m)\n", SumDuct, PreDuctX, Duct8X);

	fclose(fout);

}

void CBTRDoc:: WriteSumAtomPowerX(char * name, float xmin, float xmax)
{
	FILE * fout;
	fout= fopen(name, "w");
	if (fout == NULL) {
			AfxMessageBox("failed to create file", MB_ICONSTOP | MB_OK);
			return;
	}
	fprintf(fout, "Atom Power deposition via X-coordinate \n");
	fprintf(fout, " X \t Power, W \n");

	double x, power, Sum = 0, SumN = 0, SumRID = 0, SumCal = 0, SumDuct = 0;
	for (int k = 0; k < SumAtomPowerX.GetSize(); k++) {
		x = SumPowerStepX * (k + 0.5);
		power = SumAtomPowerX[k];
		if (x >= xmin && x <= xmax)
			fprintf(fout, " %g \t %g \n", x, power);
		Sum += power;
		if (OptFree) continue; // skip sums
		if (x >= NeutrInX && x <= NeutrOutX) SumN += power; 
		if (x >= RIDInX && x <= RIDOutX) SumRID += power; 
		if (x >= CalInX && x <= CalOutX) SumCal += power; 
		if (x >= PreDuctX && x <= Duct8X) SumDuct += power; 
	}
	fprintf(fout, "Total deposited atom power = %e W   (X = 0 - %g m)\n", Sum, AreaLong);
	if (!OptFree) fprintf(fout, "Neutralizer = %e W   (X = %g - %g m)\n", SumN, NeutrInX, NeutrOutX);
	if (!OptFree) fprintf(fout, "RID  = %e W     (X = %g - %g m)\n", SumRID, RIDInX, RIDOutX);
	if (!OptFree) fprintf(fout, "Calorimeter = %e W  (X = %g - %g m)\n", SumCal, CalInX, CalOutX);
	if (!OptFree) fprintf(fout, "DUCT = %e W     (X = %g - %g m)\n", SumDuct, PreDuctX, Duct8X);

	fclose(fout);

}

void CBTRDoc:: WriteSumPowerAngle(char * name)
{
	FILE * fout;
	fout= fopen(name, "w");
	if (fout == NULL) {
			AfxMessageBox("failed to create file", MB_ICONSTOP | MB_OK);
			return;
	}
	fprintf(fout, "Power deposition via falling angle  \n");
	fprintf(fout, " Angle, grad  \t Power, W \n");

	double angle, power, Sum = 0;
	//double x, power, Sum = 0, SumN = 0, SumRID = 0, SumCal = 0, SumDuct = 0;
	for (int l = 0; l < SumPowerAngle.GetSize(); l++) {
		angle = SumPowerAngleStep * (l + 1);
		power = SumPowerAngle[l];
		fprintf(fout, " %g \t %g \n", angle, power);
		Sum += power;
	}
	fprintf(fout, "Total power = %g W   (0 - 90 grad)\n", Sum);
	
	fclose(fout);

}

void CBTRDoc::DeleteContents() 
{
	SegmCentreHor.RemoveAll();
	SegmCentreVert.RemoveAll();
	ActiveCh.RemoveAll();
	ActiveRow.RemoveAll();
	RectIS.RemoveAll();
	RectISrow.RemoveAll();
	BeamletAngleHor.RemoveAll();
	BeamletAngleVert.RemoveAll();
	BeamletPosHor.RemoveAll();
	BeamletPosVert.RemoveAll();

//	MFdata.RemoveAll();
//	MFXdata.RemoveAll();
	FWdata.RemoveAll();
	DecayArray.RemoveAll();
	DecayPathArray.RemoveAll();
	DataComment.RemoveAll();
	DataName.RemoveAll();
	DataType.RemoveAll();
	DataValue.RemoveAll();
	Attr_Array.RemoveAll();
	BeamEntry_Array.RemoveAll();
	PolarAngle.RemoveAll();
	PolarCurrent.RemoveAll();
	
	ReionArray.RemoveAll(); //ReionArrayX.RemoveAll();	ReionArrayCurr.RemoveAll();
	NeutrArray.RemoveAll();
	PlasmaProfileNTZ.RemoveAll();
	PlasmaProfilePSI.RemoveAll();
	Load_Arr.RemoveAll();
	
	while (!PlatesList.IsEmpty()) {
		delete (PlatesList.RemoveHead());
	}

	while (!AddPlatesList.IsEmpty()) {
		delete (AddPlatesList.RemoveHead());
	}

	Singap_Array.RemoveAll();
	Attr_Array.RemoveAll();
	BeamEntry_Array.RemoveAll();
	Exit_Array.RemoveAll();
	VolumeVector.clear();
	ExitArray.RemoveAll();
	PlasmaImpurA.RemoveAll();
	PlasmaImpurW.RemoveAll();
		
	//if (ParticlesFile != NULL) fclose(ParticlesFile);
	CDocument::DeleteContents();
}

void  CBTRDoc:: SetVShifts()
{
	if (OptFree) return;
	double Xc;
	Xc = 0.5 * (NeutrInX + NeutrOutX);
	VShiftNeutr = Xc * tan(VertInclin);
	Xc = 0.5 * (RIDInX + RIDOutX);
	VShiftRID = Xc * tan(VertInclin);
	Xc = 0.5 * (CalInX + CalOutX);
	VShiftCal = Xc * tan(VertInclin);
	Xc = PreDuctX;// Scraper1
	VShiftDia = Xc * tan(VertInclin);
	Xc = DDLinerInX; // Scraper2
	VShiftLinerIn = Xc * tan(VertInclin);
	Xc = DDLinerOutX; // Duct0
	VShiftLinerOut = Xc * tan(VertInclin);
	Xc = Duct1X;
	VShiftDuct1 = Xc * tan(VertInclin);
	Xc = Duct2X;
	VShiftDuct2 = Xc * tan(VertInclin);
	Xc = Duct3X;
	VShiftDuct3 = Xc * tan(VertInclin);
	Xc = Duct4X;
	VShiftDuct4 = Xc * tan(VertInclin);
	Xc = Duct5X;
	VShiftDuct5 = Xc * tan(VertInclin);
	Xc = Duct6X;
	VShiftDuct6 = Xc * tan(VertInclin);
	Xc = Duct7X;
	VShiftDuct7 = Xc * tan(VertInclin);
	Xc = Duct8X;
	VShiftDuct8 = Xc * tan(VertInclin);

}

////-------------  BEAM --------------------------
void  CBTRDoc:: SetSINGAPfromMAMUG()
{
	BeamEntry_Array.RemoveAll();
	BEAMLET_ENTRY be;

	int i, j, ii, jj;
	int Ny = (int)NofBeamletsHor, Nz = (int)NofBeamletsVert; // MAMuG
	int NSy = (int)NofChannelsHor, NSz = (int)NofChannelsVert; // MAMuG
	int	Ntotal = Ny*Nz*NSy*NSz;
	
	// double BeamPower = IonBeamPower; // MW

	
	for (i = 0; i<NSy;  i++) { ///NofChannelsHor;
		if (!ActiveCh[i]) continue;
			
	for (j = 0; j<NSz; j++) {  ///NofChannelsVert;
	if (!ActiveRow[j]) continue;	
	
	for (ii = 0; ii<Ny; ii++)  // NofBeamletsHor
	for (jj = 0; jj<Nz; jj++) // NofBeamletsVert
	{			
		be.Active = TRUE;
		be.PosY = BeamletPosHor[i*Ny + ii]; // MAMuG
		be.PosZ = BeamletPosVert[j*Nz + jj]; // MAMuG
		be.AlfY = BeamletAngleHor[i*Ny + ii];
		be.AlfZ = BeamletAngleVert[j*Nz + jj];
		be.DivY = BeamCoreDivY;
		be.DivZ = BeamCoreDivZ;
		be.Fraction = 1;
		be.i = ii; be.j = jj;

		BeamEntry_Array.Add(be);
	} // ii,jj
	} //j
	} // i
	NofBeamletsTotal = Ntotal;
	NofBeamlets = BeamEntry_Array.GetSize();// active
}

void  CBTRDoc:: SetSINGAP()
{
//	if (!OptSINGAP) return;

	CString S;
	FILE * fold;
	FILE * fnew;
	int res, reply;
	char oldname[1024], newname[1024];

	if (!SINGAPLoaded) {
		strcpy(oldname, "Beamlets.txt"); // old name
		strcpy(newname, BeamFileName); // new BEAM_BERT.txt

		if ((fold = fopen(oldname, "r")) == NULL) { // old file not found
			// try new name 
			if ((fnew = fopen(BeamFileName, "r")) == NULL) {
				S.Format("Define file to attach the Beam\n <CANCEL> will activate MAMuG default settings");
				reply = AfxMessageBox(S, 3);
				if (reply != IDYES ) { SINGAPLoaded = FALSE; OptSINGAP = FALSE; return;}
				else ReadSINGAP();
			} // new file not found also
			else { // new file found
				fclose(fnew);
				res = ReadBeamletsOld(newname);
				if (res >=1) { SINGAPLoaded = TRUE; BeamFileName = newname; }
			}// new file found
		} // file not found
		else { // old file found
			fclose(fold);
			res = ReadBeamletsOld(oldname);
			if (res >=1) { SINGAPLoaded = TRUE; BeamFileName = oldname;}
		}
	} // !SINGAPLoaded
	
	BeamEntry_Array.RemoveAll();

	BEAMLET_ENTRY be;

	int N = Singap_Array.GetSize();
	if (N <1) return; 
	
	if (!SINGAPLoaded) {
		return;
	}

	for (int k = 0; k < N; k++) {
		be = Singap_Array.GetAt(k);
		be.AlfY += BeamMisHor; //mrad -> rad
		be.AlfZ += BeamMisVert + BeamVertTilt;
		if  (!OptFree) be.AlfZ += VertInclin; // NBI standard
	
	/*	int i, j;// = (int)((be.PosY + 0.32) / 0.16); // channel number

		/// set active chanels	
		iseg = 0;
		double Dmin = fabs(be.PosY - SegmCentreHor[0]);
		for (i = 1; i < (int)NofChannelsHor; i++) {// find iseg by closest centre
			//HorCentre = SegmCentreHor[i];
			//if (SegmStepHor > 1.e-6) maxhor = SegmStepHor * 0.5;
			if (fabs(be.PosY - SegmCentreHor[i]) < Dmin ) {
				Dmin = fabs(be.PosY - SegmCentreHor[i]);
				iseg = i; 
			}
		}
		//// set active rows
		jseg = 0;
		Dmin = fabs(be.PosZ - SegmCentreVert[0]);
		for (j = 1; j <(int)NofChannelsVert; j++) {
			//VertCentre = SegmCentreVert[j];
		//	if (fabs(be.PosZ - VertCentre) < SegmStepVert * 0.5) {
			if (fabs(be.PosZ - SegmCentreVert[j]) < Dmin ) {
				Dmin = fabs(be.PosZ - SegmCentreVert[j]);
				jseg = j; 
			}
		}
	
		be.Active = ActiveCh[iseg] * ActiveRow[jseg];
	*/
		
		be.Active = TRUE; // for SINGAP all beamlets are active!!!
		BeamEntry_Array.Add(be);
	}
	NofBeamletsTotal = BeamEntry_Array.GetSize();
	NofBeamlets = NofBeamletsTotal;
//	OptSINGAP = TRUE;
}

void CBTRDoc:: ReadSINGAP()
{
	char name[1024];
	int res;

//	SINGAPLoaded = FALSE;
	
	CFileDialog dlg(TRUE, "dat; txt | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Beamlets data (*.txt);(*.dat)  | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
	if (dlg.DoModal() == IDOK) {
			strcpy(name, dlg.GetPathName());
		
			CPreviewDlg pdlg;
			pdlg.m_Filename = name;
			if (pdlg.DoModal() == IDCANCEL) {
			//	OptSINGAP = FALSE;
			//	SINGAPLoaded = FALSE;
				AfxMessageBox("No Beam accepted", MB_ICONINFORMATION | MB_OK);
				return;
			}

			if (!IsBeamletsFile(name)) { 
			//	OptSINGAP = FALSE;
			//	SINGAPLoaded = FALSE; 
				AfxMessageBox("No Beam accepted", MB_ICONINFORMATION | MB_OK);
				return; 
			}
			
			if (OldBeamletsFormat(name) == TRUE) 
				 res = ReadBeamletsOld(name);// BERT's beam 10 col
			else res = ReadBeamletsNew(name);// AIK's beam 9 col
			
			if (res < 1)	{
			//	OptSINGAP = FALSE;
			//	SINGAPLoaded = FALSE;
				AfxMessageBox("Invalid data format",	MB_ICONSTOP | MB_OK); 
				return;
			}
			else  {
				SINGAPLoaded = TRUE;
				SetTitle(name);
				BeamFileName = name;
				return;
			}
	} // IDOK
	else {
	//	OptSINGAP = FALSE;
	//	SINGAPLoaded = FALSE;
		AfxMessageBox("No Beam accepted", MB_ICONINFORMATION | MB_OK);
		return;
	}

}

bool CBTRDoc::IsBeamletsFile(char * name)
{
	CString S;
	CString line;
	char buf[1024];
	FILE * fin;
	int reply, values, length;
	if ((fin= fopen(name, "r")) == NULL) {
		AfxMessageBox("Failed to open file", MB_ICONINFORMATION | MB_OK);
		return FALSE;
	}
	if (fgets(buf, 1024, fin) == NULL) { 
		AfxMessageBox("Invalid data format", MB_ICONSTOP | MB_OK); 
		fclose(fin); 
		return FALSE;
	}

//	char *buff, *nptr, *endptr;
	double v1, v2, v3, v4, v5, v6, v7;

/*	int length = text.GetLength()*2;
	buff = (char *)calloc(length, sizeof(char));
	strcpy(buff, text);
	
	nptr = buff;

	for (j = 0; j <= Ny; j++)
	for (i = 0; i <= Nx; i++) {
		val = strtod(nptr,&endptr);
		plate0->Load->Val[i][j] = val;
		if (nptr == endptr) nptr++; //catch special case
		else nptr = endptr;
	}
*/	
	line = "";
	length = 0;
	BOOL datagot = FALSE;
	while (!feof(fin) && !datagot) {

		if (fgets(buf, 1024, fin) == NULL) break; // read  line
		if (sscanf(buf, "%le", &v1) < 1) {
			datagot = FALSE; 
			continue;
		}
		
		if (sscanf(buf, "%le %le", &v1, &v2) < 2) {
			datagot = TRUE; 
			values = 1;
		}
		if (sscanf(buf, "%le %le %le", &v1, &v2, &v3) < 3) {
			datagot = TRUE; 
			values = 2;
		}
		if (sscanf(buf, "%le %le %le %le", &v1, &v2, &v3, &v4) < 4) {
			datagot = TRUE; 
			values = 3;
		}
		if (sscanf(buf, "%le %le %le %le %le", &v1, &v2, &v3, &v4, &v5) < 5) {
			datagot = TRUE; 
			values = 4;
		}
		if (sscanf(buf, "%le %le %le %le %le %le", &v1, &v2, &v3, &v4, &v5, &v6) < 6) {
			datagot = TRUE; 
			values = 5;
		}
		if (sscanf(buf, "%le %le %le %le %le %le %le", &v1, &v2, &v3, &v4, &v5, &v6, &v7) < 7) {
			datagot = TRUE; 
			values = 6;
		}
		if (sscanf(buf, "%le %le %le %le %le %le %le", &v1, &v2, &v3, &v4, &v5, &v6, &v7) == 7) {
			datagot = TRUE; 
			values = 7;
		}
		line = buf;
	}
	fclose(fin);

	if (values < 7) {
		 S.Format("Are you sure this is Beamlets array file? \n 1st data string found:\n %s", line);
		 reply =  AfxMessageBox(S, 3);
		 if (reply == IDYES) return TRUE;
		 else return FALSE;
	 }
	
	return TRUE;
			
}

bool CBTRDoc:: OldBeamletsFormat(char * name) // check if this is Bert's file - 10 columns
{
	CString line;
	char buf[1024];
	FILE * fin;
	if ((fin= fopen(name, "r")) == NULL) {
		AfxMessageBox("Failed to open file", MB_ICONINFORMATION | MB_OK);
		return FALSE;
	}
	if (fgets(buf, 1024, fin) == NULL) { 
		AfxMessageBox("Invalid data format", MB_ICONSTOP | MB_OK); 
		fclose(fin); 
		return FALSE;
	}
	line = buf;
	line.MakeUpper();
	int pos1 = line.Find("START");
	int pos2 = line.Find("POS-X");
	int pos3 = line.Find("WID-X");
	int pos4 = line.Find("ALF-X");

	if (pos1 >= 0 && pos2 >= 0 && pos3 >= 0 && pos4 >= 0) { fclose(fin);	return TRUE;}
	
	if (fgets(buf, 1024, fin) == NULL) { 
		AfxMessageBox("Invalid line 2", MB_ICONSTOP | MB_OK); 
		fclose(fin);
		return FALSE;
	}
	double a,b,c,d,e,f,g,h,i,j;
	int res  = sscanf(buf, "%le %le %le %le %le %le %le %le %le %le", &a, &b, &c, &d, &e, &f, &g, &h, &i, &j);
	if (res < 10) {fclose(fin); return FALSE;}
	if (a < 1.e-6) { fclose(fin); return TRUE;}

	
	fclose(fin);
	return FALSE;

}

int CBTRDoc:: ReadBeamletsOld(char * name) // BERT de ESHE file (old)
// START  POS-X  WID-X  ALF-X  DIV-X  POS-Y  WID-Y  ALF-Y  DIV-Y   FRACTION
{
	Singap_Array.RemoveAll();
	BEAMLET_ENTRY be;
	char buf[1024];
	double st, px, wx, ax, dx, py, wy, ay, dy, fr;
	int total, result;
	CString S;
	double SumFract = 0;

	FILE * fin = fopen(name, "r");
	fgets(buf, 1024, fin); // read  line
	total = 0;
	while (!feof(fin)) {
		result = sscanf(buf, "%le %le %le %le %le %le %le %le %le %le", &st, &px, &wx, &ax, &dx, &py, &wy, &ay, &dy, &fr);
	//	result = fscanf(fin, "%le %le %le %le %le %le %le %le %le %le", &st, &px, &wx, &ax, &dx, &py, &wy, &ay, &dy, &fr);
		if (result == 10) {
			be.PosY = px * 0.001; //mm -> m
			be.PosZ = py * 0.001;
			be.AlfY = ax * 0.001;// mrad -> rad
			be.AlfZ = ay * 0.001;// 
			be.DivY = dx * 0.001;
			be.DivZ = dy * 0.001;
			be.Fraction = fr; // =1
			if (total == 0) { // set common 
				BeamCoreDivY = dx * 0.001;
				BeamCoreDivZ = dy * 0.001;
			}
			//int i  = (int)((be.PosY + 0.32) / 0.16); // channel number
			be.Active = TRUE;
			Singap_Array.Add(be);
			total++;
			SumFract += fr;
			fgets(buf, 1024, fin); // read next line
		} // scanned 10 fields
		else {
			fgets(buf, 1024, fin); // read next line
		}
	} // eof
	fclose(fin);

	if (total > 0) {
		OptSINGAP = TRUE;
		S.Format("%d beamlets accepted \n file %s", total, name);
		AfxMessageBox(S);
	}
	
	if (total > 0) {
		double AverFract = SumFract / total; // normally should be 1
		if (AverFract < 1.e-12) AverFract = 1;
		// NormFract = be.Fraction / AverFract 
		for (int i = 0; i < total; i++) 
			Singap_Array[i].Fraction /= AverFract;
	}

	return total;
	
}

int CBTRDoc:: ReadBeamletsNew(char * name) // AIK file (new) - 9 columns
//"Yo"	"AY"	"AcY"	"Zo"	"AZ"	"AcZ"	rI	iY		iZ
// Yo	Ay	    Acy	    Zo	    Az  	 Acz   FrI	column	row
{
	Singap_Array.RemoveAll();
	BEAMLET_ENTRY be;
	char buf[1024];
	double Y0, Ay, Acy, Z0, Az, Acz, FrI;
	int iy, jz;
	int valid, total, comment, result, maxIy, maxJz;
	CString S;
	double SumFract = 0;

	FILE * fin = fopen(name, "r");
	if (fin == NULL) { 
		S.Format("Beam array %s not found!", name);
		AfxMessageBox(S);
		return 0;
	}

	fgets(buf, 1024, fin); // read  line

	total = 0;	valid = 0;	comment = 0;
	maxIy = 0; maxJz = 0;

	while (!feof(fin)) {
		result = sscanf(buf,"%le %le %le %le %le %le %le %d %d", 
						&Y0, &Ay, &Acy, &Z0, &Az, &Acz, &FrI, &iy, &jz );

						/*	result = fscanf(fin, "%le %le %le %le %le %le %le ", 
							&Y0, &Ay, &Acy, &Z0, &Az, &Acz, &FrI);*/

		if (result == 9) { 
			if (FrI <= 1.e-6) { // check-up for zero beamlet
				total++; 
				fgets(buf, 1024, fin);  
				continue;
			}
			be.PosY = Y0 * 0.001; //mm -> m
			be.PosZ = Z0 * 0.001;
			be.AlfY = Ay * 0.001;// mrad -> rad
			be.AlfZ = Az * 0.001;// 
			be.DivY = Acy * 0.001;
			be.DivZ = Acz * 0.001;
			be.Fraction = FrI; // =1
			
			if (iy < 0) iy = 0;
			if (jz < 0) jz = 0; 
			be.i = iy; be.j = jz;
			if (valid == 0) { // set common 
				BeamCoreDivY = Acy * 0.001;
				BeamCoreDivZ = Acz * 0.001;
			}
			//int i  = (int)((be.PosY + 0.32) / 0.16); // channel number
			be.Active = TRUE;
			Singap_Array.Add(be);
			valid++;
			total++;
			SumFract += FrI;
			maxIy = Max(maxIy, iy);
			maxJz = Max(maxJz, jz);
			fgets(buf, 1024, fin); // read  line
		} // scanned 9 fields
	
		else { // comments line
			fgets(buf, 1024, fin); // read  line
			comment++;
			total++;
		}
			
	} // eof
	fclose(fin);


	S.Format(" Non-zero beamlets - %d \n"
			"Max Horiz. index - %d\n"
			"Max Vert. index - %d\n\n"
			"Total lines in file - %d\n"
			"Comments or dubious lines - %d\t\n", 
			valid, maxIy, maxJz, total, comment);
	AfxMessageBox(S);

	if (valid < 1) return 0;

	double AverFract = SumFract / valid; // normally should be 1
	if (AverFract < 1.e-12) AverFract = 1;
	// NormFract = be.Fraction / AverFract 
	for (int i = 0; i < valid; i++) 
		Singap_Array[i].Fraction /= AverFract;

/*	BOOL isRegular = CheckRegularity(maxIy, maxJz); // SINGAP or MAMuG ?
	if (isRegular) { 
		OptSINGAP = FALSE;
//		ActiveCh.SetSize(10);
//		ActiveRow.SetSize(10);
//		SetBeam();
//		SetStatus();
		S.Format("Beam array is Regular and Symmetrical!\nactive option - MAMuG\n\nDetails:\n\n"
			"  Segments %d  Hor.Step %g  Focus %g\t\n"
			"  Groups   %d  Vert.Step %g Focus %g\n\n"
			"  beamlets %d x %d\n"
			"  steps hor/vert  %g x %g\n"
			"  focus hor/vert  %g x %g\n", 
			(int)NofChannelsHor, SegmStepHor, BeamAimHor, 
			(int)NofChannelsVert, SegmStepVert, BeamAimVert,
			(int)NofBeamletsHor, (int)NofBeamletsVert, AppertStepHor, AppertStepVert,
			  AppertAimHor, AppertAimVert); 
		AfxMessageBox(S);
	}
	else { */
		OptSINGAP = TRUE;
		SINGAPLoaded = TRUE;
		BeamFileName = name;
	//}

	return valid; //total;
}

double Round(double inval, int digits) // total non-zero digits
{
	double aval = fabs(inval);
	double val, outval;
	int ival;
	double imax = pow(10.0, digits);
	double imin = pow(10.0, digits-1); 
	int k;
	double ord;
	
	if (aval >= imin && aval <= imax) {
		ival = (int)inval; 
		if (ival - inval >= 0.5) ival--; 
		if (inval - ival >= 0.5) ival++; 
		outval = (double)ival;
	}
	
	else if (aval < imin) {
		k = 0;
		val = inval;
		while (val < imin) { val *= 10; k++; }
		ival = (int)val;
		if (ival - val >= 0.5) ival--;
		if (val - ival >= 0.5) ival++;
		ord = pow(10.0, k);
		outval = (double)ival / ord;
	} // aval < imin

	else {//aval > imax
		k = 0;
		val = inval;
		while (val > imax) {val *= 0.1; k++; }
		ival = (int)val;
		if (ival - val >= 0.5) ival--;
		if (val - ival >= 0.5) ival++;
		ord = pow(10.0, k);
		outval = (double)ival * ord;
	}

	//outval = (double)ival;
	return outval;

}

bool CBTRDoc:: CheckRegularity(int Iy, int Jz) // SINGAP or MAMuG ?
{
	CString S;

	CArray <double, double> posY;
	CArray <double, double> posZ;
	CArray <double, double> aimY;
	CArray <double, double> aimZ;
	double hy, hz, Hy, Hz, distAy, distAz, DistAy, DistAz; 
	int ny, nz, Ny, Nz;
	double y, z, ay, az; //positions / aimings of scrutinized beamlet
	BEAMLET_ENTRY be;
	double dPos = 0.001, dAim = 0.001; // precisions 
	double maxPos, maxAim; // precisions base 

	if (Iy*Jz == 1) { // 1 beamlet
		be = Singap_Array.GetAt(0);
		if (fabs(be.PosY) < 0.001*dPos && fabs(be.PosZ) < 0.001*dPos 
			&& fabs(be.AlfY) < 0.001*dAim && fabs(be.AlfZ) < 0.001*dAim) 
		{
			NofChannelsHor = 1;	NofChannelsVert = 1;
			NofBeamletsHor = 1;	NofBeamletsVert = 1;
			SegmStepHor = 0;		SegmStepVert = 0;
			AppertStepHor = 0;		AppertStepVert = 0;
			BeamAimHor = AreaLong;	BeamAimVert = AreaLong;
			AppertAimHor = 999;	AppertAimVert = 999;
		//	S.Format("Single Regular beamlet found\n active option - MAMuG"); 
		//	AfxMessageBox(S);
			return 1;
		} // regular beamlet
		else 
		{
			S.Format("Single Beamlet found\n with Non-Zero Position and/or Angle \n\n active option - SINGAP"); 
			AfxMessageBox(S);
			return 0;
		} // non-regular beamlet
	}
//////// check if Total Beamlets = Iy * Jz
	int total = Singap_Array.GetSize();
	if (total != Iy * Jz) {
		S.Format(" Total Number of beamlets (%d) does not match Max Indexes (%d x %d)!\n active option - SINGAP", 
			total, Iy, Jz);
		AfxMessageBox(S);
		return (0); // non-regular
	}
	
////////// check positions regularity 
	int k, indI, indJ;
	maxPos = 0; maxAim = 0;
	for (k = 0; k < total; k++) { // fill the base arrays - all beamlets will be compared with it
		be = Singap_Array.GetAt(k);
		y = be.PosY; z = be.PosZ;
		ay = be.AlfY; az = be.AlfZ;
		maxPos = Max(maxPos, fabs(y)); maxPos = Max(maxPos, fabs(z));
		maxAim = Max(maxAim, fabs(ay)); maxAim = Max(maxAim, fabs(az));
		if (be.i > posY.GetSize()) { posY.Add(y); aimY.Add(ay);}
		if (be.j > posZ.GetSize()) { posZ.Add(z); aimZ.Add(az);}
	}
	if (posY.GetSize() != Iy || posZ.GetSize() != Jz) {
		S.Format(" Horiz. or Vert. Index mismatch!\n active option - SINGAP"); 
		AfxMessageBox(S);
		return (0); // non-regular
	}
//	dPos = 0.001 * maxPos;
//	dAim = 0.001 * maxAim;

	for (k = 0; k < total; k++) { // compare beamlet pos/aim with base values
		be = Singap_Array.GetAt(k);
		y = be.PosY; z = be.PosZ;
		ay = be.AlfY; az = be.AlfZ;
		indI = be.i-1; indJ = be.j-1;
		if (fabs(y - posY[indI]) > dPos * maxPos || fabs(z - posZ[indJ]) > dPos * maxPos) {
			S.Format(" Non-regular Beamlets positions!\n active option - SINGAP\n\n i = %d, j = %d", 
						indI+1, indJ+1); 
			AfxMessageBox(S);
			return (0); // non-regular positions
		}
		if (fabs(ay - aimY[indI]) > dAim * maxAim || fabs(az - aimZ[indJ]) > dAim * maxAim) {
			S.Format(" Non-regular Beamlets aimings!\n active option - SINGAP\n\n i = %d, j = %d",
						indI+1, indJ+1); 
			AfxMessageBox(S);
			return (0); // non-regular aimings
		}
	} // k

	double y0, y1, z0, z1;
	double dymin, dymax, dzmin, dzmax;
	int n0 = 0;

////////// horizontal check -> Ny, ny, Hy, hy
	dymin = Max(maxPos, 1000.);	dymax = 0; 
	y0 = posY[0]; 
	for (k = 1; k < Iy; k++) { // define steps Y 
		y1 = posY[k];
		dymin = Min(dymin, fabs(y1-y0));
		dymax = Max(dymax, fabs(y1-y0));
		y0 = y1;
	}

	if (Iy == 1) { dymin = 0; dymax = 0; }

	if (fabs(dymax - dymin) < dPos * maxPos) { // segment = 1 (vert. channel) 
		Ny = 1; ny = Iy;
		Hy = 0; hy = dymin;
		DistAy = AreaLong; dymax = 0;
		//distAy = - posY[0] / atan(aimY); 
	} // segment = 1
	
	else { // segments >1
		ny = 1; Ny = 1;
		y0 = posY[0]; 
		
		for (k = 1; k < Iy; k++) {
			y1 = posY[k];
			//d1 = - posY[k] / atan(aimY[k]);
			if (fabs(fabs(y1-y0) - dymin) < dPos * maxPos) ny++; // next aperture within segment
			else if (fabs(fabs(y1-y0) - dymax) < dPos * maxPos) { // next segment
				if (Ny == 1) n0 = ny;
				else if (ny != n0) {
					S.Format(" Beamlets horiz. number within segment is not Const!\n active option - SINGAP"); 
					AfxMessageBox(S);
					return (0); // beamlet horizontal number not const
				}
				ny = 1; Ny++; 
			} // next segment
			else { 
				S.Format(" Beamlets horizontal steps mismatch!\n active option - SINGAP\n\n k = %d", k+1); 
				AfxMessageBox(S);
				return (0); // non-regular horizontal steps
			}
			y0 = y1;
		} // k
		hy = dymin; 
		Hy = dymax + dymin * (ny - 1);

	} // segments >1



///// Aimings Y (Segments, Beamlets) //////////////////////////
	int kseg;
	double Pos0; // segment centre //ay = - (posY[0] - Y0) / atan(aimY[0]); 
	double Dist0, Dist1; // segment axis aiming dist
	double dist0, dist1; // beamlet aiming dist

	Pos0 = (posY[0] + posY[ny - 1]) * 0.5; // 1st segment
	if (fabs(aimY[0] - aimY[ny-1]) < dAim * maxAim) dist0 = 999;
	else	dist0 = (posY[ny-1] - posY[0]) / (aimY[0] - aimY[ny-1]);
	if (fabs(posY[0] - Pos0 + tan(aimY[0]) * dist0) < dPos * maxPos) Dist0 = 999;
	else  Dist0 = -Pos0 * dist0 / (posY[0] - Pos0 + tan(aimY[0]) * dist0); 

	for (kseg = 1; kseg < Ny; kseg++) {
		if (Odd(Ny) && kseg == (Ny-1)/2) continue; // central column - zero aiming angle!
		Pos0 = (posY[kseg*ny] + posY[kseg*ny + ny - 1]) * 0.5; 
		if (fabs(aimY[kseg*ny] - aimY[kseg*ny + ny-1]) < dAim * maxAim) dist1 = 999;
		else	dist1 = (posY[kseg*ny + ny-1] - posY[kseg*ny]) / (aimY[kseg*ny] - aimY[kseg*ny + ny-1]);
		if (fabs(posY[kseg*ny] - Pos0 + tan(aimY[kseg*ny]) * dist1) < dPos * maxPos) Dist1 = 999;
		else  Dist1 = -Pos0 * dist1 / (posY[kseg*ny] - Pos0 + tan(aimY[kseg*ny]) * dist1); 
		
		if (fabs(Dist1 - Dist0) > dPos * Dist0) {
			S.Format(" Segments horizontal aimings mismatch!\n active option - SINGAP\n\n k = %d"
				" D0 = %g D1 = %g", kseg+1, Dist0, Dist1); 
			AfxMessageBox(S);
			return (0); // non-regular aimings
		}
		if (fabs(dist1 - dist0) > dPos * dist0) {
			S.Format(" Beamlets horizontal aimings mismatch!\n active option - SINGAP\n\n k = %d"
				" d0 = %g d1 = %g", kseg+1, dist0, dist1); 
			AfxMessageBox(S);
			return (0); // non-regular aimings
		}
	}// kseg

	DistAy = Dist0;
	distAy = dist0;


////////// vertical check -> Nz, nz, Hz, hz
	dzmin = Max(maxPos, 1000.);	dzmax = 0;
	z0 = posZ[0];
	for (k = 1; k < Jz; k++) { // define steps Z 
		z1 = posZ[k];
		dzmin = Min(dzmin, fabs(z1-z0));
		dzmax = Max(dzmax, fabs(z1-z0));
		z0 = z1;
	}

	if (Jz == 1) { dzmin = 0; dzmax = 0; }

	if (fabs(dzmax - dzmin) < dPos * maxPos) { // Single group (horizontal row) 
		Nz = 1; nz = Jz;
		Hz = 0; hz = dzmin;
		DistAz = 999; dzmax = 0; 
	//	distAz = - posZ[0] / atan(aimZ); 
	} // groups = 1

	else { //  groups >1
		nz = 1; Nz = 1;
		z0 = posZ[0]; 
		for (k = 1; k < Jz; k++) {
			z1 = posZ[k];
			if (fabs(fabs(z1-z0) - dzmin) < dPos * maxPos) nz++; // next aperture within segment
			else if (fabs(fabs(z1-z0) - dzmax) < dPos * maxPos) { // next segment
				if (Nz == 1) n0 = nz;
				else if (nz != n0) {
					S.Format(" Beamlets vert. number within segment is not Const!\n active option - SINGAP"); 
					AfxMessageBox(S);
					return (0); // beamlet horizontal number not const
				}
				nz = 1; Nz++; 
			} // next segment
			else { 
				S.Format(" Beamlets vertical steps mismatch!\n active option - SINGAP"); 
				AfxMessageBox(S);
				return (0); // non-regular vert. steps
			}
			z0 = z1;
		} // k

		hz = dzmin; 
		Hz = dzmax + dzmin * (nz - 1);
	}


///// Aimings Z  (Segments, Beamlets) /////////////////

/*	int kseg;
	double Pos0; // segment centre //ay = - (posY[0] - Y0) / atan(aimY[0]); 
	double Dist0, Dist1; // segment axis aiming dist
	double dist0, dist1; // beamlet aiming dist
*/
	Pos0 = (posZ[0] + posZ[nz-1]) * 0.5; // 1st segment
	if (fabs(aimZ[0] - aimZ[nz-1]) < dAim * maxAim) dist0 = 999;
	else	dist0 = (posZ[nz-1] - posZ[0]) / (aimZ[0] - aimZ[nz-1]);
	if (fabs(posZ[0] - Pos0 + tan(aimZ[0]) * dist0) < dPos * maxPos) Dist0 = 999;
	else  Dist0 = -Pos0 * dist0 / (posZ[0] - Pos0 + tan(aimZ[0]) * dist0); 

	for (kseg = 1; kseg < Nz; kseg++) {
		if (Odd(Nz) && kseg == (Nz-1)/2) continue; // central row - zero aiming angle!
		Pos0 = (posZ[kseg*nz] + posZ[kseg*nz + nz-1]) * 0.5; 
		if (fabs(aimZ[kseg*nz] - aimZ[kseg*nz + nz-1]) < dAim * maxAim) dist1 = 999;
		else	dist1 = (posZ[kseg*nz + nz-1] - posZ[kseg*nz]) / (aimZ[kseg*nz] - aimZ[kseg*nz + nz-1]);
		if (fabs(posZ[kseg*nz] - Pos0 + tan(aimZ[kseg*nz]) * dist1) < dPos * maxPos) Dist1 = 999;
		else  Dist1 = -Pos0 * dist1 / (posZ[kseg*nz] - Pos0 + tan(aimZ[kseg*nz]) * dist1); 
	
		if (fabs(Dist1 - Dist0) > dPos * Dist0) {
			S.Format(" Groups vertical aimings mismatch!\n active option - SINGAP\n\n k = %d"
				" D0 = %g  D1 = %g", kseg+1, Dist0, Dist1); 
			AfxMessageBox(S);
			return (0); // non-regular aimings
		}
		if (fabs(dist1 - dist0) > dPos * dist0) {
			S.Format(" Beamlets vertical aimings mismatch!\n active option - SINGAP\n\n k = %d"
				" d0 = %g  d1 = %g", kseg+1, dist0, dist1); 
			AfxMessageBox(S);
			return (0); // non-regular aimings
		}
	}// kseg

	DistAz = Dist0;
	distAz = dist0;


//////// if regular - set 12 parameters of regular beam 
	int dig = 3; // rounding precision
	NofChannelsHor = Ny;	NofChannelsVert = Nz;
	NofBeamletsHor = ny;	NofBeamletsVert = nz;
	SegmStepHor = Hy;		SegmStepVert = Hz;
	AppertStepHor = hy;	AppertStepVert = hz;
	BeamAimHor = Round(DistAy, dig);	
	BeamAimVert = Round(DistAz, dig);
	AppertAimHor = Round(distAy, dig);
	AppertAimVert = Round(distAz, dig);

	posY.RemoveAll(); posZ.RemoveAll(); 
	aimY.RemoveAll(); aimZ.RemoveAll(); 
	return (1); // regular
}

void CBTRDoc:: SetGaussBeamlet(double DivY, double DivZ)
{
//	CWaitCursor wait;
	CArray<double, double> SumCoreY;
	CArray<double, double> SumCoreZ;
	CArray<double, double> SumHaloY;
	CArray<double, double> SumHaloZ;
	CArray<double, double> AlfaY;
	CArray<double, double> AlfaZ;
	ATTRIBUTES Attr;
	
	Attr_Array.RemoveAll();

	if (BeamHaloDiverg < 1.e-16) BeamHaloPart = 0;
	if (DivY * DivZ < 1.e-16) BeamHaloPart = 1;

	int i, j;
	double core, halo, core0, halo0;
	double alfaY, alfaZ, alfaEff;
	double y, z, hy, hz;
	
	double divY = DivY;
	double divZ = DivZ;
	if (fabs(divY) < 1.e-16) divY = 0.00001;
	if (fabs(divZ) < 1.e-16) divZ = 0.00001;

	double AvCoreDiv = sqrt(divY * divZ);
	if (fabs(AvCoreDiv) < 1.e-16) AvCoreDiv = 0.00001; 
	double HaloDivRel = BeamHaloDiverg / AvCoreDiv;
	double HaloDivY = HaloDivRel * divY;
	double HaloDivZ = HaloDivRel * divZ;
	if (fabs(HaloDivY) < 1.e-16) HaloDivY = 0.00001;
	if (fabs(HaloDivZ) < 1.e-16) HaloDivZ = 0.00001;
		
	double IntLimitY;// = 3 * Max(divY, HaloDivY);
	double IntLimitZ;// = 3 * Max(divZ, HaloDivZ);
	if (BeamHaloPart < 1.e-3) {
		IntLimitY = SumGauss(1 - CutOffCurrent, divY);
		IntLimitZ = SumGauss(1 - CutOffCurrent, divZ);
	}
	else {
		IntLimitY = SumGauss(1 - CutOffCurrent, divY, HaloDivY, BeamHaloPart); // reduce
		IntLimitZ = SumGauss(1 - CutOffCurrent, divZ, HaloDivZ, BeamHaloPart); // reduce
	}
	double TotalCore = 1;// IntegralErr(IntLimitY, divY) * IntegralErr(IntLimitZ, divZ);
	double TotalHalo = 1;//IntegralErr(IntLimitY, BeamHaloDiverg) * IntegralErr(IntLimitZ, BeamHaloDiverg);
//	double Total =	(1-BeamHaloPart) * TotCore + BeamHaloPart * TotHalo; // 0..+inf
	int Ny = (int)BeamSplitNumberY;
	int Nz = (int)BeamSplitNumberZ;

	
	if (Ny <1) Ny = 1; 
	if (Nz <1) Nz = 1; 

	hy = 2 * IntLimitY / Ny;
	hz = 2 * IntLimitZ / Nz;

	PartDimHor = 0; PartDimVert = 0;
	if (Ny > 0) PartDimHor =   hy;// * 0.5; 
	if (Nz > 0) PartDimVert =  hz; // * 0.5;

	if (Ny == 1) { 
		SumCoreY.Add(1); SumHaloY.Add(1); AlfaY.Add(0); 
		SumCoreY.Add(0); SumHaloY.Add(0); AlfaY.Add(2*hy);
	} // i = 0
	if (Nz == 1) {
		SumCoreZ.Add(1); SumHaloZ.Add(1); AlfaZ.Add(0); 
		SumCoreZ.Add(0); SumHaloZ.Add(0); AlfaZ.Add(2*hz); 
	} // j = 0

	if (Ny > 1 && Odd(Ny)) { // 3,5,7...
	
		y = 0;
		core = exp(0.0);
		halo = exp(0.0);
		SumCoreY.Add(2*core); 
		SumHaloY.Add(2*halo); // i = 0
		AlfaY.Add(0); 
		
		for (i = 1; i <= (Ny - 1)/2 +1 ; i++) {
			y = hy * i;
			core = exp(-y*y / divY / divY);
			halo = exp(-y*y / HaloDivY / HaloDivY);
			SumCoreY.Add(core); 
			SumHaloY.Add(halo);
			AlfaY.Add(y); 
		//	core0 = core; halo0 = halo;
		} // i <= (Ny - 1)/2
	}
	if (!Odd(Ny)) { // 2,4,6...
	
		for (i = 0; i < Ny/2 + 1; i++) {
			y = hy * (i+0.5);
			core = exp(-y*y / divY / divY);
			halo = exp(-y*y / HaloDivY / HaloDivY);
			SumCoreY.Add(core); 
			SumHaloY.Add(halo);
			AlfaY.Add(y); 
		} // i < Ny/2
	}

	if (Nz > 1 && Odd(Nz)) { // 3,5,7...
		z = 0;
		core = exp(0.0);
		halo = exp(0.0);
		SumCoreZ.Add(2*core); 
		SumHaloZ.Add(2*halo); // i = 0
		AlfaZ.Add(0); 

		for (i = 1; i <= (Nz - 1)/2 + 1; i++) {
			z = hz * i;
			core = exp(-z*z / divZ / divZ);
			halo = exp(-z*z / HaloDivZ / HaloDivZ);
			SumCoreZ.Add(core); 
			SumHaloZ.Add(halo);
			AlfaZ.Add(z); 
		} // i <= (Nz - 1)/2
	}
	if (!Odd(Nz)) { // 2,4,6...

		for (i = 0; i < Nz/2 + 1; i++) {
			z = hz * (i+0.5);
			core = exp(-z*z / divZ / divZ);
			halo = exp(-z*z / HaloDivZ / HaloDivZ);
			SumCoreZ.Add(core); 
			SumHaloZ.Add(halo);
			AlfaZ.Add(z); 
		} // i < Nz/2
	}
	
	double SumCurrent = 0;
	double core1, halo1, core2, halo2;
	double curr0, curr1, curr2;

	for (i = 0; i < AlfaY.GetUpperBound(); i++) 
		for (j = 0; j < AlfaZ.GetUpperBound(); j++) {
			alfaY = AlfaY[i];// * divY;//
			alfaZ = AlfaZ[j];// * divZ;
			alfaEff = sqrt(alfaZ*alfaZ + alfaY*alfaY + 1.0);
			Attr.Vx = 1.0 / alfaEff;
			Attr.Vy = alfaY / alfaEff;
			Attr.Vz =  alfaZ / alfaEff;
			// V = 1; //automatically

			core0 = SumCoreY[i] * SumCoreZ[j] / TotalCore;
			halo0 = SumHaloY[i] * SumHaloZ[j] / TotalHalo;
			curr0 = core0 *(1 - BeamHaloPart) + halo0 * (BeamHaloPart); 
		
//			if (curr0 <= CutOffCurrent) continue;		
			
			Attr.Current = curr0;
			Attr.dCurrY = 0;
			Attr.dCurrZ = 0;

				core2 = SumCoreY[i+1] * SumCoreZ[j] / TotalCore;
				halo2 = SumHaloY[i+1] * SumHaloZ[j] / TotalHalo;
				curr2 = core2 *(1 - BeamHaloPart) + halo2 * (BeamHaloPart);
			
				if (i < 1) {// && Odd(Ny)) {	
					Attr.dCurrY = (curr2 - curr0) / curr0;
					//Attr.Current += 1 * (curr2 - curr0);
				}
				else {
						core1 = SumCoreY[i-1] * SumCoreZ[j] / TotalCore;
						halo1 = SumHaloY[i-1] * SumHaloZ[j] / TotalHalo;
						curr1 = core1 *(1 - BeamHaloPart) + halo1 * (BeamHaloPart); 
						Attr.dCurrY =  (curr2 - curr1) / curr0;
						if (fabs(Attr.dCurrY) > 2)  
							Attr.dCurrY = 2 * (curr2 - curr1)/fabs(curr2 - curr1);
				}
				
						
				core2 = SumCoreY[i] * SumCoreZ[j+1] / TotalCore;
				halo2 = SumHaloY[i] * SumHaloZ[j+1] / TotalHalo;
				curr2 = core2 *(1 - BeamHaloPart) + halo2 * (BeamHaloPart); 
				if (j < 1) { // && Odd(Nz)) { 
					Attr.dCurrZ = (curr2 - curr0) / curr0;
					//Attr.Current += 1 * (curr2 - curr0);
				}
				else  {
						core1 = SumCoreY[i] * SumCoreZ[j-1] / TotalCore;
						halo1 = SumHaloY[i] * SumHaloZ[j-1] / TotalHalo;
						curr1 = core1 *(1 - BeamHaloPart) + halo1 * (BeamHaloPart); 
						Attr.dCurrZ = (curr2 - curr1) / curr0;
						if (fabs(Attr.dCurrZ) > 1)  
							Attr.dCurrZ = 2 * (curr2 - curr1)/fabs(curr2 - curr1);
				}
				
						
			Attr.StartCurrent = Attr.Current;
			Attr.State = MOVING;
			Attr.X = 0;	Attr.Y = 0;	Attr.Z = 0;	Attr.L = 0;
				
			Attr_Array.Add(Attr);
			SumCurrent += Attr.Current;
			
			if (i > 0 || !Odd(Ny)) {
				Attr.Vy = - Attr.Vy;
				Attr.dCurrY = - Attr.dCurrY;
				Attr_Array.Add(Attr);
				SumCurrent += Attr.Current;
			}
			else if (j == 0 && Odd(Nz)) continue;

			if (j > 0 || !Odd(Nz)) {
				Attr.Vz = - Attr.Vz;
				Attr.dCurrZ = - Attr.dCurrZ;  
				Attr_Array.Add(Attr);
				SumCurrent += Attr.Current;

				if (i == 0 && Odd(Ny)) continue;

				if (i > 0 || !Odd(Ny)) {
					Attr.Vy = - Attr.Vy;
					Attr.dCurrY = - Attr.dCurrY;
					Attr_Array.Add(Attr);
					SumCurrent += Attr.Current;
				}
				
			}
			else continue;
			
		} // i,j

		for (int k = 0; k <= Attr_Array.GetUpperBound(); k++) {
			Attr_Array[k].StartCurrent = Attr_Array[k].Current / SumCurrent;
			Attr_Array[k].Current = Attr_Array[k].StartCurrent;
		}

	

/*	SumCurrent = 0;
	FILE *fout = fopen("attr.dat", "w");
	fprintf(fout, "Attributes Ny = %d Nz = %d \n", (int) BeamSplitNumberY, (int)BeamSplitNumberZ);
	fprintf(fout, " i		 X			Y		  Z		 Vx		Vy		Vz	Current  \n");
	for (k=0; k<=Attr_Array.GetUpperBound(); k++) {
		fprintf(fout, "%d  |  %12le   %12le   %12le  |  %12le   %12le   %12le | %12le  \n",
			k,  Attr_Array[k].X, Attr_Array[k].Y, Attr_Array[k].Z,
			Attr_Array[k].Vx, Attr_Array[k].Vy, Attr_Array[k].Vz,  Attr_Array[k].Current ); 
		SumCurrent += Attr_Array[k].Current;
	}
	fprintf(fout, "SumCurrent =  %g\n", SumCurrent);
	fclose(fout);
*/
	SumCoreY.RemoveAll();
	SumCoreZ.RemoveAll();
	SumHaloY.RemoveAll();
	SumHaloZ.RemoveAll();
	AlfaY.RemoveAll();
	AlfaZ.RemoveAll();

}


void CBTRDoc::SetPolarArrayBase(double DivY, double DivZ) // (Based AvCoreDiv = 1; Called for changed: Npolar, Nazim, CoreDiv/HaloDiv, HaloPart
/// Equal Angle Division: dAlfa = Const; Current = Var
{
	PolarAngle.RemoveAll();
	PolarCurrent.RemoveAll();

	double StepAngle;
	double SumCurrent;
	double SumAngle;
	double Curr;
	int i;
	
	if ((int)AzimNumber < 4) PolarNumber = 0;

	double AvCoreDiv = sqrt(DivY * DivZ);
	if (AvCoreDiv < 1.e-16) AvCoreDiv = 0.000001;
	double HaloDivRel = BeamHaloDiverg / AvCoreDiv;
//	double AlfaMax = 3 * Max(1.0, HaloDivRel); // 
	double AlfaMax;
	BOOL parbeam =  FALSE;

	if (BeamRadius < 1.e-4 || fabs(BeamFocusX) < 1.e-4) {
		// zero beamlet size at GG -> max angle limited by CutOff
		if (BeamHaloPart < 1.e-3) AlfaMax = SumGauss(1 - CutOffCurrent, 1);
		else AlfaMax = SumGauss(1 - CutOffCurrent, 1, HaloDivRel, BeamHaloPart); // reduce
	}
	else { // finite beamlet size GG -> max angle limited by apperture
		double minDiv = Min(BeamCoreDivY, BeamCoreDivZ);
		AlfaMax = atan(BeamRadius / fabs(BeamFocusX)) / minDiv;
		if (fabs(BeamFocusX) > 100) { 
			AlfaMax = SumGauss(1 - CutOffCurrent, 1);
			parbeam = TRUE;
		}
	}
	
	if  ((int)PolarNumber >= 1) StepAngle = AlfaMax /(int) PolarNumber;
	else StepAngle = 0.000001;

	PartDimHor = StepAngle * AvCoreDiv; // rectangular model
	PartDimVert = 2*PI*AvCoreDiv / (int)AzimNumber;// rectangular model
	
	SumCurrent = 0;
	if ((int)PolarNumber <1) {
		PolarAngle.Add(0); 
		PolarCurrent.Add(1);
		return;
	}
	else { // NPolar >= 1
		PolarAngle.Add(0); PolarCurrent.Add(0);
		SumCurrent = 0;

		for (int i=1; i<=(int)PolarNumber; i++) {
			SumAngle = i * StepAngle;//
			Curr = Gauss(SumAngle, 1, HaloDivRel, BeamHaloPart) - SumCurrent;
		//	if (Curr < CutOffCurrent) continue;
			PolarCurrent.Add(Curr);
			//if (parbeam) PolarAngle.Add(0);
			//else 
				PolarAngle.Add((i-0.5) * StepAngle);//
			SumCurrent += Curr;
		} // i = PolarNumber
	} //  NPolar >= 1
		
	for (i=0; i <= PolarCurrent.GetUpperBound(); i++)  {
		PolarCurrent[i] /= SumCurrent;
	}

//}

}

void CBTRDoc::	SetPolarBeamletIndividual(double DivY, double DivZ)	
											// set attributes for (Npolar*Nazim)BP in Beamlet CS 
											// MAMuG; SINGAP with DivX, DivY != const for beamlets
											// Beam Misalignment = 0!
{
	ATTRIBUTES Attr;
	double AzimAngle, alfaY, alfaZ, alfaEff;
	Attr_Array.RemoveAll();

	SetPolarArrayBase(DivY, DivZ);

	if ((int)AzimNumber * (int)(PolarNumber) < 1) {// Axis Particle ONLY
			Attr.Current = PolarCurrent[0];
			Attr.StartCurrent = Attr.Current;
			Attr.Vx = 1.0;	Attr.Vy = 0; Attr.Vz = 0;
			Attr.X = 0;	Attr.Y = 0;	Attr.Z = 0;	Attr.L = 0;
			Attr_Array.Add(Attr);	
			return;
	}

	// ----- AzimNumber > 0, PolarNumber > 0 -------------------------

	for (int k = 0; k <= (int)PolarNumber; k++) {

//		if (k > 0 && PolarCurrent[k] < CutOffCurrent *(AzimNumber)) continue; // AzimNumber != 0!

		if  (k == 0) {// Axis particle
			Attr.Current = PolarCurrent[0]; //Polar group =0
			Attr.StartCurrent = Attr.Current;
			Attr.Vx = 1.0;	Attr.Vy = 0; Attr.Vz = 0;
			Attr.X = 0;	Attr.Y = 0;	Attr.Z = 0;	Attr.L = 0;
			Attr_Array.Add(Attr);
		}
		else //  Polar group !=0
		for (int n = 0; n < AzimNumber; n++)
		{
			AzimAngle = n* 2*PI /(int) AzimNumber;
			Attr.Current = PolarCurrent[k] / AzimNumber; //Polar group !=0
			Attr.StartCurrent = Attr.Current;
			// alfaX = Vx/Vx; alfaY = Vy/Vx; alfaZ = Vz/Vx
			alfaZ = DivZ * PolarAngle[k] * sin(AzimAngle);//
			alfaY = DivY * PolarAngle[k] * cos(AzimAngle);//
			alfaEff = sqrt(alfaZ*alfaZ + alfaY*alfaY + 1.0);
			Attr.Vx = 1.0 / alfaEff;
			Attr.Vy = alfaY / alfaEff;
			Attr.Vz = alfaZ / alfaEff;
			// V = 1; //automatically
			Attr.X = 0;	Attr.Y = 0;	Attr.Z = 0;	Attr.L = 0;
			Attr_Array.Add(Attr);			
		} // n = AzimNumber - 1
	} // k = PolarNumber

}

void CBTRDoc::	SetPolarBeamletCommon()		// set attributes for (Npolar*Nazim)BP in Beamlet CS 
											// write "attr.dat" X Y Z Vx Vy Vz
											// MAMuG; SINGAP with DivX = DivY = const along all beamlets
											// Beam Misalignment = 0!
{
//	::SetCurrentDirectory(CurrentDirName);
//	CWaitCursor wait;
//	double AvCoreDiv = sqrt(BeamCoreDivY * (BeamCoreDivZ));
//	double HaloDivRel = BeamHaloDiverg / AvCoreDiv;

	ATTRIBUTES Attr;
	double AzimAngle, alfaY, alfaZ, alfaEff;
	Attr_Array.RemoveAll();

	if (BeamHaloDiverg < 1.e-16) BeamHaloPart = 0;
	if ((BeamCoreDivY) * (BeamCoreDivZ) < 1.e-16) BeamHaloPart = 1;

	SetPolarArrayBase(BeamCoreDivY, BeamCoreDivZ);

	if ((int)AzimNumber * (int)PolarNumber < 1) {// Axis Particle ONLY
			Attr.Current = PolarCurrent[0];
			Attr.StartCurrent = Attr.Current;
			Attr.Vx = 1.0;	Attr.Vy = 0; Attr.Vz = 0;
			Attr.X = 0;	Attr.Y = 0;	Attr.Z = 0;	Attr.L = 0;
			Attr_Array.Add(Attr);	
			return;
	}

// ----- AzimNumber > 0, PolarNumber > 0 -------------------------

	double SumCurrent = 0;
	for (int k = 0; k <= (int)PolarNumber; k++) {
		
//		if (k > 0 && PolarCurrent[k] < CutOffCurrent *(AzimNumber)) 	continue; // AzimNumber != 0!
	
		if  (k == 0) {// Axis particle
			Attr.Current = PolarCurrent[0]; // Axis particle for Plot Beamlet Foot 
			Attr.StartCurrent = Attr.Current;
			SumCurrent += Attr.Current;
			Attr.Vx = 1.0;	Attr.Vy = 0; Attr.Vz = 0;
			Attr.X = 0;	Attr.Y = 0;	Attr.Z = 0;	Attr.L = 0;
			Attr_Array.Add(Attr);
		}
		else //  Polar group !=0 
		for (int n = 0; n < (int)AzimNumber; n++)
		{
			double val = 0; //(double)rand() / (double) RAND_MAX;
			AzimAngle = (n+val)* 2*PI /(int) AzimNumber;
			
			// alfaX = Vx/Vx; alfaY = Vy/Vx; alfaZ = Vz/Vx
			alfaZ = BeamCoreDivZ * PolarAngle[k] * sin(AzimAngle);//
			alfaY = BeamCoreDivY * PolarAngle[k] * cos(AzimAngle);//
			alfaEff = sqrt(alfaZ*alfaZ + alfaY*alfaY + 1.0);
			Attr.Vx = 1.0 / alfaEff;
			Attr.Vy = alfaY / alfaEff;
			Attr.Vz = alfaZ / alfaEff;
			// V = 1; //automatically
			Attr.X = 0;	Attr.Y = 0;	Attr.Z = 0;	Attr.L = 0;
			Attr.Current = PolarCurrent[k] /(int) AzimNumber; //Polar group !=0
			if (BeamRadius > 1.e-4) {
				if (fabs(BeamFocusX) > 1.e-4 && fabs(BeamFocusX) < 100) {
					if (sqrt(alfaY*alfaY + alfaZ*alfaZ) > BeamRadius/fabs(BeamFocusX))
						Attr.Current = 0;
				}
				else if (fabs(BeamFocusX) >= 100) { //parallel rays
					Attr.X = 0; 
					Attr.Y = BeamRadius * (k/(PolarNumber)) * cos(AzimAngle);
					Attr.Z = BeamRadius * (k/(PolarNumber)) * sin(AzimAngle);
					Attr.Vx = 1; Attr.Vy = 0; Attr.Vz = 0;
				}
			}
			Attr.StartCurrent = Attr.Current;
			SumCurrent += Attr.Current;
			Attr_Array.Add(Attr);			
		} // n = AzimNumber - 1
	} // k = PolarNumber

		for (int l = 0; l <= Attr_Array.GetUpperBound(); l++) {
			Attr_Array[l].StartCurrent = Attr_Array[l].Current / SumCurrent;
			Attr_Array[l].Current = Attr_Array[l].StartCurrent;
		}
//	::SetCurrentDirectory(CurrentDirName);
}

void CBTRDoc:: SetBeam()// Beam Power; 
						// beamlets hor/vert positions/aimings for MAMuG 
						// tot number of beamlets 
{
	IonBeamPower = IonBeamCurrent * (IonBeamEnergy); 
	NeutrPower = IonBeamPower*(NeutrPart);

//	if (OptSINGAP) return;

	int i, j;//, NBhor, NBvert;
	int imax = (int)NofChannelsHor; 
	int jmax = (int)NofChannelsVert; 
	int iimax = (int)NofBeamletsHor;
	int jjmax =  (int)NofBeamletsVert;	

/*	SegmCentreHor.RemoveAll();	SegmCentreVert.RemoveAll();
	ActiveCh.RemoveAll();	ActiveRow.RemoveAll();
	RectIS.RemoveAll();	RectISrow.RemoveAll();
	BeamletAngleHor.RemoveAll();	BeamletAngleVert.RemoveAll();
	BeamletPosHor.RemoveAll();	BeamletPosVert.RemoveAll();*/

	SegmCentreHor.SetSize(100);//imax);
	SegmCentreVert.SetSize(100);//jmax);
	ActiveCh.SetSize(100);//imax);
	ActiveRow.SetSize(100);//jmax);
	RectIS.SetSize(100);//imax);
	RectISrow.SetSize(100);//jmax);
	BeamletAngleHor.SetSize(10000);//imax * iimax);
	BeamletAngleVert.SetSize(10000);//jmax * jjmax);
	BeamletPosHor.SetSize(10000);//imax * iimax);
	BeamletPosVert.SetSize(10000);//jmax * jjmax);


	for (i = 0; i < imax; i++)
		SegmCentreHor[i] =  SegmStepHor * ( -(imax -1) * 0.5 + i);
	for (j = 0; j < jmax; j++)
		SegmCentreVert[j] =  SegmStepVert * ( -(jmax -1) * 0.5 + j);

	//NBhor = (int)NofBeamletsHor;
	if (iimax > 1) SegmSizeHor = AppertStepHor * (iimax-1);
	else SegmSizeHor = 0.01;
	//NBvert = (int)NofBeamletsVert;
	if (jjmax > 1) SegmSizeVert = AppertStepVert * (jjmax-1);
	else SegmSizeVert = 0.01;
	

	double SegmAimHor, SegmAimVert;
	double dY, dZ;
	
	for (i = 0; i < imax; i++) {
		if (fabs(BeamAimHor) < 1.e-6) SegmAimHor = 0;
		else SegmAimHor = - atan(SegmCentreHor[i] / BeamAimHor);
		for (int ii = 0; ii < iimax; ii++) {
			 dY =  AppertStepHor * (-(iimax-1) * 0.5 + ii);
			 if (fabs(AppertAimHor) < 1.e-6) BeamletAngleHor[i * iimax + ii] = 0;
			 else BeamletAngleHor[i * iimax + ii] = 
			//	 atan((AppertAimHor * sin(SegmAimHor) - dY) / AppertAimHor * cos(SegmAimHor)) 
				 atan((-dY + AppertAimHor * tan(SegmAimHor)) / AppertAimHor) 
				 + BeamMisHor;
			 BeamletPosHor[i * iimax + ii] = SegmCentreHor[i] + dY;
		}
	}

	double VInclin = 0; // Free option -> no NBL inclination
	if (!OptFree) VInclin = VertInclin; // standard NBI
	/*else if (fabs(VertInclin) > 1.e-6) { // OptFree
		if (AfxMessageBox("Config: Beamline is inclined. Apply the inclination to the Beam Axis?", MB_YESNO) == IDYES)
		{
			BeamMisVert += BeamVertTilt;
			//BeamVertTilt += VertInclin;
			BeamVertTilt = VertInclin;
			VertInclin = 0;
		} // Yes
	}*/
	
	for (j = 0; j < jmax; j++){
		if (fabs(BeamAimVert) < 1.e-6) SegmAimVert = 0;
		else  SegmAimVert = - atan(SegmCentreVert[j] / BeamAimVert);
		 for (int jj = 0; jj < jjmax; jj++) {
			 dZ =  AppertStepVert * (-(jjmax-1) * 0.5 + jj);
			 if (fabs(AppertAimVert) < 1.e-6) BeamletAngleVert[j * jjmax + jj] = 0;
			 else BeamletAngleVert[j * jjmax + jj] = 
				 //atan((AppertAimVert * sin(SegmAimVert) - dZ) / AppertAimVert * cos(SegmAimVert)) 
				   atan((-dZ + AppertAimVert * tan(SegmAimVert)) / AppertAimVert) 
				 //-atan(SegmCentreVert[j] / BeamAimVert) 
				 + BeamMisVert + VInclin + BeamVertTilt;
			 BeamletPosVert[j * jjmax + jj] = SegmCentreVert[j] + dZ;
		 }
	}

	NofBeamletsTotal =  (int)NofBeamletsHor * (int)NofBeamletsVert * (int)NofChannelsHor * (int)NofChannelsVert;

}

int CBTRDoc:: EmitBeam() // account of beamlet hor/vert aimings - Rotate procedures
						// TOBEDONE: Misalignments not included! 
{
	DINSELECT = FALSE;
	NeedSave = FALSE;
	Progress = 0;
	NofCalculated = 0;
	Exit_Array.RemoveAll();
//	ShowStatus();
	int res;

	if (NofBeamlets <1) { 
		AfxMessageBox("At least one Channel/Row should be Switched-ON.", 
			MB_ICONSTOP | MB_OK);
		return (0);
	}

	if (LoadSelected < 1) {
		DINSELECT = TRUE;
		res = AfxMessageBox("No Active Surfaces. \n Create Automatically?",
			MB_ICONQUESTION | MB_YESNOCANCEL);
		if (res == IDNO) DINSELECT = FALSE;
		if (res == IDCANCEL)  return(0);
	}

/*	if (LoadSelected > 0 || DINSELECT) {
		 res =  AfxMessageBox("Save all Loads after calculation?",3);   
		if (res == IDYES) NeedSave = TRUE;
		if (res == IDCANCEL) return(0);
	}
*/
	StartTime = CTime::GetCurrentTime();
	
	pSetView->InvalidateRect(NULL, TRUE);

	ShowStatus();
	

	if (OptSINGAP) 
		res = EmitSINGAP(); // 0 - if stopped; 1 - if finished
	else 
		res = EmitMAMuG(); // 0 - if stopped; 1 - if finished

	//	ShowStatus();
	StopTime = CTime::GetCurrentTime();
	pSetView->InvalidateRect(NULL, TRUE);
	
	//Beep(500, 300); 
	if (LoadSelected > 0 && res == 1) {
		 if  (AfxMessageBox("Save results to disk?", MB_ICONQUESTION | MB_YESNO) == IDYES) NeedSave = TRUE;
	}

	if (NeedSave) SaveLoads(FALSE); //if calculation finished
	else DetachLoadFiles();
	
	//Beep(250, 200); Beep(125, 500);
	return(res);

}

int CBTRDoc::EmitElectrons(bool optSINGAP) // same as EmitSINGAP() - with very few changes!!! 
{
	double EMeV = IonBeamEnergy; //MeV - diff from EmitSingap
	// double BeamCurr = IonBeamCurrent; //A
	double BeamPower = IonBeamPower; // MW
	// double Xstart = 0;//EmitterCentre[0].X;
	double TStep = TraceTimeStep;
	double power; // BeamletPower * Attr.Current;
	ATTRIBUTES Attr;
	BEAMLET_ENTRY be;
	CParticle * Particle = new CParticle();
	Particle->SetPartSort(Electron);
	Particle->Mass = Me * RelMass(EMeV); /// ELECTRONS (diff from EmitSingap)
	C3Point Start; //in local channel (IS) coord 
	C3Point Local; // IS centre in Local CS
	C3Point Global; // IS centre in Global CS
	C3Point P;
	double DivY, DivZ;
	double fraction;

	Start = 0;  //pDoc->EmitterCentre[0]; 
	STOP = FALSE;

	double V = RelV(EMeV); //Particle->GetV(EkeV); //sqrt(2.* EkeV*1000 * Qe/mass); // {m/c}
	//	diff from EmitSingap
	
	int	Ntotal = NofBeamletsTotal; //BeamEntry_Array.GetSize();
	
	double  BeamletPower = BeamPower *1000000. / Ntotal ; //W per beamlet 

/////////////////////////////////////////////////////////////////////////////
if (optSINGAP) {

	for (int i = 0; i< Ntotal;  i++) { //
		if (STOP) return(0);
		// int result = 0;
		be = BeamEntry_Array[i];
		if (be.Active == FALSE) continue;
		Start.X = 0; 
		Start.Y = be.PosY; 
		Start.Z = be.PosZ; 
		DivY = be.DivY;
		DivZ = be.DivZ;
		fraction = be.Fraction;
		if (OptIndBeamlets) {// individual Div for each beamlet (core); average Halo diverg/part = const for all
			if ((int) BeamSplitType ==0)	SetPolarBeamletIndividual(DivY, DivZ); // polar splitting
			else SetGaussBeamlet(DivY, DivZ); // cartesian splitting
		}

	int Nmax = Attr_Array.GetUpperBound(); // BP per beamlet

	for (int n = 0; n <= Nmax; n++ ) { // Attr_Array UpperBound
		if (STOP) return(0);
		Attr = Attr_Array[n];
		Attr.Current *= fraction; Attr.StartCurrent = Attr.Current; 
		power = BeamletPower * Attr.Current; // W
		RotateVert(be.AlfZ, Attr.Vx, Attr.Vy, Attr.Vz); // SINGAP
		Attr.X = Start.X; Attr.Y = Start.Y; Attr.Z = Start.Z; Attr.L = 0;
		Attr.Vx *= V;  Attr.Vy *= V; Attr.Vz *= V;
		RotateHor(be.AlfY, Attr.Vx, Attr.Vy, Attr.Vz); // SINGAP
		Attr.Model = SLOW;	Attr.State = MOVING;
		Attr.Power = power; Attr.StartPower = power;
		Particle->SetPartAttr(Attr, TStep);
		if (n==0) Particle->Central = TRUE;
		else Particle->Central = FALSE;
		
		Particle->TraceElectron(); // 
	
	} // n  = Attr_Arr.Nmax
	NofCalculated++;
	Progress = (int) (NofCalculated*10000/NofBeamletsTotal);
	ShowStatus();

	} // Ntotal (beamlets)

}// SINGAP

///////////////////////////////////////////////////////////////////////
else { ///MAMuG

	int i, j, ii, jj;
	int Ny = (int)NofBeamletsHor, Nz = (int)NofBeamletsVert; // MAMuG
	int NSy = (int)NofChannelsHor, NSz = (int)NofChannelsVert; // MAMuG
	//int	Ntotal = Ny*Nz*NSy*NSz;

//	int N = 0; // number of beamlet == NofCalculated

for (i = 0; i<NSy;  i++) { ///NofChannelsHor;
		if (!ActiveCh[i]) continue;
			
for (j = 0; j<NSz; j++) {  ///NofChannelsVert;
	if (!ActiveRow[j]) continue;	
	
	for (ii = 0; ii<Ny; ii++)  // NofBeamletsHor
	for (jj = 0; jj<Nz; jj++) // NofBeamletsVert
	{
/// Upper Segments -----------------------------------------------
		if (STOP) return(0);
		// int result = 0;
		Start.X = 0; 
		Start.Y = BeamletPosHor[i*Ny + ii]; // MAMuG
		Start.Z = BeamletPosVert[j*Nz + jj]; // MAMuG

//		N++;
//		fprintf(fout, "%d    %d   %d   %g    %g    %g    %g\n", N, i*Ny + ii, j*Nz + jj, 
//			Start.Y, Start.Z, BeamletAngleHor[i*Ny + ii], BeamletAngleVert[j*Nz + jj]);
		
		int Nmax = Attr_Array.GetUpperBound();

	for (int n = 0; n <= Nmax; n++ ) { // Attr_Array UpperBound
		if (STOP) return(0);
		Attr = Attr_Array[n];
		//if (Attr.Current < 1.e-16) continue;
		power = BeamletPower * Attr.Current; // W
		RotateVert(BeamletAngleVert[j*Nz + jj], Attr.Vx, Attr.Vy, Attr.Vz); // MAMuG
		Attr.X = Start.X; Attr.Y = Start.Y; Attr.Z = Start.Z; Attr.L = 0;
		Attr.Vx *= V;  Attr.Vy *= V; Attr.Vz *= V;
		RotateHor(BeamletAngleHor[i*Ny + ii], Attr.Vx, Attr.Vy, Attr.Vz); // MAMuG
		Attr.Model = SLOW;	Attr.State = MOVING;
		Attr.Power = power; Attr.StartPower = power;
		Particle->SetPartAttr(Attr, TStep);
			
		if (n==0) Particle->Central = TRUE;
		else Particle->Central = FALSE;

		Particle->TraceElectron(); // 
	
	} // n  = Attr_Arr.Nmax
	NofCalculated++;
	Progress = (int) (NofCalculated *10000/NofBeamlets);
	ShowStatus();

	} // ii, ij 
	} // j
	} // i

}////MAMuG
	delete Particle;
	return (1);
}

int CBTRDoc:: EmitSINGAP()
{
	if (TracePartType == 0) return (EmitElectrons(TRUE));

	BEAMLET_ENTRY be;
	STOP = FALSE;
	int	Ntotal = BeamEntry_Array.GetSize();//NofBeamletsTotal;
	for (int i = 0; i< Ntotal;  i++) { //
		if (STOP) return(0);
		// int result = 0;
		be = BeamEntry_Array[i];
		EmitBeamlet(be);
		if (STOP) return(0);
		
		NofCalculated++;
		Progress = (int) (NofCalculated*10000/NofBeamlets);
		ShowStatus();
	} // Ntotal (beamlets)

	return (1);
}


int CBTRDoc:: EmitMAMuG() // account of beamlet hor/vert aimings - Rotate procedures
						// Misalignments are included in SetBeam() 
{
	SetSINGAPfromMAMUG();
	return (EmitSINGAP());

/*	if (TracePartType == 0) return(EmitElectrons(FALSE));
	BEAMLET_ENTRY be;
	STOP = FALSE;

	int i, j, ii, jj;
	int Ny = (int)NofBeamletsHor, Nz = (int)NofBeamletsVert; // MAMuG
	int NSy = (int)NofChannelsHor, NSz = (int)NofChannelsVert; // MAMuG
	int	Ntotal = Ny*Nz*NSy*NSz;
	
	double BeamPower = IonBeamPower; // MW
	double BeamletPower = BeamPower *1000000. / Ntotal ; //W per beamlet 

	int N = 0; // number of beamlet == NofCalculated

for (i = 0; i<NSy;  i++) { ///NofChannelsHor;
		if (!ActiveCh[i]) continue;
			
for (j = 0; j<NSz; j++) {  ///NofChannelsVert;
	if (!ActiveRow[j]) continue;	
	
	for (ii = 0; ii<Ny; ii++)  // NofBeamletsHor
	for (jj = 0; jj<Nz; jj++) // NofBeamletsVert
	{
		if (STOP) return(0);
		int result = 0;
		
		be.Active = TRUE;
		be.PosY = BeamletPosHor[i*Ny + ii]; // MAMuG
		be.PosZ = BeamletPosVert[j*Nz + jj]; // MAMuG
		be.AlfY = BeamletAngleHor[i*Ny + ii];
		be.AlfZ = BeamletAngleVert[j*Nz + jj];
		be.DivY = BeamCoreDivY;
		be.DivZ = BeamCoreDivZ;
		be.Fraction = 1;
		be.i = i; be.j = j;
	
		EmitBeamlet(be);
		N++;

		if (STOP) return(0);*/

/* //----------- old	
		Start.X = 0; 
		Start.Y = BeamletPosHor[i*Ny + ii]; // MAMuG
		Start.Z = BeamletPosVert[j*Nz + jj]; // MAMuG
		
//		fprintf(fout, "%d    %d   %d   %g    %g    %g    %g\n", N, i*Ny + ii, j*Nz + jj, 
//			Start.Y, Start.Z, BeamletAngleHor[i*Ny + ii], BeamletAngleVert[j*Nz + jj]);
		
		int Nmax = Attr_Array.GetUpperBound();

	for (int n = 0; n <= Nmax; n++ ) { // Attr_Array UpperBound
		if (STOP) return(0);
		Attr = Attr_Array[n];
		Attr.Current *= fraction; Attr.StartCurrent = Attr.Current; // MAMUG: fraction=const 
		power = BeamletPower * Attr.Current; // W
		RotateVert(BeamletAngleVert[j*Nz + jj], Attr.Vx, Attr.Vy, Attr.Vz); // MAMuG
		Attr.X = Start.X; Attr.Y = Start.Y; Attr.Z = Start.Z; Attr.L = 0;
		Attr.Vx *= V;  Attr.Vy *= V; Attr.Vz *= V;
		RotateHor(BeamletAngleHor[i*Ny + ii], Attr.Vx, Attr.Vy, Attr.Vz); // MAMuG
		Attr.Model = SLOW;	Attr.State = MOVING;
		Attr.Power = power; Attr.StartPower = power;
		Particle->SetPartAttr(Attr, TStep);
		
		if (n==0) Particle->Central = TRUE;
		else Particle->Central = FALSE;
		
	//	Particle->TraceParticle(power); // (Particle, power);

		EmitSourceParticle(Particle);
/*
		if (!OptThickNeutralization) {// THIN neutralization
		
			Particle->TraceSourceIon(NeutrXmax); // trace without Neutralization (until NeutrXmax)
			
			if (Particle->Attr.State != STOPPED) 
			{
				if (!OptNeutrStop)	Particle->EmitPosIon(-1);
				if (OptTraceAtoms) Particle->EmitAtom(-1);

				Particle->Attr.Current *= 1 - PosIonPart - NeutrPart;
				Particle->Attr.Power *= 1 - PosIonPart - NeutrPart;
				if (Particle->Attr.Current < 1.e-10) continue;

				if (!OptNeutrStop) { 
					Particle->TimeStep = IonStepL / V;
					Particle->TraceIon(); // source negative after Neutralizer
				} // trace primary ion 
			} // not stopped by solid surface
		} // THIN neutralization

		else  Particle->TraceSourceIonWithNeutralization();
	
	} // n  = Attr_Arr.Nmax
*/

/*	NofCalculated++;
	Progress = (int) (NofCalculated *10000/NofBeamlets);
	ShowStatus();

	} // ii, ij 
	} // j
	} // i
*/
//	delete Particle;
//	return (1); 
}


void CBTRDoc:: EmitSourceParticle(CParticle * Particle)
{
if (!OptThickNeutralization) {// THIN neutralization
		
			Particle->TraceSourceIon(NeutrXmax); // trace without Neutralization (until NeutrXmax)
			
			if (Particle->Attr.State != STOPPED) 
			{
				if (!OptNeutrStop) Particle->EmitPosIon(-1);
				if (OptTraceAtoms) Particle->EmitAtom(-1);

				Particle->Attr.Current *= 1 - PosIonPart - NeutrPart;
				Particle->Attr.Power *= 1 - PosIonPart - NeutrPart;
				if (Particle->Attr.Current < 1.e-10) return;//continue;

				if (!OptNeutrStop) { 
					Particle->TimeStep = IonStepL / Particle->Vstart;
					Particle->TraceIon(); // source negative after Neutralizer
				} // trace primary ion 
			} // not stopped by solid surface*/
		} // THIN neutralization

		else  Particle->TraceSourceIonWithNeutralization();

		return;
}

void CBTRDoc:: EmitBeamlet(BEAMLET_ENTRY be)
{
	if (be.Active == FALSE) return; //continue;

	ATTRIBUTES Attr;
	CParticle * Particle = new CParticle();
	Particle->SetPartType(TracePartType);
	double EkeV = IonBeamEnergy * 1000; //keV
	double V = Particle->SetV(EkeV); //sqrt(2.* EkeV*1000 * Qe/mass); // {m/c}
	double power;
	double BeamPower = IonBeamPower; // MW
	int	Ntotal = NofBeamletsTotal; //BeamEntry_Array.GetSize();
	double BeamletPower = BeamPower *1000000. / Ntotal ; //W per beamlet 
				
	if (OptSINGAP && OptIndBeamlets) {// individual Div for each beamlet (core); average Halo diverg/part = const for all
		if ((int)BeamSplitType == 0)	
			SetPolarBeamletIndividual(be.DivY, be.DivZ); // polar splitting
		else SetGaussBeamlet(be.DivY, be.DivZ); // cartesian splitting
	}
	// for MAMuG - SetPolarBeamletCommon() or SetGaussBeamlet(BeamCoreDivY,BeamCoreDivZ)
		
	int Nmax = Attr_Array.GetUpperBound(); // BP per beamlet
	
	for (int n = 0; n <= Nmax; n++ ) { // Attr_Array UpperBound
		if (STOP) return;
		Attr = Attr_Array[n];
		Attr.Current *= be.Fraction; Attr.StartCurrent = Attr.Current;//SINGAP fraction!=const 
		power = BeamletPower * Attr.Current; // W
		RotateVert(be.AlfZ, Attr.Vx, Attr.Vy, Attr.Vz); 
		RotateHor(be.AlfY, Attr.Vx, Attr.Vy, Attr.Vz); 
		Attr.Vx *= V;  Attr.Vy *= V; Attr.Vz *= V;

		//if (IonBeamStartX >= 0) {	Attr.X = IonBeamStartX; Attr.Y = be.PosY; Attr.Z = be.PosZ;}
		Attr.X = 0; Attr.Y = be.PosY; Attr.Z = be.PosZ;
		//Attr.Y = be.PosY - (IonBeamStartX) * Attr.Vy / Attr.Vx;
		//Attr.Z = be.PosZ - (IonBeamStartX) * Attr.Vz / Attr.Vx;
		
		Attr.L = 0;
		Attr.Model = SLOW;	Attr.State = MOVING;
		Attr.Power = power; Attr.StartPower = power;
		Particle->SetPartAttr(Attr, TraceTimeStep);
		
		if (n==0) Particle->Central = TRUE;
		else Particle->Central = FALSE;
		
		EmitSourceParticle(Particle);

	} // n  = Attr_Arr.Nmax
	if (!OptDrawPart) ShowBeamlet(be);

	delete Particle;
}

void CBTRDoc:: ShowBeamlet(BEAMLET_ENTRY be)
{
	//CMainView* pMainView = (CMainView*)m_pViewWnd; 
	CDC* pDC = pMainView->GetDC();
	int x1, y1, z1, x2, y2, z2;
	double y0 = be.PosY;
	double z0 = be.PosZ;
	double	x = AreaLong;
	double	y = y0 + x * tan(be.AlfY); 
	double	z = z0 + x * tan(be.AlfZ); 
	
	x1 = pMainView->OrigX;
	y1 = pMainView->OrigY - (int)(y0 * pMainView->ScaleY);
	z1 = pMainView->OrigZ - (int)(z0 * pMainView->ScaleZ);
	x2 = pMainView->OrigX + (int)(x * pMainView->ScaleX);
	y2 = pMainView->OrigY - (int)(y * pMainView->ScaleY);
	z2 = pMainView->OrigZ - (int)(z * pMainView->ScaleZ);
	pMainView->ReleaseDC(pDC);
	
	//HDC DC = pMainView->GetDC()->GetSafeHdc();
	//cs.Lock();
	CPen * pOldPen = pDC->SelectObject(&pMainView->AtomPen);//DotPen);
	pDC->MoveTo(x1, y1); pDC->LineTo(x2, y2);
	pDC->MoveTo(x1, z1); pDC->LineTo(x2, z2);
	pDC->SelectObject(pOldPen);
	GdiFlush();
	pMainView->ReleaseDC(pDC);
	//cs.Unlock();
}

void CBTRDoc:: RandAttr(ATTRIBUTES & Attr, double step)
{
//	srand( (unsigned)time( NULL ) );   /* Display 10 numbers. */
//  for( i = 0;   i < 10;i++ )      printf( "  %6d\n", rand() );
//	srand(1);
	double val = (double)rand() / (double) RAND_MAX;
	double V = sqrt(Attr.Vx*Attr.Vx + Attr.Vy*Attr.Vy + Attr.Vz*Attr.Vz);
	double dx = step*val*Attr.Vx / V; 
	double dy = step*val*Attr.Vy / V; 
	double dz = step*val*Attr.Vz / V; 
	Attr.X += dx; Attr.Y += dy; Attr.Z += dz;
}


void CBTRDoc::OnOptionsAccountofreionization() 
{
	//OptReionAccount = !OptReionAccount;
	
	int res;
	if (OptReionAccount && !PressureLoaded) {
		res = AfxMessageBox(" The account of re-ionization needs Gas profile to be set.\n\t  Continue?",
			MB_ICONQUESTION | MB_OKCANCEL); 
		if (res == IDOK) { 
			OnEditGas(); 
			if (!PressureLoaded) OptReionAccount = FALSE;
		}
		else OptReionAccount = FALSE;
	}

	if (OptReionAccount) { // calculate re-ionized percent
		SetReionPercent();
	}

	OnShow(); //OnDataActive();	
}

void CBTRDoc:: ClearPressure(int add)
{
	if (add != 0) { AddGField = new CGasField(); return; } // clear additional profile

	switch (PressureDim) {
		case 0: break; // const everywhere
		case 1: GField.reset(new CGasField()); break;
		case 2: GFieldXZ.reset(new CGasFieldXZ()); break;
	}
	PressureLoaded = FALSE;
	GasFileName = "";
	GasCoeff = 0;
}


double CBTRDoc:: GetPressure(C3Point P)
{
	if (!PressureLoaded || GasCoeff < 1.e-6) return 0;
	double Dens = 0;

	switch (PressureDim) {
		case 0: Dens = 0; break; // const everywhere
		case 1: Dens = GField->GetPressure(P.X); break;
		case 2: Dens = GFieldXZ->GetDensity(P.X, P.Z); break;
	}

	return Dens * GasCoeff;
}

void CBTRDoc:: ClearB()
{
	switch (MagFieldDim) {
		case 0: break; // const everywhere
		case 1: BField.reset(new CMagField()); break;
		case 2: break; // not used
		case 3: BField3D.reset(new CMagField3D()); break;
	}

	FieldLoaded = FALSE;
	MagFieldFileName = "";
	MFcoeff = 0;
}

C3Point CBTRDoc:: GetB(C3Point P)
{
	C3Point B(0,0,0);
	if (!FieldLoaded) return B;
	
	switch (MagFieldDim) {
		case 0: break; // const everywhere
		case 1: B = BField->GetB(P.X); break;
		case 2: break; // not used
		case 3: B = BField3D->GetB(P); break;
	}
	return B * MFcoeff;
}

C3Point CBTRDoc:: GetB(double x, double y, double z)
{
	return GetB(C3Point(x,y,z));
}

void CBTRDoc:: SetReionPercent()
{
	if (!PressureLoaded) return;
	//|| GasCoeff < 1.e-6) return;

	ReionArray.RemoveAll();

	double Summa = 0; // atom current drop
	double Curr = 0; //  = NeutrDrop = PosCurr
	double NeutrCurr = 1;
	double x = ReionXmin;
	double dL;// = ReionStepL; //0.01;
	C3Point P;
	double Dens;

	
	while (x < ReionXmax) {
		if (x >= RXspec0 && x <= RXspec1) dL = ReionStepLspec;//special area for AP
		else dL = ReionStepL;
		Dens = GetPressure(C3Point(x, 0, 0));
		Curr = Dens * dL * (ReionSigma);// = dj/j = NeutrDrop = PosCurr 
		if (OptAddPressure) { 
			double ADens = AddGField->GetPressure(x);
			Curr += dL * ADens * AddReionSigma;
		}

		Summa += Curr;
		NeutrCurr = NeutrCurr * (1 - Curr); 
		P.X = x; 
		P.Y = Curr * NeutrCurr; // H+ released at dL
		P.Z = exp(-Summa);// H0 total at X
		ReionArray.Add(P);
		x += dL;
	}
//	fclose(fout);

	ReionPercent = 100 * (1 - P.Z);
}

void CBTRDoc:: SetNeutrCurrents()
{
	if (!PressureLoaded || GasCoeff < 1.e-6) return;

	NeutrArray.RemoveAll();
	C3Point P;

	// double SummaNeg = 0; // source current total drop
	// double SummaPos = 0; // Total Pos current 
	double NL = 0; // Target Thickness
	double x = NeutrXmin;
	double dL = NeutrStepL; //;
	double NegDrop, PosRate; // = dj/j = NegDrop = NeutrCurr + PosCurr
	double NegCurr, PosCurr; //j-, j+
	double A, B, C, D;
	
	if (TracePartQ > 0) {// H+/D+
		A = PosExchSigma; // H+ -> H0
		B = ReionSigma; // H0 -> H+
		C = A + B;
		NegCurr = 0; PosCurr = 1;
		P.X = x; P.Y = NegCurr; P.Z = PosCurr;// 
		NeutrArray.Add(P);
		x += dL;
		while (x <= NeutrXmax) {
			NL += GetPressure(C3Point(x, 0, 0)) * dL; // dL = NeutrStepL
			if (NL < 1.e-30 || fabs(C) < 1.e-30) PosCurr = 1; 
			else  PosCurr = (1 - B/C) * exp(-C*NL) +  B / C; //
			P.X = x; P.Y = NegCurr; P.Z = PosCurr;
			NeutrArray.Add(P);
			x += dL;
		}
	} // positive source ions

	else { // H-/D-
		A = ReionSigma + PosExchSigma; // H-/D-
		B = TwoStripSigma - ReionSigma; // H-/D-
		C = ReionSigma; // H-/D-
		D = NeutrSigma + TwoStripSigma;// H-/D-
		NegCurr = 1; PosCurr = 0;
		P.X = x; P.Y = NegCurr; P.Z = PosCurr;// // H-/D-
		NeutrArray.Add(P);
		x += dL;
		while (x <= NeutrXmax) {
			NL += GetPressure(C3Point(x, 0, 0)) * dL; 
			if (NL < 1.e-30 || fabs(D) < 1.e-30) NegCurr = 1; 
			else  NegCurr = exp(-D*NL);
			if (NL < 1.e-30 || fabs(A) < 1.e-30 || fabs(D) < 1.e-30 || fabs(A-D) < 1.e-30) PosCurr = 0;
			else  PosCurr = C/A - (C/A + B/(A-D)) * exp(-A*NL) + B/(A-D) * exp(-D*NL);
			P.X = x; P.Y = NegCurr; P.Z = PosCurr;
			NeutrArray.Add(P);
			x += dL;
		}
	} // negative source ions
	
	double NegIonPart = NegCurr; //exp(-SummaNeg);
	PosIonPart = PosCurr; // (1 - ((NeutrSigma)*exp(-SummaPos) - (ReionSigma)*exp(-SummaNeg)) / (NeutrSigma - ReionSigma));
	NeutrPart = 1 - NegIonPart - PosIonPart;
	NeutrPower = IonBeamPower * (NeutrPart);
}

C3Point CBTRDoc:: GetCurrentRate(double x, double NL, bool getRate) // 0 - currents, 1 - rates
// source ions H-/D- !
{
	C3Point P(0,1,0);
	if (!PressureLoaded || GasCoeff < 1.e-6) return P;
	C3Point Pos(x,0,0);
	double Dens = GetPressure(Pos);
	double dL = NeutrStepL;
	double NegDrop, PosRate, NeutrRate; // = dj/j = NegDrop = NeutrCurr + PosCurr
	double NegCurr, PosCurr, NeutrCurr; //j-, j+, j0
	double A, B, C, D;
	double S01, S10, S_10, S_11;

	S01 = ReionSigma;
	S10 = PosExchSigma;
	S_10 = NeutrSigma;
	S_11 = TwoStripSigma;
	A = S01 + S10; // H-/D-
	B = S_11 - S01; // H-/D-
	C = S01; // H-/D-
	D = S_10 + S_11;// H-/D-
	
	if (NL < 1.e-30 || fabs(D) < 1.e-30) NegCurr = 1; 
	else  NegCurr = exp(-D*NL);
	if (NL < 1.e-30 || fabs(A) < 1.e-30 || fabs(D) < 1.e-30 || fabs(A-D) < 1.e-30) PosCurr = 0;
	else  PosCurr = C/A - (C/A + B/(A-D)) * exp(-A*NL) + B/(A-D) * exp(-D*NL);
	if (PosCurr < 0 ) PosCurr = 0;
	NeutrCurr = 1 - NegCurr - PosCurr;
	
	if (getRate == 0) {
		P.X = PosCurr;
		P.Y = NegCurr;
		P.Z = NeutrCurr;
		return P;
	}

	NegDrop = NegCurr * D * dL * Dens; // Drop >0
	PosRate = (NeutrCurr * S01 - PosCurr * S10 + NegCurr * S_11) * dL * Dens; // (dj+/dl)*dL
//	NeutrRate = (NegCurr * S_10 - NeutrCurr * S01 + PosCurr * S10) * dL * Dens;  // (djo/dl)*dL
	NeutrRate = (NegCurr * S_10 + PosCurr * S10) * dL * Dens; // without reionisation
	if (NeutrRate < 0) NeutrRate = 0;
	P.X = PosRate;
	P.Y = NegDrop;
	P.Z = NeutrRate;
	return P;
}

double CBTRDoc:: GetNL(double xmin, double xmax)
{
	double NL = 0;
	if (!PressureLoaded || GasCoeff < 1.e-6) return NL;
	double x = xmin;
	C3Point Pos(0,0,0);
	Pos.X = xmin;
	double Dens0 = GetPressure(Pos);
	double Dens1, Dens;
	double dL = NeutrStepL;
	while (x < xmax) {
		x += dL;
		Pos.X = x;
		Dens1 = GetPressure(Pos);
		Dens = (Dens0 + Dens1) * 0.5;
		NL += Dens * dL;
		Dens0 = Dens1;
	}
	return NL;
}

void CBTRDoc::OnUpdateOptionsAccountofreionization(CCmdUI* pCmdUI) 
{
	
	//pCmdUI->SetCheck(OptReionAccount);
	if (!OptReionAccount) pCmdUI->SetText("Allow for Re-ionization");
	else pCmdUI->SetText("Skip Re-ionization");
}

void CBTRDoc::OnOptionsStopionsafterneutraliser() 
{
	OptNeutrStop = !OptNeutrStop;
	
	OnShow(); //OnDataActive();
}

void CBTRDoc::OnUpdateOptionsStopionsafterneutraliser(CCmdUI* pCmdUI) 
{
	//pCmdUI->SetCheck(OptNeutrStop);
	if (!OptNeutrStop) pCmdUI->SetText("Stop Residual Ions");
	else pCmdUI->SetText("Trace Residual Ions");
}

void CBTRDoc::OnOptionsStopreionizedparticles() 
{
//	OptReionStop = !OptReionStop;
	if (!OptReionStop && !OptReionAccount) OnOptionsAccountofreionization(); 

	if (!OptReionAccount) { 
		OptReionStop = TRUE; 
		OnShow(); //OnDataActive(); 
		return; 
	}

	// !OptReionStop
	int res;
	if (!OptReionStop && !FieldLoaded) {
		res = AfxMessageBox(" Ions Tracing needs Magnetic Field to be set.\n\t  Continue?",
			MB_ICONQUESTION | MB_OKCANCEL); 
		if (res == IDOK) { 
			OnEditMagfield_4columns(); 
			if (!FieldLoaded) OnEditMagfield_7columns(); 
			OptReionStop = !FieldLoaded;
		}
		else  OptReionStop = TRUE;
	}
	OnShow(); //OnDataActive();
}

void CBTRDoc::OnUpdateOptionsStopreionizedparticles(CCmdUI* pCmdUI) 
{
	//pCmdUI->SetCheck(OptReionStop);
	if (!OptReionStop) pCmdUI->SetText("Stop Re-ionized");
	else pCmdUI->SetText("Trace Re-ionized");
}

void CBTRDoc::OnOptionsStrayfieldonoff() 
{
//	OptStrayField =!OptStrayField;
	pMainView->InvalidateRect(NULL, TRUE);
	OnShow(); //OnDataActive();
}

void CBTRDoc::OnUpdateOptionsStrayfieldonoff(CCmdUI* /* pCmdUI */) 
{
	//pCmdUI->SetCheck(OptStrayField);
	//if (!OptStrayField) pCmdUI->SetText("Switch-ON MagField");
	//else pCmdUI->SetText("Switch-OFF MagField");
}

void CBTRDoc::OnOptionsOpencalorimeter() 
{
	OptCalOpen =!OptCalOpen;

	SetPlates();
	OnShow(); //OnDataActive();
	pMainView->InvalidateRect(NULL, TRUE);

}

void CBTRDoc::OnUpdateOptionsOpencalorimeter(CCmdUI* pCmdUI) 
{
	//pCmdUI->SetCheck(OptCalOpen);
	if (!OptCalOpen) pCmdUI->SetText("Open Calorimeter");
	else pCmdUI->SetText("Close Calorimeter");

}

void CBTRDoc::OnTasksMagshield() // disabled now
{
	CRemnDlg dlg;
	dlg.m_B1 = Bremnant1;
	dlg.m_B2 = Bremnant2;
	dlg.m_B3 = Bremnant3;
	dlg.m_X1 = Xremnant1;
	dlg.m_X2 = Xremnant2;
	dlg.m_X3 = Xremnant3;
	if (dlg.DoModal() == IDOK) {
		Bremnant1 = dlg.m_B1;
		Bremnant2 = dlg.m_B2;
		Bremnant3 = dlg.m_B3;
		Xremnant1 = dlg.m_X1;
		Xremnant2 = dlg.m_X2;
		Xremnant3 = dlg.m_X3;
		if (Xremnant2 < Xremnant1) Xremnant2 = Xremnant1;
		if (Xremnant3 < Xremnant2) Xremnant3 = Xremnant2;
		TaskRemnantField = TRUE;
		ShowTestField();
	}
	else TaskRemnantField = FALSE;
}

void CBTRDoc::OnUpdateTasksMagshield(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);
//	pCmdUI->SetCheck(TaskRemnantField);
}

void CBTRDoc::OnTasksReionization() 
{
/*	CReionDlg dlg;

	switch (TracePartType) {
	case 0:	dlg.m_Caption = "e -> e+"; break;
	case 1:
	case -1:
	case 10:
			dlg.m_Caption = "Ho -> H+"; break;
	case 2:
	case -2:
	case 20:
			dlg.m_Caption = "Do -> D+"; break;
	default: dlg.m_Caption = "Neutral atom Zo -> Ion Z+"; break; 
	}
	dlg.m_IonStepL = IonStepL;
	dlg.m_Lstep = ReionStepL;
	dlg.m_Percent =	ReionPercent;
	dlg.m_Sigma = ReionSigma;
	dlg.m_Xmin = ReionXmin;
	dlg.m_Xmax = ReionXmax;

	if (dlg.DoModal() == IDOK) {
		ReionSigma = dlg.m_Sigma;
		ReionXmin = dlg.m_Xmin;
		ReionXmax = dlg.m_Xmax;
		ReionStepL = dlg.m_Lstep;
		IonStepL = dlg.m_IonStepL;
	
		SetReionPercent();
		CString S;
		if (PressureLoaded)	S.Format("Re-ionization loss = %3.1f %%", ReionPercent);
		else S.Format("Pressure profile not defined. \n Re-ionized current = 0");
		AfxMessageBox(S);
	}
	*/
	SetReionization();
///////////////////
	Progress = 0;
	CurrentDirName = TopDirName;
	::SetCurrentDirectory(CurrentDirName);
	SetTitle(CurrentDirName);

	TaskRID = FALSE;
	TaskReionization = TRUE; //!TaskReionization; 
	if (LoadSelected > 0) SelectAllPlates(); // empty the plates list
	InitTaskReionization();
	//SetPlates(); 
	TaskName = " RE-IONISED POWER";
	OnShow();

}

void CBTRDoc::OnUpdateTasksReionization(CCmdUI* pCmdUI) 
{
//	pCmdUI->Enable(FALSE);
	pCmdUI->SetCheck(TaskReionization);
}


void CBTRDoc::OnTasksNeutralisation() //
{
//	if (PressureLoaded)	SetNeutrCurrents();
//	OnShow();

/* 	CNeutrDlg dlg;
	dlg.m_Thin = OptThickNeutralization;

	if (dlg.DoModal() == IDOK) {
				OptThickNeutralization = dlg.m_Thin;
			}
	else return; // ThickNeutralization = FALSE;
	
	if (!PressureLoaded && OptThickNeutralization) {
		AfxMessageBox("Please, define gas profile before choosing THICK model \n THIN model is active ");
		OptThickNeutralization = FALSE;
	}

	if (!OptThickNeutralization) {
		CThinDlg dlg;
		dlg.m_Xlim = NeutrXmax;
		dlg.m_Neff = NeutrPart * 100;
		dlg.m_PosYield = PosIonPart * 100;
		if (dlg.DoModal() == IDOK) {
			NeutrXmax = dlg.m_Xlim;
			NeutrPart = dlg.m_Neff * 0.01;
			PosIonPart = dlg.m_PosYield * 0.01;
			CheckData();
		}
	}

	else {
		CThickDlg dlg;
		dlg.m_Xmin = NeutrXmin;
		dlg.m_Xmax = NeutrXmax;
		dlg.m_Step = NeutrStepL;
		dlg.m_SigmaNeutr = NeutrSigma * 10000; // -> cm2
		dlg.m_SigmaIon = ReionSigma * 10000;
		dlg.m_Sigma2Strip = TwoStripSigma * 10000;
		dlg.m_SigmaExch = PosExchSigma * 10000;
		if (dlg.DoModal() == IDOK) {
			NeutrXmin = dlg.m_Xmin;
			NeutrXmax = dlg.m_Xmax;
			NeutrStepL = dlg.m_Step;
			NeutrSigma = dlg.m_SigmaNeutr * 0.0001; // -> m2
			ReionSigma = dlg.m_SigmaIon * 0.0001;
			TwoStripSigma = dlg.m_Sigma2Strip * 0.0001;
			PosExchSigma = dlg.m_SigmaExch * 0.0001;
			SetNeutrCurrents();
		}
	}*/
	SetNeutralisation();
	OnShow();
}

void CBTRDoc::OnUpdateTasksNeutralisation(CCmdUI* pCmdUI) 
{
//	pCmdUI->Enable(FALSE);
	pCmdUI->SetCheck(PressureLoaded);
}

void CBTRDoc::OnResultsRead() 
{
	CLoadView * pLV = (CLoadView *) pLoadView;

	CLoad * load = NULL;
	char name[1024];
//	char buf[1024];
//	CFileDialog dlg(TRUE, "dat", "*.dat");
	CFileDialog dlg(TRUE, "dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"3-column load data file (*.dat) | *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
	if (dlg.DoModal() == IDOK) {
	
		strcpy(name, dlg.GetPathName());
		CWaitCursor wait;
		CPreviewDlg dlg;
		dlg.m_Filename = name;
		if (dlg.DoModal() == IDCANCEL) return;
		SetTitle(name);// + TaskName);
	
//	if (LoadSelected > 0) SelectAllPlates();
//	InitAddPlates();

		
	load = ReadLoad(name);
	if (load != NULL && load->MaxVal >1.e-10) {
		pLV->ShowLoad = TRUE;
		pLV->SetLoad_Plate(load, pMarkedPlate);
		pSetView->SetLoad_Plate(load, pMarkedPlate);
		ShowProfiles = TRUE;
		OptCombiPlot = 1; 
	} // load != NULL
	else {
		AfxMessageBox("OnResultsRead : load = NULL");
 		pLV->ShowLoad = FALSE;
		pSetView->Load = NULL;
	}

	ModifyArea(FALSE);
    pMainView->InvalidateRect(NULL, TRUE);
	pLV->InvalidateRect(NULL, TRUE);
	pSetView->InvalidateRect(NULL, TRUE);
	ShowFileText(name);
	} // if IDOK
	OptParallel = FALSE;// ! for CalculateCombi(0)
	
}

CLoad* CBTRDoc::ReadLoad(char * name)
{
	//if (InvUser) return NULL;
	//SetLoadArray(NULL, FALSE);//TRUE);
	CPlate * plate = NULL; 
	CPlate * plate0 = new CPlate();
	CLoad * load = new CLoad();
	plate0->Load = load;
	int Number = -1;
	int Nx = 0, Ny = 0, SmoothDegree = 0;
	double StepX = 0, StepY = 0, Xmax = 0, Ymax = 0;
	C3Point Orig(-1,0,0), OrtX(0,1,0), OrtY(0,0,1);
	CString Comment = "No comment";
	C3Point p0, p1, p2, p3, mass;
	CString S;

//	ReadLoadInfo(m_Text, Nx, Ny, StepX, StepY);// standard old
	BOOL Free;
	Free = ReadPlateInfo(name, plate0);
	Nx = plate0->Load->Nx;
	Ny = plate0->Load->Ny;
	StepX = plate0->Load->StepX;
	StepY = plate0->Load->StepY;
	Xmax = Nx*StepX;
	Ymax = Ny*StepY;
	Orig = plate0->Orig;
	OrtX = plate0->OrtX; OrtY = plate0->OrtY;
	SmoothDegree = plate0->SmoothDegree;
	Number = plate0->Number;
	Comment = plate0->Comment;
	
	//mass = (p0 + p1 + p2 + p3) * 0.25;

if (Xmax * Ymax > 1.e-6) {
	load = new CLoad(Xmax, Ymax, StepX, StepY);
	ReadLoadArray(name, load, Free);
	load->SetSumMax();
}
	bool found = FALSE;

	POSITION pos = PlatesList.GetHeadPosition();
	while (pos != NULL && !found) {// find plate0 in the existing plates list 
		plate = PlatesList.GetNext(pos);
		//if (GetDistBetween(plate->MassCentre, mass) < 1.e-3) { found = TRUE; break; }
		/*C3Point Dist = (plate->Orig) - Orig;
		C3Point Vsum1 = VectSum(plate->OrtX, OrtX, 1, -1);
		C3Point Vsum2 = VectSum(plate->OrtY, OrtY, 1, -1);
		if (ModVect(Dist) < 1.e-3 && ModVect(Vsum1) < 0.1 && ModVect(Vsum2) < 0.1) {*/
		//if (GetDistBetween(plate->Corn[1], plate0->Corn[1]) < 1.e-6 && GetDistBetween(plate->Corn[2], plate0->Corn[2]) < 1.e-6) { found = TRUE; break; } 
		if (!OptFree && Comment.Find(plate->Comment, 0) > -1) { found = TRUE; break; }
		if (plate->Number == Number && GetDistBetween(plate->Orig, Orig) < 1.e-3) {
			found = TRUE; break; }
		if (GetDistBetween(plate->Vmax, plate0->Vmax) < 1.e-3 
			&& GetDistBetween(plate->Vmin, plate0->Vmin) < 1.e-3) {
			found = TRUE; break; }
		
	}//pos
	
	if (found) {
			plate->SetLocals(plate->Corn[0], plate->Corn[1], plate->Corn[3], plate->Corn[2]);
			plate->filename = name;

		if (plate->Loaded && Xmax * Ymax > 1.e-6) { // delete existing load
			plate->Load->Clear();
			plate->Load->~CLoad();
		}
			plate->Load = load; 
			plate->Loaded = TRUE;
			plate->Xmax = Xmax; plate->Ymax = Ymax;
			load->Comment = plate->Comment;
			plate->SmLoad = new CLoad(plate->Xmax, plate->Ymax, StepX, StepY);
			plate->SmLoad->Comment = load->Comment;
			plate->SmoothDegree = SmoothDegree;
			SetLoadArray(plate, TRUE); // 
			S.Format("Plate %d %s \n is identified", Number, Comment);
			//AfxMessageBox(S);
			pMarkedPlate = plate;
			return load;
	} // found in list

	else {// (!found) or  free surf
		S.Format("Plate %d %s \n not identified", Number, Comment);
		AfxMessageBox(S);
		return NULL; // not found
	}

	// --- free mode ---
	{ // (!found) or  free surf
		p0 = plate0->Corn[0]; //p0 = Orig; 
		p1 = plate0->Corn[1]; //p1 = Orig + OrtX*Xmax;
		p2 = plate0->Corn[3]; //p2 = Orig + OrtY*Ymax;
		p3 = plate0->Corn[2]; //p3 = p1 + OrtY*Ymax;
		
		if (GetDistBetween(p0, p3) < 1.e-6 && GetDistBetween(p1, p2) < 1.e-6) {
			p0 = Orig; 
			p1 = Orig + OrtX*Xmax;
			p2 = Orig + OrtY*Ymax;
			p3 = p1 + OrtY*Ymax;
		}
		plate0->SetLocals(p0, p1, p2, p3);
		plate0->Fixed = -1;
		plate0->filename = name;
		if (Xmax * Ymax > 1.e-6) {
			plate0->Loaded = TRUE;
			plate0->Load = load;
			load->Comment = plate0->Comment;
			plate0->SmLoad = new CLoad(Xmax, Ymax, StepX, StepY);
			plate0->SmLoad->Comment = load->Comment;
			plate0->SmoothDegree = SmoothDegree;
		}
		else  { // load not found
			plate0->Loaded = FALSE;
			plate0->Load = NULL;
			load = NULL;
		}
		
		CString com = plate0->Comment.MakeUpper();
		if (com.Find("SOLID") >= 0)  plate0->Solid = TRUE; 
		//else  plate0->Solid = FALSE;
		plate0->Visible = plate0->Solid;
	
		PlatesList.AddTail(plate0);
		if (load != NULL) 
			SetLoadArray(plate0, TRUE); // changes plate->Number!
		pMarkedPlate = plate0;
		//AddPlatesNumber++;

	} // not found in the PlatesList

	return load;
//} //Nx*Ny>0

//else return NULL;

}

void CBTRDoc:: ReadLoadInfo(CString & Text, int & Nx, int & Ny, double & StepX, double & StepY)
{
//	m_Text.Empty();// = '\0';
	CString text = Text; 
	CString line, name, valstr;
	double Value;
	BOOL found = FALSE; 

	int pos, pos1; // current position of symbol
	while (text.GetLength() > 0 && !found) {
		//pos =  text.FindOneOf("\n\0");// text.Find("\n", n);
		pos = text.Find("=", 0);
		if (pos < 2) break;
		name = text.Left(pos);
		valstr = text.Mid(pos+1);
	    Value = atof(valstr);
		pos1 = name.Find("Nx", 0);
		if (pos1 >0) {
			Nx = (int)Value;
			text.Delete(0, pos+1);
			continue;
		}
		pos1 = name.Find("Ny", 0);
		if (pos1 >0) {
			Ny = (int)Value;
			text.Delete(0, pos+1);
			continue;
		}
		pos1 = name.Find("StepX", 0);
		if (pos1 >0) {
			StepX = Value;
			text.Delete(0, pos+1);
			continue;
		}
		pos1 = name.Find("StepY", 0);
		if (pos1 >0) {
			StepY = Value;
			text.Delete(0, pos+1);
			found = TRUE;
			continue;
		}
	} // while !found && textLength >0
	
}

BOOL CBTRDoc:: ReadPlateInfo(char* name, CPlate * Plate)
{
	FILE * fin;
	char buf[1024];
	CString Line;
	if ( (fin= fopen(name, "r")) == NULL) {
		CString S ="Can't find/open ";
		S+=  name;
		AfxMessageBox(S, MB_ICONSTOP | MB_OK);
		return 0;
	}
	//AfxMessageBox("Enter ReadPlateInfo");
	int  pos0, pos, res; //Name, "="
	CString valstr;
	double Value, x, y, z;
	//C3Point P;
	Plate->Corn[0] = C3Point(0,0,0);//Orig; 
	Plate->Corn[1] = C3Point(0,0,0); //p1 = Orig + OrtX*Xmax;
	Plate->Corn[3] = C3Point(0,0,0); //p2 = Orig + OrtY*Ymax;
	Plate->Corn[2] = C3Point(0,0,0); //p3 = p1 + OrtY*Ymax;
	Plate->Number = -1;
	Plate->Comment = "No comment";
	Plate->Solid = FALSE;
	BOOL foundFree = FALSE;

	//while (!feof(fin)) {
		Line = fgets(buf, 1024, fin);
		pos0 = -1;
		pos = -1;
		Line.MakeUpper();
		//AfxMessageBox(Line);

		if (Line.Find("#")>-1 || Line.Find("FREE") > -1)  
		{
			foundFree = TRUE; 
			if ((Line.Find("SOLID")) > -1) Plate->Solid = TRUE;
			else if ((Line.Find("TRANSPAR")) > -1) Plate->Solid = FALSE;
		} //found Free

		if (foundFree) {
			AfxMessageBox("ReadPlateInfo found FREE surf");
			for (int i = 0; i < 4; i++) { // read corners
				if (fgets(buf, 1024, fin) == NULL) continue;
				res = sscanf(buf, "%le %le %le", &x, &y, &z);
			
				if (res != 3) {
					CString S;
					S.Format("%s - Corner %d not defined", name, i);
					AfxMessageBox(S); 
					//fgets(buf, 1024, fin); // read  line
					break;
				} //if

				Plate->Corn[i].X = x; Plate->Corn[i].Y = y; Plate->Corn[i].Z = z; 
			} //read corners
			//Line = fgets(buf, 1024, fin); // read neaxt line - Comments 
		} // # found Free surf

		//else OptFree = FALSE;// Standard surf found -> switch to Standard geometry
 
 // Next 2 lines shoud be read in Free mode!!! (uncommented)
	//	Line = fgets(buf, 1024, fin); // read neaxt line - Comments 
	//	Line.MakeUpper();
	
		if ((pos0 = Line.Find("PARAM",0)) >=0) {
			if ((Line.Find("SOLID")) > -1) Plate->Solid = TRUE;
			else if ((Line.Find("TRANSPAR")) > -1) Plate->Solid = FALSE;
			else Plate->Solid = TRUE;
			Plate->Comment = Line.Left(pos0-3);
			pos = Line.MakeUpper().Find("PLATE", 0);
			valstr = Line.Mid(pos+5);
			Value = atof(valstr);
			Plate->Number = (int)Value;
		} // 
	

	while (!feof(fin)) {
		Line = fgets(buf, 1024, fin);
		//AfxMessageBox(Line);
		if ((pos0 = Line.Find("Nx",0)) >=0) {
			pos = Line.Find("=", 0);
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->Load->Nx = (int)Value;
		}
		if ((pos0 = Line.Find("Ny",0)) >=0) {
			pos = Line.Find("=", pos0);
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->Load->Ny = (int)Value;
			continue;
		}
		if ((pos0 = Line.Find("StepX",0)) >=0) {
			pos = Line.Find("=", 0);
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->Load->StepX = Value;
			Plate->Load->Xmax = Plate->Load->Nx * Plate->Load->StepX;
			Plate->Xmax = Plate->Load->Xmax;
		}
		if ((pos0 = Line.Find("StepY",0)) >=0) {
			pos = Line.Find("=",pos0);
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->Load->StepY = Value;
			Plate->Load->Ymax = Plate->Load->Ny * Plate->Load->StepY;
			Plate->Ymax = Plate->Load->Ymax;
			continue;
		}
		if ((pos0 = Line.Find("Origin",0)) >=0) {
			pos = Line.Find("=", 0); //X =
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->Orig.X = Value;
			Line.Delete(0, pos+1);
			pos = Line.Find("=", 0); //Y =
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->Orig.Y = Value;
			Line.Delete(0, pos+1);
			pos = Line.Find("=",0); //Z = 
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->Orig.Z = Value;
			continue;
		}
		if ((pos0 = Line.Find("OrtX",0)) >=0) {
			pos = Line.Find("=", 0); //X =
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->OrtX.X = Value;
			Line.Delete(0, pos+1);
			pos = Line.Find("=", 0); //Y =
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->OrtX.Y = Value;
			Line.Delete(0, pos+1);
			pos = Line.Find("=",0); //Z = 
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->OrtX.Z = Value;
			continue;
		}
		if ((pos0 = Line.Find("OrtY",0)) >=0) {
			pos = Line.Find("=", 0); //X =
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->OrtY.X = Value;
			Line.Delete(0, pos+1);
			pos = Line.Find("=", 0); //Y =
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->OrtY.Y = Value;
			Line.Delete(0, pos+1);
			pos = Line.Find("=",0); //Z = 
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->OrtY.Z = Value;
			continue;
		}
		if (Line.Find("Degree",0)>=0){
			pos = Line.Find("=", 0);
			valstr = Line.Mid(pos+1);
			Value = atof(valstr);
			Plate->SmoothDegree = (int)Value;
		}
		//if (Line.Find("DEPOSIT",0)>=0) break; //endInfo = TRUE;

	} // feof
	fclose(fin);

	if (Plate->Number < 0) {
		Line = CString(name);
		pos = Line.Find("load", 0);
		if (pos < 0) {
			Plate->Number = 1000; return 0;}
		Line.Delete(pos, 4);
		pos = Line.Find("dat", 0);
		Line.Delete(pos-1, 4);
		valstr = Line;
		Value = atof(valstr);
		Plate->Number = (int)Value;
	}

	if (foundFree) return TRUE;// OptFree = TRUE;
	else return FALSE;
}



void CBTRDoc:: ReadLoadArray(char* name, CLoad* Load, bool isfree)
{
	if (Load == NULL) return;
	//if (Load->Nx * Load->Ny == 0) return;
	//if (Load->StepX * Load->StepY < 1.e-8) return;
	//AfxMessageBox("Enter ReadLoadArray");

	FILE * fin;
	if ( (fin = fopen(name, "r")) == NULL) {
		CString S ="Can't find/open ";
		S+=  name;
		AfxMessageBox(S, MB_ICONSTOP | MB_OK);
		return;
	}
	char buf[1024];
	double x, y, load;
	double stepX = Load->StepX;
	double stepY = Load->StepY;
	int i, j;
	if (isfree) {
		for (int k = 0; k < 5; k ++) fgets(buf, 1024, fin);
	}

	while (!feof(fin)) {
		fgets(buf, 1024, fin);
		int result = sscanf(buf, "%lf %lf %lf",  &x, &y, &load);
		if (result < 3) continue;
				
		else {
			i = (int) (x / stepX);
			if ( i*stepX - x > 0.5*stepX) i--; 
			if ( i*stepX - x < -0.5*stepX) i++; 
			j = (int) (y / stepY);
			if ( j*stepY - y > 0.5*stepY) j--; 
			if ( j*stepY - y < -0.5*stepY) j++; 
			if (i <= Load->Nx  && j <= Load->Ny)
			Load->Val[i][j] = load;
		}

		//else	fgets(buf, 1024, fin);
		
	}
		fclose(fin);
}

void CBTRDoc:: ReadIonPowerX()
{
	//WriteSumReiPowerX("Sum_ReiX.dat");
	//WriteSumAtomPowerX("Sum_AtomX.dat");
	//CString name = "Sum_X.dat";
	FILE * fin;
	CString S;
	fin = fopen("Sum_X.dat", "r");
	if (fin == NULL) fin = fopen("Sum_ReiX.dat", "r");
	if (fin == NULL) fin = fopen("Sum_ReiX.txt", "r");
	if (fin == NULL)  {
		S = "Failed to read IonPower along X";
		//AfxMessageBox(S, MB_ICONSTOP | MB_OK);
		return;
	}


	SumReiPowerX.RemoveAll();

	char buf[1024];
	double x, y;
	int i, j=0;
	for (int k = 0; k <2; k ++) fgets(buf, 1024, fin);
	while (!feof(fin)) {
		int result = fscanf(fin, " %le  %le", &x, &y); 
		//	fprintf(fout, "\t%-7.3f \t %-7.3f \t %-12.3le \n", x,y,load);
		if (result != 2) {
				fgets(buf, 1024, fin);
				continue;
			}
		else {
			i = (int) (x / SumPowerStepX);
			SumReiPowerX.Add(y);
			j++;// data line
		}
		//else	fgets(buf, 1024, fin);
	}
		fclose(fin);
		//S.Format("%d lines accepted, array size - %d", j, SumPowerX.GetSize()); 
		//AfxMessageBox(S);
		
}

void CBTRDoc:: ReadAtomPowerX()
{
	//WriteSumReiPowerX("Sum_ReiX.dat");
	//WriteSumAtomPowerX("Sum_AtomX.dat");
	//CString name = "Sum_X.dat";
	FILE * fin;
	CString S;
	fin = fopen("Sum_AtomX.dat", "r");
	if (fin == NULL) fin = fopen("Sum_AtomX.txt", "r");
	if (fin == NULL)  {
		S = "Failed to read AtomPower along X";
		//AfxMessageBox(S, MB_ICONSTOP | MB_OK);
		return;
	}

	SumAtomPowerX.RemoveAll();

	char buf[1024];
	double x, y;
	int i, j=0;
	for (int k = 0; k <2; k ++) fgets(buf, 1024, fin);
	while (!feof(fin)) {
		int result = fscanf(fin, " %le  %le", &x, &y); 
		//	fprintf(fout, "\t%-7.3f \t %-7.3f \t %-12.3le \n", x,y,load);
		if (result != 2) {
				fgets(buf, 1024, fin);
				continue;
			}
		else {
			i = (int) (x / SumPowerStepX);
			SumAtomPowerX.Add(y);
			j++;// data line
		}
		//else	fgets(buf, 1024, fin);
	}
		fclose(fin);
		//S.Format("%d lines accepted, array size - %d", j, SumPowerX.GetSize()); 
		//AfxMessageBox(S);
		
}

void CBTRDoc::OnResultsSaveall() 
{
//	NeedSave = TRUE;
	int res;
	if (!OptFree) {// Standard Geom
		res = AfxMessageBox("Standard NBI geometry can be also stored as Free Surfaces.\n Do you want to Save it Free?",
			MB_YESNOCANCEL); 
		if (res == IDCANCEL) return;
		else if (res == IDYES) { // Save Standard As Free
			OptFree = TRUE;
			SaveLoads(TRUE); // + save SumPower included
			return;
		}
		else SaveLoads(FALSE); // Save Standard
		return;
	} // OptFree = FALSE
	
	else 	SaveLoads(TRUE); // OptFree = TRUE -> Save Free
	
}

void CBTRDoc::OnResultsSaveList()
{
	CFileDialog dlg(FALSE, "dat;txt | * ", "AllLoads.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Loads Summary file (*.dat); (*.txt) | *.dat; *.DAT; *.txt; *.TXT | All Files (*.*) | *.*||", NULL);
	
	if (dlg.DoModal() == IDOK) {
		FILE * fout;
		char name[1024];
		
		strcpy(name, dlg.GetPathName());
		fout = fopen(name, "w");
		//fprintf(fout, Text);
		
	//FILE * fout = fopen("LoadsList.txt", "w");
		fprintf(fout, "Power Loads Summary \n");
		fprintf(fout, " Num      Total, W     Max, W/m2          Comment\n");

		CPlate * plate;
		CString S;
		//double percent;
		int k;
		for (int i = 0; i < LoadSelected; i++) {
			k = i;
			if (Sorted_Load_Ind.GetSize() > 1) // sorted 
				k = Sorted_Load_Ind[i]; 
			plate = Load_Arr[k];
	/*	percent = (plate->Load->Sum) / (pDoc->NeutrPower)/10000;
		S.Format(" %d    %10.4e    %10.4e    %0.4f", plate->Number, plate->Load->Sum,  plate->Load->MaxVal,  percent);*/
			S.Format(" %3d    %10.3e    %10.3e   ", plate->Number, plate->Load->Sum,  plate->Load->MaxVal);
			S += plate->Comment;
			fprintf(fout, S + "\n");
		}
		fclose(fout);
	} 
}

void CBTRDoc::OnEditPlasmaTeNe()
{
	//if (!OptBeamInPlasma) return;
	char name[1024];
//	char buf[1024];
//	CFileDialog dlg(TRUE, "dat", "*.dat");
	CFileDialog dlg(TRUE, "dat; txt | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"psi Te Ne Ti Zeff columns  (*.txt);(*.dat)  | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
	
	if (dlg.DoModal() == IDOK) {
		strcpy(name, dlg.GetPathName());
		//CWaitCursor wait;
		CPreviewDlg pdlg;
		pdlg.m_Filename = name;
		if (pdlg.DoModal() == IDCANCEL) {
			pPlasma->ProfilesLoaded = FALSE; // use parabolic
			return;
		}
		//SetTitle(name);// + TaskName);
		//BOOL res = 
		
		pPlasma->ProfilesLoaded = pPlasma->ReadProfilesWithSigmas(name); //ReadProfiles(name);
				//pPlasma->ProfilesLoaded = FALSE; // use parabolic
	}
	else {
		pPlasma->ProfilesLoaded = FALSE; // use parabolic
		return;
	}
	
	PlotPSIArrays(); // profiles along PSI
	MaxPlasmaDensity = pPlasma->Nemax;
	MaxPlasmaTe = pPlasma->Temax;

	//SetDecayInPlasma(); // fill decay array

}

void CBTRDoc:: ReadPlasmaProfiles(char* name) //moved to plasma obj
{	
	FILE * fin;
	CString S;
	if ( (fin= fopen(name, "r")) == NULL) {
		S ="Can't find/open ";
		S+= name;
		AfxMessageBox(S, MB_ICONSTOP | MB_OK);
		return;
	}

	double MaxDensity = 0;
	double MaxTe = 0;
	PlasmaProfileNTZ.RemoveAll();
	PlasmaProfilePSI.RemoveAll();

	char buf[1024];
	double psi, Te, Ne, Ti, Zeff;
	C3Point P;
	int i, j=0;
	//for (int k = 0; k <2; k ++) 
	fgets(buf, 1024, fin);
	while (!feof(fin)) {
		int result = fscanf(fin, " %le  %le  %le  %le  %le", &psi, &Te, &Ne, &Ti, &Zeff); //Te,keV	Ne,10^19/m3
		//	fprintf(fout, "\t%-7.3f \t %-7.3f \t %-12.3le \n", x,y,load);
		if (result != 5) {
				fgets(buf, 1024, fin);
				continue;
			}
		else {
			fgets(buf, 1024, fin);
			//i = (int) (x / SumPowerStepX);
			P.X = Ne; P.Y = Te; P.Z = Zeff; //Te,keV	Ne,10^19/m3
			PlasmaProfileNTZ.Add(P);
			PlasmaProfilePSI.Add(psi);
			MaxDensity = Max(MaxDensity, Ne);
			MaxTe = Max(MaxTe, Te);
			j++;// data line
		}
		//else	fgets(buf, 1024, fin);
	}
		fclose(fin);

		if (MaxDensity > 1.e-3) MaxPlasmaDensity = MaxDensity;
		if (MaxTe > 1.e-3) MaxPlasmaTe = MaxTe;


		if (j < 1) {
			AfxMessageBox("invalid number of columns (must be 5)");
			ProfLoaded = FALSE;
			PlasmaLoaded = FALSE;
			return;
		}

		if (MaxDensity * MaxTe > 1.e-6) ProfLoaded = TRUE;
		else ProfLoaded = FALSE;
		
		if (ProfLoaded && PSILoaded) PlasmaLoaded = TRUE;
		else PlasmaLoaded = FALSE;

		//MaxPlasmaDensity *= 1.e19;
		//S.Format("%d lines accepted, array size - %d", j, PlasmaProfileNTZ.GetSize()); 
		//AfxMessageBox(S);
		
}




void CBTRDoc::OnUpdateOptionsRealionsourcestructure(CCmdUI* /* pCmdUI */) 
{
/*	pCmdUI->SetCheck((int)*ISourceType); */
}

void CBTRDoc::OnDataSave() 
{
/*	if (!STOP) {
		AfxMessageBox("Stop calculations before storing data! \n (Red cross on the Toolbar)");
		return ;
	} */
	STOP = TRUE;
	OnStop();
	CWaitCursor wait; 
	SaveData();
	OnShow();

}

void CBTRDoc::OnResultsReadall() 
{
	OptFree = FALSE; // set standard by default
	// CLoad* load = NULL;
	if (OnDataGet() == 0) return;// read config failed
	//OnPlateClearSelect();
	//if (LoadSelected > 0) SelectAllPlates();
	SetLoadArray(NULL, FALSE);//clear
	//InitAddPlates();

	ReadIonPowerX();
	ReadAtomPowerX();

	BeginWaitCursor(); //OnShow();
	WIN32_FIND_DATA FindFileData; //fData;
	HANDLE hFind;
	// LPTSTR DirSpec = (LPTSTR)"*.dat";

	char name[1024];
	CString  sn;

	DINSELECT = FALSE;	

	// Find the first file in the directory.
   hFind = FindFirstFile("*.dat", &FindFileData);

   if (hFind == INVALID_HANDLE_VALUE) AfxMessageBox("Invalid file handle");
 
   else  {
	   sn = (CString) (FindFileData.cFileName);
	   if (sn.Find("load", 0) >= 0) {
		strcpy(name, sn);
		ReadLoad(name);
	   }
   }
  
      while (FindNextFile(hFind, &FindFileData) != 0) 
      {
         //_tprintf (TEXT("Next file name is: %s\n"),  FindFileData.cFileName);
		  sn = (CString) (FindFileData.cFileName);
		  if (sn.Find("load", 0) >= 0) {
			  strcpy(name, sn);
			  ReadLoad(name);
		  }
      }
    
     // dwError = GetLastError();
    FindClose(hFind);

	//pMarkedPlate = NULL;
	OptCombiPlot = -1;//-1 - no load, 0 - map is calculated, >0 - selected but not calculated 
	

	ModifyArea(FALSE);
	//if (LoadSelected > 0) SelectAllPlates();
	OnPlateClearSelect();

	EndWaitCursor();
	Progress = 0;

	char OpenDirName[1024];
	::GetCurrentDirectory(1024, OpenDirName);
	//::SetCurrentDirectory(OpenDirName);
	SetTitle(OpenDirName);// + TaskName);
	
	/*pMainView->InvalidateRect(NULL, TRUE);
	pLoadView->InvalidateRect(NULL, TRUE);
	pSetView->InvalidateRect(NULL, TRUE);*/
	OptParallel = FALSE; // CalculateCombi(0)
	OnShow();
}

bool CBTRDoc:: CorrectPDPInput()
{
	WIN32_FIND_DATA fData;
	HANDLE h;
//	char name[1024];
	char * fname;
	CString  S = "";
	int pos, pos1, reply = -1;
	bool found = false;
 
	::SetCurrentDirectory(CurrentDirName);

	// .TXT 
	h = ::FindFirstFile("*.txt", &fData); 
	do {// (h != NULL) {
		//		if (h == (HANDLE) 0xFFFFFFFF) break;
		if (h == INVALID_HANDLE_VALUE) { 
			found = false;
			break;
		}
		fname = fData.cFileName;
		S = fname;
		S.MakeUpper();
		pos = S.Find("INP");
		pos1 = S.Find("BEAM");
		if (pos >= 0 && pos1 < 0) { // not beamlets file!
			CorrectFile(fname);
			found = true;

			CPreviewDlg dlg;
			dlg.m_Filename = fname;
			if (dlg.DoModal() == IDCANCEL)
				found = false; //return 0;
			else
				return true;
		}
	} while (::FindNextFile(h, &fData));

	// .DAT
	h = ::FindFirstFile("*.dat", &fData); 
	do {// (h != NULL) {
		//		if (h == (HANDLE) 0xFFFFFFFF) break;
		if (h == INVALID_HANDLE_VALUE) { 
			found = false;
			break;
		}
		fname = fData.cFileName;
		S = fname;
		S.MakeUpper();
		pos = S.Find("INP");
		pos1 = S.Find("BEAM");
		if (pos >= 0 && pos1 < 0) { // not beamlets file!
			CorrectFile(fname);
			found = true;
			
			CPreviewDlg dlg;
			dlg.m_Filename = fname;
			if (dlg.DoModal() == IDCANCEL)
				found = false;
			else
				return true;
		}
	} while (::FindNextFile(h, &fData));

	if (!found)
		reply = AfxMessageBox("INPUT file not found or rejected \n Continue anyway?", 3); 
	return (reply == IDYES);
}

void CBTRDoc::CorrectFile(char * name)
{
	FILE * fin;
	FILE * fout;

	fin = fopen(name, "r");
	if (fin==NULL){
		AfxMessageBox("input file not found", MB_ICONSTOP | MB_OK);
		return;
	}

	char buf[1024];
	CString text; 
	
	int result;

	double Eo, Iacc;
	if (fgets(buf,1024,fin) == NULL) { AfxMessageBox("Problem 0 with file"); fclose(fin); return; }
		
	result = sscanf(buf, "%lf %lf", &Eo, &Iacc); 
		
	if (result < 2) {
			text ="";
			while (!feof(fin) && result < 2) {
				fgets(buf, 1024, fin);
				result = sscanf(buf, "%lf %lf", &Eo, &Iacc);
			}
			if (feof(fin)) { AfxMessageBox("Data not found"); fclose(fin); return;}
			text += buf;
		
			while (!feof(fin)) {
				fgets(buf, 1024, fin);
				if (!feof(fin)) text += buf;
			}
		
			fclose(fin); 
	
		fout = fopen(name, "w");
		if (fout==NULL){
			AfxMessageBox("problem opening data file", MB_ICONSTOP | MB_OK);
			return;
		}
		fprintf(fout, text);
		fclose(fout);

	} // result < 2

}

void CBTRDoc::OnOptionsSingap() 
{
	OptSINGAP = !OptSINGAP;
	if (OptSINGAP && !SINGAPLoaded) {
		ReadSINGAP();
		SetSINGAP();
	}
	pMainView->InvalidateRect(NULL, TRUE);
	if (OptSINGAP) TaskName = "SINGAP BEAM";
	else TaskName = "MAMuG BEAM";

	Progress = 0;
	OnShow(); //OnDataActive();

}

void CBTRDoc::OnUpdateOptionsSingap(CCmdUI* pCmdUI) 
{
	
//	pCmdUI->SetCheck(OptSINGAP);
	if (OptSINGAP) pCmdUI->SetText("Choose MAMuG");
	else pCmdUI->SetText("Choose SINGAP");
}

void CBTRDoc::OnTasksRid() 
{
/*
	Progress = 0;
	CurrentDirName = TopDirName;
	::SetCurrentDirectory(CurrentDirName);
	SetTitle(CurrentDirName);
	
	TaskReionization = FALSE;
	TaskRID = TRUE;//!TaskRID;
	if (LoadSelected > 0) SelectAllPlates(); // empty the plates list
	InitTaskRID();
	SetPlates(); */
	
	CurrentDirName = TopDirName;
	::SetCurrentDirectory(CurrentDirName);

	CRIDDlg dlg;
	dlg.SetDocument(this);
	if (dlg.DoModal() == IDOK) {// APPLY button pushed
		RIDField->Copy(dlg.Nx, dlg.Ny, dlg.StepX, dlg.StepY, dlg.X0, dlg.NodeU);
		RIDFieldLoaded = TRUE;
		TaskName = "RID model applied";

	}

	//TaskName = " ION POWER in RID";

	OnShow();
}

void CBTRDoc::OnUpdateTasksRid(CCmdUI* pCmdUI) 
{
	//pCmdUI->Enable(FALSE);
	pCmdUI->Enable(!OptFree);
	pCmdUI->SetCheck(TaskRID);
	
}


/*
UINT ThreadProc(LPVOID pParam) /// not used
{
	CCriticalSection cs;
	//CDC * pDC = (CDC*) pParam;
	//if (pDC == NULL || !pDC->IsKindOf(RUNTIME_CLASS(CDC))) return -1;
	CBTRDoc * pDoc = (CBTRDoc*) pParam;
	if (pDoc == NULL || !pDoc->IsKindOf(RUNTIME_CLASS(CBTRDoc))) return -1;
	if (pDoc->STOP) return 0;

/*	cs.Lock();
	HDC DC = pMainView->GetDC()->GetSafeHdc();
	CString s;
	s.Format("%d", pDoc->ThreadNumber);

	int k = pDoc->ThreadNumber * 20;
	Rectangle(DC, k, k, k+100, k+100);
	TextOut(DC, k+1, k+1, s, s.GetLength());
	GdiFlush();
	cs.Unlock();
*/
/*	//pDoc->EmitBeam(OptSINGAP);
	int res;
	if (pDoc->OptSINGAP) 
		res = pDoc->EmitSINGAP(); // 0 - if stopped; 1 - if finished
	else 
		res = pDoc->EmitMAMuG(); // 0 - if stopped; 1 - if finished

	//Sleep(1000);
	return res;
}

void CBTRDoc::OnParallel() /// not used
{
	CWinThread * pThread[2000];// max - 16
	//int ThreadNumber;
	int NofThreads = 30;
	int res;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}
	if (LoadSelected > 0) {
		res = AfxMessageBox("Keep Surfaces selection as is?",3);
		
		if (res == IDYES) ClearAllPlates();
		else if (res == IDNO) OnOptionsSurfacesEnabledisableall();
		else return;
	}

	CString s;
	//Beep(100,100);
	Progress = 0;
	STOP = FALSE;
	
	pMainView->STOP = FALSE;
	//pMainView->InvalidateRect(NULL, TRUE);
		
//	int finished = EmitBeam(OptSINGAP);// run beam in series

// begin parallel beam ---------------------------------------------------
	OptDrawPart = FALSE;
	OptParallel = TRUE;
	//int prior = THREAD_PRIORITY_LOWEST; // _LOWEST, _BELOW_NORMAL, _NORMAL, _ABOVE_NORMAL, _HIGHEST
	int i;
	int finished = 0;
	//CDC* pDC = pMainView->GetDC();
	/*for (i = 0; i < NofThreads; i++)
	{
		if (pThread[i] != NULL) {
			WaitForSingleObject(pThread[i]->m_hThread, INFINITE);
			delete pThread[i];
		}
	}*/

/*	for (i = 0; i < NofThreads; i++)
	{
		/*pThread[i] = new CWinThread(ThreadProc, pDC->GetSafeHdc());
		if (pThread[i] == NULL) break;
		pThread[i] ->m_bAutoDelete = FALSE;
		if (!pThread[i]->CreateThread(CREATE_SUSPENDED))
		{
			delete pThread[i];
			pThread[i] = NULL;
			break;
		}
		VERIFY(pThread[i]->SetThreadPriority(prior));
		pThread[i]->ResumeThread();*/

		//ThreadNumber = i;
	/*	pThread[i] = ::AfxBeginThread(ThreadProc, this);//, prior);
		if (STOP) {
			finished = 0;
			break;
		}
		finished = 1;
		//Sleep(6000); // ms
	
	}
// end parallel beam ---

	if (finished == 1) s.Format(" FINISHED    "); //Progress = 100;
	else s.Format(" Beam STOPPED  ");//Progress = 50;
	STOP = TRUE;
	Progress = 100;
	SetLoadArray(NULL, TRUE);
	if (finished == 0) DetachLoadFiles();
	AfxMessageBox(s, MB_ICONEXCLAMATION | MB_OK);
	ShowStatus();
	Progress = 0;
//	pMainView->InvalidateRect(NULL, FALSE);
}
// <--- not used
*/

void CBTRDoc::OnStop() // stop (or suspend - commented) threads
{
	int i;
	pMainView->STOP = TRUE;
	pLoadView->STOP = TRUE;
	
	StopTime = CTime::GetCurrentTime();
	
	CString s;
	if (OptParallel && !STOP) { //NofCalculated > 0) {// started = TRUE
	//if (STOP) { //Paused
		
		for (i = 0; i < ThreadNumber; i++) {
			m_Tracer[i].SetContinue(FALSE);
			//m_Tracer[i].DumpArrays();
		}
		//SuspendAll(TRUE);// works bad
		for (i = 0; i < ThreadNumber; i++) 
			WaitForSingleObject(m_pTraceThread[i]->m_hThread, 1000); //INFINITE);
			
		//NofCalculated = 0;// to check if everything works!!!
		//SetTitle("STOPPED");

	//} // if paused
/*	else { //not paused yet
		SuspendAll(FALSE);// run = FALSE
		TbeginSuspend = CTime::GetCurrentTime();
		pMainView->ShowNBLine(); pMainView->ShowCoord();
		s.Format("Beam Paused (%d)", ThreadNumber);
		AfxMessageBox(s);
		SetTitle("PAUSED");
		
	}*/
	
	} //OptParallel && NofCalculated > 0)
	
	STOP = TRUE;
	SetTitle("STOPPED"); // in all cases!
	
	//ShowStatus();
	OnShow();

	//SwapMouseButton(TRUE);
	
}


void CBTRDoc:: OnStartParallel()/// start or resume threads(enables BTR-Fast)
{
	//#define DIV 1024
	//AfxMessageBox("BTR-F \n(under development)", MB_ICONEXCLAMATION | MB_OK);
	CString s, s1, s2;
	int res;
	
	if (!STOP) {
		OnStop(); // only stop threads, keep NofCalculated
		s.Format("Stopped (%d threads)", ThreadNumber);
		SetTitle(s);
		return;	
	}

	//if (!OptParallel) NofCalculated = 0; // modified -> to check!!!
	//if (NofCalculated >= NofBeamlets) NofCalculated = 0;
	
	TracksCalculated = 0;//map tracks on vert/horiz planes in plasma -> CalculateTracks
	
	OptParallel = TRUE;
	SetTitle("Trying to start");
	//pMarkedPlate = NULL;
	OptCombiPlot = -1; //-1 - no load, 0 - map is calculated, >0 - selected but not calculated 
	
	ClearAllPlates();

	if (!SINGAPLoaded) SetSINGAPfromMAMUG();

	SetPlasmaTarget(); //init plasma object, Geometry, Nray = -1
	//SetPlasmaGeom(); // set beam-tor geometry, plasma Rminor/Rmajor, Xmin/Xmax
	
	pBeamHorPlane->Load->Clear(); // created in SetPlatesNBI
	pBeamVertPlane->Load->Clear();// created in SetPlatesNBI

	ShowStatus();
	
	// here we detect number of processors present in the system (for unknown purposes)
/*	SYSTEM_INFO si;
	::GetSystemInfo(&si);
	int num_proc = si.dwNumberOfProcessors;*/
	
/*	if (NofCalculated > 0 && NofCalculated < NofBeamlets) { // if paused
		s.Format("Beam is currently paused. Do you want to continue? \n (Press NO to start a new beam)");
			res = AfxMessageBox(s, MB_ICONQUESTION | MB_YESNO); 
			if (res	== IDNO) {
				OnStop();
				//return;
			}
	}
	*/

	if (STOP) { // && NofCalculated == 0) { // start anew, set NofCalculated = 0
		NofCalculated = 0;
		if (TracePartType == 0) { // e
			AfxMessageBox("For electrons Parallel tracing is not available.\n\t Ions D- are active.");
			SetTraceParticle(-2);
		}

		//OptDrawPart = TRUE;
		if (OptDrawPart){
			s.Format("Tracks show will slow down the calculation!"
				"\n Do you want to hide the tracks during the run? \n");
			if (AfxMessageBox(s, MB_ICONQUESTION | MB_YESNO) == IDYES) OptDrawPart = FALSE;
		}
		
		s.Format("Started Parallel (%d)", ThreadNumber);
		SetTitle(s);

		//ThreadNumber = num_proc;
		for (int k = 0; k < ThreadNumber; k++) m_pTraceThread[k] = NULL;
		
	/*	CThreadsDlg dlg;

		dlg.Nproc = num_proc;
		dlg.Nthreads = ThreadNumber;
		dlg.m_CalcNeutr = OptCalcNeutralizer;
		dlg.m_CalcRID = OptCalcRID;
		dlg.m_CalcDuct = OptCalcDuct;
		dlg.m_Xmin = CalcLimitXmin;
		dlg.m_Xmax = CalcLimitXmax;

		if (dlg.DoModal() == IDOK) {
			
			ThreadNumber = dlg.Nthreads;
			OptCalcNeutralizer = dlg.m_CalcNeutr;
			OptCalcRID = dlg.m_CalcRID;
			OptCalcDuct = dlg.m_CalcDuct;
			CalcLimitXmin = dlg.m_Xmin;
			CalcLimitXmax = dlg.m_Xmax;

			InitTracers();
						
			if (LoadSelected > 0) SelectAllPlates();
			SuspendedSpan = 0;
			StartTime = CTime::GetCurrentTime();
			OnShow();
			//if (InvUser) SendReport(TRUE); // include input
		}
		else return; // cancel */

			InitTracers();

			//if (LoadSelected > 0) SelectAllPlates();// already done by ClearAllPlates()
			SuspendedSpan = 0;
			StartTime = CTime::GetCurrentTime();
			//OnShow();
	} // start a new run

	else {// (resume from pause) -> this is already checked by if (!STOP) see the top
		s.Format("Continued");	
		AfxMessageBox(s); 
		TendSuspend = CTime::GetCurrentTime();
		SuspendedSpan += TendSuspend - TbeginSuspend; 
	}
		
	STOP = FALSE;//started = TRUE
	for (int i = 0; i < ThreadNumber; i++)	m_Tracer[i].SetContinue(TRUE);
	SuspendAll(TRUE); // run = TRUE
	OnShow();

	//int n = Run_BTR_Fast();// test func

	//s.Format("WORKING Parallel (%d)", ThreadNumber);
	//SetTitle(s);
	
	/*CalculateTracks();
	pBeamHorPlane->Load->SetSumMax(); // created in SetPlatesNBI
	pBeamVertPlane->Load->SetSumMax();// created in SetPlatesNBI*/

	
}

void CBTRDoc:: GetMemState()
{
	int DIV = 1024;

	MEMORYSTATUSEX statex;
	statex.dwLength = sizeof (statex);
	GlobalMemoryStatusEx (&statex);

//  printf ("There is  %*ld percent of memory in use.\n",WIDTH, statex.dwMemoryLoad);
//  printf ("There are %*I64d total Kbytes of physical memory.\n", WIDTH, statex.ullTotalPhys/DIV);//DIV = 1024
//  printf ("There are %*I64d free Kbytes of physical memory.\n", WIDTH, statex.ullAvailPhys/DIV);//DIV = 1024

	MemFree = (long) (statex.ullAvailPhys /DIV); // available on the system
	
	HANDLE hProcess = GetCurrentProcess();
	PROCESS_MEMORY_COUNTERS pmc;
	//DWORD processID = GetCurrentProcessId(); 
	//hProcess = OpenProcess(  PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processID );
	if (NULL == hProcess)  return;

	if (GetProcessMemoryInfo(hProcess, &pmc, sizeof(pmc)) )
		MemUsed = pmc.WorkingSetSize /DIV; // currently used by BTR
		//MemUsed = pmc.PrivateUsage / DIV;
	//CloseHandle( hProcess );

	long Falls = 0;// total fall-points
	MemFalls = 0;// m_AttrVector[0].size() * ThreadNumber * sizeof(SATTR) / DIV;
	//for (int i = 0; i < ThreadNumber; i++) Falls += m_AttrVector[i].size();// falls within thread
	
	// fall-points
	Falls = m_GlobalVector.size();
	//Falls = m_GlobalDeque.size();
								  //long mem = Falls * sizeof(SATTR);
	//MemFalls =  mem/ DIV; // total kB for falls
	ArrSize = Falls; //sizeof(m_AttrVector[0]); // +mem / ThreadNumber) / DIV;
	
/*	if (NofCalculated < 1) return;

	int FallsB = Falls / NofCalculated; // falls per beamlet

	if (MemFallReserved) return; // reserve only once!!
	int numb = NofBeamlets / ThreadNumber; // beamlets per thread
	int Nattr = Attr_Array.GetSize();
	int numpart = numb * Nattr * MultCoeff; // particles per thread
	int newsize = FallsB * numb + Nattr; // for falls array in each Thread
	
	for (int i = 0; i < ThreadNumber; i++) {
		//m_AttrVector[i].shrink_to_fit();
		m_AttrVector[i].reserve(newsize); // reserve space for all beamlets in Thread
		m_Tracer[i].SetAttrArray(&m_AttrVector[i]);
		MemFallReserved = TRUE;
	}
*/
/*	if (OptParallel && NofCalculated == 1) {
		
		CString s, s1, s2;
		std::vector<SATTR> & arr = m_AttrVector[MaxThreadNumber-1];
		arr = m_AttrVector[0];
		int sizeTATTR = sizeof(SATTR);
		long TotPart = NofBeamlets * Attr_Array.GetSize() * MultCoeff;
		long MemBeamlet = (int)arr.size() * sizeTATTR / DIV / NofCalculated;
		long MemDemand =  NofBeamlets * MemBeamlet;//TotPart / DIV * kfall * sizeTATTR;
		
		//if (MemFree > MemDemand * 2) return;
		
		s1.Format("There are %ld KB of FREE physical memory on your system. ", MemFree);//statex.ullAvailPhys/DIV);
		s2.Format("\nTracing %ld particles can take more than %ld KB \n(~%ld KB per beamlet). ",
			TotPart, MemDemand, MemBeamlet);
		s.Format("\n\nYou can stop the beam and reduce the number of particles. \nOr press YES to continue the tracing. ");
		if (AfxMessageBox(s1+ s2 + s, MB_ICONEXCLAMATION | MB_YESNO) == IDNO) { STOP = TRUE; OnStop(); }
		
	} */
}

int CBTRDoc:: Run_BTR_Fast() //test func
{	
	CWinThread * pThread[16];// max - 16
	HANDLE hThread[16];

	int NofThreads;
	//int ThreadNumber;
	BEAMLET_ENTRY b;
	
	CWaitCursor wait;
	
	//Exit_Array.SetSize(NofBeamlets);

	SourceArr.RemoveAll();
	//SourceArr.SetSize(NofBeamlets + 1);
	// 0 - for halo parameters

	b.Fraction = BeamHaloPart;
	b.DivY = BeamHaloDiverg;
	b.PosY = IonBeamPower *1000000/ NofBeamletsTotal; //BeamletPower
	b.PosZ = 1; // NeutrPart 
	b.AlfY = b.AlfZ = 0; // not used
	SourceArr.Add(b); // 0 element - for halo parameters!!!
	Exit_Array.Add(C3Point(0,0,0));// 0 element - for beamlet counter!!
	int k;

	// init Source Array
	for (k = 0; k < NofBeamlets; k++) {
		b = BeamEntry_Array[k];
		SourceArr.Add(b);
		Exit_Array.Add(C3Point(0,0,0));
	}

	int tn = 0; //Thread counter
	AreaXmax = AreaLong;
	NofThreads = 4; //NofBeamlets;//total beamlets/segments number OR equal to processors
	int numb = NofBeamlets / NofThreads; // beamlets per thread
	NofCalculated = 0; // beamlets counter
	
	
	CPoint P;
	// start threads
	for (k = 0; k < NofThreads; k++) // k < NofBeamlets; k++)
	{
		//b = SourceArr.GetAt(k+1);
		P.x = (k) * numb + 1; P.y = (k+1) * numb;
		pThread[k] = ::AfxBeginThread(_Threadfunc, &P); //&b);
		hThread[k] = pThread[k]->m_hThread;
		tn = k;
		//NofCalculated++;
	
	} 
	
// Wait for all threads to terminate
    
	WaitForMultipleObjects(NofThreads, hThread, TRUE, INFINITE);
    // Close thread (and mutex) handles
/*	for( k=1; k <= NofThreads; k++ ){
		CloseHandle(hThread[k]);
		//delete pThread[k];
	}
*/

/*	DWORD res = 0;
	for (k = 0; k < NofBeamlets; k++)
	{
		if (pThread[k] != NULL) {
			res = WaitForSingleObject(pThread[k]->m_hThread, INFINITE);
			//delete pThread[i];// error
		}
	}*/
	
	Progress = (int) Exit_Array[0].X;//.GetUpperBound(); //NofCalculated;////
	NofCalculated = Progress;
	
	SYSTEM_INFO si;
	::GetSystemInfo(&si);
	int num_proc = si.dwNumberOfProcessors;
	CString s;
	s.Format("DONE: %d threads on %d processors \n Finished %d beamlets", 
				tn, num_proc, Progress);
	AfxMessageBox(s);


	return tn; // =NofCalculated; // 
}

UINT _Threadfunc(LPVOID param)// called by BTR_FAST only!!
{
//	BEAMLET_ENTRY * pb = (BEAMLET_ENTRY *) param;
//	if (pb == NULL) return -1;// || !pDoc->IsKindOf(RUNTIME_CLASS(CBTRDoc))) return -1;
	CPoint * lim = (CPoint*) param;
	int min = lim->x;
	int max = lim->y;
	//int numcalc = 0;
	if (min < 1 || max < 1) { MessageBox(NULL, "invalid index", "BTR", 0); return 1;}

	CCriticalSection cs;
	//int k = (pDoc->NofCalculated) - 1;
	//if (k<0) return 0;
	int x1, y1, z1, x2, y2, z2;
	BEAMLET_ENTRY be;
	double y0, z0, x,y,z;
	
/* // single beamlet
	BEAMLET_ENTRY be = *pb;//pDoc->BeamEntry_Array[k];//.GetAt(k);
	double y0 = be.PosY;
	double z0 = be.PosZ;
	double	x = AreaXmax;
	double	y = y0 + x * tan(be.AlfY); 
	double	z = z0 + x * tan(be.AlfZ); 
	Exit_Array.Add(C3Point(x,y,z));

	x1 = pMainView->OrigX;
	y1 = pMainView->OrigY - (int)(y0 * pMainView->ScaleY);
	z1 = pMainView->OrigZ - (int)(z0 * pMainView->ScaleZ);
	x2 = pMainView->OrigX + (int)(x * pMainView->ScaleX);
	y2 = pMainView->OrigY - (int)(y * pMainView->ScaleY);
	z2 = pMainView->OrigZ - (int)(z * pMainView->ScaleZ);
		
	cs.Lock();
	CDC* pDC = pMainView->GetDC();
	//HDC DC = pMainView->GetDC()->GetSafeHdc();
	CPen * pOldPen = pDC->SelectObject(&pMainView->BluePen);
	pDC->MoveTo(x1, y1); pDC->LineTo(x2, y2);
	pDC->MoveTo(x1, z1); pDC->LineTo(x2, z2);
	pDC->SelectObject(pOldPen);
	GdiFlush();
	cs.Unlock();
*/	
	CDC* pDC = pMainView->GetDC();
	CPen * pOldPen = pDC->SelectObject(&pMainView->BluePen);
	for (int k = min; k <= max; k++) // < NofBeamlets; k++)
	{
		cs.Lock();
		be = SourceArr.GetAt(k);
		cs.Unlock();
		
		y0 = be.PosY;
		z0 = be.PosZ;
		x = AreaXmax;
		y = y0 + x * tan(be.AlfY); 
		z = z0 + x * tan(be.AlfZ); 
	
		x1 = pMainView->OrigX;
		y1 = pMainView->OrigY - (int)(y0 * pMainView->ScaleY);
		z1 = pMainView->OrigZ - (int)(z0 * pMainView->ScaleZ);
		x2 = pMainView->OrigX + (int)(x * pMainView->ScaleX);
		y2 = pMainView->OrigY - (int)(y * pMainView->ScaleY);
		z2 = pMainView->OrigZ - (int)(z * pMainView->ScaleZ);
	
	cs.Lock();
		
		Exit_Array[0].X += 1.0;
		Exit_Array[k] = C3Point(x,y,z);
		//numcalc++;
		NofCalculated++;
		pDC->MoveTo(x1, y1); pDC->LineTo(x2, y2);
		pDC->MoveTo(x1, z1); pDC->LineTo(x2, z2);
		
	cs.Unlock();
	}
	GdiFlush();
		
	cs.Lock();
	pDC->SelectObject(pOldPen);
	cs.Unlock();
	
	pMainView->ReleaseDC(pDC);
	//Sleep(1000);
	return 0;

}


void CBTRDoc:: F_CalcRIDsimple()  //simplified form
{
	CPlate * plate = pMarkedPlate;//(CPlate *) param;
	if (plate == NULL) return;// -1;
	CLoad * L = plate->Load;
	C3Point Ploc, Ploc0, Ploc1, Ps, Pgl, P0, V;
	double  Ay, Az, Dy, Dz, DyH, DzH, dens, SumDens;
	double totdist, Cos, Path0, Y0, Z0, X0 = RIDXmin, distX, distZ;
	// double TotSum = 0;
	
	BEAMLET_ENTRY b;
	double divH = BeamHaloDiverg; //SourceArr[0].DivY; //*pDoc->BeamHaloDiverg;
	double H = BeamHaloPart; //SourceArr[0].Fraction; //*pDoc->BeamHaloPart;			
	double BeamletPower = IonBeamPower * 1000000 /NofBeamletsTotal;//(SourceArr[0].PosY) * (SourceArr[0].PosZ); 
	//pDoc->IonBeamPower *1000000/ pDoc->NofBeamletsTotal * NeutrPart; //W per beamlet 

	//CCriticalSection cs;
		
	int MaxSource = SourceArr.GetUpperBound();// Element 0 is for halo!
	if (MaxSource < 1) return;// 0; // Element 0 is for halo!

	int x1, y1, z1, x2, y2, z2;
	double y0, z0, x, y, z, dx, dy, dz;
	BOOL positive;
	double IonFraction;
	int sign;
	double dt = 1.0e-9, alfaEff, vx, vy, vz;

	CDC* pDC = pMainView->GetDC();
	//HDC DC = pMainView->GetDC()->GetSafeHdc();
	CPen * pOldPen;
	CPen pen;

	if (RID_A * plate->OrtZ.Y < 0) {
		positive = TRUE;
		pen.CreatePen(PS_SOLID, 1, RGB(200,0,0));
		pOldPen = pDC->SelectObject(&pen);	
		sign = 1;
		IonFraction = PosIonPart;
	}
	else {
		positive = FALSE;
		pen.CreatePen(PS_SOLID, 1, RGB(0,200,0));
		pOldPen = pDC->SelectObject(&pen);	
		sign = -1;
		IonFraction = 1.0 - NeutrPart - PosIonPart;
	}
	
	for (int k = 1; k <= MaxSource; k++) { // NofBeamlets or NofCalculated
			b = SourceArr.GetAt(k); 
			y0 = b.PosY;
			z0 = b.PosZ;
			// beamlet position at RID entry
			x = X0;// RIDXmin
			y = y0 + x * tan(b.AlfY); 
			z = z0 + x * tan(b.AlfZ); 
	
			if (fabs(y - plate->Orig.Y) > RIDInW) continue;// out of channel
			if ((y - plate->Orig.Y) * plate->OrtZ.Y < 0) continue;// non-face plate side
					
			x1 = pMainView->OrigX + (int)(x * pMainView->ScaleX);
			y1 = pMainView->OrigY - (int)(y * pMainView->ScaleY);
			z1 = pMainView->OrigZ - (int)(z * pMainView->ScaleZ);
							
			BOOL stopped = FALSE;
			Y0 = fabs(y - plate->Orig.Y); 
			Z0 = z;
			Path0 = 0;
						
			alfaEff = sqrt(b.AlfY * b.AlfY  + b.AlfZ * b.AlfZ  + 1.0);
			vx = Part_V / alfaEff;
			vy = Part_V * tan(b.AlfY) / alfaEff;
			vz = Part_V * tan(b.AlfZ) / alfaEff;
			
			while (!stopped) { // tracing axis particle
				dx = vx * dt;
				dz = vz * dt;
				x += dx; z += dz; 
				vy += sign * RID_A * dt; 
				dy = vy * dt;
				y += dy;
				Path0 += sqrt(dx*dx + dy*dy + dz*dz);
				x2 = pMainView->OrigX + (int)(x * pMainView->ScaleX);
				y2 = pMainView->OrigY - (int)(y * pMainView->ScaleY);
				z2 = pMainView->OrigZ - (int)(z * pMainView->ScaleZ);
				pDC->MoveTo(x1, y1); pDC->LineTo(x2, y2); 
				pDC->MoveTo(x1, z1); pDC->LineTo(x2, z2);

				P0 = C3Point(x,y,z);
				Ploc0 = plate->GetLocal(P0); // axis point

				if (Ploc0.Z < 0 || Ploc0.Z > RIDchannelWidth)  stopped = TRUE;
				x1 = x2; y1 = y2; z1 = z2;
			}
			//GdiFlush();
			//cs.Unlock();

			for (int i = 0; i <= L->Nx; i++) {
			Ploc.X = i * L->StepX;
			Ploc.Z = 0;
			for (int j = 0; j <= L->Ny; j++) {
				Ploc.Y = j * L->StepY;
				Pgl = plate->GetGlobalPoint(Ploc);
				distX = Pgl.X - X0; // dist to entry point
				distZ = fabs(Pgl.Z - Z0);
				y = distX * distX /(P0.X-X0)/(P0.X-X0) * Y0;

				Ay = atan((y-Y0)/X0) + b.AlfY;// horizontal angle
				Az = atan((Pgl.Z - z0)/Pgl.X);
				totdist = X0 + Path0 * distX  /(P0.X - X0);// very approx! 

				Ploc1.X = 0;	Ploc1.Y = 0;	Ploc1.Z = y; //point image
				if (Ploc1.Z > RIDInW) continue; // out of channel
				Pgl = plate->GetGlobalPoint(Ploc1); 
				Pgl.Z = z0 + X0 * tan(Az); 
				Ps = C3Point(0, y0, z0);// source point
				if (!F_GotThrough(Ps, Pgl)) continue; // intercepted before RID
			
				//SumDens = 0;
				V.X = vx; V.Z = vx * Az;
				if (distX > 1.e-6)	V.Y = sign * vx * 2 * y * RID_A / fabs(RID_A) / distX;
				else V.Y = 0;
				Cos = -ScalProd(V, plate->OrtZ) / ModVect(V);
				if (Cos < 1.e-6) continue; // no load
			
				Dy = GAUSS(fabs(Ay - b.AlfY), b.DivY);
				Dz = GAUSS(fabs(Az - b.AlfZ), b.DivZ);
				DyH = GAUSS(fabs(Ay - b.AlfY), divH);
				DzH = GAUSS(fabs(Az - b.AlfZ), divH);
				dens = (1-H) * Dy * Dz + H * DyH * DzH; 
				//SumDens += BeamletPower * dens * Cos * b.Fraction / (dist*dist * PI);
				L->Val[i][j] += IonFraction * BeamletPower * dens * Cos * b.Fraction / (totdist*totdist * PI);
			} // j
			} // i
			

			//ShowProfiles = TRUE;
			//plate->ShowLoadState();			

	}// k = MaxSource
	pDC->SelectObject(pOldPen);
	pMainView->ReleaseDC(pDC);
	
	return;// 1;
}

void CBTRDoc:: F_CalcRID()  //exact form
{
	CPlate * plate = pMarkedPlate;//(CPlate *) param;
	if (plate == NULL) return;// -1;
	CLoad * L = plate->Load;
	C3Point Ploc, Ploc0, Ploc1, Ps, Pgl, P0, V;
	double Ay, Az, Dy, Dz, DyH, DzH, dens, SumDens;
	double TotSum = 0;
	
	BEAMLET_ENTRY b;
	double divH = BeamHaloDiverg; //SourceArr[0].DivY; //*pDoc->BeamHaloDiverg;
	double H = BeamHaloPart; //SourceArr[0].Fraction; //*pDoc->BeamHaloPart;			
	double BeamletPower = IonBeamPower * 1000000 /NofBeamletsTotal;//(SourceArr[0].PosY) * (SourceArr[0].PosZ); 
	
	int MaxSource = SourceArr.GetUpperBound();// Element 0 is for halo!
	if (MaxSource < 1) return;// 0; // Element 0 is for halo!
	
	BOOL positive;
	double IonFraction;
	int sign;

	CDC* pDC = pMainView->GetDC();
	//HDC DC = pMainView->GetDC()->GetSafeHdc();
	CPen * pOldPen;
	CPen pen;

	if (RID_A * plate->OrtZ.Y < 0) {
		positive = TRUE;
		pen.CreatePen(PS_SOLID, 1, RGB(200,0,0));
		pOldPen = pDC->SelectObject(&pen);	
		sign = 1;
		IonFraction = PosIonPart;
	}
	else {
		positive = FALSE;
		pen.CreatePen(PS_SOLID, 1, RGB(0,200,0));
		pOldPen = pDC->SelectObject(&pen);	
		sign = -1;
		IonFraction = 1.0 - NeutrPart - PosIonPart;
	}

	int x1, y1, z1, x2, y2, z2;
	double Ys, Zs, X0 = RIDXmin+0.01, Y0, Z0, y0, x, y, z, dx, dy, dz;
	double dt = 1.0e-9, alfaEff, V0, VV0, Vx0, Vy0, Vz0, Vx, Vy, Vz, Vtan, Vabs, t0, t;
	double Dist0, Dist, TotDist, Len, TotLen, Cos;
	double A, B, C, D;
	
	for (int k = 1; k <= MaxSource; k++) { // NofBeamlets or NofCalculated
			b = SourceArr.GetAt(k); 
			Ys = b.PosY;
			Zs = b.PosZ;
			Ps = C3Point(0, Ys, Zs);
			// global position at RID entry - X0, Y0, Z0
			Y0 = Ys + X0 * tan(b.AlfY);
			Z0 = Zs + X0 * tan(b.AlfZ);
			x = X0;	y = Y0; z = Z0; 
			
	
			if (fabs(y - plate->Orig.Y) > RIDInW) continue;// out of channel
			if ((y - plate->Orig.Y) * plate->OrtZ.Y < 0) continue;// non-face plate side
					
			x1 = pMainView->OrigX + (int)(x * pMainView->ScaleX);
			y1 = pMainView->OrigY - (int)(y * pMainView->ScaleY);
			z1 = pMainView->OrigZ - (int)(z * pMainView->ScaleZ);
							
			BOOL stopped = FALSE;
			y0 = fabs(y - plate->Orig.Y); 
									
			V0 = Part_V;
			VV0 = V0 * V0;
			/*alfaEff = sqrt(b.AlfY * b.AlfY  + b.AlfZ * b.AlfZ  + 1.0);
			Vx0 = V0 / alfaEff;
			Vy0 = V0 * tan(b.AlfY) / alfaEff;
			Vz0 = V0 * tan(b.AlfZ) / alfaEff;*/
			Vx0 = V0 * cos(b.AlfY)* cos(b.AlfZ);
			Vy0 = V0 * sin(b.AlfY);
			Vz0 = V0 * cos(b.AlfY)* sin(b.AlfZ);
	
			Vx = Vx0; Vy = Vy0; Vz = Vz0;
			t0 = 0;
			Dist = 0;
			Len = 0;
			
			while (!stopped) { // tracing axis particle - not for load calculation!
				dx = Vx * dt;
				dz = Vz * dt;
				x += dx; z += dz; 
				Vy += sign * RID_A * dt; 
				dy = Vy * dt;
				y += dy;
				Len += sqrt(dx*dx + dy*dy + dz*dz);
				t0 += dt;
				Dist += sqrt(dx*dx + dz*dz);
				x2 = pMainView->OrigX + (int)(x * pMainView->ScaleX);
				y2 = pMainView->OrigY - (int)(y * pMainView->ScaleY);
				z2 = pMainView->OrigZ - (int)(z * pMainView->ScaleZ);
				pDC->MoveTo(x1, y1); pDC->LineTo(x2, y2); 
				pDC->MoveTo(x1, z1); pDC->LineTo(x2, z2);

				P0 = C3Point(x,y,z);
				Ploc0 = plate->GetLocal(P0); // axis point

				if (Ploc0.Z < 0 || Ploc0.Z > RIDchannelWidth)  stopped = TRUE;
				x1 = x2; y1 = y2; z1 = z2;
			}
			t0 = Dist / sqrt(Vx0*Vx0 + Vz0*Vz0);
			
			for (int i = 0; i <= L->Nx; i++) {
			Ploc.X = i * L->StepX;
			Ploc.Z = 0;
			for (int j = 0; j <= L->Ny; j++) {
				Ploc.Y = j * L->StepY;
				Pgl = plate->GetGlobalPoint(Ploc);
				//distX = Pgl.X - X0; // dist to RID entry point
				//distZ = Pgl.Z - Zs;
				//y = distX * distX /(P0.X-X0)/(P0.X-X0) * Y0;
				//Ay = atan((y-Y0)/X0) + b.AlfY;// horizontal angle
				TotDist = sqrt(Pgl.X * Pgl.X + (Pgl.Z - Zs)*(Pgl.Z - Zs));// GetDistBetween(Ps, Pgl); // from beam source to calc.point
				Az = atan((Pgl.Z - Zs)/Pgl.X);
				Dist0 = TotDist * X0 / Pgl.X; // from source to RID
				Dist = TotDist - Dist0; // in RID
				if (Dist < 1.e-6) continue;
				//totdist = X0 + Path0 * distX  /(P0.X - X0);// very approx! 

				A = 1;
				B = - 2 * VV0 * Dist0 * (1 + Dist0/Dist) / (Dist * fabs(RID_A));// * sign);
				C = Dist0 * Dist0;
				D = B * B - 4 * A * C;
				if (D < 0) continue;

				y = (-B - sqrt(D)) * 0.5;
				if (y <= 1.e-6) {
					y = (-B + sqrt(D)) * 0.5;
				}
				if (y > RIDInW) continue; // out of channel
				
				Ploc1.X = 0;	 Ploc1.Y = 0;	Ploc1.Z = y; //point image
				//if (Ploc1.Z > RIDInW) continue; // out of channel
				Pgl = plate->GetGlobalPoint(Ploc1); 
				Pgl.X = X0;
				Pgl.Z = Zs + X0 * tan(Az);
				//Pgl.Y = plate->Orig.Y + y * plate->OrtZ.Y;//y0 = fabs(y - plate->Orig.Y); 
				
				
				//Ps = C3Point(0, Ys, Zs);// source point
				if (!F_GotThrough(Ps, Pgl)) continue; // intercepted before RID
				Ay = atan((Pgl.Y - Ys)/Pgl.X);
			
				//SumDens = 0;
				Vtan = V0 * cos(Ay);
				t = Dist / Vtan;
				Vy0 = V0 * sin(Ay);
				V.Y = Vy0 + sign * RID_A * t;
				V.X = Vtan * cos(Az); 
				V.Z = Vtan * sin(Az);
				//if (Dist > 1.e-6)	V.Y = sign * vx * 2 * y * RID_A / fabs(RID_A) / distX;
				//else V.Y = 0;
				Vabs = ModVect(V);
				Cos = -ScalProd(V, plate->OrtZ) / Vabs;
				if (Cos < 1.e-6) continue; // no load

				//Len = t * sqrt(VV0 - 2 * sign * RID_A * y);
				/*Len = 0.5 / fabs(RID_A) * 
					( fabs(V.Y) * Vabs - fabs(Vy0) * V0 + 
					Vtan*Vtan * log((fabs(V.Y) + Vabs)/(fabs(Vy0) + V0)) ); */
				//Vy0 = 0;
				Len = 0.6 / fabs(RID_A) * 
					(fabs(V.Y) * Vabs - Vy0 * V0 + 
					Vtan*Vtan * log((fabs(V.Y) + Vabs)/fabs(Vy0 + V0)) ); 

				TotLen = Dist0/cos(Ay) + Len;// * t / t0;
				
				Dy = GAUSS(fabs(Ay - b.AlfY), b.DivY);
				Dz = GAUSS(fabs(Az - b.AlfZ), b.DivZ);
				DyH = GAUSS(fabs(Ay - b.AlfY), divH);
				DzH = GAUSS(fabs(Az - b.AlfZ), divH);
				dens = (1-H) * Dy * Dz + H * DyH * DzH; 
				SumDens = IonFraction * BeamletPower * dens * Cos * b.Fraction / (TotLen*TotLen * PI);
				L->Val[i][j] += SumDens; //IonFraction * BeamletPower * dens * Cos * b.Fraction / (TotLen*TotLen * PI);
				TotSum += SumDens;
		
			} // j
			} // i
			//ShowProfiles = TRUE;
			//plate->ShowLoadState();
	}// k = MaxSource
	
	pDC->SelectObject(pOldPen);
	pMainView->ReleaseDC(pDC);
	
	return;// 1;
}
void CBTRDoc:: F_CalcDirect() //UINT _ThreadCalcLoad(LPVOID param)
{
//	CBTRDoc * pDoc = (CBTRDoc*) param;// pointer type cast
//	if (pDoc == NULL || !pDoc->IsKindOf(RUNTIME_CLASS(CBTRDoc))) return -1;
	CPlate * plate = pMarkedPlate;//(CPlate *) param;// pDoc->pMarkedPlate;
	if (plate == NULL) return;// -1;

	CLoad * L = plate->Load;
	C3Point Ploc, Pgl, P0, V;
	double  Ay, Az, Dy, Dz, DyH, DzH, dens, SumDens;
	double dist, Cos, CosX, CosY, VortX, VortY, VortZ;
	// double TotSum = 0;
	
	BEAMLET_ENTRY b;
	double divH = BeamHaloDiverg; //SourceArr[0].DivY; //*pDoc->BeamHaloDiverg;
	double H = BeamHaloPart; //SourceArr[0].Fraction; //*pDoc->BeamHaloPart;			
	double BeamletPower = IonBeamPower *1000000/NofBeamletsTotal; //* NeutrPart;//(SourceArr[0].PosY) * (SourceArr[0].PosZ); 
	//pDoc->IonBeamPower *1000000/ pDoc->NofBeamletsTotal * NeutrPart; //W per beamlet 
	if (plate->Orig.X > NeutrOutX) BeamletPower *= NeutrPart;
	
	//CCriticalSection cs;
	int x1, y1, z1;
	
	//int i = SourceArr[0].i; // row number (pDoc->IofCalculated);
	//if (i < 0) return 0;

	int MaxSource = SourceArr.GetUpperBound();
	if (MaxSource < 1) return;// 0; // Element 0 is for halo!

/*	for (i = 0; i <= L->Nx; i++) {
	Ploc.X = i * L->StepX;
	Ploc.Z = 0;
	for (int j = 0; j <= L->Ny; j++) {
		Ploc.Y = j * L->StepY;
		Pgl = plate->GetGlobalPoint(Ploc); 
		
		SumDens = 0;*/
		
		for (int k = 1; k <= MaxSource; k++) { // NofBeamlets or NofCalculated
			b = SourceArr.GetAt(k); //pDoc->BeamEntry_Array.GetAt(k);
			P0 = C3Point(0, b.PosY, b.PosZ); // ion source position
			
			for (int i = 0; i <= L->Nx; i++) {
				Ploc.X = i * L->StepX;
				Ploc.Z = 0;
			for (int j = 0; j <= L->Ny; j++) {
				Ploc.Y = j * L->StepY;
				Pgl = plate->GetGlobalPoint(Ploc); 
			
			if (!F_GotThrough(P0, Pgl)) continue; // 
			
			V = VectSum(Pgl, P0, 1, -1);
			dist  = ModVect(V);
			Ay = atan(V.Y/V.X);
			Az = atan(V.Z/V.X);
			
			//Normal = - plate->OrtZ;
			Cos = -ScalProd(V, plate->OrtZ) / dist;
			if (Cos < 1.e-6) continue; // no load
						
			Dy = GAUSS(fabs(Ay - b.AlfY), b.DivY);
			Dz = GAUSS(fabs(Az - b.AlfZ), b.DivZ);
			DyH = GAUSS(fabs(Ay - b.AlfY), divH);
			DzH = GAUSS(fabs(Az - b.AlfZ), divH);
			dens = (1-H) * Dy * Dz + H * DyH * DzH; 
			//SumDens += BeamletPower * dens * Cos * b.Fraction / (dist*dist * PI);
			L->Val[i][j] += BeamletPower * dens * Cos * b.Fraction / (dist*dist * PI);
			} // j
			} // i
			//OnPlotMaxprofiles();
			//ShowProfiles = TRUE;
			//pSetView->InvalidateRect(NULL, TRUE);
			//plate->ShowLoadState(); // works well for many beamlets
		} // k

		//L->Val[i][j] = SumDens;
		
		//TotSum += SumDens;

	//} // i
	//ShowProfiles = TRUE;
	//plate->ShowLoadState(); // works well for many beamlets
	//} // i
	//dc.Detach();

	/*cs.Lock();
	SourceArr[0].j = i;	//(pDoc->ThreadNumber)++;
	cs.Unlock();*/
	
	return;// 1;
}
/*double CBTRDoc:: GAUSS(double arg, double delta) // inline
{	
	return exp(-arg*arg / (delta*delta)) / delta;
}*/

BOOL F_GotThrough(C3Point P1, C3Point P2)
{
	int PassedNumber = 0;
	int Channel = 0;
	RECT_DIA dia;
	double xdia, y, z, ymin, ymax, zmin, zmax;
	C3Point V = VectSum(P2, P1, 1, -1);
	int NdiaMax = Dia_Array.GetUpperBound();
			for (int ndia = 0; ndia <= NdiaMax; ndia++) {
				dia = Dia_Array.GetAt(ndia);
				
				if (dia.Number - PassedNumber > 1) // stopped at prev layer!
					return 0;
				if (dia.Number > 1 && dia.Number < 5 
					&& Channel != 0 && dia.Channel != Channel) // wrong channel
					continue;

				xdia  = dia.Corn[0].X;
				if ((xdia - P1.X) * (xdia - P2.X) > -1.e-12 ) { //both points at one side
					PassedNumber = dia.Number; 
					Channel = 0;
					continue; // go next dia
				}
				ymin = dia.Corn[0].Y; ymax = dia.Corn[2].Y;
				zmin = dia.Corn[0].Z; zmax = dia.Corn[2].Z;
				y = P1.Y + V.Y * xdia / V.X;
				z = P1.Z + V.Z * xdia / V.X;
				if ((y-ymin) * (y - ymax) > -1.e-12) continue; // crossed outside
				if ((z-zmin) * (z - zmax) > -1.e-12) continue; // crossed outside

				PassedNumber = dia.Number;
				Channel = dia.Channel; 
				// success
				
			} // ndia

			if (PassedNumber >= 15) return 1; //passed all
			else return 0; // stopped 
}

bool CBTRDoc:: F_CrossedSolid(C3Point P1, C3Point P2)
{
	//PtrList & PlatesList = PlatesList;
	POSITION pos = PlatesList.GetHeadPosition();
	CPlate * plate;
	C3Point Pend, Ploc;
	C3Point Last = P2;
	double dist;//, dist0 = GetDistBetween(P1, P2);
	
	while (pos != NULL) {
			plate = PlatesList.GetNext(pos); 
			if (plate->Solid == FALSE) continue;

			if (plate->IsCrossed(P1, Last)) { // crossed solid
				Ploc = plate->FindLocalCross(P1, Last);
				Pend = plate->GetGlobalPoint(Ploc);
				dist = GetDistBetween(P2, Pend);
				if (dist < 1.e-3) return 0;
								
				if (Ploc.X < plate->Xmax && Ploc.X > 0 
					&& Ploc.Y < plate->Ymax && Ploc.Y > 0) { // within plate
						return TRUE;
					
					/*dist = GetDistBetween(P1, Pend);
					 if (dist < dist0) { // check if plate is closer than previous
						//dist0 = dist;
						//Last = Pend;
						return 1; // YES
					}*/
				} // within plate
			} // crossed solid
			
		} // while pos
	return 0; // NO
}
	
void CBTRDoc:: F_CalculateLoad(CPlate * plate)
{
	if (OptCalOpen == FALSE && plate->Orig.X > CalOutX) return; 
	CWinThread * pThread[1000];// max 
	//HANDLE hThread[1000];

	int NofThreads;
	//int ThreadNumber;

	CWaitCursor wait;
	CCriticalSection cs;
	STOP = FALSE;
	plate->Loaded = TRUE;
	CLoad * L = plate->Load;
	pSetView->Load = L;
	C3Point Ploc, Pgl, P0, V, Vxy, Vxz, Normal;
	double dist, Cos, Ay, Az, Dy, Dz, dens, SumDens;
	int i;
	//double BeamPower = IonBeamPower; // MW
	//double BeamletPower = BeamPower *1000000. / NofBeamletsTotal ; //W per beamlet 
	SourceArr[0].PosZ = 1;
	if (plate->Orig.X > NeutrXmax) SourceArr[0].PosZ = NeutrPart;
	
	//ThreadNumber = 0;// thread counter, which is increased on _Threadfunc call
	IofCalculated = 0;// rows counter
	
	NofThreads = 1;//L->Nx + 1;

	BOOL RIDwall = FALSE;
	if (plate->Comment.Find("RID", 0) >= 0 && plate->Comment.Find("wall", 0) >= 0)
		RIDwall = TRUE;
		
	if (!OptNeutrStop && RIDwall) { // RID wall
		RIDXmin = RIDInX;
		RIDchannelWidth = RIDInW;
		C3Point p = plate->MassCentre;
		//p.Y += 0.1 * plate->OrtZ.Y;
		C3Point E = RIDField->GetE(p.X, p.Y, p.Z);
		RID_A = Qe * E.Y / TracePartMass;
		double EkeV = IonBeamEnergy * 1000; //keV
	    Part_V = sqrt(2.* EkeV * 1000 * Qe / TracePartMass); // {m/c}
		
		F_CalcRID();
		
	/*for (i = 0; i < NofThreads; i++) {
		pThread[i] = ::AfxBeginThread(_ThreadCalcRID, plate);
		
	} // i,j */
	//Sleep(1000);
		STOP = TRUE;
		return;
	}

	else {

		F_CalcDirect();

	/*for (i = 0; i < NofThreads; i++) {
		cs.Lock();
		SourceArr[0].i = i;
		cs.Unlock();
		//Sleep(100);
		pThread[i] = ::AfxBeginThread(_ThreadCalcLoad, plate);
		//hThread[i] = pThread[i]->m_hThread;
		//ThreadNumber++;
		IofCalculated = SourceArr[0].j;
	} // i,j*/
	

 // Wait for all threads to terminate
  	/* WaitForMultipleObjects(NofThreads, hThread, TRUE, INFINITE);
    // Close thread (and mutex) handles
	for( i=0; i < NofThreads; i++ ){
		CloseHandle(hThread[i]);
		//delete pThread[i];
	} */
	/*for (i = 0; i < NofThreads; i++)
	{
		if (pThread[i] != NULL) {
		//	while (1)
			DWORD res = WaitForSingleObject(pThread[i]->m_hThread, INFINITE);
			//delete pThread[i];// error
		}
	}*/
		STOP = TRUE;
		return;
	} // not RID

	
	//plate->ShowLoadState();
}

void CBTRDoc::OnStart() // BTR-slow
{
	//if (!STOP) OnStop();
	if (!STOP) {
		AfxMessageBox("Stop the beam before restart! \n (push stop-button on the Toolbar)");
		return;
	}
	int res, i;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}
//	else AfxMessageBox("Data is not modified");

	CString s;

	Progress = 0;

	OptParallel = FALSE;
/*	for (i = 0; i < ThreadNumber; i++)	m_Tracer[i].SetContinue(FALSE);
	SuspendAll(FALSE);
	for (i = 0; i < ThreadNumber; i++) {
		WaitForSingleObject(m_pTraceThread[i]->m_hThread, INFINITE);
	}*/
	InitTracers(); // clear arrays
	ClearAllPlates();
	//pMarkedPlate = NULL;
	OptCombiPlot = -1;
	SetTitle("Started Non-parallel");
		
	pMainView->STOP = FALSE;
	//OnShow();
	
	if (LoadSelected > 0) {
		res = AfxMessageBox("Keep Surfaces selection as is?",3);
		
		//if (res == IDYES) ClearAllPlates();
		if (res == IDNO) OnOptionsSurfacesEnabledisableall(); // SelectAllPlates()
		else if (res == IDCANCEL) return;
	 
	}
	SuspendedSpan = 0;
	int finished = EmitBeam();

 	//if (finished == 1) s.Format(" FINISHED    "); //Progress = 100;
	if (finished == 0) { s.Format(" Beam STOPPED  "); AfxMessageBox(s, MB_ICONEXCLAMATION | MB_OK); }//Progress = 50;
	STOP = TRUE;
	Progress = 100;
	SetLoadArray(NULL, TRUE);
	if (finished == 0) DetachLoadFiles();
	
	ShowStatus();
	Progress = 0;
	if (Sorted_Load_Ind.GetSize() > 1) // sorted already
		SortLoadArrayAlongX();//unsort
	//pMainView->InvalidateRect(NULL, FALSE);
	
	OnShow();
}

void CBTRDoc::OnViewFullarea() 
{
	AreaLong = AreaLongMax;
	OnShow();
}

void CBTRDoc::OnViewNeutraliser() 
{
	AreaLong = NeutrOutX + 0.5;
	OnShow();
}

void CBTRDoc::OnViewRid() 
{
	AreaLong = RIDOutX + 0.5;
	OnShow();
	
}
void CBTRDoc::OnTasksOther() 
{
	Progress = 0;
	CurrentDirName = TopDirName;
	::SetCurrentDirectory(CurrentDirName);
	SetTitle(CurrentDirName);
	
	TaskRID = FALSE;
	TaskReionization = FALSE;
	
	if (LoadSelected > 0) SelectAllPlates(); // empty the plates list
	InitTaskTransport();
	//SetPlates();
	TaskName = "New task"; //Beam Transport";
	TaskComment = "To be defined"; 
	OnShow();
}

void CBTRDoc::OnUpdateTasksOther(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);
	pCmdUI->SetCheck(!TaskRID && !TaskReionization && !TaskRID);
	pCmdUI->SetText("Transport");
}

void CBTRDoc::OnViewFitonoff() 
{
	pMainView->OnViewFitonoff();
	
}

void CBTRDoc::OnUpdateViewFitonoff(CCmdUI* pCmdUI) 
{
	pMainView->OnUpdateViewFitonoff(pCmdUI);
}

void CBTRDoc::OnViewBeam() 
{
	pMainView->OnViewBeam();
}

void CBTRDoc::OnUpdateViewBeam(CCmdUI* pCmdUI) 
{
	pMainView->OnUpdateViewBeam(pCmdUI);
	
}

void CBTRDoc::OnViewFields() 
{
	pMainView->OnViewFields(); 
	
}

void CBTRDoc::OnUpdateViewFields(CCmdUI* pCmdUI) 
{
	pMainView->OnUpdateViewFields(pCmdUI);
	
}

void CBTRDoc::OnUpdateViewFullarea(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!Progress); 
	pCmdUI->SetCheck(AreaLong == AreaLongMax);
	
}

void CBTRDoc::OnUpdateViewNeutraliser(CCmdUI* pCmdUI) 
{
	//pCmdUI->Enable(!Progress);
	pCmdUI->Enable(!OptFree);
	//pCmdUI->SetCheck(AreaLong == NeutrOutX + 0.5);
}

void CBTRDoc::OnViewNumbering() 
{
	pMainView->OnViewNumbering();
	
}

void CBTRDoc::OnUpdateViewNumbering(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!OptFree);
	pMainView->OnUpdateViewNumbering(pCmdUI); 
}

void CBTRDoc::OnUpdateViewRid(CCmdUI* pCmdUI) 
{
	//pCmdUI->Enable(!Progress); 
	pCmdUI->Enable(!OptFree);
	//pCmdUI->SetCheck(AreaLong == RIDOutX + 0.5);
}

void CBTRDoc::OnEditComments() 
{
	CCommentsDlg dlg;
	dlg.m_Comment = TaskComment;
	if (dlg.DoModal() == IDOK) {
		TaskComment = dlg.m_Comment;
	}
	OnShow(); //OnDataActive();
}

void CBTRDoc::OnEditTitle() 
{
	CTaskDlg dlg;
	dlg.m_Task = TaskName;
	if (dlg.DoModal() == IDOK) {
		TaskName = ' ' + dlg.m_Task;
	}
	//else TaskName = "No tytle";
	OnShow();//OnDataActive();
}

void CBTRDoc::OnFileNew() 
{
	InitAddPlates();
//	OnTasksOther();

}

void CBTRDoc::OnFileOpen() 
{
	//OnDataGet(); // finally calls BTRDoc::ReadData()

	char name[1024];
	char buf[1024];
//	CFileDialog dlg(TRUE, "dat;txt", "Configuration file");
	CFileDialog dlg(TRUE, "dat;txt | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.dat);(*.txt) | *.dat; *.DAT; *.txt; *.TXT | All Files (*.*) | *.*||", NULL);
	if (dlg.DoModal() == IDOK) {
		strcpy(name, dlg.GetPathName());

		//::GetCurrentDirectory(1024, CurrentDirName);
	
	/*CPreviewDlg dlg;
		dlg.m_Filename = name;
		if (dlg.DoModal() == IDCANCEL) return 0;*/

		FILE * fin;
		fin = fopen(name, "r");
		m_Text.Empty();// = "";
		while (!feof(fin)) {
			fgets(buf, 1024, fin);
			if (!feof(fin))	m_Text += buf;
		}
		fclose(fin);

		SetTitle(name);
		pDataView->m_rich.SetFont(&pDataView->font, TRUE);
		pDataView->m_rich.SetBackgroundColor(FALSE, RGB(250,230,180));
		pDataView->m_rich.SetWindowText(m_Text);
		pDataView->m_rich.SetModify(FALSE);
		
	}
}

void CBTRDoc::OnFileSave() 
{
	//OnDataSave();
	CString S;
	CString text;
	pDataView->m_rich.GetWindowText(S);
	int pos = S.Find("****\n");
	if (pos >= 0) text = S.Mid(pos + 5);
	else text = S;

	CFileDialog dlg(FALSE, "dat;txt | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.dat); (*.txt) | *.dat; *.DAT; *.txt; *.TXT | All Files (*.*) | *.*||", NULL);
		if (dlg.DoModal() == IDOK) {
			FILE * fout;
			char name[1024];
			strcpy(name, dlg.GetPathName());
			fout = fopen(name, "w");
			fprintf(fout, text);
			fclose(fout);
		}
		OnShow(); //OnDataActive();
}


void CBTRDoc::OnFileSaveAs() 
{
	OnFileSave();
}



void CBTRDoc::OnViewParticles() 
{
	OptDrawPart = !OptDrawPart;
	//if (!OptDrawPart) 
	pMainView->InvalidateRect(NULL, TRUE); 
	//OnShow();
}

void CBTRDoc::OnUpdateViewParticles(CCmdUI* pCmdUI) 
{
//	if (!OptDrawPart) pCmdUI->(SetText("Show Particles on the screen");
//	else pCmdUI->SetText("Hide Particles");
	pCmdUI->SetCheck(OptDrawPart);
}

void CBTRDoc::OnEditGas() 
{
}

void CBTRDoc::OnGasProf_X()
{
	char s[1024];
	CGasDlg dlg;
	dlg.m_Head1 = "X,m"; 
	dlg.m_Head2 = "Density, 1/m3"; 
	dlg.m_Filename = GasFileName;
	dlg.m_X.Empty();
	dlg.m_Y.Empty();
	dlg.Arr = &(GField->GasArray);
	dlg.m_Caption = "Gas Profile along X";

	double x, p, xmax = 0, pmax = 0, xmin = 1000;
	int i;
	for (i = 0; i <= GField->GasArray.GetUpperBound(); i++) {
		x = GField->GasArray[i].X;
		p = GField->GasArray[i].Y;
		sprintf(s,"%f\r\n",x); dlg.m_X += s;
		sprintf(s,"%le\r\n",p); dlg.m_Y += s;
	}

	if(dlg.DoModal()==IDCANCEL) return;

	for (i = 0; i <= dlg.Arr->GetUpperBound(); i++) {
		x = dlg.Arr->GetAt(i).X;
		p = dlg.Arr->GetAt(i).Y;
		xmax = Max(xmax, x);
		pmax = Max(pmax, p);
		xmin = Min(xmin, x);
	}

 	GField->Pmax = pmax;
	GField->Xmax = xmax;
	GField->Xmin = xmin;
	GField->Nx = dlg.Arr->GetSize();

	GasFileName = dlg.m_Filename;
	PressureLoaded = TRUE;
	PressureDim = 1;
	GasCoeff = 1;
	OptReionAccount = TRUE;//automatic when gas loaded
	//OptThickNeutralization = TRUE; // not automatic 
	SetReionPercent();
	SetNeutrCurrents();

	OnShow();
}

void CBTRDoc::OnGasProf_XZ()
{
	CFileDialog *fname_dia;
	CString infile;
	char s[1024];

//	CFileDialog dlg(TRUE, "dat; txt | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
//		"E-field data (*.txt);(*.dat)  | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
	
	fname_dia=new CFileDialog(TRUE, "dat; txt  | * ",	infile,	OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Gas density file (*.txt);(*.dat) | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||",
		NULL);

	if(fname_dia->DoModal()==IDCANCEL){
		delete[] fname_dia;
		return;
	}
	infile = fname_dia->GetPathName();
	delete[] fname_dia;

	CPreviewDlg dlg;
	dlg.m_Filename = infile;
	if (dlg.DoModal() == IDCANCEL) return;

	int n =0;
	FILE * fp = fopen(infile,"rt");
	if (fp==NULL){
		AfxMessageBox("problem opening data file", MB_ICONSTOP | MB_OK);
		return;
	}
	fclose(fp);

	char name[256];
	strcpy(name, infile);
		
	n = GFieldXZ->ReadData(name);//(fp);

	/*CString S;
	S.Format("read %d data lines\n from file %s", n, name);
	AfxMessageBox(S);*/

	if (n<0)  {
		sprintf(s,"Invalid format of Gas Matrix data", MB_ICONSTOP | MB_OK);
		AfxMessageBox(s,MB_ICONINFORMATION);
		//MF_7 = FALSE;
	}
	else {
		//sprintf(s,"MF data is Read (%d lines)", n);
		//MF_7 = TRUE;
		//OptStrayField = TRUE;
		PressureLoaded = TRUE;
		GasFileName = dlg.m_Filename;
		PressureDim = 2;
		GasCoeff = 1;
		OptReionAccount = TRUE;//automatic when gas loaded
		//OptThickNeutralization = TRUE;
		SetReionPercent();
		SetNeutrCurrents();

	}

	OnShow();
}

void CBTRDoc::OnEditFW2D()
{
	if (!OptBeamInPlasma) return;
	char s[1024];
	CGasDlg dlg;
	dlg.m_Head1 = "R,m"; 
	dlg.m_Head2 = "Z,m"; 
	dlg.m_Filename = FW2DFileName;
	dlg.m_X.Empty();
	dlg.m_Y.Empty();
	dlg.Arr = &FWdata;
	dlg.m_Caption = "First Wall 2D contour";

	double r, z, rmin = 1000, rmax = -1000, zmin = 1000, zmax = -1000;
	int i;
	for (i = 0; i <= FWdata.GetUpperBound(); i++) {
		r = FWdata[i].X;
		z = FWdata[i].Y;
		sprintf(s,"%f\r\n",r); dlg.m_X += s;
		sprintf(s,"%le\r\n",z); dlg.m_Y += s;
		
	}
		

	if(dlg.DoModal()==IDCANCEL) return;

	for (i = 0; i <= FWdata.GetUpperBound(); i++) {
		r = FWdata[i].X; // data cm->m 
		z = FWdata[i].Y; // data cm->m
		//FWdata[i].X = r;
		//FWdata[i].Y = z;
	
		rmax = Max(rmax, r);
		rmin = Min(rmin, r);
		zmax = Max(zmax, z);
		zmin = Min(zmin, z);
	}

	FWRmin = rmin;
	FWRmax = rmax;
	FWZmin = zmin;
	FWZmax = zmax;

	FW2DFileName = dlg.m_Filename;
	FWdataLoaded = TRUE;
	
	//SetPlates();
	//SetPlasmaGeom(); // called from SetPlatesNBI
	//SetDecayInPlasma();
	OnShow();
}


void CBTRDoc::OnEditMagfield() 
{
}

void CBTRDoc::OnEditMagfield_7columns() 
{
	CFileDialog *fname_dia;
	CString infile;
	char s[1024];

//	CFileDialog dlg(TRUE, "dat; txt | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
//		"E-field data (*.txt);(*.dat)  | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
	
	fname_dia=new CFileDialog(TRUE, "dat; txt  | * ",	infile,	OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"MF data file (*.txt);(*.dat) | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||",
		NULL);

	if(fname_dia->DoModal()==IDCANCEL){
		delete[] fname_dia;
		return;
	}
	infile = fname_dia->GetPathName();
	delete[] fname_dia;

	CPreviewDlg dlg;
	dlg.m_Filename = infile;
	if (dlg.DoModal() == IDCANCEL) return;

	int n =0;
	FILE * fp=fopen(infile,"rt");
	if (fp==NULL){
		AfxMessageBox("problem opening data file", MB_ICONSTOP | MB_OK);
		return;
	}
	fclose(fp);

	char name[256];
	strcpy(name, infile);
	
	//BField3D->Init(name);
	//return;

	n = BField3D->ReadData(name);//(fp);

	/*CString S;
	S.Format("read %d data lines\n from file %s", n, name);
	AfxMessageBox(S);*/

	if (n<0)  {
		sprintf(s,"Invalid format of Mag. Field data", MB_ICONSTOP | MB_OK);
		AfxMessageBox(s,MB_ICONINFORMATION);
		//MF_7 = FALSE;
	}
	else {
		//sprintf(s,"MF data is Read (%d lines)", n);
		//MF_7 = TRUE;
		//OptStrayField = TRUE;
		MagFieldDim = 3;
		FieldLoaded = TRUE;
		MagFieldFileName = dlg.m_Filename;
	}
	
	//MFcoeff = 1.;
//	pMainView->SHOW_FIELDS = TRUE;
//	pMainView->SHOW_BEAM = FALSE;
	OnShow();
}

void CBTRDoc::OnUpdateEditMagfield_7columns(CCmdUI* /* pCmdUI */) 
{
//	pCmdUI->SetCheck(MF_7);

}

void CBTRDoc::OnEditMagfield_4columns() 
{
	char s[1024];
	CMFDlg dlg;
	if (MagFieldDim == 1) dlg.m_Filename = MagFieldFileName; //"Manually Set MF Data";
	else dlg.m_Filename = "";
	dlg.m_COLUMNS = "  X,m \t  Bx,T \t  By,T \t  Bz,T";
	dlg.m_Bdata.Empty();
	dlg.XArr = &(BField->ArrX);//&MFXdata;
	dlg.BArr = &(BField->ArrB);//&MFdata;
	int i;
	double x, bx, by, bz;
	C3Point P;
	CString S;

	for (i = 0; i < BField->Nx; i++) {
		x = BField->ArrX[i];
		bx = BField->ArrB[i].X; by = BField->ArrB[i].Y; bz = BField->ArrB[i].Z;
		sprintf(s,"%g\t %g\t %g\t %g\r\n ", x,bx,by,bz); 
		dlg.m_Bdata += s;
	}

	if(dlg.DoModal() == IDCANCEL) return;

	double xmax = 0, bmax = 0, xmin = 1000;
	for (i = 0; i <= dlg.XArr->GetUpperBound(); i++) {
		x = dlg.XArr->GetAt(i);
		P = dlg.BArr->GetAt(i);
		xmax = Max(xmax, x);
		bmax = Max(bmax, P.X); bmax = Max(bmax, P.Y); bmax = Max(bmax, P.Z);
		xmin = Min(xmin, x);
	}

 	BField->Bmax = bmax;
	BField->Xmax = xmax;
	BField->Xmin = xmin;
	BField->Nx = dlg.XArr->GetSize();
	MagFieldFileName = dlg.m_Filename;
	//MF_7 = FALSE;
	MagFieldDim = 1;
	FieldLoaded = TRUE;
	if (MFcoeff == 0) MFcoeff = 1.;
	
	S.Format("%d", BField->Nx);	//AfxMessageBox(S);

	OnShow();
	
}

void CBTRDoc::OnUpdateEditMagfield_4columns(CCmdUI*) 
{
//	pCmdUI->SetCheck(!MF_7);
}

/*C3Point CBTRDoc:: GetManMF(double x)
 {
	 C3Point P(0,0,0);
	 double x0, x1;
	 C3Point P0, P1;
	 int Nmax = MFXdata.GetUpperBound();
	 double xmax = max(MFXdata[0], MFXdata[Nmax]);
	 double xmin = min(MFXdata[0], MFXdata[Nmax]);
	 if (x > xmax || x < xmin) return P;
	 for (int i = 0; i < Nmax; i++) {
		 if (((x - MFXdata[i]) * (x - MFXdata[i+1])) <= 0) {
			  x0 = MFXdata[i];  x1 = MFXdata[i+1];
			  P0 = MFdata[i];  P1 = MFdata[i+1];
			  P = P0 + (P1-P0) * (x-x0) / (x1-x0);
			  return P;
		 } //if
	 } // for
	 return P;
 }*/

C3Point CBTRDoc:: GetFW_Z(double x, double y, int nz) //  called by ShowTor
// if nz > 0 -> Z > 0
{
	// double Z = 1000;
	double dx = x - TorCentre.X;
	double dy = y - TorCentre.Y;
	double r = sqrt(dx * dx + dy * dy); // from torus centre
	double z;
	C3Point P(r,1000,1000);
 
	if (!FWdataLoaded) // default 
	{
		double dr = fabs(r - PlasmaMajorR);
		if (fabs(dr) > PlasmaMinorR) return P;
		z = sqrt(PlasmaMinorR * PlasmaMinorR - dr*dr);
		if (nz < 0) z = -z;
		P.Y = z + TorCentre.Z; P.Z = z + TorCentre.Z;
		return P;
	}

	int Nmax = FWdata.GetUpperBound();
	double  z0, z1, r0, r1;
	for (int i = 0; i < Nmax; i++) { //increase
		r0 = FWdata[i].X; r1 = FWdata[i+1].X;
		if ((r0-r)*(r1-r) > 0) continue;
		z0 = FWdata[i].Y; z1 = FWdata[i+1].Y;
		z = z0 + (r - r0) / (r1 - r0) * (z1 - z0);
		if (z * nz < 0) continue;
		P.Y = z + TorCentre.Z;
		break;
		//return (z + TorCentre.Z);
	}
	for (int i = Nmax; i > 0; i--) { //decrease
		r0 = FWdata[i].X; r1 = FWdata[i-1].X;
		if ((r0-r)*(r1-r) > 0) continue;
		z0 = FWdata[i].Y; z1 = FWdata[i-1].Y;
		z = z0 + (r - r0) / (r1 - r0) * (z1 - z0);
		if (z * nz < 0) continue;
		P.Z = z + TorCentre.Z;
		break;
		//return (z + TorCentre.Z);
	}

	return P; // 1000 if not found
}
C3Point CBTRDoc:: GetBeamFootLimits(double Xtarget, double & Ymin, double & Ymax, double & Zmin, double & Zmax)
{
	double y0, z0, x, y, z;
	double ymin = 1000, ymax = -1000, zmin = 1000, zmax = -1000; 
	if (!OptSINGAP || !SINGAPLoaded) { // Mamug
	for (int is = 0; is < (int)NofChannelsHor;  is++)  ///NofChannelsHor;
		for (int js = 0; js < (int)NofChannelsVert; js++)   ///NofChannelsVert;
			for (int i = 0; i < (int)NofBeamletsHor; i++) 
				for (int j = 0; j < (int)NofBeamletsVert; j++)
	
		{
			y0 = BeamletPosHor[is * (int)NofBeamletsHor + i]; 
			z0 = BeamletPosVert[js * (int)NofBeamletsVert + j]; 
			x = Xtarget;
			y = y0 + x * tan(BeamletAngleHor[is * (int)NofBeamletsHor + i]);
			z = z0 + x * tan(BeamletAngleVert[js * (int)NofBeamletsVert + j]);
			ymin = Min(ymin, y); ymax = Max(ymax, y);
			zmin = Min(zmin, z); zmax = Max(zmax, z);
		}
				
	}// Mamug
	
	else if (OptSINGAP){ // Singap
		BEAMLET_ENTRY be;
		int N = BeamEntry_Array.GetSize();
		for (int k = 0; k < N; k++) {
			be = BeamEntry_Array.GetAt(k);
			y0 = be.PosY;
			z0 = be.PosZ;
			x = Xtarget;
			y = y0 + x * tan(be.AlfY); 
			z = z0 + x * tan(be.AlfZ); 
			ymin = Min(ymin, y); ymax = Max(ymax, y);
			zmin = Min(zmin, z); zmax = Max(zmax, z);
		}
	} // singap
	Ymin = ymin; Ymax = ymax;
	Zmin = zmin; Zmax = zmax;
	C3Point P = C3Point(Xtarget, 0.5 * (Ymin + Ymax), 0.5 * (Zmin + Zmax));
	return P;
}

void CBTRDoc::OnPlotSingappos() 
{
	int N = BeamEntry_Array.GetSize();
	if (N <1) return; 

	int i;
	double x, y;
	CArray<double, double> PosY;
	CArray<double, double> PosZ;
	BEAMLET_ENTRY be;
	PLOTINFO SingapPlot;
	SingapPlot.Caption = "SINGAP beamlets Positions,  X = 0";
	SingapPlot.LabelX = "X, m";
	SingapPlot.LabelY = "Y, m";
	SingapPlot.LimitX = 0;//0.3;
	SingapPlot.LimitY = 0;//0.8;
	SingapPlot.CrossX = 0.1;
	SingapPlot.CrossY = 0.2;
	SingapPlot.Line = 0;
	SingapPlot.Interp = 1;
//	SingapPlot.N1 = BeamEntry_Array.GetSize(); //Singap_Array.GetSize();
//	SingapPlot.N2 = SingapPlot.N1;
	SingapPlot.PosNegX = TRUE;
	SingapPlot.PosNegY = TRUE;
//	SingapPlot.DataX = &PolarAngle;
//	SingapPlot.DataY = &PolarCurrent;
	for (i = 0; i < BeamEntry_Array.GetSize(); i++) {
		be = BeamEntry_Array.GetAt(i);
		if (be.Active == FALSE) continue;
		x = be.PosY;
		y = be.PosZ;
		PosY.Add(x);
		PosZ.Add(y);
	}
	SingapPlot.N1 = PosY.GetSize();

	int j =0;
	if (OptSINGAP)
		for (i = 0; i < NofBeamlets, j < NofCalculated; i++) {
			be = BeamEntry_Array.GetAt(i);
			if (be.Active == FALSE) continue;
			x = be.PosY;
			y = be.PosZ;
			PosY.Add(x);
			PosZ.Add(y);
			j++;
			
		} //i < NofBeamlets

	SingapPlot.N = PosY.GetSize();
	SingapPlot.N2 = SingapPlot.N1;
	

	SingapPlot.DataX = &PosY;
	SingapPlot.DataY = &PosZ;
	
	CPlotDlg dlg;
	dlg.Plot = &SingapPlot;
	dlg.InitPlot();
	dlg.DoModal();

	PosY.RemoveAll();
	PosZ.RemoveAll();
}

void CBTRDoc::OnUpdatePlotSingappos(CCmdUI* pCmdUI) 
{
	//pCmdUI->Enable(SINGAPLoaded);
	pCmdUI->SetCheck(OptSINGAP);
}

void CBTRDoc::OnPlotGasprofile() 
{
	CArray<double, double>  ArrX;
	CArray<double, double>  ArrY;
	double Xmax;
	if (PressureDim == 1) Xmax = GField->Xmax;
	else Xmax = GFieldXZ->Xmax;

	PLOTINFO GasPlot;
	GasPlot.Caption = "Gas Density Distribution along NBL";
	GasPlot.LabelX = "X, m";
	GasPlot.LabelY = "Gas Density [1/m3], NL [1/m2]";
	if (OptAddPressure) GasPlot.LabelY = "Basic Profile [1/m3], NL [1/m2], Additional Profile";
	GasPlot.LimitX = Xmax;//ReionXmax;
	GasPlot.LimitY = 0;//1.e20;
	GasPlot.CrossX = 1;
	GasPlot.CrossY = 1.e19;
	GasPlot.Line = 1;
	GasPlot.Interp = 1;
	//GasPlot.N = 100; //GField->GasArray.GetSize();
	//GasPlot.N1 = GasPlot.N +1;
	//GasPlot.N2 = GasPlot.N +1;
	GasPlot.PosNegY = FALSE;
	GasPlot.PosNegX = FALSE;
	double x, y, xmin = 0;
	double xmax = ReionXmax;
	double dx = NeutrStepL; 
	x = xmin;
	while (x <= xmax) {
		//x = GField->GasArray[i].X;
		y = GetPressure(C3Point(x, 0, 0)); //GField->GasArray[i].Y;
		ArrX.Add(x); ArrY.Add(y);
		x += dx;
	}
	GasPlot.N1 = ArrX.GetSize();

	x = xmin;
	double sumNL = 0;
	while (x <= xmax) {
		//x = GField->GasArray[i].X;
		sumNL += dx * GetPressure(C3Point(x, 0, 0));// NL
		y = sumNL; 
		ArrX.Add(x); ArrY.Add(y);
		x += dx;
	}
	
if (OptAddPressure) {
	GasPlot.N2 = ArrX.GetSize();

	x = xmin;
	while (x <= xmax) {
		//x = GField->GasArray[i].X;
		y = AddGField->GetPressure(x); //GField->GasArray[i].Y;
		ArrX.Add(x); ArrY.Add(y);
		x += dx;
	}
} // optaddpressure
	else GasPlot.N2 = ArrX.GetSize() +1;

	GasPlot.N = ArrX.GetSize();
	
	GasPlot.DataX = &ArrX;
	GasPlot.DataY = &ArrY;
	
	CPlotDlg dlg;
	dlg.Plot = &GasPlot;
	dlg.InitPlot();
	dlg.DoModal();

	ArrX.RemoveAll();
	ArrY.RemoveAll();
	
}

void CBTRDoc::OnUpdatePlotGasprofile(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(PressureLoaded);
	
}

void CBTRDoc::OnPlotMagneticfield() 
{
	CArray<double, double>  ArrX;
	CArray<double, double>  ArrY;
	double Xmax;

	PLOTINFO MFPlot;
	MFPlot.Caption = "Magnetic Field Distribution along NBL (Scaling = 1)";
	MFPlot.LabelX = "X, m";
	MFPlot.LabelY = "Bx, By, Bz (Tesla)";
	//MFPlot.LabelY = "Bz(z=-0.7), Bz(z=0), Bz(z=0.7) Tesla";
	if (MagFieldDim == 1) Xmax = BField->Xmax;
	else Xmax = BField3D->Xmax;
	MFPlot.LimitX = 0;//Xmax;//AreaLong;
	MFPlot.LimitY = 0; //5;
	MFPlot.CrossX = 0;
	MFPlot.CrossY = 1;
	MFPlot.Line = 1;
	MFPlot.Interp = 1;	
	MFPlot.PosNegY = TRUE;
	MFPlot.PosNegX = FALSE;
	
	int Nmax;
	if (MagFieldDim == 1) Nmax = BField->Nx; // 4-col
	else Nmax = BField3D->Nx; 

	MFPlot.N = 3 * Nmax;
	MFPlot.N1 = Nmax;
	MFPlot.N2 = 2 * Nmax; 

	double x, y, z;
	int i, j, k;
		
	for (i = 0; i < Nmax; i++) {
		if (MagFieldDim == 1) { // 4 col
			x = BField->ArrX[i];
			y = BField->ArrB[i].X;
		} // 4 col
		else {// 6-col
			x = BField3D->ArrX[i]; //i * BField3D->StepX;
			y = BField3D->GetB(x, 0, 0).X;//ValB[i][j][k].X;
			//y = BField3D->GetB(x, 0, -0.7).Z;
		}
		ArrX.Add(x); ArrY.Add(y);
	}
	for (i = 0; i < Nmax; i++) {
		if (MagFieldDim == 1) { // 4 col
			x = BField->ArrX[i];
			y = BField->ArrB[i].Y;
		} // 4 col
		else {// 6-col
			x =  BField3D->ArrX[i]; //i * BField3D->StepX;
			y = BField3D->GetB(x, 0, 0).Y;//BField3D->ValB[i][j][k].Y;
			//y = BField3D->GetB(x, 0, 0).Z;
		}
		ArrX.Add(x); ArrY.Add(y);
	}
	for (i = 0; i < Nmax; i++) {
		if (MagFieldDim == 1) { // 4 col
			x = BField->ArrX[i];
			y = BField->ArrB[i].Z;
		} // 4 col
		else {// 6-col
			x = BField3D->ArrX[i]; //i * BField3D->StepX;
			y = BField3D->GetB(x, 0, 0).Z; //BField3D->ValB[i][j][k].Z; 
			
		}
		ArrX.Add(x); ArrY.Add(y);
	}

	MFPlot.DataX = &ArrX;
	MFPlot.DataY = &ArrY;
	
	CPlotDlg dlg;
	dlg.Plot = &MFPlot;
	dlg.InitPlot();
	dlg.DoModal();

	ArrX.RemoveAll();
	ArrY.RemoveAll();
	
}

void CBTRDoc::OnUpdatePlotMagneticfield(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FieldLoaded);
		
}

void CBTRDoc::OnPlotBeamletcurr() 
{
	/*int res;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}*/
	PlotBeamletCurrent();
}

void CBTRDoc:: PlotBeamletCurrent()
{
	CWaitCursor wait;
	double angle, y;
	CArray<double, double> PosX;
	CArray<double, double> PosY;
	PLOTINFO DecilPlot;
	CString S;

	if ((int)BeamSplitType ==0) { 
		DecilPlot.Caption = "Beamlet Integral Current vs Polar Angle ";
//		S.Format(" (Polar = %d)", (int)PolarNumber);
		S.Format(" (Core Div = %g mrad, Halo Div = %g mrad, Halo Fraction = %g)",
			BeamCoreDivY*1000, BeamHaloDiverg*1000, BeamHaloPart);
		DecilPlot.Caption += S;
		DecilPlot.LabelX = "Angle, mrad";
		DecilPlot.LabelY = "Polar Profile(green), Splitting(red)";
		DecilPlot.Line = 1;
		DecilPlot.Interp = 0; // stairs
		
	}
	else {
		DecilPlot.Caption = "Beamlet Current vs Horizontal Direction ";
		S.Format(" (Core DivY = %g mrad, Halo Div = %g mrad, Halo Fraction = %g)", 
			BeamCoreDivY*1000, BeamHaloDiverg*1000, BeamHaloPart);
		DecilPlot.Caption += S;
		DecilPlot.LabelX = "Angle, mrad";
		DecilPlot.LabelY = "Core+Halo, Core, Halo";
		DecilPlot.Line = 1;
		DecilPlot.Interp = 1; //
		
	}
	DecilPlot.LimitX = 0;
	DecilPlot.LimitY = 1;
	DecilPlot.CrossX = 5;
	DecilPlot.CrossY = 0.2;
	
	DecilPlot.PosNegX = FALSE;
	DecilPlot.PosNegY = FALSE;

	double divY = BeamCoreDivY;
	if (fabs(divY) < 1.e-16) divY = 0.00001;
	double divZ = BeamCoreDivZ;
	if (fabs(divZ) < 1.e-16) divZ = 0.00001;

	if ((int)BeamSplitType ==0) { //  Polar Splitting --------------------------
		PosX.Add(PolarAngle[0] * divY);
		PosY.Add(PolarCurrent[0]);
		for (int i = 1; i <= PolarAngle.GetUpperBound(); i++) {
			PosX.Add(0.5 * 1000 *(PolarAngle[i-1] + PolarAngle[i])* divY);
			PosY.Add(PolarCurrent[i]);
		}
		DecilPlot.N1 = PosX.GetSize();

		angle = 0;
		double amax = SumGauss(0.99999, BeamCoreDivY, BeamHaloDiverg, BeamHaloPart);
		while (angle < amax) {
			PosX.Add(angle * 1000);
		//	y = GaussDensity(angle, BeamCoreDiverg, BeamHaloDiverg, BeamHaloPart);
			y = 1. - Gauss(angle, BeamCoreDivY, BeamHaloDiverg, BeamHaloPart);
			PosY.Add(y);
			angle += 0.00001;
		}
	
		DecilPlot.N = PosX.GetSize();
		DecilPlot.N2 = DecilPlot.N +1;
	}//  Polar Splitting 

	else { // Cartesian splitting ---------------------------------------
//	int i;
	double x, core0, halo0, core, halo;
	// int Ny = (int) BeamSplitNumberY;
//	double DivY = BeamCoreDivY;
	double dx = 0.0001; //2 * 3 * Max(BeamHaloDiverg, DivY) / Ny;
	double MaxVal = 1;
	
	x = 0;
	core0 = 0; halo0 = 0; core = 0; halo = 0; 
	if (BeamCoreDivY > 1.e-16)	core =  IntegralErr(x+0.5*dx, divY) * (1 - BeamHaloPart);
	if (BeamHaloDiverg > 1.e-16) halo = IntegralErr(x+0.5*dx, BeamHaloDiverg) * (BeamHaloPart);
	MaxVal = 2*(core+halo);
			PosY.Add(2*(core+halo)/MaxVal);
			PosX.Add(0); //(x - 0.5*dx);
			core0 = core; halo0 = halo;
			x+=dx;
		//for (i = 0; i < Ny/2; i++) {
	while (x <= 2 * Max(divY, BeamHaloDiverg)) { //DecilPlot.LimitX) 
			if (BeamCoreDivY > 1.e-16) core =  IntegralErr(x+0.5*dx, divY) * (1-BeamHaloPart);
			if (BeamHaloDiverg > 1.e-16) halo =  IntegralErr(x+0.5*dx, BeamHaloDiverg) * (BeamHaloPart);
			PosY.Add((core - core0 + halo - halo0)/MaxVal);
			PosX.Add(1000*x);//(x - 0.5*dx);
			core0 = core; halo0 = halo;
			x+=dx;
		} // 
	DecilPlot.N1 = PosX.GetSize();


	core0 = 0; x = 0; core = 0;
	if (BeamCoreDivY > 1.e-16)	core = IntegralErr(x+0.5*dx, divY) * (1 - BeamHaloPart);
			PosY.Add(2*core/MaxVal);
			PosX.Add(0); //(x - 0.5*dx);
			core0 = core;
			x+=dx;
		//for (i = 0; i < Ny/2; i++) {
	while (x <= 2 * Max(divY, BeamHaloDiverg)) { //DecilPlot.LimitX) 
			if (BeamCoreDivY > 1.e-16)	core =  IntegralErr(x+0.5*dx, divY) * (1-BeamHaloPart);
			PosY.Add((core - core0)/MaxVal);
			PosX.Add(1000*x);//(x - 0.5*dx);
			core0 = core;
			x+=dx;
		} // 
	DecilPlot.N2 = PosX.GetSize();

	halo0 = 0; x = 0; halo = 0;
	if (BeamHaloDiverg > 1.e-16) halo = IntegralErr(x+0.5*dx, BeamHaloDiverg) * (BeamHaloPart);
			PosY.Add(2*halo/MaxVal);
			PosX.Add(0); //(x - 0.5*dx);
			halo0 = halo;
			x+=dx;
		//for (i = 0; i < Ny/2; i++) {
	while (x <= 2 * Max(divY, BeamHaloDiverg)) { // DecilPlot.LimitX) 
			if (BeamHaloDiverg > 1.e-16) halo =  IntegralErr(x+0.5*dx, BeamHaloDiverg) * (BeamHaloPart);
			PosY.Add((halo - halo0)/MaxVal);
			PosX.Add(1000*x); //(x - 0.5*dx);
			halo0 = halo;
			x+=dx;
		} // 
	DecilPlot.N = PosX.GetSize();



	} // cartesian

	DecilPlot.DataX = &PosX; //PolarAngle;
	DecilPlot.DataY = &PosY; //PolarCurrent;

	CPlotDlg dlg;
	dlg.Plot = &DecilPlot;
	dlg.InitPlot();
	dlg.DoModal();
	PosX.RemoveAll();
	PosY.RemoveAll();

}

void CBTRDoc::OnPlotMamugpositions() 
{
//	int is, js, i, j;
	int res;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}
	double x, y;
	CArray<double, double> PosY;
	CArray<double, double> PosZ;
	
	PLOTINFO MamugPlot;
	MamugPlot.Caption = "MAMuG beamlets Positions,  X = 0";
	MamugPlot.LabelX = "X, m";
	MamugPlot.LabelY = "Y, m";
	MamugPlot.LimitX = 0;//0.3;
	MamugPlot.LimitY = 0; //0.8;
	MamugPlot.CrossX = 0.1;
	MamugPlot.CrossY = 0.2;
	MamugPlot.Line = 0;
	MamugPlot.Interp = 1;
//	MamugPlot.N1 = NofChannelsHorNofChannelsVertNofBeamletsHorNofBeamletsVert;
//	MamugPlot.N2 = MamugPlot.N1; 
	MamugPlot.PosNegX = TRUE;
	MamugPlot.PosNegY = TRUE;
//	MamugPlot.DataX = &PolarAngle;
//	MamugPlot.DataY = &PolarCurrent;
	for (int is = 0; is < (int)NofChannelsHor;  is++)  ///NofChannelsHor;
		for (int js = 0; js < (int)NofChannelsVert; js++)   ///NofChannelsVert;
			for (int i = 0; i < (int)NofBeamletsHor; i++) 
				for (int j = 0; j < (int)NofBeamletsVert; j++)
	
	{
		if (ActiveCh[is] == FALSE || ActiveRow[js] == FALSE) continue;
		x = BeamletPosHor[is * (int)NofBeamletsHor + i]; 
		y = BeamletPosVert[js * (int)NofBeamletsVert + j]; 
		PosY.Add(x);
		PosZ.Add(y);
	}
	MamugPlot.N1 = PosY.GetSize();

int j = 0;
if (!OptSINGAP) 
	for (int k = 0; k < NofBeamlets, j < NofCalculated; k++) {
		x = PosY.GetAt(k);
		y = PosZ.GetAt(k);
		PosY.Add(x);
		PosZ.Add(y);
		j++;
	}

	MamugPlot.N = PosY.GetSize();
	MamugPlot.N2 = MamugPlot.N1; 

	MamugPlot.DataX = &PosY;
	MamugPlot.DataY = &PosZ;
	
	CPlotDlg dlg;
	dlg.Plot = &MamugPlot;
	dlg.InitPlot();
	dlg.DoModal();

	PosY.RemoveAll();
	PosZ.RemoveAll();
	
}

void CBTRDoc::OnUpdatePlotMamugpositions(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!OptSINGAP);
}

void CBTRDoc::OnPlot3dload() 
{
	if (OptCombiPlot == -1) return; //pMarkedPlate == NULL) 
	if (!(pMarkedPlate->Loaded)) return;
	
	ShowProfiles = FALSE;
	pSetView->InvalidateRect(NULL, TRUE);
}

void CBTRDoc::OnUpdatePlot3dload(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(OptCombiPlot != -1 && pMarkedPlate->Loaded);
	
}

void CBTRDoc::OnPlotLoadmap() 
{
	//if (InvUser) return;
	if (OptCombiPlot == -1) return;//(pMarkedPlate == NULL) return;
	if (!(pMarkedPlate->Loaded)) return;
	//if (!(pMarkedPlate->Selected)) return;
	//pMarkedPlate->Load->SetSumMax(); // max profiles
	pLoadView->Contours = FALSE;
	pLoadView->Cross.X = pMarkedPlate->Load->iProf * pMarkedPlate->Load->StepX;
	pLoadView->Cross.Y = pMarkedPlate->Load->jProf * pMarkedPlate->Load->StepY;
	//pMarkedPlate->ShowLoadState();
	pMarkedPlate->ShowLoad();
	
}

void CBTRDoc::OnUpdatePlotLoadmap(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(OptCombiPlot != -1 && pMarkedPlate->Loaded);
}

void CBTRDoc::OnPlotContours() 
{
	//if (InvUser) return;
	if (OptCombiPlot == -1) return;//;(pMarkedPlate == NULL) return;
	//if (!(pMarkedPlate->Selected)) return;
	if (!(pMarkedPlate->Loaded)) return;
	//pMarkedPlate->Load->SetSumMax(); // max profiles
	pLoadView->Contours = TRUE;
	pLoadView->Cross.X = pMarkedPlate->Load->iProf * pMarkedPlate->Load->StepX;
	pLoadView->Cross.Y = pMarkedPlate->Load->jProf * pMarkedPlate->Load->StepY;
	//pMarkedPlate->ShowLoadState();
	CLevelsDlg dlg;
	dlg.m_Min = 0;
	dlg.m_Max = pMarkedPlate->Load->MaxVal * 1.e-6; // -> MW/m2
	dlg.m_Step = Min(LevelStep, dlg.m_Max * 0.1);
	dlg.m_Write = LevelWrite;
	if (dlg.DoModal() == IDOK) {
		LevelMin = dlg.m_Min;
		LevelMax = dlg.m_Max;
		LevelStep = dlg.m_Step;
		LevelWrite = dlg.m_Write;
		pMarkedPlate->ShowLoad();
	}
	
}

void CBTRDoc::OnUpdatePlotContours(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(OptCombiPlot != -1 && pMarkedPlate->Loaded);
	
}


void CBTRDoc::OnPlotMaxprofiles() 
{
	if (OptCombiPlot == -1) return;//(pMarkedPlate == NULL) return;
	if (!(pMarkedPlate->Loaded)) return;
	//if (!(pMarkedPlate->Selected)) return;
	//pMarkedPlate->Load->SetSumMax();
	ShowProfiles = TRUE;
	pLoadView->Cross.X = pMarkedPlate->Load->iProf * pMarkedPlate->Load->StepX;
	pLoadView->Cross.Y = pMarkedPlate->Load->jProf * pMarkedPlate->Load->StepY;
//	if (pLoadView->ShowLoad == TRUE) pLoadView->InvalidateRect(NULL, TRUE);
	pSetView->InvalidateRect(NULL, TRUE);
//	UpdateAllViews(NULL, NULL);
	
}

void CBTRDoc::OnUpdatePlotMaxprofiles(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(OptCombiPlot != -1 && pMarkedPlate->Loaded);
	
}

void CBTRDoc:: GetCombiPlotLimits(C3Point & lb, C3Point & rt)
{
	double Xmin = 100, Xmax = 0;//AreaLong;
	double Ymin = 100, Ymax = 0;//AreaHorMax;
	double Zmin = 100, Zmax = 0;//AreaVertMax;
	CPlate * plate;
	POSITION pos = PlatesList.GetHeadPosition();
		while (pos != NULL) {
			plate = PlatesList.GetNext(pos);
			if (plate->Selected) {
				for (int k = 0; k < 4; k++) {
					Xmin = Min(Xmin, plate->Corn[k].X); 
					Xmax = Max(Xmax, plate->Corn[k].X); 
					Ymin = Min(Ymin, plate->Corn[k].Y); 
					Ymax = Max(Ymax, plate->Corn[k].Y); 
					Zmin = Min(Zmin, plate->Corn[k].Z); 
					Zmax = Max(Zmax, plate->Corn[k].Z); 
				}// k
			}//if selected
		}//pos

	lb.X = Xmin; lb.Y = Ymin; lb.Z = Zmin;
	rt.X = Xmax; rt.Y = Ymax; rt.Z = Zmax;
	return;
}
void CBTRDoc:: GetCombiPlotOrts(C3Point & OrtX, C3Point & OrtY)
{
	CPlate * plate;
	//BOOL Target = TRUE;
	POSITION pos = PlatesList.GetHeadPosition();
		while (pos != NULL) {
			plate = PlatesList.GetNext(pos);
			if (plate->Selected) {
				OrtX = plate->OrtX;
				OrtY = plate->OrtY;
				break;
			}//if selected
		}//pos
		
	return;
}

void CBTRDoc:: CreateBaseSingle() // creates a new plate - pMarkedPlate projection
{
//	if (OptCombiPlot < 1) return;
	C3Point P, Ploc, OrtX, OrtY, OrtZ, Orig, p0, p1, p2, p3;
	CPlate * plate = new CPlate();

	OrtZ = pMarkedPlate->OrtZ;// / (double)k;
	Orig = pMarkedPlate->Orig;
	int DirZ = 0;
	if (fabs(OrtZ.X) > fabs(OrtZ.Y) && fabs(OrtZ.X) > fabs(OrtZ.Z)) DirZ = 1;
	if (fabs(OrtZ.Y) > fabs(OrtZ.X) && fabs(OrtZ.Y) > fabs(OrtZ.Z)) DirZ = 2;
	if (fabs(OrtZ.Z) > fabs(OrtZ.X) && fabs(OrtZ.Z) > fabs(OrtZ.Y)) DirZ = 3;
	
	switch (DirZ) {
		case 1: OrtX = C3Point(0,1,0); OrtY = C3Point(0,0,1); OrtZ = C3Point(1,0,0); break;
		case 2: OrtX = C3Point(1,0,0); OrtY = C3Point(0,0,1); OrtZ = C3Point(0,1,0); break;
		case 3: OrtX = C3Point(1,0,0); OrtY = C3Point(0,1,0); OrtZ = C3Point(0,0,1); break;
		default: OrtX = C3Point(0,1,0); OrtY = C3Point(0,0,1); break;
	}
	//OrtZ = VectProd(OrtX, OrtY);

	plate->Orig = Orig;
	plate->OrtX = OrtX; plate->OrtY = OrtY;  plate->OrtZ = OrtZ;
	
	double xmin = 1000, xmax = -1000;//baseplate->Xmax;
	double ymin = 1000, ymax = -1000;//baseplate->Ymax;
	double stepX = 0, stepY = 0;
	
	for (int k = 0; k < 4; k++) {
		P = pMarkedPlate->Corn[k];
		Ploc = plate->GetLocal(P);
		xmin = Min(xmin, Ploc.X);
		xmax = Max(xmax, Ploc.X);
		ymin = Min(ymin, Ploc.Y);
		ymax = Max(ymax, Ploc.Y);
	} //k

		if (pMarkedPlate->Loaded) {
				stepX = Max(stepX, pMarkedPlate->Load->StepX);
				stepY = Max(stepY, pMarkedPlate->Load->StepY);
		}

				
		Ploc = C3Point(xmin, ymin, 0);
		p0 = plate->GetGlobalPoint(Ploc);
		Ploc = C3Point(xmax, ymin, 0);
		p1 = plate->GetGlobalPoint(Ploc);
		Ploc = C3Point(xmin, ymax, 0);
		p2 = plate->GetGlobalPoint(Ploc);
		Ploc = C3Point(xmax, ymax, 0);
		p3 = plate->GetGlobalPoint(Ploc);

	//plate = new CPlate(); // combi-load
	plate->SetLocals(p0, p1, p2, p3);
	plate->Solid = FALSE;
	plate->Visible = FALSE;
	plate->Comment = pMarkedPlate->Comment + " /proj";
	plate->Number = pMarkedPlate->Number;
	 //PlatesList.AddTail(pPlate);
	
	plate->ApplyLoad(TRUE, stepX, stepY); // optimize grid 
	plate->Selected = TRUE;

	pMarkedPlate = plate;

	OptCombiPlot = 0;
	P_CalculateCombi(1); // calculate maps + proect them on the combi-plate
	plate->ShowLoadState();	
	OnPlotMaxprofiles();

	//pMarkedPlate = plate;
	//return plate;

}

void CBTRDoc::OnPlotCombi() // creates a new plate on which selected maps will be projected
//  NOT USED now ----------------------------
{
	//if (InvUser) return;
	OptCombiPlot = 0;//!OptCombiPlot;
	// CLoadView * pLV = (CLoadView *) pLoadView;
	C3Point P, Ploc, OrtX, OrtY, OrtZ, Orig, p0, p1, p2, p3;
	CPlate * plate;
	CPlate * baseplate = new CPlate(); //  combi-load base
	C3Point SumOrtZ = C3Point(0,0,0);
	CString Comment = "No plate selected";
	int k = 0;
	POSITION pos = PlatesList.GetHeadPosition();
		while (pos != NULL) {
			plate = PlatesList.GetNext(pos);
			if (plate->Selected) {
				k++;
				SumOrtZ = SumOrtZ + plate->OrtZ;
				Orig = plate->Orig;
				Comment = plate->Comment;
				//break;
			}//if selected
		}//pos
		OptCombiPlot = k;
		CString S;
		S.Format("%d", k);
		if (k >= 1) {
			Comment = Comment + " - Combi-" +S;
		}
		if (k < 1) { AfxMessageBox("No plate selected"); return; }

	OrtZ = SumOrtZ;// / (double)k;
	int DirZ = 0;
	if (fabs(OrtZ.X) > fabs(OrtZ.Y) && fabs(OrtZ.X) > fabs(OrtZ.Z)) DirZ = 1;
	if (fabs(OrtZ.Y) > fabs(OrtZ.X) && fabs(OrtZ.Y) > fabs(OrtZ.Z)) DirZ = 2;
	if (fabs(OrtZ.Z) > fabs(OrtZ.X) && fabs(OrtZ.Z) > fabs(OrtZ.Y)) DirZ = 3;
	
	switch (DirZ) {
		case 1: OrtX = C3Point(0,1,0); OrtY = C3Point(0,0,1); break;
		case 2: OrtX = C3Point(1,0,0); OrtY = C3Point(0,0,1); break;
		case 3: OrtX = C3Point(1,0,0); OrtY = C3Point(0,1,0); break;
		default: OrtX = C3Point(0,1,0); OrtY = C3Point(0,0,1); break;
	}
	OrtZ = VectProd(OrtX, OrtY);

	baseplate->Orig = Orig;
	baseplate->OrtX = OrtX; baseplate->OrtY = OrtY;  baseplate->OrtZ = OrtZ;
	
	double xmin = 1000, xmax = -1000;//baseplate->Xmax;
	double ymin = 1000, ymax = -1000;//baseplate->Ymax;
	double stepX = 0, stepY = 0; // grid steps
	
	pos = PlatesList.GetHeadPosition();
		while (pos != NULL) {
			plate = PlatesList.GetNext(pos);
			if (plate->Selected && plate->Solid) {
				for (int k = 0; k < 4; k++) {
					P = plate->Corn[k];
					Ploc = baseplate->GetLocal(P);
					xmin = Min(xmin, Ploc.X);
					xmax = Max(xmax, Ploc.X);
					ymin = Min(ymin, Ploc.Y);
					ymax = Max(ymax, Ploc.Y);
				}// k
				if (plate->Loaded) {
					stepX = Max(stepX, plate->Load->StepX);
					stepY = Max(stepY, plate->Load->StepY);
				}
			}//if selected
		}//pos
		Ploc = C3Point(xmin, ymin, 0);
		p0 = baseplate->GetGlobalPoint(Ploc);
		Ploc = C3Point(xmax, ymin, 0);
		p1 = baseplate->GetGlobalPoint(Ploc);
		Ploc = C3Point(xmin, ymax, 0);
		p2 = baseplate->GetGlobalPoint(Ploc);
		Ploc = C3Point(xmax, ymax, 0);
		p3 = baseplate->GetGlobalPoint(Ploc);

	plate = new CPlate(); // combi-load
	plate->SetLocals(p0, p1, p2, p3);
	 plate->Solid = FALSE;
	 plate->Visible = FALSE;
	 plate->Comment = Comment;
	 //PlatesList.AddTail(pPlate);
	plate->ApplyLoad(TRUE, stepX, stepY); // optimize grid 
	plate->Selected = TRUE;

	pMarkedPlate = plate;

	P_CalculateCombi(OptParallel); // calculate maps + proect them on the combi-plate
	plate->ShowLoadState();	
	OnPlotMaxprofiles();
	OptCombiPlot = 0;

	baseplate->~CPlate();
}

void CBTRDoc::OnPlotBeamletfoot() 
{
	int res;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}
	PlotBeamletFoot();
}

void CBTRDoc:: PlotBeamletFoot()
{
	CString S;
	double Vx, Vy, Vz, y, z, Vymin, Vzmin, Curr, MaxCurr, MaxY, MaxZ;
	CArray<double, double> PosY;
	CArray<double, double> PosZ;
	PLOTINFO BletPlot;
	
	BletPlot.LabelX = "Y, m";
	BletPlot.LabelY = "Z, m";
	BletPlot.LimitX = 0;//1.4;
	BletPlot.LimitY = 0;//1.4;
	BletPlot.CrossX = 0.2;
	BletPlot.CrossY = 0.2;
	BletPlot.Line = 0;
	BletPlot.Interp = 1;
	
	BletPlot.PosNegX = TRUE;
	BletPlot.PosNegY = TRUE;
	BletPlot.Caption = "Beamlet Exit Image";
	S.Format(" at X = %g m ", AreaLong);
	BletPlot.Caption += S;
	if ((int)BeamSplitType == 0) 
		S.Format(" (Polar = %d  Azim = %d  Cut-Off = %g)", (int)PolarNumber, (int)AzimNumber, CutOffCurrent);
	else 
		S.Format(" (Horiz. = %d  Vert. = %d  Cut-Off = %g)", (int)BeamSplitNumberY, (int)BeamSplitNumberZ, CutOffCurrent);
	BletPlot.Caption += S;

	int i;
	Vymin = 1.e100; Vzmin = 1.e100; 
	MaxCurr = 0; MaxY = 0; MaxZ = 0;
	for (i = 0; i < Attr_Array.GetSize(); i++) {
		Vx =  Attr_Array.GetAt(i).Vx;
		Vy = Attr_Array.GetAt(i).Vy;
		
		Vymin = Min(Vymin, fabs(Vy));
		Vz = Attr_Array.GetAt(i).Vz;
		
		Vzmin = Min(Vzmin, fabs(Vz));
		MaxCurr = Max(MaxCurr, Attr_Array.GetAt(i).Current);
		y = AreaLong * Vy / Vx; 
		if (fabs(y) < 1.e-6) y = Attr_Array.GetAt(i).Y;
		MaxY = Max(MaxY, fabs(y));
		z = AreaLong * Vz / Vx;
		if (fabs(z) < 1.e-6) z = Attr_Array.GetAt(i).Z;
		MaxZ = Max(MaxZ, fabs(z));
		PosY.Add(y);
		PosZ.Add(z);
	}

	BletPlot.N1 = Attr_Array.GetSize();
	BletPlot.N2 = BletPlot.N1;

/*	if ((int)BeamSplitType !=0) {// && Attr_Array.GetSize() >= 400) {// Cartesian
	for (i = 0; i < Attr_Array.GetSize(); i++) {
		Vx = Attr_Array.GetAt(i).Vx;
		Vy = Attr_Array.GetAt(i).Vy;
		Vz = Attr_Array.GetAt(i).Vz;
		Curr  =  Attr_Array.GetAt(i).Current;
		
			if (fabs(Vz) <= Vzmin + 1.e-16) {
				y = AreaLong * Vy / Vx;
				z = Curr / MaxCurr * MaxZ;
				PosY.Add(y);PosZ.Add(z);
			}
			if (fabs(Vy) <=  Vymin + 1.e-16) {
				y = Curr / MaxCurr * MaxY;
				z = AreaLong * Vz / Vx;
				PosY.Add(y);PosZ.Add(z);
			}
		
	}
	} // Cartesian
*/
	BletPlot.N = PosY.GetSize();

	BletPlot.DataX = &PosY;
	BletPlot.DataY = &PosZ;
	
	CPlotDlg dlg;
	dlg.Plot = &BletPlot;
	dlg.InitPlot();
	dlg.DoModal();

	PosY.RemoveAll();
	PosZ.RemoveAll();

	
}

void CBTRDoc::OnPlotBeamfoot() 
{
	int res;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}

	double x, y0, z0, y, z;
	CArray<double, double> PosY;
	CArray<double, double> PosZ;
	CString S;
	int N = 0, N1 = 0, N2 = 0;
	C3Point P;
	
	PLOTINFO FootPlot;
	
	FootPlot.LabelX = "Y, m";
	FootPlot.LabelY = "Z, m";
	FootPlot.LimitX = 0;//0.3;
	FootPlot.LimitY = 0;//0.8;
	FootPlot.CrossX = 0.1;
	FootPlot.CrossY = 0.2;
	FootPlot.Line = 0;
	FootPlot.Interp = 1;
	FootPlot.N = 0;
	FootPlot.PosNegX = TRUE;
	FootPlot.PosNegY = TRUE;
	// Set Caption
	if (OptSINGAP) S.Format("SINGAP ");
	else S.Format("MAMuG ");
	FootPlot.Caption = S + " Beam Exit";
	if (Progress == 0)	S.Format(" Target Image");
	else S.Format(" Footprint of %d beamlets", Exit_Array.GetUpperBound());
	FootPlot.Caption += S;
	S.Format("   X = %gm ", AreaLong);
	FootPlot.Caption += S;

if (Progress == 0) {// Calculation OFF - create target image

	if (!OptSINGAP || !SINGAPLoaded) { // Mamug
	for (int is = 0; is < (int)NofChannelsHor;  is++)  ///NofChannelsHor;
		for (int js = 0; js < (int)NofChannelsVert; js++)   ///NofChannelsVert;
			for (int i = 0; i < (int)NofBeamletsHor; i++) 
				for (int j = 0; j < (int)NofBeamletsVert; j++)
	
		{
			y0 = BeamletPosHor[is * (int)NofBeamletsHor + i]; 
			z0 = BeamletPosVert[js * (int)NofBeamletsVert + j]; 
			x = AreaLong;
			y = y0 + x * tan(BeamletAngleHor[is * (int)NofBeamletsHor + i]);
			z = z0 + x * tan(BeamletAngleVert[js * (int)NofBeamletsVert + j]);
			PosY.Add(y);
			PosZ.Add(z);
		}
		N = NofBeamlets;
		
	}// Mamug
	
	else if (OptSINGAP){ // Singap
		BEAMLET_ENTRY be;
		N = BeamEntry_Array.GetSize();
		for (int k = 0; k < N; k++) {
			be = BeamEntry_Array.GetAt(k);
			y0 = be.PosY;
			z0 = be.PosZ;
			x = AreaLong;
			y = y0 + x * tan(be.AlfY); 
			z = z0 + x * tan(be.AlfZ); 
			PosY.Add(y);
			PosZ.Add(z);
		}
	} // singap
} // Calculation OFF (Progress = 0)

else { // calculation in progress 
	N = Exit_Array.GetSize();
		for (int k = 0; k < N; k++) {
			P = Exit_Array.GetAt(k);
			y = P.Y;
			z = P.Z;
			PosY.Add(y);
			PosZ.Add(z);
		}
} // in progress
	
	FootPlot.N = N;
	FootPlot.N1 = N1;
	FootPlot.N2 = N2;
	FootPlot.DataX = &PosY;
	FootPlot.DataY = &PosZ;

	CPlotDlg dlg;
	dlg.Plot = &FootPlot;
	dlg.InitPlot();
	dlg.DoModal();

	PosY.RemoveAll();
	PosZ.RemoveAll();
	
}

void CBTRDoc::OnAsk() 
{
	AskDlg->Create();
	AskDlg->ShowWindow(SW_RESTORE);

//	EnableAsk = FALSE;
}

void CBTRDoc::OnUpdateAsk(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(EnableAsk);	
}

////////////// from BTR-K ///////////////////////////////////////////////////////
///////////////// Beam + Plasma ///////////////////////
/*
void CBTRDoc:: SetSigmaExchangeDefault()
{
	SigmaExchEeV.RemoveAll();
	SigmaExchValcm2.RemoveAll();

	SigmaExchEeV.Add(1);	SigmaExchValcm2.Add(7e-15);
	SigmaExchEeV.Add(4);	SigmaExchValcm2.Add(6e-15);
	SigmaExchEeV.Add(10);	SigmaExchValcm2.Add(5e-15);
	SigmaExchEeV.Add(40);	SigmaExchValcm2.Add(4e-15);
	SigmaExchEeV.Add(100);	SigmaExchValcm2.Add(3.5e-15);
	SigmaExchEeV.Add(1000); SigmaExchValcm2.Add(2e-15);
	SigmaExchEeV.Add(2000); SigmaExchValcm2.Add(1.5e-15);
	SigmaExchEeV.Add(4000); SigmaExchValcm2.Add(1.2e-15);
	SigmaExchEeV.Add(6000); SigmaExchValcm2.Add(1.1e-15);
	SigmaExchEeV.Add(10000); SigmaExchValcm2.Add(1e-15);
	SigmaExchEeV.Add(20000); SigmaExchValcm2.Add(6e-16);
	SigmaExchEeV.Add(30000); SigmaExchValcm2.Add(4e-16);
	SigmaExchEeV.Add(40000); SigmaExchValcm2.Add(2e-16);
	SigmaExchEeV.Add(50000); SigmaExchValcm2.Add(1e-16);
	SigmaExchEeV.Add(60000); SigmaExchValcm2.Add(6e-17);
	SigmaExchEeV.Add(70000); SigmaExchValcm2.Add(3e-17);
	SigmaExchEeV.Add(80000); SigmaExchValcm2.Add(2e-17);
	SigmaExchEeV.Add(100000); SigmaExchValcm2.Add(1e-17);
}

double 	CBTRDoc:: GetSigmaExchange(int A, double EkeV)//
{
	CArray<double, double> * Xdata = &SigmaExchEeV; // E, eV 
	CArray<double, double> * Sdata = &SigmaExchValcm2; // cm2

	double S = 0;
	double x0, x1;
	double s0, s1;
	double x = EkeV * 1000 / A; // eV  (Energy div 2 for D)
//	double v = 1.e6 * sqrt(2*EkeV*1000 / A); // cm/s
	int Nmax = Xdata->GetUpperBound();
	 if (x > Xdata->GetAt(Nmax) || x < Xdata->GetAt(0)) return 0;
	 for (int i = 0; i < Nmax; i++) {
		 if (x >= Xdata->GetAt(i) && x < Xdata->GetAt(i+1)) {
			  x0 = Xdata->GetAt(i);  x1 = Xdata->GetAt(i+1);
			  s0 = Sdata->GetAt(i);  s1 = Sdata->GetAt(i+1);
			  S = s0 + (s1-s0) * (x-x0) / (x1-x0);
			  return (S * 1e-4); // m2
		 } //if
	 } // for
	return 0;

}

void CBTRDoc:: SetSigmaIonDefault()
{
	SigmaIonEeV.RemoveAll();
	SigmaIonValcm2.RemoveAll();

	SigmaIonEeV.Add(1000); SigmaIonValcm2.Add(0);
	SigmaIonEeV.Add(2000); SigmaIonValcm2.Add(4e-18);
	SigmaIonEeV.Add(4000); SigmaIonValcm2.Add(4e-17);
	SigmaIonEeV.Add(6000); SigmaIonValcm2.Add(8e-17);
	SigmaIonEeV.Add(8000); SigmaIonValcm2.Add(1e-16);
	SigmaIonEeV.Add(10000); SigmaIonValcm2.Add(1.2e-16);
	SigmaIonEeV.Add(20000); SigmaIonValcm2.Add(1.5e-16);
	SigmaIonEeV.Add(40000); SigmaIonValcm2.Add(1.5e-16);
	SigmaIonEeV.Add(60000); SigmaIonValcm2.Add(1.4e-16);
	SigmaIonEeV.Add(100000); SigmaIonValcm2.Add(1.2e-16);
	SigmaIonEeV.Add(200000); SigmaIonValcm2.Add(8e-17);
	SigmaIonEeV.Add(400000); SigmaIonValcm2.Add(5e-17);
	SigmaIonEeV.Add(600000); SigmaIonValcm2.Add(3e-17);
	SigmaIonEeV.Add(800000); SigmaIonValcm2.Add(2.5e-17);
	SigmaIonEeV.Add(1000000); SigmaIonValcm2.Add(2e-17);
	SigmaIonEeV.Add(2000000); SigmaIonValcm2.Add(1e-17);
	SigmaIonEeV.Add(4000000); SigmaIonValcm2.Add(6e-18);
	SigmaIonEeV.Add(6000000); SigmaIonValcm2.Add(4e-18);
	SigmaIonEeV.Add(10000000); SigmaIonValcm2.Add(3e-18);
}

double 	CBTRDoc:: GetSigmaIon(int A, double EkeV)// proton ionisation
{
	CArray<double, double> * Xdata = &SigmaIonEeV; // E, eV 
	CArray<double, double> * Sdata = &SigmaIonValcm2; // cm2
	
	double S = 0;
	double x0, x1;
	double s0, s1;
	double x = EkeV * 1000 / A; // eV  (Energy div 2 for D)
//	double v = 1.e6 * sqrt(2*EkeV*1000 / A); // cm/s
	int Nmax = Xdata->GetUpperBound();
	 if (x > Xdata->GetAt(Nmax) || x < Xdata->GetAt(0)) return 0;
	 for (int i = 0; i < Nmax; i++) {
		 if (x >= Xdata->GetAt(i) && x < Xdata->GetAt(i)) {
			  x0 = Xdata->GetAt(i);  x1 = Xdata->GetAt(i+1);
			  s0 = Sdata->GetAt(i);  s1 = Sdata->GetAt(i+1);
			  S = s0 + (s1-s0) * (x-x0) / (x1-x0);
			  return (S * 1e-4); // m2
		 } //if
	 } // for
	return 0;
}

void CBTRDoc:: SetRateElectronDefault()
{
	RateElectronTeV.RemoveAll();
	RateElectronValcm3s.RemoveAll();

	RateElectronTeV.Add(2); RateElectronValcm3s.Add(0);
	RateElectronTeV.Add(3); RateElectronValcm3s.Add(1e-10);
	RateElectronTeV.Add(4); RateElectronValcm3s.Add(5e-10);	
	RateElectronTeV.Add(6); RateElectronValcm3s.Add(2e-9);
	RateElectronTeV.Add(8); RateElectronValcm3s.Add(4e-9);
	RateElectronTeV.Add(10); RateElectronValcm3s.Add(6e-9);
	RateElectronTeV.Add(20); RateElectronValcm3s.Add(1.5e-8);
	RateElectronTeV.Add(40); RateElectronValcm3s.Add(3e-8);
	RateElectronTeV.Add(60); RateElectronValcm3s.Add(4e-8);
	RateElectronTeV.Add(80); RateElectronValcm3s.Add(4e-8);
	RateElectronTeV.Add(100); RateElectronValcm3s.Add(4e-8);
	RateElectronTeV.Add(400); RateElectronValcm3s.Add(3e-8);
	RateElectronTeV.Add(1000); RateElectronValcm3s.Add(2e-8);
	RateElectronTeV.Add(4000); RateElectronValcm3s.Add(1.5e-8);
	RateElectronTeV.Add(10000); RateElectronValcm3s.Add(1e-8);
	RateElectronTeV.Add(20000); RateElectronValcm3s.Add(8e-9);
	RateElectronTeV.Add(40000); RateElectronValcm3s.Add(6e-9);
	RateElectronTeV.Add(100000); RateElectronValcm3s.Add(4e-9);
}

double 	CBTRDoc:: GetSigmaElectron(int A, double EkeV, double TkeV)
{
	CArray<double, double> * Xdata = &RateElectronTeV; // Te, eV 
	CArray<double, double> * SVdata = &RateElectronValcm3s; // rate cm3/c
	
	double SV = 0;
	double x0, x1;
	double s0, s1;
	double x = TkeV * 1000 / A; // Te, eV  (Energy div 2 for D ??????)
	double v = 1.e6 * sqrt(2*EkeV*1000 / A); // cm/s
	int Nmax = Xdata->GetUpperBound();
	 if (x > Xdata->GetAt(Nmax) || x < Xdata->GetAt(0)) return 0;
	 for (int i = 0; i < Nmax; i++) {
		 if (x >= Xdata->GetAt(i) && x < Xdata->GetAt(i+1)) {
			  x0 = Xdata->GetAt(i);  x1 = Xdata->GetAt(i+1);
			  s0 = SVdata->GetAt(i);  s1 = SVdata->GetAt(i+1);
			  SV = s0 + (s1-s0) * (x-x0) / (x1-x0);
			  return (SV/v * 1e-4); // m2
		 } //if
	 } // for
	 return 0;
}
*/	
/////////end ///////BTR-K ///////////////////////////////////////

void CBTRDoc::OnTasksBeamplasma() 
{
	OnPlotPenetration();
}

void CBTRDoc::OnPlotPenetration() 
{
	//if (!OptBeamInPlasma) return;
	OptBeamInPlasma = TRUE; //!OptBeamInPlasma;
	if (OptBeamInPlasma) { // calculate expected (axial) beam decay
		PlotBeamDecay(0, 0);
	}
}

void CBTRDoc::OnOptionsTraceneutralsinplasma() 
{
	OnPlotPenetration();
	
}

double CBTRDoc:: GetPlasmaDensityParabolic(double r, int order)
{
	double Dens = 1;
	if (fabs(r) > PlasmaMinorR) return 0;
	double rn = r / PlasmaMinorR;
	switch (order) {
	case 0: Dens = 1;break;
	case 1: Dens = 1 - rn; break;
	case 2: Dens = 1 - rn*rn; break;
	case 4: Dens = 1 - rn*rn*rn*rn; break;
	case 8: Dens = 1 - rn*rn*rn*rn*rn*rn*rn*rn;	break;
	default: Dens = 1;
	}
	return Dens;
}

double CBTRDoc:: GetPlasmaTeParabolic(double r, int order)
{
	double Te = 1;
	if (fabs(r) > PlasmaMinorR) return 0;
	double rn = r / PlasmaMinorR;
	switch (order) {
	case 0: Te = 1; break;
	case 1: Te = 1 - rn; break;
	case 2: Te = 1 - rn*rn; break;
	case 4: Te = 1 - rn*rn*rn*rn; break;
	case 8: Te = 1 - rn*rn*rn*rn*rn*rn*rn*rn; break;
	default: Te = 1;
	}
	return Te;
}

double CBTRDoc:: GetR(double X, double Y, double Z) // poloidal radius of plasma
{
	double x = X - TorCentre.X;
	double y = Y - TorCentre.Y;
	double z = Z - TorCentre.Z;
	double R, r;
	R = sqrt(x*x + y*y); // toroidal radius at z=0 
	r = R - PlasmaMajorR; //poloidal radius at z=0
	return sqrt(r*r + z*z);
}

C3Point CBTRDoc:: GetTorRZ(double X, double Y, double Z) // get R/Z in tokamak frame
{
	C3Point P(0,0,0);
	double x = X - TorCentreX;
	double y = Y - TorCentreY;
	double z = Z - TorCentreZ;
	double R = sqrt(x*x + y*y); // toroidal radius at z=0 
	P.X = R; P.Y = R; P.Z = z;
	return P;
}
double CBTRDoc:: GetPSI(double R, double Z) // get poloidal flux value (normalized to 1 on separatrix)
{
	double PSI = -1;
	C3Point Pgl, Ploc;
	if (R < PlasmaMajorR - PlasmaMinorR || R > PlasmaMajorR + PlasmaMinorR) return -1;
	Pgl.X = 1000; Pgl.Y = R; Pgl.Z = Z; // R, Z - in tor frame!
	if (pTorCrossPlate != NULL) {
		Ploc = pTorCrossPlate->GetLocal(Pgl);
		PSI = pTorCrossPlate->Load->GetVal(Ploc.X, Ploc.Y);
	}

	return PSI;
}
double CBTRDoc::GetPSIrdr(double psi) // averaged PSI-volume r*dr
{
	return StepPSI;
}

void CBTRDoc:: SetNeutralisation()
{
	CNeutrDlg dlg;
	dlg.m_Thin = OptThickNeutralization ? 1 : 0;

	if (dlg.DoModal() == IDOK) {
		OptThickNeutralization = (dlg.m_Thin != 0);
	}
	else
		return; // ThickNeutralization = FALSE;
	
	if (!PressureLoaded && OptThickNeutralization) {
		AfxMessageBox("Please, define gas profile before choosing THICK model \n THIN model is active ");
		OptThickNeutralization = FALSE;
	}

	if (!OptThickNeutralization) {
		CThinDlg dlg;
		dlg.m_Xlim = NeutrXmax;
		dlg.m_Neff = NeutrPart * 100;
		dlg.m_PosYield = PosIonPart * 100;
		if (dlg.DoModal() == IDOK) {
			NeutrXmax = dlg.m_Xlim;
			NeutrPart = dlg.m_Neff * 0.01;
			PosIonPart = dlg.m_PosYield * 0.01;
			CheckData();
		}
	}

	else {
		CThickDlg dlg;
		dlg.m_Xmin = NeutrXmin;
		dlg.m_Xmax = NeutrXmax;
		dlg.m_Step = NeutrStepL;
		dlg.m_SigmaNeutr = NeutrSigma * 10000; // -> cm2
		dlg.m_SigmaIon = ReionSigma * 10000;
		dlg.m_Sigma2Strip = TwoStripSigma * 10000;
		dlg.m_SigmaExch = PosExchSigma * 10000;
		if (dlg.DoModal() == IDOK) {
			NeutrXmin = dlg.m_Xmin;
			NeutrXmax = dlg.m_Xmax;
			NeutrStepL = dlg.m_Step;
			NeutrSigma = dlg.m_SigmaNeutr * 0.0001; // -> m2
			ReionSigma = dlg.m_SigmaIon * 0.0001;
			TwoStripSigma = dlg.m_Sigma2Strip * 0.0001;
			PosExchSigma = dlg.m_SigmaExch * 0.0001;
			SetNeutrCurrents();
		}
	}
}

void CBTRDoc:: SetReionization()
{
	CReionDlg dlg;

	switch (TracePartType) {
	case 0:	dlg.m_Caption = "e -> e+"; break;
	case 1:
	case -1:
	case 10:
			dlg.m_Caption = "Ho -> H+"; break;
	case 2:
	case -2:
	case 20:
			dlg.m_Caption = "Do -> D+"; break;
	default: dlg.m_Caption = "Neutral atom Zo -> Ion Z+"; break; 
	}
	dlg.m_IonStepL = IonStepL;
	dlg.m_Lstep = ReionStepL;
	dlg.m_Percent =	ReionPercent;
	dlg.m_Sigma = ReionSigma;
	dlg.m_Xmin = ReionXmin;
	dlg.m_Xmax = ReionXmax;
	dlg.m_StepSpec = IonStepLspec;
	dlg.m_Xspec0 = Xspec0;
	dlg.m_Xspec1 = Xspec1;
	dlg.m_StepSpecR = ReionStepLspec;
	dlg.m_XRspec0 = RXspec0;
	dlg.m_XRspec1 = RXspec1;

	if (dlg.DoModal() == IDOK) {
		ReionSigma = dlg.m_Sigma;
		ReionXmin = dlg.m_Xmin;
		ReionXmax = dlg.m_Xmax;
		ReionStepL = dlg.m_Lstep;
		IonStepL = dlg.m_IonStepL;
		IonStepLspec = dlg.m_StepSpec;
		Xspec0 = dlg.m_Xspec0;
		Xspec1 = dlg.m_Xspec1;
		ReionStepLspec = dlg.m_StepSpecR;
		RXspec0 = dlg.m_XRspec0;
		RXspec1 = dlg.m_XRspec1;
	
		SetReionPercent();
		CString S;
		if (PressureLoaded && GasCoeff > 1.e-6)	S.Format("Re-ionization loss = %3.1f %%", ReionPercent);
		else S.Format("Pressure profile not defined. \n Re-ionized current = 0");
		AfxMessageBox(S);
	}
}

double CBTRDoc:: GetReionDecay(C3Point P)
{
	if (!OptReionAccount) return 1;
	double power = 1, power0, power1;
	//C3Point P0, P1;
	double X0, X1;
	int Nmax = ReionArray.GetUpperBound();
	if (Nmax < 1) return 1; 
	if (P.X > ReionArray[Nmax].X) return (ReionArray[Nmax].Z);
	if (P.X < ReionArray[0].X) return 1;
	
	for (int i = 0; i < Nmax; i++) {
		 X0 = ReionArray[i].X;  X1 = ReionArray[i+1].X;
		 if (P.X >= X0 && P.X < X1) {
			 power0 = ReionArray[i].Z; power1 = ReionArray[i+1].Z;
			 power = power0 + (power1 - power0) * (P.X - X0) / (X1 - X0);
			 
			 return power;
		 } // if
	 } // for
	
	return power;
}

double CBTRDoc:: GetNeutrDecay(C3Point P1, C3Point P2)
{
	if (P1.X >= P2.X) return 1;
	double Pend = Min(P2.X, NeutrXmax);
	double NL = GetNL(P1.X, Pend);
	double S01 = ReionSigma;
	double decay = exp(- S01 * NL); 
	return decay;
}

void CBTRDoc:: SetPlasmaGeom() // Tor geometry
{
	//if (!OptBeamInPlasma) return;
	//InjectAimR = -TorCentreY; //5.31; //tangency rad of Inject Point from Tokamak Center
	//InjectAimZ = 0;//-0.131; // InjectPoint shift from Tokamak Center line
	TorCentre.X = TorCentreX; //31.952; // horiz distance from GG centre to InjectPoint
	TorCentre.Y = TorCentreY; //- InjectAimR;
	TorCentre.Z = TorCentreZ; //-1.443;// vert distance from GG centre to Tokamak Center line
	if (!FWdataLoaded) {
		InitFWarray();
		//PlasmaMajorR = (FWRmin + FWRmax) * 0.5;
		//PlasmaMinorR = (FWRmax - FWRmin) * 0.5;
		FWRmin = PlasmaMajorR - PlasmaMinorR;
		FWRmax = PlasmaMajorR + PlasmaMinorR;
		FWZmin = TorCentreZ - PlasmaMinorR;
		FWZmax = TorCentreZ + PlasmaMinorR;
	}
	else { // FW loaded
		PlasmaMajorR = (FWRmin + FWRmax) * 0.5;
		PlasmaMinorR = (FWRmax - FWRmin) * 0.5;
	}
	double dx = 0;
	if (FWRmax > fabs(TorCentreY)) 
		dx = sqrt(FWRmax*FWRmax - TorCentreY * TorCentreY);
	PlasmaXmax = TorCentreX + dx;
	PlasmaXmin = TorCentreX - dx;
	if (FWRmin > fabs(TorCentreY)) {
		double dx1 = sqrt(FWRmin*FWRmin - TorCentreY * TorCentreY);
		PlasmaXmax = TorCentreX - dx1;
	}

	
// NEXT ARRAYS TO BE REMOVED! -> CPlasma -----------------------

	MagSurfDim = 3;
	StepPSI = 1.0 / MagSurfDim;
	DecayArray.RemoveAll();
	DecayPathArray.RemoveAll();
	SumPSIArray.RemoveAll();
	//PlasmaLoaded = FALSE;

	if (!PSILoaded) {
		PSIvolume.RemoveAll();
		for (int k = 0; k < MagSurfDim; k++) PSIvolume.Add((k + 1));// *(k + 1));// v = 2PI*r
	
	}
	
//	pBeamHorPlane->Load->Clear(); // created in SetPlatesNBI
//	pBeamVertPlane->Load->Clear();// created in SetPlatesNBI

	int Kpsi = MagSurfDim;// (int)ceil(1. / StepPSI);
	for (int k = 0; k < Kpsi; k++) {
		//double vol = PSIvolume[k];
		SumPSIArray.Add(C3Point(0, 0, 0)); // sum IonPower, L, Npower for each PSI
	}

// create path - to be moved to CPlasma!! (target)
	double Xstart = PlasmaXmin - 1;
	double Xfin = PlasmaXmax + 1;
	double LpathX = Xfin - Xstart;//GetDistBetween(P0, P1); //P1.X - P0.X;
	int Kpath = 1000;//Kpsi * 20;// (int)ceil(Lpath / StepPath);
	double StepX = LpathX / Kpath;// 0.0002 * Lpath;// PathArray
								  //C3Point vectL = (P1 - P0) / Lpath * StepPath;

	for (int k = 0; k <= Kpath; k++)
		DecayPathArray.Add(C3Point(Xstart + StepX * k, 0, 0)); // Xpoint Density Sigma along path (Kpath + 1)

	for (int k = 0; k <= Kpath; k++)
		DecayArray.Add(C3Point(0, 0, 0)); // thickness, psi, Npower  - along path
	
}

void CBTRDoc:: SetPlasmaTarget() //init plasma object
{
	// global inject geom
	SetPlasmaGeom();// set global beam-tor geometry, plasma Rminor/Rmajor, Xmin/Xmax
	// psi, profiles, cross-sections
	int Knucl = TracePartNucl;
	double E = IonBeamEnergy * 1000 / Knucl; //keV AtomEnergy;
	double Sigma0 = SigmaBase;// GetSigmaEkeV(E);
	double SigMult = (1. + SigmaEnhancement);// Delta = 1 + SigmaEnh, defined like Janev
	//double SigmaTot = Sigma0 * SigMult ; 
	//pPlasma->SetPlasmaParam(this, SigmaTot);
	double Nemax = MaxPlasmaDensity;
	double Temax = MaxPlasmaTe;
	C3Point TorC;// = TorCentre;
	TorC.X = TorCentreX;
	TorC.Y = TorCentreY;
	TorC.Z = TorCentreZ;
	double Rmin = PlasmaMinorR;
	double Rmax = PlasmaMajorR;
	
	pPlasma->SetPlasmaParam(TorC, Rmin, Rmax, Nemax, Temax, Sigma0);
	pPlasma->SetSigMult(SigMult);
	double Xstart = PlasmaXmin;
	double Xfin = PlasmaXmax;
	
	//C3Point P0 = GetBeamFootLimits(Xstart, Ymin, Ymax, Zmin, Zmax);
	//C3Point P1 = GetBeamFootLimits(PlasmaXmax, Ymin, Ymax, Zmin, Zmax);
	double Ymin, Ymax, Zmin, Zmax;
	double Y0min, Y0max, Z0min, Z0max, Y1min, Y1max, Z1min, Z1max;
	C3Point P0, P1;
	P0 = GetBeamFootLimits(Xstart, Y0min, Y0max, Z0min, Z0max);
	P1 = GetBeamFootLimits(Xfin, Y1min, Y1max, Z1min, Z1max);
	Ymin = Min(Y0min, Y1min); Ymax = Max(Y0max, Y1max);
	Zmin = Min(Z0min, Z1min); Zmax = Max(Z0max, Z1max);
	
	C3Point Pmin = C3Point(Xstart, Ymin-0.2, Zmin-0.5); //C3Point(Xstart, P0.Y - 0.25, P0.Z - 0.5);// 
	C3Point Pmax = C3Point(Xfin, Ymax+0.2, Zmax+0.5); //C3Point(Xfin, P0.Y + 0.25, P0.Z + 0.5); //
	pPlasma->SetMesh(Pmin, Pmax, 100, 20, 20);// SetOriginDim->SetCutArrays

	C3Point Vn = P1 - P0;
	BEAM_RAY ray = BEAM_RAY(IonBeamEnergy * 1.e6, TracePartNucl, P0, Vn);
	pPlasma->SetBeamRay(ray);
	
}

void CBTRDoc::CalculateThickFocused() // run real set of axis-rays
{
	//double decay;// = GetDecayBetween(P0, P1); //fill arrays, return neutral power / power0
	CWaitCursor wait;
	double y0, z0, Ystart, Zstart, Yfin, Zfin; // bml axis
	double Xstart = PlasmaXmin - 0.5;
	double Xfin = PlasmaXmax;
	double LpathX = Xfin - Xstart;//GetDistBetween(P0, P1); //P1.X - P0.X;
	int Kpath = 3000;//Kpsi * 20;// (int)ceil(Lpath / StepPath);
	double StepL = LpathX / Kpath;
	double Ymin, Ymax, Zmin, Zmax;// tot beam size
	C3Point P0, P1, Pstart, Pfin;
	P0 = GetBeamFootLimits(Xstart, Ymin, Ymax, Zmin, Zmax);
	P1 = GetBeamFootLimits(PlasmaXmax, Ymin, Ymax, Zmin, Zmax);
	pPlasma->SetPath(P0, P1, StepL);
	pPlasma->AddDecayArrays(); // set Nrays = 0 initialize sumarrays for axis path
 // actual beam axes
	for (int is = 0; is < (int)NofChannelsHor; is++)  ///NofChannelsHor;
		for (int js = 0; js < (int)NofChannelsVert; js++)   ///NofChannelsVert;
			for (int i = 0; i < (int)NofBeamletsHor; i++)
				for (int j = 0; j < (int)NofBeamletsVert; j++)
				{
					y0 = BeamletPosHor[is * (int)NofBeamletsHor + i];
					z0 = BeamletPosVert[js * (int)NofBeamletsVert + j];

					Ystart = y0 + Xstart * tan(BeamletAngleHor[is * (int)NofBeamletsHor + i]);
					Zstart = z0 + Xstart * tan(BeamletAngleVert[js * (int)NofBeamletsVert + j]);
					Yfin = y0 + Xfin * tan(BeamletAngleHor[is * (int)NofBeamletsHor + i]);
					Zfin = z0 + Xfin * tan(BeamletAngleVert[js * (int)NofBeamletsVert + j]);

					Pstart = C3Point(Xstart, Ystart, Zstart);
					Pfin = C3Point(Xfin, Yfin, Zfin);
					pPlasma->SetPath(Pstart, Pfin, StepL);
					pPlasma->SetDecayArrays();// thin ray
					pPlasma->AddDecayArrays();// Nrays++
				
				}

}
void CBTRDoc::CalculateThickParallel() // run parallel set of rays
{
	// thick parallel beam along common axis
	CWaitCursor wait;
	double Xstart = PlasmaXmin - 0.5;
	double Xfin = PlasmaXmax;
	double LpathX = Xfin - Xstart;//GetDistBetween(P0, P1); //P1.X - P0.X;
	int Kpath = 3000;//Kpsi * 20;// (int)ceil(Lpath / StepPath);
	double StepL = LpathX / Kpath;
	
	double Ymin, Ymax, Zmin, Zmax; // tot beam 
	double Ystart, Zstart, Yfin, Zfin;  // bml axis
	C3Point P0, P1, Pstart, Pfin;
	P0 = GetBeamFootLimits(Xstart, Ymin, Ymax, Zmin, Zmax);
	P1 = GetBeamFootLimits(PlasmaXmax, Ymin, Ymax, Zmin, Zmax);
	C3Point Vn = P1 - P0; // CONST
	BEAM_RAY ray;// = BEAM_RAY(IonBeamEnergy * 1.e6, TracePartNucl, P0, Vn);
	BeamArray1D rays;
	double th = 1.0;// 1m
	double dy = 0.4 * th; // beam port width
	double dz = 0.8 * th; // beam port height

	int ky = 2, kz = 2; // to write set of rays 3x3
/*	for (int i = 0; i <= ky; i++)
		for (int j = 0; j <= kz; j++) {
			Ystart = P0.Y - dy * 0.5 + dy / ky * i;
			Zstart = P0.Z - dz * 0.5 + dz / kz * j;
			Pstart = C3Point(P0.X, Ystart, Zstart);
			//Vn = P1 - P0; // = const for parallel
			ray = BEAM_RAY(IonBeamEnergy * 1.e6, TracePartNucl, Pstart, Vn);
			rays.Add(ray);
		} // i,j
	*/		
//	pPlasma->WritePathSet(rays, pPlasma);

// calculate thick beam
	pPlasma->SetPath(P0, P1, StepL);//axis ray
	pPlasma->AddDecayArrays(); // set Nrays = 0 initialize sumarrays for axis path
	ky = 19; // to calculate 20x20
	kz = 39;
	for (int i = 0; i <= ky; i++)
		for (int j = 0; j <= kz; j++) {
			Ystart = P0.Y - dy * 0.5 + dy / ky * i;
			Zstart = P0.Z - dz * 0.5 + dz / kz * j;
			Yfin = P1.Y - dy * 0.5 + dy / ky * i;
			Zfin = P1.Z - dz * 0.5 + dz / kz * j;
			Pstart = C3Point(P0.X, Ystart, Zstart);
			Pfin = C3Point(P1.X, Yfin, Zfin);
			pPlasma->SetPath(Pstart, Pfin, StepL);
			pPlasma->SetDecayArrays();// thin ray
			pPlasma->AddDecayArrays();// Nrays++
									  //decay = GetFillDecayBetween(Pstart, Pfin, 1); // fill arrays
		}

}

void CBTRDoc:: CalculateThinDecay() //run axis beam
{
	double Xstart = PlasmaXmin;
	double Xfin = PlasmaXmax;
	double LpathX = Xfin - Xstart;//GetDistBetween(P0, P1); //P1.X - P0.X;
	int Kpath = 10000;//Kpsi * 20;// (int)ceil(Lpath / StepPath);
	double StepL = LpathX / Kpath;// 0.0002 * Lpath;// PathArray
	//C3Point vectL = (P1 - P0) / Lpath * StepPath;
	//C3Point P0(Xstart, 0, 0);
	//C3Point P1(Xfin, 0, 0);
	double Ymin, Ymax, Zmin, Zmax;
	C3Point P0, P1;
	P0 = GetBeamFootLimits(PlasmaXmin, Ymin, Ymax, Zmin, Zmax);
	P1 = GetBeamFootLimits(PlasmaXmax, Ymin, Ymax, Zmin, Zmax);
	C3Point Vn = P1 - P0;
	//pPlasma->SetOriginDim(P0, 100, 0, 0); // target start, nx,ny,nz
	
	//pPlasma->SetPath(P0, P1, 0.1);// calc path for output
	//pPlasma->WritePathThin(); // old output (no Sigmas)
	BEAM_RAY ray = BEAM_RAY(IonBeamEnergy * 1.e6, TracePartNucl, P0, Vn);
	pPlasma->SetPathFrom(P0, Vn, 0.01);
	pPlasma->WritePathSingle(ray, pPlasma);
	
	pPlasma->SetPath(P0, P1, StepL);// calc path points
	pPlasma->AddDecayArrays();// Init decay arrays, Nrays++ -1 -> 0

	pPlasma->SetDecayArrays();// calculate decay arrays
	pPlasma->AddDecayArrays();// add to sumarrays + convert to flux
		
	/*
	for (int k = 0; k < MagSurfDim; k++) {
	SumPSIArray[k].X = SumPSIArray[k].X / PSIvolume[k]; // IonPower/ V
	SumPSIArray[k].Y = SumPSIArray[k].Z / SumPSIArray[k].Y; //Npower / L
	SumPSIArray[k].Z = SumPSIArray[k].Z / PSIvolume[k]; // Npower
	}
	*/
}

/*double GetSumHDT_Janev(int A, double E, double Density, double Te)
{
	double Sum = 0;
	return Sum;
}*/

void CBTRDoc::FillArrayA_Suzuki(int A, double * CoeffA) // A = 1/2/3 for H/D/T plasma
{
	CoeffA[0] = A; // atom number H/D/T
	switch (A) {
		case 1: //H
			CoeffA[1] = 12.7;
			CoeffA[2] = 1.25;
			CoeffA[3] = 0.452;
			CoeffA[4] = 0.0105;
			CoeffA[5] = 0.547;
			CoeffA[6] = -0.102;
			CoeffA[7] = 0.36;
			CoeffA[8] = -0.0298;
			CoeffA[9] = -0.0959;
			CoeffA[10] = 4.21e-3;
			break;
		case 2: //D
			CoeffA[1] = 14.1;
			CoeffA[2] = 1.11;
			CoeffA[3] = 0.408;
			CoeffA[4] = 0.0105;
			CoeffA[5] = 0.547;
			CoeffA[6] = -0.0403;
			CoeffA[7] = 0.345;
			CoeffA[8] = -0.0288;
			CoeffA[9] = -0.0971;
			CoeffA[10] = 4.74e-3;
			break;
		case 3: // T
			CoeffA[1] = 12.7;
			CoeffA[2] = 1.26;
			CoeffA[3] = 0.449;
			CoeffA[4] = 0.0105;
			CoeffA[5] = 0.547;
			CoeffA[6] = -5.77e-3;
			CoeffA[7] = 0.336;
			CoeffA[8] = -0.0282;
			CoeffA[9] = -0.0974;
			CoeffA[10] = 4.87e-3;
			break;
	}

}

void CBTRDoc::FillArrayB_Suzuki(int A, double * CoeffB) // 
{
	CoeffB[0] = A; // atom number 
	switch (A) {
		case 2: // He (alfa)
			CoeffB[1] = -1.05; // B111
			CoeffB[2] = 0.141; // B112
			CoeffB[3] = -0.375; // B121
			CoeffB[4] = -0.0155; // B122
			CoeffB[5] = 0.531; // B211
			CoeffB[6] = -0.0309; // B212
			CoeffB[7] = 0.105; // B221
			CoeffB[8] = 5.03e-3; // B222
			CoeffB[9] = -0.0417; // B311
			CoeffB[10] = 2.58e-3; // B312
			CoeffB[11] = -7.02e-3; // B321
			CoeffB[12] = -3.47e-3; // B322
			break;
		case 3: // Li
			CoeffB[1] = -1.27; // B111
			CoeffB[2] = -1.41e-3; // B112
			CoeffB[3] = -0.284; // B121
			CoeffB[4] = -0.0184; // B122
			CoeffB[5] = 0.552; // B211
			CoeffB[6] = 0.0102; // B212
			CoeffB[7] = 0.0781; // B221
			CoeffB[8] = 5.63e-3; // B222
			CoeffB[9] = -0.0408; // B311
			CoeffB[10] = -2.95e-4; // B312
			CoeffB[11] = -5.09e-3; // B321
			CoeffB[12] = -3.75e-4; // B322
			break;
		case 4: // Be
			CoeffB[1] = -1.28; // B111
			CoeffB[2] = -0.0439; // B112
			CoeffB[3] = -0.255; // B121
			CoeffB[4] = -0.0176; // B122
			CoeffB[5] = 0.529; // B211
			CoeffB[6] = 0.0209; // B212
			CoeffB[7] = 0.0682; // B221
			CoeffB[8] = 5.2e-3; // B222
			CoeffB[9] = -0.0377; // B311
			CoeffB[10] = -9.73e-4; // B312
			CoeffB[11] = -4.27e-3; // B321
			CoeffB[12] = -3.27e-4; // B322
			break;
		case 5: // B
			CoeffB[1] = -1.32; // B111
			CoeffB[2] = -0.06; // B112
			CoeffB[3] = -0.225; // B121
			CoeffB[4] = -0.0185; // B122
			CoeffB[5] = 0.519; // B211
			CoeffB[6] = 0.0242; // B212
			CoeffB[7] = 0.594; // B221
			CoeffB[8] = 5.32e-3; // B222
			CoeffB[9] = -0.0359; // B311
			CoeffB[10] = -1.14e-3; // B312
			CoeffB[11] = -3.67e-3; // B321
			CoeffB[12] = -3.29e-4; // B322
			break;
		case 6: // C
			CoeffB[1] = -1.54; // B111
			CoeffB[2] = -0.0868; // B112
			CoeffB[3] = -0.1830; // B121
			CoeffB[4] = -0.0153; // B122
			CoeffB[5] = 0.567; // B211
			CoeffB[6] = 0.0313; // B212
			CoeffB[7] = 0.046; // B221
			CoeffB[8] = 4.21e-3; // B222
			CoeffB[9] = -0.0386; // B311
			CoeffB[10] = -1.6e-3; // B312
			CoeffB[11] = -2.68e-3; // B321
			CoeffB[12] = -2.41e-4; // B322
			break;
		case 7: // N
			CoeffB[1] = -1.5; // B111
			CoeffB[2] = -0.0883; // B112
			CoeffB[3] = -0.147; // B121
			CoeffB[4] = -0.0119; // B122
			CoeffB[5] = 0.537; // B211
			CoeffB[6] = 0.03; // B212
			CoeffB[7] = 0.0355; // B221
			CoeffB[8] = 3.12e-3; // B222
			CoeffB[9] = -0.0354; // B311
			CoeffB[10] = -1.41e-3; // B312
			CoeffB[11] = -1.97e-3; // B321
			CoeffB[12] = -1.61e-4; // B322
			break;
		case 8: // 0
			CoeffB[1] = -1.46; // B111
			CoeffB[2] = -0.085; // B112
			CoeffB[3] = -0.105; // B121
			CoeffB[4] = -8.88e-3; // B122
			CoeffB[5] = 0.51; // B211
			CoeffB[6] = 0.0278; // B212
			CoeffB[7] = 0.0237; // B221
			CoeffB[8] = 2.21e-3; // B222
			CoeffB[9] = -0.0329; // B311
			CoeffB[10] = -1.2e-3; // B312
			CoeffB[11] = -1.18e-3; // B321
			CoeffB[12] = -9.79e-5; // B322
			break;
		case 26: // Fe
			CoeffB[1] = -0.427; // B111
			CoeffB[2] = 0.0439; // B112
			CoeffB[3] = 0.103; // B121
			CoeffB[4] = 0.0124; // B122
			CoeffB[5] = 0.0827; // B211
			CoeffB[6] = 0.0224; // B212
			CoeffB[7] = 0.0378; // B221
			CoeffB[8] = 4.72e-3; // B222
			CoeffB[9] = 2.84e-3; // B311
			CoeffB[10] = 2.91e-3; // B312
			CoeffB[11] = 3.19e-3; // B321
			CoeffB[12] = 4.32e-4; // B322
			break;
		default: break;
		}
}


double CBTRDoc::GetSumHDT_Suzuki(int A, double E, double Density, double Te)
{
	double Sum = 0;
	double * CoeffA = new double[12];
	FillArrayA_Suzuki(A, CoeffA);
	double e = log(E);
	double N = Density / (1.e19);
	double U = log(Te);

	double S1 = 1 + CoeffA[2] * e + CoeffA[3] * e * e;
	double S2 = 1 - exp(-CoeffA[4] * N); 
	double S3 = CoeffA[6] + CoeffA[7] * e + CoeffA[8] * e * e;
	double S4 = 1 + CoeffA[9] * U + CoeffA[10] * U * U;

	Sum = CoeffA[1] * S1 * (1 + pow(S2, CoeffA[5]) * S3) * S4; 
	return Sum;
}

double CBTRDoc::GetSumSz(int A, double E, double Density, double Te)
{
	double Sum = 0;
	double * CoeffB = new double[13];
	FillArrayB_Suzuki(A, CoeffB);
	double e = log(E);
	double N = Density / 1.e19;
	double U = log(Te);
	double lnN = log(N);

	double S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12;
	int i, j, k;
	i = 1; j = 1; k = 1;
	S1 = CoeffB[1] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 1; j = 1; k = 2;
	S2 = CoeffB[2] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 1; j = 2; k = 1;
	S3 = CoeffB[3] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 1; j = 2; k = 2;
	S4 = CoeffB[4] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 2; j = 1; k = 1;
	S5 = CoeffB[5] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 2; j = 1; k = 2;
	S6 = CoeffB[6] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 2; j = 2; k = 1;
	S7 = CoeffB[7] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 2; j = 2; k = 2;
	S8 = CoeffB[8] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 3; j = 1; k = 1;
	S9 = CoeffB[9] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 3; j = 1; k = 2;
	S10 = CoeffB[10] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 3; j = 2; k = 1;
	S11 = CoeffB[11] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	i = 3; j = 2; k = 2;
	S12 = CoeffB[12] * pow(e, i-1) * pow(lnN, j-1) * pow(U, k-1);
	
	Sum = S1 + S2 + S3 + S4 + S5 + S6 + S7 + S8 + S9 + S10 + S11 + S12;

	return Sum;
}

void CBTRDoc::SetImpurNumber()
{
	NofPlasmaImpur = 0;
	double Wimp;
	for (int i = 0; i < NofPlasmaImpurMax; i++) {
				Wimp = PlasmaImpurW[i];
				if (Wimp > 1.e-6) NofPlasmaImpur++;
	} //i
	CString S;
	S.Format("Number of impurities - %d", NofPlasmaImpur);
	AfxMessageBox(S);
}
int CBTRDoc::GetFirstImp()
{
	int A = 0;
	int Aimp;
	double Wimp;
	for (int i = 0; i < NofPlasmaImpurMax; i++) {
				Aimp = PlasmaImpurA[i];
				Wimp = PlasmaImpurW[i];
				if (Wimp > 1.e-6) { 
					A = Aimp;
					break;
				}
	}
	return A;
}

void CBTRDoc::SetDecayInPlasma() //not called (fills array of neutral power / ion density / SumPSIArray)
{
	//if (!PlasmaLoaded)  - use simplified model
/*	TorCentre.X = TorCentreX; //31.952; // horiz distance from GG centre to InjectPoint
	TorCentre.Y = TorCentreY; //- InjectAimR;
	TorCentre.Z = TorCentreZ; //-1.443;// vert distance from GG centre to Tokamak Center line
	return;
*/
	FILE * fout = fopen("Decay_in_pl.txt", "w");
	
	DecayArray.RemoveAll();
	DecayPathArray.RemoveAll();
	SumPSIArray.RemoveAll();
	StepPSI = 0.05;
	int Kpsi = (int)ceil(1. / StepPSI);
	for (int k = 0; k < Kpsi; k++) SumPSIArray.Add(C3Point(0,0,0));

	if (AreaLong < PlasmaXmin) return;
	double Ymin, Ymax, Zmin, Zmax;
	C3Point P0, P1, P, Power;

	P0 = GetBeamFootLimits(PlasmaXmin, Ymin, Ymax, Zmin, Zmax);
	P1 = GetBeamFootLimits(PlasmaXmax, Ymin, Ymax, Zmin, Zmax);

	double power = 1;
	TorCentre.X = TorCentreX; //31.952; // horiz distance from GG centre to InjectPoint
	TorCentre.Y = TorCentreY; //- InjectAimR;
	TorCentre.Z = TorCentreZ; //-1.443;// vert distance from GG centre to Tokamak Center line
	C3Point D = P1 - TorCentre;
	double R = sqrt(D.X*D.X + D.Y*D.Y); // from tor vert axis
	double DR = R - PlasmaMajorR;
	double r = sqrt(DR*DR + D.Z*D.Z); // from toroidal axis (from Major radius)
	double Density, Te, Zeff, LinIonDensity; 
	double E = IonBeamEnergy *1000; //keV AtomEnergy;
	
	int A = abs(TracePartType); //BeamType; // mass number
	int AccountEl = 1;
	int AccountIon = 1;
	int AccountEx = 1;
	double SigmaEx, SigmaIon, SigmaEl, TotalSigma = 0;
	//double SigmaEnhancement = 0;
	
	double PSI = -1;
	double EkeVamu, Wh, Wd, Wt, Wimp, TotalW;
	double SigmaH =0, SigmaD, SigmaT, Simp, TotalImpurSum;
	int Aimp, Zimp;
	double Rtor, Ztor;

	double SumThickness = 0.;
	double L = 0, dL = 0.001;
	C3Point vect = P1 - P0;
	double TotDist = ModVect(vect);
	C3Point unitvect = vect / TotDist;
	dL = Min(TotDist * 0.02, dL);
	C3Point Ptor;
	int ipsi;// index of magsurf (psi=const)
	double dth; // local thickness


	//fprintf(fout, " X	PSI	\t Ne\t	Te \t Zeff \t SigmaH \t Stotal \t NSL \t Power \t LinIonDens\n\n");	
	fprintf(fout, "\t X \t  Y \t  Z \t R \t\t      PSI 	Density  TotalSigma  Power  ipsi\n");
	P = P0;
	while (L < TotDist) {
	
		if (!PlasmaLoaded) {// plasma profiles not set -> get them from simplified model
			r = GetR(P.X, P.Y, P.Z);// poloidal radius of plasma (double)
			ipsi = (int)floor(r / PlasmaMinorR / StepPSI); // index of magsurf (psi=const)
			Density = MaxPlasmaDensity * GetPlasmaDensityParabolic(r, 2);
			Te = MaxPlasmaTe * GetPlasmaTeParabolic(r, 2);
			Zeff = 1.7;
			Ptor = GetTorRZ(P.X, P.Y, P.Z);// 2D-point in tor frame C3Point(R,R,Z)
			Rtor = Ptor.X;
			//L += dL;
			//P = P0 + unitvect * L;

			// Sigmas <- old model of beam stopping --->
			SigmaEx = AccountEx * GetSigmaExchange(A, E);//
			SigmaIon = AccountIon * GetSigmaIon(A, E);//
			SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
			TotalSigma = (SigmaEx + SigmaIon + SigmaEl) * (1. + SigmaEnhancement);// 
		}
	
		else
		{	// plasma profiles + PSI are loaded -> use new model
			Ptor = GetTorRZ(P.X, P.Y, P.Z);// 2D-point in tor frame C3Point(R,R,Z)
			Rtor = Ptor.X;
			Ztor = Ptor.Z;
			PSI = GetPSI(Rtor, Ztor); // poloidal flux 0...1
			ipsi = (int)(PSI / StepPSI);

			if (PSI < 1.e-6 || PSI > 1) {// out of limits
				Density = 0;
				Power.X = 0;// liniondensity
				Power.Y = 0; // density
				Power.Z = power; // last value of neutral power
				TotalSigma = 0;
				ipsi = -1;
				
			}
			else { // 0 < PSI < 1
				C3Point PP = GetPlasmaTeNe(PSI); //  Ne,Te, Zeff
				Density = PP.X * (1.e19); //m-3
				Te = PP.Y; //keV
				Zeff = PP.Z; /////// PSI-profiles
				if (Density < 1.e-6) {
					AfxMessageBox("Density = 0");
					break;
				}

				// if loaded -> use Janev-Suzuki model
				EkeVamu = E / A; // beam energy per beam nucleo
				Wh = PlasmaWeightH; // hydrogen
				Wd = PlasmaWeightD; // deuterium
				Wt = PlasmaWeightT; // tritium
				TotalW = Wh + Wd + Wt;

				SigmaH = GetSumHDT_Suzuki(1, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
				SigmaD = GetSumHDT_Suzuki(2, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
				SigmaT = GetSumHDT_Suzuki(3, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
				TotalSigma = 0.0001 * (Wh * SigmaH + Wd * SigmaD + Wt * SigmaT) / TotalW;//cm2 -> m2


				/*	if (NofPlasmaImpur > 0) {// Single or many impurities plasma, Suzuki model

				if (NofPlasmaImpur == 1) {
					Aimp = GetFirstImp(); // 1st = single
					Simp = GetSumSz(Aimp, EkeVamu, Density, Te);
					TotalSigma = TotalSigma * (1 + (Zeff - 1) * Simp);  //m2
				} // single impur
				else { // > 1 impur
					TotalImpurSum = 0;
					for (int i = 0; i < NofPlasmaImpurMax; i++) {
						Aimp = PlasmaImpurA[i];
						Wimp = PlasmaImpurW[i];
						TotalW += Wimp;
						Simp = GetSumSz(Aimp, EkeVamu, Density, Te);
						Zimp = Aimp;
						TotalImpurSum += Wimp / TotalW * (Zimp - 1) * Simp;
					} // i
					TotalSigma = TotalSigma * (1 + TotalImpurSum); //(Zeff - 1) * Sz);  //m2
				}// > 1 impur
				} // plasma with impurities
			*/
			} // 0 < PSI < 1
		}

/*
		if (!PlasmaLoaded) {// old model of beam stopping --->

			SigmaEx = AccountEx * GetSigmaExchange(A, E);//
			SigmaIon = AccountIon * GetSigmaIon(A, E);//
			SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
			TotalSigma = (SigmaEx + SigmaIon + SigmaEl) * (1. + SigmaEnhancement);// 
		}

		else { // if loaded -> use Janev-Suzuki model

// ------------ Suzuki model of stopping
			//double EkeVamu, Wh, Wd, Wt, Wimp, TotalW;
			//double SigmaH, SigmaD, SigmaT, TotalSigma, Simp, TotalImpurSum;
			//int Aimp, Zimp;
			EkeVamu = E / A; // beam energy per beam nucleo
			Wh = PlasmaWeightH; // hydrogen
			Wd = PlasmaWeightD; // deuterium
			Wt = PlasmaWeightT; // tritium
			TotalW = Wh + Wd + Wt;

			SigmaH = GetSumHDT_Suzuki(1, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
			SigmaD = GetSumHDT_Suzuki(2, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
			SigmaT = GetSumHDT_Suzuki(3, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
			TotalSigma = 0.0001 * (Wh * SigmaH + Wd * SigmaD + Wt * SigmaT) / TotalW;//cm2 -> m2

	/*	if (NofPlasmaImpur > 0) {// Single or many impurities plasma, Suzuki model

			if (NofPlasmaImpur == 1) {
				Aimp = GetFirstImp(); // 1st = single
				Simp = GetSumSz(Aimp, EkeVamu, Density, Te);
				TotalSigma = TotalSigma * (1 + (Zeff - 1) * Simp);  //m2
			} // single impur
			else { // > 1 impur
				TotalImpurSum = 0;
				for (int i = 0; i < NofPlasmaImpurMax; i++) {
					Aimp = PlasmaImpurA[i];
					Wimp = PlasmaImpurW[i];
					TotalW += Wimp;
					Simp = GetSumSz(Aimp, EkeVamu, Density, Te);
					Zimp = Aimp;
					TotalImpurSum += Wimp / TotalW * (Zimp - 1) * Simp;
				} // i
				TotalSigma = TotalSigma * (1 + TotalImpurSum); //(Zeff - 1) * Sz);  //m2
			}// > 1 impur
		} // plasma with impurities
	*/
//		} // PSI + Profiles loaded -> use Janev-Suzuki model
	
// <---------Suzuki
		dth = Density * TotalSigma * dL;
		SumThickness += dth; // integral x0...x
		power = exp(-SumThickness); // power0 = 1
		LinIonDensity = Density * TotalSigma * power;
		
		Power.X = LinIonDensity; 
		Power.Y = Density; // already multiplied by * (1.e19); //m-3
		Power.Z = power;
		DecayArray.Add(Power);
		DecayPathArray.Add(P);
		if (ipsi >= 0 && ipsi < Kpsi) {
			SumPSIArray[ipsi].X += dL;
			SumPSIArray[ipsi].Y += dth;
			SumPSIArray[ipsi].Z += LinIonDensity;
		}

	//	fprintf(fout, " %8g	%8g	%12g %12g %6g	%12g	%12g		%8g	  %8g   %8g\n", 
		//		P.X, PSI, Density, Te, Zeff,   SigmaH, TotalSigma, SumThickness, power, LinIonDensity);	
		fprintf(fout, " %2g	%2g	%2g %4g     %12g %12g %12g %8g  \t %3d \n",
						P.X, P.Y, P.Z, Rtor, PSI, Density, TotalSigma, power, ipsi);
		L += dL;
		P = P0 + unitvect * L;
	} // while (L < TotDist) 

	fclose(fout);
	//power = exp(-SumThickness); // power0 = 1
	//return endpower;
}

void CBTRDoc::SetBeamRayDecay(C3Point P0, C3Point P1) // not called more (in past - by PlotBeamDecay)
// clears arrays -> calls GetDecayBetween to fill - fixed step along L
{
	if (AreaLong < PlasmaXmin) return;
	//FILE * fout = fopen("Ray_in_pl.txt", "w");

	DecayArray.RemoveAll();
	DecayPathArray.RemoveAll();
	SumPSIArray.RemoveAll();
	
	StepPSI = 0.02;
	int Kpsi = (int)ceil(1. / StepPSI);
	for (int k = 0; k <= Kpsi; k++)
		SumPSIArray.Add(C3Point(0, 0, 0)); // accumulate IonPower, Density*Sigma, Npower

	double Lpath = GetDistBetween(P0, P1); //P1.X - P0.X;
	StepPath = 0.0002 * Lpath;// PathArray
	C3Point vectL = (P1 - P0) / Lpath * StepPath;
	
	int Kpath = (int)ceil(Lpath / StepPath);
	for (int k = 0; k <= Kpath; k++) 
		DecayPathArray.Add(C3Point(P0 + vectL * k)); // set points along path
	for (int k = 0; k <= Kpath; k++)
		DecayArray.Add(C3Point(0, 0, 0)); // set rnorm, psi, power along path

	double decay = GetFillDecayBetween(P0, P1, 1); //fill arrays, return neutral power / power0

	//fclose(fout);
}

double CBTRDoc:: GetDecay(C3Point P0, C3Point P1)// calls GetDecayBetween
{
	double decay = 1;
	if (P1.X < PlasmaXmin) return decay;
	//if (GetDistBetween(P0, P1) < StepPath) return decay;
		
	//decay = GetDecayBetween(P0, P1); // not called any more
	/*double PathLen = ModVect(P1 - P0);
	int Npath = 1000;
	double StepL = PathLen / Npath;
	//pPlasma->SetPath(P0, P1, StepL);
	//pPlasma->SetDecayArrays();// thin ray
	//pPlasma->AddDecayArrays();// BAD - Tracers will overlap!! (Nrays++)*/

	decay = pPlasma->GetPowerDecay(P0, P1, 0.01);

	return decay;

/*	if (!PlasmaLoaded || !OptBeamInPlasma) return 1;
	
	double power = 1, power0, power1;
	C3Point P0, P1;
	int Nmax = DecayArray.GetUpperBound();
	 
	if (P.X > DecayPathArray[Nmax].X) return DecayArray[Nmax].Z;
	if (P.X < DecayPathArray[0].X) return 1;
	
	for (int i = 0; i < Nmax; i++) {
		 P0 = DecayPathArray[i];  P1 = DecayPathArray[i+1];
		 if (P.X >= P0.X && P.X < P1.X) {
			 power0 = DecayArray[i].Z; power1 = DecayArray[i+1].Z;
			 power = power0 + (power1 - power0) * (P.X - P0.X) / (P1.X - P0.X);
			 return power;
		 } //if
	 } // for
	
	return power;*/
}

double CBTRDoc::GetDecayBetween(C3Point P0, C3Point P1) // calculate decay - not filling arrays
															
{
	int Kpsi = MagSurfDim;// SumPSIArray.GetSize(); // (int)ceil(1. / StepPSI);

	double Lpath = GetDistBetween(P0, P1); 
	int Kpath = DecayPathArray.GetSize() - 1;// (int)ceil(Lpath / StepPath);

	double decay = 0;
	double Npower0 = 1;
	double IonPower = 0;
	double dth, SumThickness = 0;
	//double dNpower, dIonPower;// 1/m3 - volume power densities

	int ipsi, ipath;
	double r, rnorm = 1, Rtor, Ztor;
	C3Point Ptor;
	double Vsurf; // PSI-volume (within StepPSI)
	double Density, Te;
	int AccountEl = 1;
	int AccountIon = 1;
	int AccountEx = 1;
	double SigmaEx, SigmaIon, SigmaEl, TotalSigma = 0;
	//double SigmaEnhancement = 0;
	int A = abs(TracePartType); //BeamType; // mass number
	int Knucl = TracePartNucl;
	double E = IonBeamEnergy * 1000/ Knucl; //keV AtomEnergy;
	CString S;
	C3Point P = P0;
	double L = 0;
	double Lmax = Lpath;// GetDistBetween(P0, P1);
	double dL = Lpath / Kpath;// *0.01;// *PlasmaMinorR;//Lmax;
	double PSI = -1;
	double Npower = Npower0;
	double Xloc, Yloc; // local coord at hor/vert planes
	SigmaEx = AccountEx * GetSigmaExchange(A, E);//
	SigmaIon = AccountIon * GetSigmaIon(A, E);//
	//SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
	 //TotalSigma = 1.e-20; // CONST!!!!
	double Sigma0 = GetSigmaEkeV(E); //Min = 1.e-20;
	double dSigma = SigmaEnhancement;
	double mult = 1 + dSigma;
	int k = 0;
	DecayArray[0].X += IonPower;// rnorm;
	DecayArray[0].Y += 1;
	DecayArray[0].Z += Npower;// k = 0

	while (k < Kpath) { //(L < Lmax) {
		k++;
		L = k * dL;
		P = P0 + (P1 - P0) * L / Lmax;
		
		if (!PlasmaLoaded) {
			r = GetR(P.X, P.Y, P.Z);// poloidal radius of plasma (double)
			rnorm = r / PlasmaMinorR;
			if (rnorm > 1) continue;
			
			//ipsi = (int)floor(r / PlasmaMinorR / StepPSI); // index of magsurf (psi=const)
			Density = MaxPlasmaDensity * GetPlasmaDensityParabolic(r, 2);
			Te = MaxPlasmaTe * GetPlasmaTeParabolic(r, 2);
			//Zeff = 1.7;
			// Sigmas <- old model of beam stopping --->
			//SigmaEx = AccountEx * GetSigmaExchange(A, E);//
			//SigmaIon = AccountIon * GetSigmaIon(A, E);//
			//SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
			//TotalSigma = (SigmaEx + SigmaIon + SigmaEl) * (1. + SigmaEnhancement);//
			PSI = rnorm*rnorm;
			TotalSigma = Sigma0 * mult;// *(1 - PSI));
			//Vsurf = rnorm;// *StepPSI; // r*dr;
		}
		else { // Plasma Loaded
			Ptor = GetTorRZ(P.X, P.Y, P.Z);// 2D-point in tor frame C3Point(R,R,Z)
			Rtor = Ptor.X;
			Ztor = Ptor.Z;
			PSI = GetPSI(Rtor, Ztor); // poloidal flux 0...1
			if (PSI >= 0) rnorm = sqrt(PSI);
			else continue;
			//Vsurf = StepPSI;// GetPSIrdr(PSI);
			Density = GetPlasmaTeNe(PSI).X * (1.e19); //m-3; //  Ne,Te, Zeff
			Te = GetPlasmaTeNe(PSI).Y;
			//TotalSigma = GetStopSigma(PSI);// Suzuki - ???
			//SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
			//TotalSigma = (SigmaEx + SigmaIon + SigmaEl) * (1. + SigmaEnhancement);//old
			//TotalSigma = 6.e-21 * (1.+ SigmaEnhancement); // m2 - sigma(0,1) from PAA table 
			TotalSigma = Sigma0 * mult;// *(1 - PSI));
		}
		dth = Density * TotalSigma * dL;
		SumThickness += dth;
		decay = exp(-SumThickness);
		IonPower = Npower * dth;//linear density
		Npower = Npower - IonPower; // Npower0 * decay;// Npower0 = 1
	}// (L < Lmax)
	
	return decay;
}

double CBTRDoc::GetFillDecayBetween(C3Point P0, C3Point P1, double Power) // fill arrays - along path and along PSI
// PSI, SumThick, decay
{
	//double StepPath = 0.1 * PlasmaMinorR;// for DecayPathArray
	int Kpsi = MagSurfDim;// SumPSIArray.GetSize(); // (int)ceil(1. / StepPSI);
	
	double Lpath = GetDistBetween(P0, P1); //P1.X - P0.X;
	//StepPath = 0.02 * Lpath;// PathArray
	//C3Point vectL = (P1 - P0) / Lpath * StepPath;
	int Kpath = DecayPathArray.GetSize() - 1;// (int)ceil(Lpath / StepPath);

	double decay = 0;
	double Npower0 = Power;
	double IonPower = 0;
	double dth, SumThickness = 0;
	//double dNpower, dIonPower;// 1/m3 - volume power densities
	
	int ipsi, ipath;
	double r, rnorm = 1, Rtor, Ztor;
	C3Point Ptor;
	double Vsurf; // PSI-volume (within StepPSI)
	double Density, Te;
	int AccountEl = 1;
	int AccountIon = 1;
	int AccountEx = 1;
	//double SigmaEx, SigmaIon, SigmaEl;
	double TotalSigma = 0;
	//double SigmaEnhancement = 1;
	int A = abs(TracePartType); //BeamType; // mass number
	int Knucl = TracePartNucl;
	double E = IonBeamEnergy * 1000 /Knucl; //keV AtomEnergy;
	CString S;
	C3Point P = P0;
	double L = 0;
	double Lmax = Lpath;// GetDistBetween(P0, P1);
	double dL = Lpath / Kpath;// *0.01;// *PlasmaMinorR;//Lmax;
	double PSI = -1;
	double Npower = Npower0;
	double Xloc, Yloc; // local coord at hor/vert planes
	//SigmaEx = AccountEx * GetSigmaExchange(A, E);//
	//SigmaIon = AccountIon * GetSigmaIon(A, E);//
	//SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
	//TotalSigma = 1.e-20; // CONST!!!!
	double Sigma0 = GetSigmaEkeV(E);// 1.e-20;
	double dSigma = SigmaEnhancement;
	//if (fabs(dSigma) < 1.e-6) dSigma = 1.e-6;

	int k = 0;
	DecayArray[0].X += IonPower;// rnorm;
	DecayArray[0].Y += 1;
	DecayArray[0].Z += Npower;// k = 0

	while (k < Kpath) { //(L < Lmax) {
		k++;
		L = k * dL;
		P = P0 + (P1 - P0) * L / Lmax;
	/*	if (L > Lmax) { // stop on P1
			dL = GetDistBetween(P, P1);// decrease step at final point
			P = P1;
		} */

		if (!PlasmaLoaded) {
			r = GetR(P.X, P.Y, P.Z);// poloidal radius of plasma (double)
			rnorm = r / PlasmaMinorR;
			if (rnorm > 1) {
				DecayArray[k].X += 0;// rnorm;
				DecayArray[k].Y += 1;
				DecayArray[k].Z += Npower;
				continue;
			}
			//ipsi = (int)floor(r / PlasmaMinorR / StepPSI); // index of magsurf (psi=const)
			Density = MaxPlasmaDensity * GetPlasmaDensityParabolic(r, 2);
			Te = MaxPlasmaTe * GetPlasmaTeParabolic(r, 2);
			//Zeff = 1.7;
			// Sigmas <- old model of beam stopping --->
			//SigmaEx = AccountEx * GetSigmaExchange(A, E);//
			//SigmaIon = AccountIon * GetSigmaIon(A, E);//
			//SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
			//TotalSigma = (SigmaEx + SigmaIon + SigmaEl) * (1. + SigmaEnhancement);//
			PSI = rnorm;// *rnorm;
			TotalSigma = Sigma0 * (1 + dSigma);// *(1 - PSI));
			//Vsurf = rnorm;// *StepPSI; // r*dr;
		}
		else { // Plasma Loaded
			Ptor = GetTorRZ(P.X, P.Y, P.Z);// 2D-point in tor frame C3Point(R,R,Z)
			Rtor = Ptor.X;
			Ztor = Ptor.Z;
			PSI = GetPSI(Rtor, Ztor); // poloidal flux 0...1
			if (PSI >= 0) rnorm = sqrt(PSI);
			else {
				DecayArray[k].X += 0;// IonPower or thickness
				DecayArray[k].Y += 1;
				DecayArray[k].Z += Npower;
				continue;
			}
			
			//Vsurf = StepPSI;// GetPSIrdr(PSI);
			Density = GetPlasmaTeNe(PSI).X * (1.e19); //m-3; //  Ne,Te, Zeff
			Te = GetPlasmaTeNe(PSI).Y;
			//TotalSigma = GetStopSigma(PSI);// Suzuki - ???
			//SigmaEl = AccountEl * GetSigmaElectron(A, E, Te);//
			//TotalSigma = (SigmaEx + SigmaIon + SigmaEl) * (1. + SigmaEnhancement);//old
			
			//TotalSigma = 6.e-21 * (1. + SigmaEnhancement); // m2 - sigma(0,1) from PAA table 
			TotalSigma = Sigma0 * (1 + dSigma);// *(1 - PSI));
			
			/*if (Density < 1.e-6 || TotalSigma < 1.e-18 && PSI < 1) {
				S.Format("Density = %g Sigma = %g PSI = %g", Density, TotalSigma, PSI);
				AfxMessageBox(S);break;
			}*/
		}
		
		dth = Density * TotalSigma * dL;
		SumThickness += dth; 
		decay = exp(-SumThickness);
		IonPower = Npower * dth;//linear density
		Npower =  Npower - IonPower; // Npower0 * decay;// Npower0 = 1
		
		DecayArray[k].X += dth;// IonPower;// rnorm;
		DecayArray[k].Y += PSI;
		DecayArray[k].Z += Npower;
		DecayPathArray[k].Y += Density;
		DecayPathArray[k].Z += TotalSigma;

		Xloc = P.X - pBeamHorPlane->Orig.X;
		Yloc = P.Y - pBeamHorPlane->Orig.Y;
		pBeamHorPlane->Load->Distribute(Xloc, Yloc, IonPower);

		Xloc = P.X - pBeamVertPlane->Orig.X;
		Yloc = P.Z - pBeamVertPlane->Orig.Z;
		pBeamVertPlane->Load->Distribute(Xloc, Yloc, IonPower);
						
		ipsi = (int)floor(PSI / StepPSI);
		if (PSI > 0 && ipsi > 0 && ipsi < Kpsi) {
			SumPSIArray[ipsi].X += IonPower;
			SumPSIArray[ipsi].Y += dL;// PSIvolume[ipsi];//dth; // SumPath within StepPSI
			SumPSIArray[ipsi].Z += Npower;
		}
			
	}// (L < Lmax)
			
	return decay;
}

double CBTRDoc::GetSigmaEkeV(double EkeV)
{
	double CS = 0;
	double x = EkeV;
	double x0, x1, cs0, cs1;
	int n = CSarray.GetSize();
	if (n == 0) return CS;
	if (n == 1) return CSarray[0].Y * (1.e-4);
	else {
	for (int i = 0; i < n-1; i++) {
		 if (x >= CSarray[i].X && x <= CSarray[i+1].X) {
			 x0 = CSarray[i].X;  x1 = CSarray[i+1].X;
			 cs0 = CSarray[i].Y; cs1 = CSarray[i+1].Y;
			 CS = cs0 + (cs1-cs0) * (x-x0) / (x1-x0);
			 return (CS *1.e-4);
		 } //if
	 } // for
	}
	 return (CS * 1.e-4);
}

double CBTRDoc::GetStopSigma(double PSI)
{
	double TotalSigma = 0;
	if (PSI < 0 || PSI > 1) {// out of limits
		return TotalSigma; // 0
	}
	else { // 0 < PSI < 1
		C3Point PP = GetPlasmaTeNe(PSI); //  Ne,Te, Zeff
		double Density = PP.X * (1.e19); //m-3
		double Te = PP.Y; //keV
		double Zeff = PP.Z; /////// PSI-profiles

		// if loaded -> use Janev-Suzuki model
		int A = abs(TracePartType); //BeamType; // mass number
		double E = IonBeamEnergy * 1000; //keV AtomEnergy;
		double EkeVamu = E / A; // beam energy per beam nucleo

		int AccountEl = 1;
		int AccountIon = 1;
		int AccountEx = 1;
		//double SigmaEx, SigmaIon, SigmaEl, 
		double TotalSigma = 0;
		double SigmaEnhancement = 0;
		double Wh, Wd, Wt, Wimp, TotalW;
		double SigmaH = 0, SigmaD, SigmaT, Simp, TotalImpurSum;
		Wh = PlasmaWeightH; // hydrogen
		Wd = PlasmaWeightD; // deuterium
		Wt = PlasmaWeightT; // tritium
		TotalW = Wh + Wd + Wt;

		SigmaH = GetSumHDT_Suzuki(1, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;//cm2
		SigmaD = GetSumHDT_Suzuki(2, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
		SigmaT = GetSumHDT_Suzuki(3, EkeVamu, Density, Te) * (1.e-16) / EkeVamu;
		TotalSigma = 0.0001 * (Wh * SigmaH + Wd * SigmaD + Wt * SigmaT) / TotalW;//cm2 -> m2
	}

	return TotalSigma;
}

C3Point CBTRDoc:: GetPlasmaTeNe(double PSI) // ref to poloidal flux
{
	C3Point P0, P1, P(0,0,0);
	double psi0, psi1;
	int Kmax = PlasmaProfilePSI.GetUpperBound();
	if (PSI < 0) return P;
	if (Kmax < 1) return P;
	if ((PSI - PlasmaProfilePSI[Kmax]) * (PSI - PlasmaProfilePSI[0]) > 0) return P;//PlasmaProfile[Kmax]; // Te/Ne at separatrix
	//if (PSI <= PlasmaProfilePSI[0]) return P;// PlasmaProfile[0];
	
	for (int i = 0; i < Kmax; i++) {
		 psi0 = PlasmaProfilePSI[i];  psi1 = PlasmaProfilePSI[i+1];
		 if ((PSI - psi0) * (PSI - psi1)<= 1.e-12) {
			 P0 = PlasmaProfileNTZ[i]; P1 = PlasmaProfileNTZ[i+1];
			 P = P0 + (P1 - P0) * (PSI - psi0) / (psi1 - psi0);
			 return P;
		 } //if
	 } // for
	
	return P;
}

void CBTRDoc:: SetBeamDecay() //previously called by PlotBeamDecay, CalculateTracks
{ // calls GetFillDecayBetween
	double decay;// = GetDecayBetween(P0, P1); //fill arrays, return neutral power / power0
	CWaitCursor wait;
	double y0, z0, Ystart, Zstart, Yfin, Zfin;
	C3Point Pstart, Pfin;
	double Xstart = DecayPathArray[0].X;
	int Kmax = DecayPathArray.GetUpperBound();
	double Xfin = DecayPathArray[Kmax].X;//PlasmaXmax + 1;
	
	// actual beam axes
	for (int is = 0; is < (int)NofChannelsHor; is++)  ///NofChannelsHor;
		for (int js = 0; js < (int)NofChannelsVert; js++)   ///NofChannelsVert;
			for (int i = 0; i < (int)NofBeamletsHor; i++)
				for (int j = 0; j < (int)NofBeamletsVert; j++)

				{
					y0 = BeamletPosHor[is * (int)NofBeamletsHor + i];
					z0 = BeamletPosVert[js * (int)NofBeamletsVert + j];

					Ystart = y0 + Xstart * tan(BeamletAngleHor[is * (int)NofBeamletsHor + i]);
					Zstart = z0 + Xstart * tan(BeamletAngleVert[js * (int)NofBeamletsVert + j]);
					Yfin = y0 + Xfin * tan(BeamletAngleHor[is * (int)NofBeamletsHor + i]);
					Zfin = z0 + Xfin * tan(BeamletAngleVert[js * (int)NofBeamletsVert + j]);

					Pstart = C3Point(Xstart, Ystart, Zstart);
					Pfin = C3Point(Xfin, Yfin, Zfin);
					//SetBeamRayDecay(Pstart, Pfin);
					decay = GetFillDecayBetween(Pstart, Pfin, 1); //fill arrays, return neutral power / power0
				}


	// thin/thick beam = axis ray + parallel rays
/*	double Ymin, Ymax, Zmin, Zmax;
	C3Point P0 = GetBeamFootLimits(Xstart, Ymin, Ymax, Zmin, Zmax);
	C3Point P1 = GetBeamFootLimits(PlasmaXmax, Ymin, Ymax, Zmin, Zmax);
	double th = 1.0;// 1 cm
	double dy =  0.2 * th; // beam port width
	double dz =  0.4 * th; // beam port height
	double y, z;
	int ky = 10, kz = 10;
	for (int i = 0; i <= ky; i++)
	for (int j = 0; j <= kz; j++) {
	y = P0.Y - dy * 0.5 + dy / ky * i;
	z = P0.Z - dz * 0.5 + dz / kz * j;
	Pstart = C3Point(P0.X, y, z);
	y = P1.Y - dy * 0.5 + dy / ky * i;
	z = P1.Z - dz * 0.5 + dz / kz * j;
	Pfin = C3Point(P1.X, y, z);
	decay = GetFillDecayBetween(Pstart, Pfin, 1); // fill arrays
	}
	*/

		/*	SumPSIArray[ipsi].X += IonPower;
			SumPSIArray[ipsi].Y += dL;// PSIvolume[ipsi];//dth; // SumPath within StepPSI
			SumPSIArray[ipsi].Z += Npower;*/
	for (int k = 0; k < MagSurfDim; k++) {
		SumPSIArray[k].X = SumPSIArray[k].X / PSIvolume[k]; // IonPower/ V
		SumPSIArray[k].Y = SumPSIArray[k].Z / SumPSIArray[k].Y; //Npower / L
		SumPSIArray[k].Z = SumPSIArray[k].Z / PSIvolume[k]; // Npower 
	}
} 

void CBTRDoc::CalculateBeamPlasma() // 0 - thin, 1 -  parallel, 2 - focused
{
	int bopt = pPlasma->BeamOpt;
	if (bopt == 0) CalculateThinDecay(); //run ray beam along axis
	else if (bopt == 1) CalculateThickParallel(); // parallel set 11x11
	else CalculateThickFocused(); // beamopt =2 real bml axes
}

void CBTRDoc::PlotBeamDecay(int bopt, int popt) // calculate and plot the decay along set of beam rays
{
	int AccountEl = 1;
	int AccountIon = 1;
	int AccountEx = 1;
	
	double AtomEnergy = IonBeamEnergy * 1000; //keV
	int BeamType = abs(TracePartType);
	int beamopt = bopt; // beam
	int pathopt = popt; // path
	//pPlasma->SetCalcOpt(pathopt);

	//double SigmaEnhancement = 0;
	//SetPlasmaTarget(); //init plasma object + geom
	//CalculateThinDecay();
		
	CInjectDlg dlg;
	dlg.doc = this;
	CString S = "plasma: ";

	//while (idres != IDCANCEL) {
	if (pPlasma->PSIloaded) S = S + "PSI ";
	if (pPlasma->ProfilesLoaded) S = S + "prof";
	if (pPlasma->SigmaLoaded) S = S + " sigmas";
	//AfxMessageBox(S);
	dlg.m_Sort = BeamType - 1;
	dlg.m_Energy1 = AtomEnergy;
	dlg.m_Density = MaxPlasmaDensity;
	dlg.m_Te = MaxPlasmaTe;
	dlg.m_Rmajor = PlasmaMajorR;
	dlg.m_Rminor = PlasmaMinorR;
	dlg.m_Sigma0 = SigmaBase;
	dlg.m_Enhance = SigmaEnhancement;
	dlg.m_TorCentreX = TorCentreX;
	dlg.m_TorCentreY = TorCentreY;
	dlg.m_TorCentreZ = TorCentreZ;
	//dlg.m_AimR = -TorCentre.Y;//InjectAimR;
	dlg.m_OptEl = AccountEl;
	dlg.m_OptIon = AccountIon;
	dlg.m_OptExch = AccountEx;
	dlg.m_Rays = beamopt;
	dlg.m_Path = pathopt;
	
	int idres = dlg.DoModal();
	
	if (idres == IDOK) { // || idres == IDCANCEL){ // APPLY or CLOSE
		//dlg.UpdateData(TRUE);
		BeamType = (dlg.m_Sort) + 1;
		TracePartType = -BeamType; // Neg Ions
		IonBeamEnergy = dlg.m_Energy1 * 0.001;
		//TorCentre.Y = - dlg.m_AimR;
		TorCentreX = dlg.m_TorCentreX;
		TorCentreY = dlg.m_TorCentreY;
		TorCentreZ = dlg.m_TorCentreZ;
		TorCentre.X = TorCentreX;
		TorCentre.Y = TorCentreY;
		TorCentre.Z = TorCentreZ;

		AtomEnergy = dlg.m_Energy1;
		MaxPlasmaDensity = dlg.m_Density;
		MaxPlasmaTe = dlg.m_Te;
		PlasmaMajorR = dlg.m_Rmajor;
		PlasmaMinorR = dlg.m_Rminor;
		SigmaBase = dlg.m_Sigma0;
		SigmaEnhancement = dlg.m_Enhance; // 
		//AccountEl = dlg.m_OptEl; // not used !!
		//AccountIon = dlg.m_OptIon; // not used  !!
		//AccountEx = dlg.m_OptExch; // not used  !!
		beamopt = dlg.m_Rays;
		pathopt = dlg.m_Path;
		
		SetPlasmaTarget(); //init plasma object, Nray = -1, plasma->ClearArrays(), set beam Ray (axial)
		// SetPlasmaGeom();// set beam-tor geometry, plasma Rminor/Rmajor, Xmin/Xmax
		pPlasma->SetBeamCalcOpt(beamopt, pathopt);// option CalcPlot is used only for plot, nowhere else
		
		OnShow();
		PlotBeamDecay(beamopt, pathopt); // self call - return back to dlg

	}// OK or CANCEL

	else { // trace beam
		//CalculateBeamPlasma();
		//if (beamopt == 0) CalculateThinDecay(); //run ray beam along axis
		//else if (beamopt == 1) CalculateThickParallel(); // parallel set 11x11
		//else CalculateThickFocused(); // beamopt =2 real bml axes
		//pPlasma->SetCalcOpt(pathopt);// option CalcPlot is used only for plot, nowhere else
		//	pBeamHorPlane->Load->Clear(); // created in SetPlatesNBI
	    //	pBeamVertPlane->Load->Clear();// created in SetPlatesNBI
		//SetBeamDecay(); // calls GetFillDecayBetween - to replace!
		//pBeamHorPlane->Load->SetSumMax();
		//pBeamVertPlane->Load->SetSumMax();
		//TracksCalculated = 1;// otherwise will recalculate tracks!!!
	}// Apply (OK) 

}

void CBTRDoc::PlotPSIArrays() // profiles along PSI
{
	CArray<double, double> PosX;
	CArray<double, double> PosY;
	//CArray<double, double> NCurr;
	PLOTINFO DecayPlot;
	int idres = IDOK;
	
	DecayPlot.Caption = "Plasma parameters across norm. poloidal flux";   //"Beam deposition across magnetic surfaces" ;
	DecayPlot.LabelX = "PSI norm";
	DecayPlot.LabelY = "Te, Ne, Vol   "; 
	DecayPlot.LimitX = 1;
	DecayPlot.LimitY = 1;

	DecayPlot.CrossX = 0.1;
	DecayPlot.CrossY = 0.1;
	DecayPlot.Line = 1;
	DecayPlot.Interp = 1;
	DecayPlot.PosNegX = FALSE;
	DecayPlot.PosNegY = FALSE;

	//C3Point P;
	double psi, Te, Ne, Vol, Tmax, Nmax;
	double V1max = 0, V2max = 0, V3max = 0;
	double fStep = pPlasma->StepFlux;//pDoc->StepPSI
	int Kmax = (int)ceil(1.0 / fStep); 
	if (pPlasma->ProfilesLoaded) Kmax = pPlasma->Nprof;
	Tmax = pPlasma->Temax;
	Nmax = pPlasma->Nemax;
	for (int i = 0; i < Kmax; i++) { 
		//P = SumPSIArray[i];
		psi = pPlasma->PSIprof[i];// *fStep;
		PosX.Add(psi);// (StepPSI * i);
		Te = pPlasma->TeNorm[i]; // GetPlasmaTePSI(psi);
		PosY.Add(Te);
		V1max = max(V1max, Te);
	}
	DecayPlot.N1 = PosX.GetSize();

	for (int i = 0; i < Kmax; i++) { // Npower div PSI volume
		//P = SumPSIArray[i];
		psi = pPlasma->PSIprof[i];// i * fStep;
		PosX.Add(psi);// (StepPSI * i);
		Ne = pPlasma->NeNorm[i]; //pPlasma->GetPlasmaNePSI(psi);
		PosY.Add(Ne);
		V2max = max(V2max, Ne);
	}
	DecayPlot.N2 = PosX.GetSize();

	for (int i = 0; i < Kmax; i++) { // plot Npower		
		//P = SumPSIArray[i];
		psi = pPlasma->PSIprof[i];// i * fStep;
		PosX.Add(psi);// (StepPSI * i);
		Vol = pPlasma->GetPlasmaVolPSI(psi);
		PosY.Add(Vol);
		V3max = max(V3max, Vol);
	}
	DecayPlot.N = PosX.GetSize();

	// Normalize
	int k;
	for (k = 0; k < DecayPlot.N1; k++) PosY[k] = PosY[k] / V1max;
	for (k = DecayPlot.N1; k < DecayPlot.N2; k++) PosY[k] = PosY[k] / V2max;
	for (k = DecayPlot.N2; k < DecayPlot.N; k++) PosY[k] = PosY[k] / V3max;
	
	DecayPlot.DataX = &PosX;
	DecayPlot.DataY = &PosY;

	//DecayPlot.Caption += S;
	CString S, Sopt;
	if (pPlasma->ProfilesLoaded) Sopt = "ON";
	else Sopt = "OFF";
	S.Format(" real %s Tmax = %g, Nmax = %g, VMax = %g ", Sopt, Tmax, Nmax, V3max);
	DecayPlot.Caption += S;

	CPlotDlg pdlg;
	pdlg.Plot = &DecayPlot;
	pdlg.InitPlot();
	if (pdlg.DoModal() == IDCANCEL) idres = IDCANCEL;
	PosX.RemoveAll();
	PosY.RemoveAll();

}

void CBTRDoc::PlotDecayArray(int opt)// = beamopt 0 - thin, 1 - par, 2 - real
{

	CArray<double, double> PosX;
	CArray<double, double> PosY;
	CArray<C3Point, C3Point> * path = &(pPlasma->AverPath);
	CArray<double, double> * Power = &(pPlasma->SumPower);
	CArray<double, double> * NL = &(pPlasma->SumNL);
	CArray<double, double> * IonRate = &(pPlasma->SumIonRate);
	CArray<int, int> * Npart = &(pPlasma->SumPart);
	int Nrays = pPlasma->Nrays;
	int Kmax = path->GetSize()-1;// AverPath
	CArray<C3Point, C3Point> fPath;// create for R/flux option
	CArray<int, int> Np; // create for 1 ray along path
	
	C3Point P;
	int CalcOpt = pPlasma->CalcOpt;// 0 -path 1 - rad
	//double Npower0, Npower1;
	double df = pPlasma->StepFlux;
	int N;// , N0, N1;
	
	
	double Percent = pPlasma->RayDecay * 100; //thin
	if (opt > 0) Percent = pPlasma->SumDecay * 100;// thick
		
	if (CalcOpt == 1) {//along radius -> generate "path" - array along R/flux
		Kmax = pPlasma->Npsi;
		for (int i = 0; i <= Kmax; i++) { // generate "points" - with const stepFlux along R/flux
			P = C3Point(i * df, 0, 0);
			fPath.Add(P);
		}
		path = &fPath;
		Power = &(pPlasma->fPower);
		NL = &(pPlasma->fNL);
		IonRate = &(pPlasma->fIonRate);
		Npart = &(pPlasma->fSumPart);
	} //  opt  R/flux

	else if (opt == 0 && CalcOpt == 0 )  { //i.e. CalcOpt != 1 along path, 1 ray -> create Npart=1
		path = &(pPlasma->Path);
		Power = &(pPlasma->Power);
		NL = &(pPlasma->NL);
		IonRate = &(pPlasma->IonRate);
		Kmax = pPlasma->Npath;
		
		for (int i = 0; i <= Kmax; i++) {// create Npart = 1 everywhere
			Np.Add(1);
		}
		Npart = &Np;
		
	}
	else { // leave default AverPath, Sumarrays
		}
	
	//CArray<double, double> NCurr;
	PLOTINFO DecayPlot;
	int idres = IDOK;
	int BeamType = abs(TracePartType);
	CString S;
	CString Sopt;
	if (pPlasma->ProfilesLoaded) Sopt = "EQDSK";
	else Sopt = "PARAB";
	if (BeamType == 2) S.Format("D beam in %s plasma:  ", Sopt);
	else S.Format("H Beam in %s plasma:", Sopt);
	DecayPlot.Caption = S;
	DecayPlot.LabelX = "Xb-Xo, m";
	if (CalcOpt == 1) DecayPlot.LabelX = "psi";
	//DecayPlot.Caption = "Beam deposition across magnetic surfaces";
	//DecayPlot.LabelX = "PSI norm";
	DecayPlot.LabelY = "IRate, PSI/Volume, NPower"; //"NSdL, PSI, Npower   "; 
		//+IonPower, +SumThickness, +Npower
	
	if (pPlasma->CalcOpt == 0) DecayPlot.LimitX = floor(PlasmaXmax - PlasmaXmin) + 1;
	else DecayPlot.LimitX = 1;	
	DecayPlot.LimitY = 1;

	if (pPlasma->CalcOpt == 0) DecayPlot.CrossX = 1;
	else DecayPlot.CrossX = 0.1;

	DecayPlot.CrossY = 0.1;
	DecayPlot.Line = 1;
	DecayPlot.Interp = 1;
	DecayPlot.PosNegX = FALSE;
	DecayPlot.PosNegY = FALSE;

	double x, val, psi;
	P = path->GetAt(0);
	double Xstart = P.X;// DecayPathArray[0].X;
	double Vol = 1.0; // default psi Vol
	
	double V1max = 0, V2max = 0, V3max = 0;
	//int Kmax = pPlasma->Npath;//DecayPathArray.GetSize(); // (int)ceil((PlasmaXmax - PlasmaXmin) / StepPath);
	for (int i = 0; i < Kmax; i++) { // rn
		P = path->GetAt(i);
		x = P.X - Xstart;
		N =  Npart->GetAt(i);
		if (N < 1) N = 1;
		if (CalcOpt == 1) Vol = pPlasma->GetPlasmaVolPSI(x + 0.5*df);// fVolume[i];//;
		else Vol = 1.0;
		val = (IonRate->GetAt(i)) / Vol;// P = DecayArray[i];
		PosX.Add(x);// (StepPath * (i + 0.5));
		PosY.Add(val);//(P.X);
		V1max = max(V1max, val);
	}
	DecayPlot.N1 = PosX.GetSize();

	for (int i = 0; i < Kmax; i++) { // psi
		P = path->GetAt(i);
		x = P.X - Xstart;
		N = Npart->GetAt(i);
		if (N < 1) N = 1;
		if (CalcOpt == 1) val = pPlasma->GetPlasmaVolPSI(x); //fVolume[i]; // show PSI volume
		else val = NL->GetAt(i) / N;// show <Ne>
		PosX.Add(x);// (StepPath * (i + 0.5));
		PosY.Add(val);//(P.Y);
		V2max = max(V2max, val);
	}
	DecayPlot.N2 = PosX.GetSize();

		
	for (int i = 0; i < Kmax; i++) { // Npower
		P = path->GetAt(i);
		x = P.X - Xstart;
		N = Npart->GetAt(i);
		if (N < 1) N = 1;
		if (CalcOpt == 1) Vol = pPlasma->GetPlasmaVolPSI(x + 0.5 * df); //fVolume[i];
		else Vol = 1.0;
		val = (Power->GetAt(i)) / Vol;
		PosX.Add(x);// (StepPath * (i + 0.5));
		PosY.Add(val);
		V3max = max(V3max, val);
	}
	
	DecayPlot.N = PosX.GetSize();

	// Normalize
	int k;
	for (k = 0; k < DecayPlot.N1; k++) PosY[k] = PosY[k] / V1max;
	for (k = DecayPlot.N1; k < DecayPlot.N2; k++) PosY[k] = PosY[k] / V2max;
	for (k = DecayPlot.N2; k < DecayPlot.N; k++) PosY[k] = PosY[k] / V3max;

	DecayPlot.DataX = &PosX;
	DecayPlot.DataY = &PosY;

	double sigma = pPlasma->Sigma;
	double mult = pPlasma->SigMult;
	double lost = 100 - Percent;//power onto FW (not captured)
	double Vbeam = pPlasma->Ray.Vmod;
	
	S.Format("%d rays, Ytor = %6.2f, Ztor= %6.2f, X = %5.2f->%5.2f, v = %e, SigMult = %4.2f Capt/lost = %7.4f / %5.4f %% %d pts",
		Nrays, TorCentreY, TorCentreZ, PlasmaXmin, PlasmaXmax, Vbeam, mult, Percent, lost, Kmax);
	DecayPlot.Caption += S;

	CPlotDlg pdlg;
	pdlg.Plot = &DecayPlot;
	pdlg.InitPlot();
	if (pdlg.DoModal() == IDCANCEL) idres = IDCANCEL;
	PosX.RemoveAll();
	PosY.RemoveAll();

}

/*void CBTRDoc::PlotDecayArray()// along beam path
{	
	double AtomEnergy = IonBeamEnergy * 1000; //keV
	int BeamType = abs(TracePartType);
	int idres = IDOK;
	double SigmaEx, SigmaIon, SigmaEl;
	double TotalSigma;// = (SigmaEx + SigmaIon + SigmaEl)*1.0;//0.8e-20
	double x = PlasmaXmin;
	// double dL = 0.2;
	double SumThickness = 0.; // Summa N*Sigma*L
	double NeutrCurr0 = 0, NeutrCurr = 0, LinIonDensity, PSI = 0;
	double r;
	// int A = BeamType; // mass number
	double E; // beam energy
	double Density, Te; 
	int i;
	CString S;

	double MaxCurr = 1;
//----------------------------------------
	CArray<double, double> PosX;
	CArray<double, double> PosY;
	//CArray<double, double> NCurr;
	PLOTINFO DecayPlot;

	if (BeamType == 2) S.Format("DEUTERIUM Beam ");
	else S.Format("HYDROGEN Beam ");
	DecayPlot.Caption = S;
	DecayPlot.LabelX = "Xb-Xo, m";
	//DecayPlot.LabelY = "Ion Density, Plasma Density, Neutral Beam Current   ";
	DecayPlot.LabelY = "Poloidal flux, Thickness, Neutral Beam Current   ";
	DecayPlot.LimitX = floor(PlasmaXmax - PlasmaXmin)+1;
	DecayPlot.LimitY = MaxCurr;
		
	DecayPlot.CrossX = 1;
	DecayPlot.CrossY = 0.1;
	DecayPlot.Line = 1;
	DecayPlot.Interp = 1;
	DecayPlot.PosNegX = FALSE;
	DecayPlot.PosNegY = FALSE;

	E = AtomEnergy;//Energy keV;
	NeutrCurr0 = MaxCurr;
	x = PlasmaXmin; // AreaLongMax
	SumThickness = 0.;
	C3Point P;

	// plot  PSI //old - Ion current, generated by neutral beam
	for (int i = 0; i <= DecayArray.GetUpperBound(); i++) {
	//while (x < PlasmaXmax) {
	
		
			P = DecayPathArray[i];
			//LinIonDensity = DecayArray[i].X;
			PSI = DecayArray[i].X;
			PosX.Add(P.X - PlasmaXmin);
			PosY.Add(PSI);
			//NCurr.Add(P.Y);
			//x += dL;
		
	
	}
	DecayPlot.N1 = PosX.GetSize();

	
	// plot Thickness // old - Density
	int Nmax = DecayArray.GetUpperBound();
	double MaxVal = DecayArray[Nmax].Y;// last value
	for (int i = 0; i <= DecayArray.GetUpperBound(); i++) {
		P = DecayPathArray[i];
		SumThickness = DecayArray[i].Y;
		PosX.Add(P.X - PlasmaXmin);
		PosY.Add(SumThickness / MaxVal);
		//double dens = Density / MaxPlasmaDensity;
		//if (PlasmaLoaded) dens = dens / 1.0E+19;
		//PosY.Add(dens); // (Density / (MaxPlasmaDensity * 1.0E+19));
	}
	DecayPlot.N2 = PosX.GetSize();

	
	// plot Neutral current
	for (int i = 0; i <= DecayArray.GetUpperBound(); i++) {
		P = DecayPathArray[i];
		NeutrCurr = DecayArray[i].Z;
		PosX.Add(P.X - PlasmaXmin);
		PosY.Add(NeutrCurr);
	}
	DecayPlot.N = PosX.GetSize();

	DecayPlot.DataX = &PosX; 
	DecayPlot.DataY = &PosY; 

	//NeutrCurr = DecayArray[DecayArray.GetUpperBound()].Z;
	double Percent = 100 * (1 - NeutrCurr / NeutrCurr0);
	//S.Format("(Ne = %gx10^19 m-3, Te = %g keV)  Absorbed power = %4.2f %%",
				//MaxPlasmaDensity, MaxPlasmaTe, Percent);
	S.Format("Plasma(%d), Ytor = %g, Ztor= %g,  X = %f -> %f,  Absorbed power = %4.2f %%",
		PlasmaLoaded, TorCentreY, TorCentreZ, PlasmaXmin, PlasmaXmax, Percent);
	DecayPlot.Caption += S;

	CPlotDlg pdlg;
	pdlg.Plot = &DecayPlot;
	pdlg.InitPlot();
	if (pdlg.DoModal() == IDCANCEL) idres = IDCANCEL;
	PosX.RemoveAll();
	PosY.RemoveAll();
	//NCurr.RemoveAll();
	
//	} // while !idres = IDCANCEL

	
}*/



void CBTRDoc::OnUpdateOptionsTraceneutralsinplasma(CCmdUI*) 
{
//	if (!OptBeamInPlasma) pCmdUI->SetText("Trace Beam in Plasma");
//	else pCmdUI->SetText("Stop Beam before Plasma");
	
}

double 	CBTRDoc:: GetSigmaExchange(int A, double EkeV)//
{
	CArray<double, double> Xdata; // Te, eV 
	CArray<double, double> Sdata; // rate cm3/c

	Xdata.Add(1); Sdata.Add(7e-15);
	Xdata.Add(4); Sdata.Add(6e-15);
	Xdata.Add(10); Sdata.Add(5e-15);
	Xdata.Add(40); Sdata.Add(4e-15);
	Xdata.Add(100); Sdata.Add(3.5e-15);
	Xdata.Add(1000); Sdata.Add(2e-15);
	Xdata.Add(2000); Sdata.Add(1.5e-15);
	Xdata.Add(4000); Sdata.Add(1.2e-15);
	Xdata.Add(6000); Sdata.Add(1.1e-15);
	Xdata.Add(10000); Sdata.Add(1e-15);
	Xdata.Add(20000); Sdata.Add(6e-16);
	Xdata.Add(30000); Sdata.Add(4e-16);
	Xdata.Add(40000); Sdata.Add(2e-16);
	Xdata.Add(50000); Sdata.Add(1e-16);
	Xdata.Add(60000); Sdata.Add(6e-17);
	Xdata.Add(70000); Sdata.Add(3e-17);
	Xdata.Add(80000); Sdata.Add(2e-17);
	Xdata.Add(100000); Sdata.Add(1e-17);

	double S = 0;
	double x0, x1;
	double s0, s1;
	double x = EkeV * 1000 / A; // eV  (Energy div 2 for D)
//	double v = 1.e6 * sqrt(2*EkeV*1000 / A); // cm/s
	int Nmax = Xdata.GetUpperBound();
	 if (x > Xdata[Nmax] || x < Xdata[0]) return 0;
	 for (int i = 0; i < Nmax; i++) {
		 if (x >= Xdata[i] && x < Xdata[i+1]) {
			  x0 = Xdata[i];  x1 = Xdata[i+1];
			  s0 = Sdata[i];  s1 = Sdata[i+1];
			  S = s0 + (s1-s0) * (x-x0) / (x1-x0);
			  return (S * 1e-4); // m2
		 } //if
	 } // for
	return 0;
}

double 	CBTRDoc:: GetSigmaIon(int A, double EkeV)// proton ionisation
{
	CArray<double, double> Xdata; // Te, eV 
	CArray<double, double> Sdata; // rate cm3/c

	Xdata.Add(1000); Sdata.Add(0);
	Xdata.Add(2000); Sdata.Add(4e-18);
	Xdata.Add(4000); Sdata.Add(4e-17);
	Xdata.Add(6000); Sdata.Add(8e-17);
	Xdata.Add(8000); Sdata.Add(1e-16);
	Xdata.Add(10000); Sdata.Add(1.2e-16);
	Xdata.Add(20000); Sdata.Add(1.5e-16);
	Xdata.Add(40000); Sdata.Add(1.5e-16);
	Xdata.Add(60000); Sdata.Add(1.4e-16);
	Xdata.Add(100000); Sdata.Add(1.2e-16);
	Xdata.Add(200000); Sdata.Add(8e-17);
	Xdata.Add(400000); Sdata.Add(5e-17);
	Xdata.Add(600000); Sdata.Add(3e-17);
	Xdata.Add(800000); Sdata.Add(2.5e-17);
	Xdata.Add(1000000); Sdata.Add(2e-17);
	Xdata.Add(2000000); Sdata.Add(1e-17);
	Xdata.Add(4000000); Sdata.Add(6e-18);
	Xdata.Add(6000000); Sdata.Add(4e-18);
	Xdata.Add(10000000); Sdata.Add(3e-18);

	double S = 0;
	double x0, x1;
	double s0, s1;
	double x = EkeV * 1000 / A; // eV  (Energy div 2 for D)
//	double v = 1.e6 * sqrt(2*EkeV*1000 / A); // cm/s
	int Nmax = Xdata.GetUpperBound();
	 if (x > Xdata[Nmax] || x < Xdata[0]) return 0;
	 for (int i = 0; i < Nmax; i++) {
		 if (x >= Xdata[i] && x < Xdata[i+1]) {
			  x0 = Xdata[i];  x1 = Xdata[i+1];
			  s0 = Sdata[i];  s1 = Sdata[i+1];
			  S = s0 + (s1-s0) * (x-x0) / (x1-x0);
			  return (S * 1e-4); // m2
		 } //if
	 } // for
	return 0;
}

double 	CBTRDoc:: GetSigmaElectron(int A, double EkeV, double TkeV)
{
	CArray<double, double> Xdata; // Te, eV 
	CArray<double, double> SVdata; // rate cm3/c

	Xdata.Add(10); SVdata.Add(6e-9);
	Xdata.Add(20); SVdata.Add(1.5e-8);
	Xdata.Add(40); SVdata.Add(3e-8);
	Xdata.Add(60); SVdata.Add(4e-8);
	Xdata.Add(80); SVdata.Add(4e-8);
	Xdata.Add(100); SVdata.Add(4e-8);
	Xdata.Add(400); SVdata.Add(3e-8);
	Xdata.Add(1000); SVdata.Add(2e-8);
	Xdata.Add(4000); SVdata.Add(1.5e-8);
	Xdata.Add(10000); SVdata.Add(1e-8);
	Xdata.Add(20000); SVdata.Add(8e-9);
	Xdata.Add(40000); SVdata.Add(6e-9);
	Xdata.Add(100000); SVdata.Add(4e-9);

	double SV = 0;
	double x0, x1;
	double s0, s1;
	double x = TkeV * 1000;// / A; // Te, eV  (Energy div 2 for D ??????)
	double v = 1.e6 * sqrt(2*EkeV*1000 / A); // cm/s
	int Nmax = Xdata.GetUpperBound();
	 if (x > Xdata[Nmax] || x < Xdata[0]) return 0;
	 for (int i = 0; i < Nmax; i++) {
		 if (x >= Xdata[i] && x < Xdata[i+1]) {
			  x0 = Xdata[i];  x1 = Xdata[i+1];
			  s0 = SVdata[i];  s1 = SVdata[i+1];
			  SV = s0 + (s1-s0) * (x-x0) / (x1-x0);
			  return (SV/v * 1e-4); // m2
		 } //if
	 } // for
	 return 0;
}
	

void CBTRDoc::OnPlotSigmas() // not called
{
	CArray<double, double>  ArrX;
	CArray<double, double>  ArrY;

	PLOTINFO SigmaPlot;
	SigmaPlot.Caption = "Hydrogen Atom Stopping Sigmas vs Energy";
	SigmaPlot.LabelX = "H Energy, keV";
	SigmaPlot.LabelY = "Sigma, cm2: proton, electron, Charge Exchange  ";
	SigmaPlot.LimitX = 150;
	SigmaPlot.LimitY = 1.e-15;
	SigmaPlot.CrossX = 10;
	SigmaPlot.CrossY = 0.1e-15;
	SigmaPlot.Line = 1;
	SigmaPlot.Interp = 1;
//	SigmaPlot.N = GField->GasArray.GetSize();
//	
//	SigmaPlot.N2 = SigmaPlot.N +1;
	SigmaPlot.PosNegY = FALSE;
	SigmaPlot.PosNegX = FALSE;
	double dx = 1;
	double x = 1;
	double sigma;
	while (x < SigmaPlot.LimitX) {
		sigma = GetSigmaIon(1, x)*10000;
		ArrX.Add(x); ArrY.Add(sigma);
		x += dx;
	}
	SigmaPlot.N1 = ArrX.GetSize();

	x = 1;
	while (x < SigmaPlot.LimitX) {
		sigma = GetSigmaElectron(1, x, MaxPlasmaTe)*10000;
		ArrX.Add(x); ArrY.Add(sigma);
		x += dx;
	}
	SigmaPlot.N2 = ArrX.GetSize();

	x = 10;
	while (x < 100) {
		sigma = GetSigmaExchange(1, x)*10000;
		ArrX.Add(x); ArrY.Add(sigma);
		x += dx;
	}
	SigmaPlot.N = ArrX.GetSize();
	
	SigmaPlot.DataX = &ArrX;
	SigmaPlot.DataY = &ArrY;
	
	CPlotDlg dlg;
	dlg.Plot = &SigmaPlot;
	dlg.InitPlot();
	dlg.DoModal();

	ArrX.RemoveAll();
	ArrY.RemoveAll();
	
}

double 	CBTRDoc:: GetNeutrOutput(int A, int K , double EkeV)// inf neutralization target - NOT USED
{
	CArray<double, double> Xdata; // E, eV 
	CArray<double, double> Fdata; // 

	Xdata.Add(10); Fdata.Add(0.9);
	Xdata.Add(20); Fdata.Add(0.81);
	Xdata.Add(30); Fdata.Add(0.72);
	Xdata.Add(40); Fdata.Add(0.63);
	Xdata.Add(50); Fdata.Add(0.53);
	Xdata.Add(60); Fdata.Add(0.43);
	Xdata.Add(70); Fdata.Add(0.35);
	Xdata.Add(80); Fdata.Add(0.3);
	Xdata.Add(90); Fdata.Add(0.25);
	Xdata.Add(100); Fdata.Add(0.21);
	Xdata.Add(120); Fdata.Add(0.14);
	Xdata.Add(140); Fdata.Add(0.11);
	Xdata.Add(150); Fdata.Add(0.1);
	Xdata.Add(200); Fdata.Add(0.05);

	double F = 0;
	double x0, x1;
	double f0, f1;
	double x = EkeV / A; // eV  (Energy div 2 for D)
//	double v = 1.e6 * sqrt(2*EkeV*1000 / A); // cm/s
	int Nmax = Xdata.GetUpperBound();
	 if (x > Xdata[Nmax] || x < Xdata[0]) return 0;
	 for (int i = 0; i < Nmax; i++) {
		 if (x >= Xdata[i] && x < Xdata[i+1]) {
			  x0 = Xdata[i];  x1 = Xdata[i+1];
			  f0 = Fdata[i];  f1 = Fdata[i+1];
			  F = f0 + (f1-f0) * (x-x0) / (x1-x0);
			  return (F * K); // account of molecule dissociation to atoms
		 } //if
	 } // for
	return 0;
}

void CBTRDoc::OnPlotReionization()
{
	int res;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}
	CArray<double, double>  ArrX;
	CArray<double, double>  ArrY;
	CString S, spart;
	char name[1024];

	PLOTINFO ReiPlot;
	ReiPlot.Caption = "Beam Re-ionization loss" ;
	ReiPlot.LabelX = "X, m";
	ReiPlot.LabelY = "j+, J0";
	ReiPlot.LimitX = ReionXmax + 0.5;
	ReiPlot.LimitY = 1;
	ReiPlot.CrossX = 5;
	ReiPlot.CrossY = 0.1;
	ReiPlot.Line = 1;
	ReiPlot.Interp = 1;
	ReiPlot.PosNegY = FALSE;
	ReiPlot.PosNegX = FALSE;

		//Summa += Curr;
		//P.X = x; P.Y = Curr; P.Z = exp(-Summa);
	int i;
	double x;
	// double dx = ReionStepL;
	double Curr = 0;
	int Nmax = ReionArray.GetUpperBound(); 
	for (i = 0; i <= Nmax; i++) {
		x = ReionArray[i].X;
		Curr += ReionArray.GetAt(i).Y;
		ArrX.Add(x);
		ArrY.Add(Curr); // H+
	}
	ReiPlot.N1 = ArrX.GetSize();

	double NCurr = 0;
	for (i = 0; i <= Nmax; i++) {
		x = ReionArray[i].X;
		NCurr = ReionArray.GetAt(i).Z;
		ArrX.Add(x);
		ArrY.Add(NCurr); // H0
	}
	ReiPlot.N2 = ArrX.GetSize();

	ReiPlot.N = ArrX.GetSize();
	
	ReiPlot.DataX = &ArrX;
	ReiPlot.DataY = &ArrY;
	
	CPlotDlg dlg;
	dlg.Plot = &ReiPlot;
	dlg.InitPlot();
	if (dlg.DoModal() == IDOK) {
		CFileDialog dlg(FALSE, "txt | * ", "Reion_data.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.txt) | *.TXT | All Files (*.*) | *.*||", NULL);
		if (dlg.DoModal() == IDOK) {
			FILE * fout;
			strcpy(name, dlg.GetPathName());
			fout = fopen(name, "w");
			//fprintf(fout, m_Text);
			//FILE * fout = fopen("Reion_data.txt", "w");
			fprintf(fout, " Reionization along X-axis \n");
			fprintf(fout, " Gas file <%s> \n Xmin = %g  Xmax = %g ReionPercent = %f\n", 
				GasFileName, ReionXmin, ReionXmax, ReionPercent);
			fprintf(fout, " X   \t\t  J+   \t\t  J0 \n");
			Curr = 0;
			for (i = 0; i <= Nmax; i++) {
				x = ReionArray[i].X;
				Curr += ReionArray.GetAt(i).Y;//H+
				NCurr = ReionArray.GetAt(i).Z;//H0
				fprintf(fout, "  %f \t %f \t %f \n", x, Curr, NCurr); 
			}
			fclose(fout);
			delete dlg;
		} // filedialog OK
	} // Plot.DoModal
	
	ArrX.RemoveAll();
	ArrY.RemoveAll();

}

void CBTRDoc::OnUpdatePlotReion(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(PressureLoaded);
}

void CBTRDoc:: PlotCurrentRates(bool rate) 
{
	CArray<double, double>  ArrX;
	CArray<double, double>  ArrY;
	double Xmax = NeutrXmax;
	CString S;
	
	PLOTINFO CurrPlot;
	
	int Knucl = TracePartNucl;
	if (Knucl == 0) Knucl = 1;
	S.Format("THICK Neutralization:  Energy = %g keV/nucl",  
		IonBeamEnergy*1000/Knucl,  NeutrXmin);

	if (rate) CurrPlot.Caption = "Creation/drop Rates (Neutralization region)";
	else CurrPlot.Caption = S;
	CurrPlot.LabelX = "X, m";
	if (TracePartType == -1) CurrPlot.LabelY = "H+,  H-,  Ho   ";
	else CurrPlot.LabelY = "D+,  D-,  Do   ";
		
	CurrPlot.LimitX = Xmax;//ReionXmax;
	CurrPlot.LimitY = 0;//1.e20;
	CurrPlot.CrossX = 0.5;
	CurrPlot.CrossY = 0;
	CurrPlot.Line = 1;
	CurrPlot.Interp = 1;
	//GasPlot.N = 100; //GField->GasArray.GetSize();
	//GasPlot.N1 = GasPlot.N +1;
	//GasPlot.N2 = GasPlot.N +1;
	CurrPlot.PosNegY = FALSE;
	CurrPlot.PosNegX = FALSE;
	double x, y;
	//double xmax = NeutrXmax;
	double dx = NeutrStepL; 
	double NL = 0;
	x = NeutrXmin;
	while (x <= Xmax) {
		NL += dx * GetPressure(C3Point(x, 0, 0));// NL
		y = GetCurrentRate(x, NL, rate).X; //PosRate
		if (y > 1.e-20) {
			ArrX.Add(x); ArrY.Add(y);
		}
		x += dx;
		
	}
	CurrPlot.N1 = ArrX.GetSize();

	x = NeutrXmin;
	NL = 0;
	while (x <= Xmax) {
		NL += dx * GetPressure(C3Point(x, 0, 0));// NL
		y = GetCurrentRate(x, NL, rate).Y; //NegRate
		if (y > 1.e-20) {
			ArrX.Add(x); ArrY.Add(y);
		}
		x += dx;
		
	}
	
	CurrPlot.N2 = ArrX.GetSize();

	x = NeutrXmin;
	NL = 0;
	while (x <= Xmax) {
		NL += dx * GetPressure(C3Point(x, 0, 0));// NL
		y = GetCurrentRate(x, NL, rate).Z; //NeutrRate
		if (y > 1.e-20) {
			ArrX.Add(x); ArrY.Add(y);
		}
		x += dx;
		
	}

	CurrPlot.N = ArrX.GetSize();
	
	CurrPlot.DataX = &ArrX;
	CurrPlot.DataY = &ArrY;
	
	CPlotDlg dlg;
	dlg.Plot = &CurrPlot;
	dlg.InitPlot();
	//dlg.DoModal();
	if (dlg.DoModal() == IDOK) {
		char name[1024];
		CFileDialog dlg(FALSE, "txt | * ", "Neutr_data.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.txt) | *.TXT | All Files (*.*) | *.*||", NULL);
		if (dlg.DoModal() == IDOK) {
			FILE * fout;
			strcpy(name, dlg.GetPathName());
			fout = fopen(name, "w");
			
			if (rate) fprintf(fout, " Rates in Neutralization area along X-axis \n");
			else fprintf(fout, " Currents in Neutralization area along X-axis \n");
			fprintf(fout, " Gas file <%s> \n Xmin = %g  Xmax = %g\t  J0 = %f \t J- = %f \t J+ = %f\n", 
				GasFileName, NeutrXmin, NeutrXmax, NeutrPart, (1. - NeutrPart - PosIonPart), PosIonPart);
			fprintf(fout, "  X  \t\t  J+  \t\t   J- \t\t  J0 \n");
			x = NeutrXmin;
			NL = 0;
			C3Point P;
			while (x <= Xmax) {
				NL += dx * GetPressure(C3Point(x, 0, 0));// NL
				P = GetCurrentRate(x, NL, rate); //NegRate
				fprintf(fout, "  %g \t %g \t %g  \t %g \n", x, P.X, P.Y, P.Z);
				x += dx;
			}
			
			fclose(fout);
			delete dlg;//filedlg
		} // filedialog OK
	} // Plot.DoModal

	ArrX.RemoveAll();
	ArrY.RemoveAll();
	
}
void CBTRDoc::OnPlotNeutrefficiency() // -> OnNeutralization -> PlotCurrentRates
{
	/*PlotCurrentRates(1);
	return;

	int res;
	if (pDataView->m_rich.GetModify()) {
		res = AfxMessageBox("Data is modified but NOT UPDATED! \n Continue?", 3);
		if (res != IDYES) return;
	}
	CArray<double, double>  ArrX;
	CArray<double, double>  ArrY;
	CString S, spart;
	char name[1024];
	switch (TracePartType) {
	case 0: spart = "(e)"; break;
	case -1: spart = "H-"; break;
	case -2: spart = "D-"; break;
	case 1: spart = "H+"; break;
	case 2: spart = "D+"; break;
	case 10: spart = "Ho"; break;
	case 20: spart = "Do"; break;
	default: spart = ""; break;
	}

	int Knucl = TracePartNucl;
	if (Knucl == 0) Knucl = 1;

	S.Format("THICK Neutralization:  %s  Energy = %g keV/nucl", spart,
				 IonBeamEnergy*1000/Knucl,  NeutrXmin);

	PLOTINFO NeffPlot;
	NeffPlot.Caption = S;
	NeffPlot.LabelX = "X, m";
	if (TracePartType == -1) NeffPlot.LabelY = "H+,  H-,  Ho   ";
	else NeffPlot.LabelY = "D+,  D-,  Do   ";
	NeffPlot.LimitX = NeutrXmax + 0.5;
	NeffPlot.LimitY = 1;
	NeffPlot.CrossX = 0.5;
	NeffPlot.CrossY = 0.1;
	NeffPlot.Line = 1;
	NeffPlot.Interp = 1;
	NeffPlot.PosNegY = FALSE;
	NeffPlot.PosNegX = FALSE;

	int i;
	double x;
	C3Point P;
	// double dx = NeutrStepL;
	double PosEff = 0;
	int Nmax = NeutrArray.GetUpperBound(); 
	for (i = 0; i <= Nmax; i++) {
		x = NeutrArray[i].X;
		PosEff = NeutrArray.GetAt(i).Z;
		ArrX.Add(x);
		ArrY.Add(PosEff); // H+
	}
	NeffPlot.N1 = ArrX.GetSize();

	double NegEff = 0;
	for (i = 0; i <= Nmax; i++) {
		x = NeutrArray[i].X;
		NegEff = NeutrArray.GetAt(i).Y;
		ArrX.Add(x);
		ArrY.Add(NegEff); // H-
	}
	NeffPlot.N2 = ArrX.GetSize();

	double AtomEff = 0;
	for (i = 0; i <= Nmax; i++) {
		x = NeutrArray[i].X;
		PosEff = NeutrArray.GetAt(i).Z;
		NegEff = NeutrArray.GetAt(i).Y;
		ArrX.Add(x);
		ArrY.Add(1 - NegEff - PosEff); // Ho
	}

	NeffPlot.N = ArrX.GetSize();
	
	NeffPlot.DataX = &ArrX;
	NeffPlot.DataY = &ArrY;
		
	CPlotDlg dlg;
	dlg.Plot = &NeffPlot;
	dlg.InitPlot();
	if (dlg.DoModal() == IDOK) {
		CFileDialog dlg(FALSE, "txt | * ", "Neutr_data.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.txt) | *.TXT | All Files (*.*) | *.*||", NULL);
		if (dlg.DoModal() == IDOK) {
			FILE * fout;
			strcpy(name, dlg.GetPathName());
			fout = fopen(name, "w");
			
			fprintf(fout, " Neutralization along X-axis \n");
			fprintf(fout, " Gas file <%s> \n Xmin = %g  Xmax = %g\t  J0 = %f \t J- = %f \t J+ = %f\n", 
				GasFileName, NeutrXmin, NeutrXmax, NeutrPart, (1. - NeutrPart - PosIonPart), PosIonPart);
			fprintf(fout, "  X  \t\t  J+  \t\t   J- \t\t  J0 \n");
			
			for (i = 0; i <= Nmax; i++) {
				x = NeutrArray[i].X;
				PosEff = NeutrArray.GetAt(i).Z;//H+
				NegEff = NeutrArray.GetAt(i).Y;//H-
				AtomEff = 1 - NegEff - PosEff; // Ho
				fprintf(fout, "  %f \t %f \t %f  \t %f \n", x, PosEff, NegEff, AtomEff); 
			}
			fclose(fout);
			delete dlg;
		} // filedialog OK
	} // Plot.DoModal

	ArrX.RemoveAll();
	ArrY.RemoveAll();
	
	*/
}


void CBTRDoc::OnUpdatePlotNeutrefficiency(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(PressureLoaded);
	
}

void CBTRDoc::OnUpdatePlotSigmas(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);
	
}

void CBTRDoc::OnCloseDocument() 
{
	CDocument::OnCloseDocument();
}


void CBTRDoc::OnUpdateAppExit(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(STOP);
	
}

BOOL CBTRDoc::CanCloseFrame(CFrameWnd* pFrame) 
{
	//int reply = AfxMessageBox(" Report on BTR Exit ", MB_YESNOCANCEL);
	int reply = AfxMessageBox(" Exit BTR? ", MB_OKCANCEL);
	if (reply == IDCANCEL) return FALSE;

	STOP = TRUE;	OnStop();
		
	//SendReport(FALSE); // don't include input	//for Valid User returns back:

	return CDocument::CanCloseFrame(pFrame);
}


void CBTRDoc::SendReport(bool includetext)
{
/*	unsigned long Size1 = MAX_COMPUTERNAME_LENGTH + 1;
	unsigned long Size2 = MAX_COMPUTERNAME_LENGTH + 1;
	char user[MAX_COMPUTERNAME_LENGTH + 1];
	char machine[MAX_COMPUTERNAME_LENGTH + 1];*/
	CString CompName = GetMachine();
	CString UserName = GetUser();
	CString Body;

	//if (!includetext && !InvUser && UserName.Find("NAS",0) <= 0) return;

	char * server = "smtp.gmail.com";//"nfi.kiae.ru"; ////
	char * from = "INFO@BTR.com"; //"edlougach@nfi.kiae.ru";//"edlougach@gmail.com";//
	char * to = "edlougach@gmail.com";
	//char * to = "kuyanov@nfi.kiae.ru";
	//char * to = "edlougach@gmail.com";// gmail does not accept exe-attachments!
	char subject[1024];
	strcpy(subject, CompName);//machine);
	strcat(subject, " / "); strcat(subject, UserName);

	char body[65555];
	
	if (includetext) {
		strcat(subject, " -> BTR input");
		FormDataText(TRUE);
		strcpy(body, m_Text);
	}
	else { // empty
		strcat(subject, " -> exit");
		CString CurrDate, CurrTime;
		CString Date, Time, version = " - \n 4 beta - unlimited since Jan 2012 \n";
		CTime tm = CTime::GetCurrentTime();// tm.GetDay() GetMonth()
		CurrDate.Format(" date %02d:%02d:%04d", tm.GetDay(), tm.GetMonth(), tm.GetYear());
		CurrTime.Format("  time %02d:%02d:%02d", tm.GetHour(), tm.GetMinute(), tm.GetSecond());
		strcpy(body,("sent by BTR " + version + CurrDate + CurrTime ));
	}

	char * attach = 0;//"BTR.exe";

	sendMail(server, from, to, subject, body, attach);
}

void CBTRDoc::OnSendBtrInput()
{
	//CSMTPConnection smtp;
	//CIMapi mail;
	MapiMessage msg;
	memset(&msg, 0, sizeof(MapiMessage));//size = strTitle.GetLength() + 1;
	msg.lpszSubject = "test subject";
	msg.lpszNoteText = "Test message from OnSendBTRInput";
	msg.lpszMessageType = NULL;
		
	MapiRecipDesc recipient;
	memset(&recipient, 0, sizeof(MapiRecipDesc));
	recipient.ulEIDSize = 0;
	recipient.ulRecipClass = MAPI_TO;
	CString cstrAddress = "edlougach@gmail.com"; //strAddress;
	recipient.lpszAddress = (char*)(const char*)cstrAddress;
	recipient.lpszName = (char*)(const char*)cstrAddress;
	msg.lpRecips = &recipient;
	msg.nRecipCount = 1;
	LPMAPISENDMAIL lpfnMAPISendMail = NULL;
	HINSTANCE hlibMAPI = LoadLibrary("MAPI32.DLL");//Mapi32.dll
	lpfnMAPISendMail = (LPMAPISENDMAIL)GetProcAddress(hlibMAPI, "MAPISendMail");
	//return (*lpfnMAPISendMail)(0, (ULONG)hWnd, &msg, 0, 0);
	//MAPISendMail(0, 0, &msg, 0, 0);
	HWND hWndTop;
	CWnd * pParentWnd = CWnd::GetSafeOwner(NULL, &hWndTop);
	// send mail
	FLAGS flags = MAPI_LOGON_UI;
	//BitSetIf(flags, MAPI_DIALOG, bShowDialog);
	ULONG nError = (*lpfnMAPISendMail)(0, (ULONG)pParentWnd->GetSafeHwnd(), &msg, flags, 0);

	if (nError != SUCCESS_SUCCESS &&
		nError != MAPI_USER_ABORT &&
		nError != MAPI_E_LOGIN_FAILURE)
	{
		AfxMessageBox(AFX_IDP_FAILED_MAPI_SEND);
	}
	//CMailAPI32   m_api;              // MAPI interface
	//m_api.SendMail();
	
	//SendReport(TRUE);
	AfxMessageBox("Message is sent.\n  Thank you!");
}

void CBTRDoc::OnSendOther()
{
	char * server = "smtp.gmail.com";//"nfi.kiae.ru"; ////
	char * from = "BTR@mail.com"; //"edlougach@nfi.kiae.ru";//"edlougach@gmail.com";//
	char * to = "edlougach@gmail.com";//nfi.kiae.ru";
	//char * to = "kuyanov@nfi.kiae.ru";
	//char * to = "edlougach@gmail.com";// gmail does not accept exe-attachments!
	char subject[1024];
	strcpy(subject, "BTR version");
	
	char body[65555];
	CString CurrDate, CurrTime;
	CString Date, Time;
	CString version = " - \n 3.3 May 03 2012 - unlimited since Jan 2012 \n";
	CTime tm = CTime::GetCurrentTime();// tm.GetDay() GetMonth()
	CurrDate.Format(" date %02d:%02d:%04d", tm.GetDay(), tm.GetMonth(), tm.GetYear());
	CurrTime.Format("  time %02d:%02d:%02d", tm.GetHour(), tm.GetMinute(), tm.GetSecond());
	strcpy(body,("This is sent by BTR via gmail \n\n" + CurrDate + CurrTime + version));
	
	char * attach = 0;// "BTR.exe";

	sendMail(server, from, to, subject, body, attach);

}

void CBTRDoc::CreateCopyMessage(CString server)
{/*
   MailAddress^ from = gcnew MailAddress( L"edlougach@nfi.kiae.ru",L"DED" );
   MailAddress^ to = gcnew MailAddress( L"edlougach@nfi.kiae.ru",L"Jane" );
   MailMessage^ message = gcnew MailMessage( from,to );

   // message.Subject = "Using the SmtpClient class.";
   message->Subject = L"BTR message";
   message->Body = L"Using this feature, you can send an e-mail message from an application very easily.";

   // Add a carbon copy recipient.
   MailAddress^ copy = gcnew MailAddress( L"edlougach@gmail.com" );
   message->CC->Add( copy );
   SmtpClient^ client = gcnew SmtpClient( server );

   // Include credentials if the server requires them.
   client->Credentials = CredentialCache::DefaultNetworkCredentials;
   AfxMessageBox(L"Sending an e-mail message by using the SMTP ");
   Console::WriteLine( L"Sending an e-mail message to {0} by using the SMTP host {1}.", to->Address, client->Host );
   client->Send( message );
   client->~SmtpClient();*/
}



void CBTRDoc::OnOptionsSurfacesAdd() 
{
	C3Point P0, P1, P2, P3;
	//BOOL solid = FALSE;
	CPlate * plate = pMarkedPlate; // last selected
	CString S;
	CSurfDlg dlg;
	
	if (plate != NULL) {
		dlg.m_X1 = plate->Corn[0].X; dlg.m_Y1 = plate->Corn[0].Y; dlg.m_Z1 = plate->Corn[0].Z;
		dlg.m_X2 = plate->Corn[1].X; dlg.m_Y2 = plate->Corn[1].Y; dlg.m_Z2 = plate->Corn[1].Z;
		dlg.m_X3 = plate->Corn[2].X; dlg.m_Y3 = plate->Corn[2].Y; dlg.m_Z3 = plate->Corn[2].Z;
		dlg.m_X4 = plate->Corn[3].X; dlg.m_Y4 = plate->Corn[3].Y; dlg.m_Z4 = plate->Corn[3].Z;
		dlg.m_Solid = !plate->Solid;
		dlg.m_N = plate->Number;
		dlg.m_Comment = "free";//+ plate->Comment;
		dlg.m_N = PlateCounter + 1;//AddPlatesNumber;
	}
	else { // plate == NULL
		dlg.m_N = PlateCounter + 1;//AddPlatesNumber;
		dlg.m_Comment = "Type Surf Name here";
		dlg.m_Solid = 0;
	}

	int res = dlg.DoModal();
	
	if (res == IDCANCEL) {//
		if (!dlg.OptRead) return;
		int added = ReadAddPlates();
		AddPlatesNumber += added;
		S.Format("Total addSurf %d (added %d) ", AddPlatesNumber, added);
		AfxMessageBox(S);
		OnShow();
		return;
	}

	if (res == IDOK) {
		P0.X = dlg.m_X1; P0.Y = dlg.m_Y1; P0.Z = dlg.m_Z1;
		P1.X = dlg.m_X2; P1.Y = dlg.m_Y2; P1.Z = dlg.m_Z2;
		P2.X = dlg.m_X4; P2.Y = dlg.m_Y4; P2.Z = dlg.m_Z4;
		P3.X = dlg.m_X3; P3.Y = dlg.m_Y3; P3.Z = dlg.m_Z3;
		
		plate = new CPlate();//(P1, P2, P3, P4);
		plate->SetLocals(P0, P1, P2, P3); //SetArbitrary(P1, P2, P3, P4);
		plate->Solid = !(dlg.m_Solid);
		plate->Comment = dlg.m_Comment;
		plate->Number = dlg.m_N;
		if (plate->Solid && plate->Comment.Find("solid") < 0) plate->Comment += " (solid)";
		if (plate->Comment.Find("free") < 0 && plate->Comment.Find("add") < 0) plate->Comment += " added";
		//else plate->Comment += " (transpar)";
						
		plate->Fixed = -1; // to define
		plate->Visible = plate->Solid;
		AddPlate(plate); // (solid, P1, P2, P3, P4);//AddPlatesNumber++;
		AppendAddPlates();//PlateCounter++;
		PlatesList.AddTail(plate);
	}

	OnShow();

}

void CBTRDoc:: WriteAddPlates(char * name)
{
	FILE * fout;
	fout= fopen(name, "w");
	if (fout == NULL) {
			AfxMessageBox("failed to create file", MB_ICONSTOP | MB_OK);
			return;
	}
	fprintf(fout, "Free Surfaces List \n");
	fprintf(fout, "Each Surface is defined by 4 Corner Points  (X  Y  Z) \n");
	
	CPlate * plate;
	CString com;
	CString sol;
	C3Point P;
	POSITION pos = PlatesList.GetHeadPosition();
	while (pos != NULL) {// find Plate0 in the existing plates list 
		plate = PlatesList.GetNext(pos);
		com = plate->Comment;
		com.MakeUpper();
		if (com.Find("ADDIT") >= 0 || com.Find("FREE") >= 0) {
			if (plate->Solid) sol = " (solid)";
			else sol = " (transpar)";
			fprintf(fout, "# %s\n", com + sol);
			for (int i = 0; i < 4; i++) {
				P = plate->Corn[i];
				fprintf(fout, "%g    %g    %g\n", P.X, P.Y, P.Z);
			}
		} // additional
	} // list
	fclose(fout);

}

int CBTRDoc:: ReadAddPlates()
{
	char name[1024];
	char buf[1024];
	CString line = "";
	int i, pos, num, res;
	char *endptr;
	CPlate * plate;
	double x, y, z;
	C3Point P[4];
	int total = 0;
	bool solid;


	CFileDialog dlg(TRUE, "txt; dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Addit. Surf. list for BTR (*.txt); (*.dat) | *.txt; *.TXT; *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
	if (dlg.DoModal() == IDOK) {
		strcpy(name, dlg.GetPathName());

		CPreviewDlg dlg;
		dlg.m_Filename = name;
		if (dlg.DoModal() == IDCANCEL) return 0;

		FILE * fin;
		fin = fopen(name, "r");
		if (fin == NULL) {
			AfxMessageBox("problem 1 opening data file", MB_ICONSTOP | MB_OK);
			return 0;
		}

		total = 0;  
		while (!feof(fin)) {
			if (fgets(buf, 1024, fin) == NULL)
				break;
			line = buf;
			pos = line.Find("#");
			if (pos < 0) continue;
		
			line = line.Mid(pos+1);
			strcpy(buf, line);
			num = strtol(buf, &endptr, 10);
			if (line.Find("solid") > -1)
				solid = true;
			else
				solid = false;
			pos = line.Find("\n");
			if (pos > 0) line = line.Left(pos);
			
			for (i = 0; i < 4; i++) {
				if (fgets(buf, 1024, fin) == NULL) break;
				res = sscanf(buf, "%le %le %le", &x, &y, &z);
				P[i].X = x; P[i].Y = y; P[i].Z = z; 
			}
			plate = new CPlate();//(P[0], P[1], P[2], P[3]);
			plate->Comment = line;// + " Additional";
			plate->SetLocals(P[0], P[1], P[2], P[3]);//plate->SetArbitrary(P[0], P[1], P[2], P[3]);
			plate->Solid = solid;
			plate->Visible = solid;
			
		
			AddPlatesList.AddTail(plate);//	AddPlate(plate);
			total++;
			//AddPlatesNumber++;
			PlateCounter++;
			plate->Number = PlateCounter;//AddPlatesNumber;
			plate->Fixed = -1; // to define
			PlatesList.AddTail(plate);
				
		}// feof
		fclose(fin);
	} // IDOK
	
	//ShowFileText(name);
		
	ModifyArea(FALSE);
	return total;
	
}

void CBTRDoc::OnOptionsBeam() 
{
	CBeamDlg dlg;
	dlg.doc = this;
	dlg.m_Gauss = (int)BeamSplitType;
	dlg.m_OptSINGAP = !OptSINGAP;
	
	switch (TracePartType) {
		case 0: dlg.m_D = 2; break;
		case 1:
		case -1:
		case 10:dlg.m_D = 1; break;
		case 2: 
		case -2:
		case 20:dlg.m_D = 0; break;
		
		default: dlg.m_D = 0; break;
	}
	
	dlg.m_OptThick = OptThickNeutralization;
	dlg.m_OptRID = !OptNeutrStop;
	dlg.m_Atoms = OptTraceAtoms;
	dlg.m_OptReion = !OptReionStop;
	dlg.m_OptPlasma = OptBeamInPlasma;
	dlg.m_AtomPower = OptAtomPower;
	dlg.m_NegIon_Power = OptNegIonPower;
	dlg.m_PosIon_Power = OptPosIonPower;
	
	dlg.m_Reflect = OptReflectRID;
	
	if (dlg.DoModal() == IDOK) {
			OptSINGAP = !(dlg.m_OptSINGAP);
			BeamSplitType = dlg.m_Gauss;
			OptThickNeutralization = (dlg.m_OptThick != 0);
			OptNeutrStop = !dlg.m_OptRID;
			OptTraceAtoms = (dlg.m_Atoms != 0);
			OptReionStop = !dlg.m_OptReion;
			OptAtomPower = (dlg.m_AtomPower != 0);
			OptNegIonPower = (dlg.m_NegIon_Power != 0);
			OptPosIonPower = (dlg.m_PosIon_Power != 0);
			OptBeamInPlasma = TRUE; // (dlg.m_OptPlasma != 0);
			OptReflectRID = (dlg.m_Reflect != 0);

		//	TracePartType = 2 - dlg.m_D;
			CheckData();
		
		
			if (OptSINGAP) {
				TaskName = "SINGAP BEAM";
				if (!SINGAPLoaded) SetSINGAP(); // form BEAMLET_ENTRY array (apply midalign, active chan)
				
			}
			else { 
				TaskName = "MAMuG BEAM";
				SetBeam();// Mamug Aimings, IS positions, BeamPower
				for (int i = 0; i < (int)NofChannelsHor; i++) ActiveCh[i] = TRUE;
				for (int j = 0; j < (int)NofChannelsVert; j++) ActiveRow[j] = TRUE;
				//SetStatus();// NofBeamlets, Nofactive channels/rows/totbeamlets	
			}
				
			if ((int)BeamSplitType ==0) SetPolarBeamletCommon(); //SetBeamletAt(0);
			else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ); 


			if (TracePartType == 0) { // trace electrons
				TraceStepL = Min(TraceStepL, 0.01);
				TraceTimeStep = Min(TraceTimeStep, 1.e-10);
			}
	
			SetTraceParticle(TracePartNucl, TracePartQ);

	} // IDOK
//	RIDField->Set();

//	SetBeam();  
	if (STOP) //(NofCalculated == 0)
	SetStatus(); // NofBeamlets, Nofactive channels/rows/totbeamlets	
	
	OnShow();
}

void CBTRDoc::OnOptionsFields() 
{
	CFieldsDlg dlg;
	dlg.doc = this;
	dlg.m_MFON = !FieldLoaded; //MFON = 0 if MF is ON 
	dlg.m_MFcoeff = MFcoeff;
	dlg.m_Volt = RIDU;
	dlg.m_GasON = !PressureLoaded;
	dlg.m_GasCoeff = GasCoeff;
	dlg.m_MFfilename = MagFieldFileName;
	dlg.m_Gasfilename = GasFileName;
	
	if (dlg.DoModal() == IDOK) {
		MFcoeff = dlg.m_MFcoeff;
		GasCoeff = dlg.m_GasCoeff;
		if (dlg.m_MFON == 1) MFcoeff = 0; // switched off
		if (dlg.m_GasON == 1) GasCoeff = 0; // switched off

		RIDU = dlg.m_Volt;

		if (dlg.m_MFON == 0 && !FieldLoaded) {// MF is ON but not read
			AfxMessageBox("MF is not read!");
		}
		if (dlg.m_GasON == 0 && !PressureLoaded) {// Gas is ON but not read
			AfxMessageBox("Gas is not read!");
		}
	}

//	RIDField->Set();
	CheckData();
	SetNeutrCurrents();
	SetReionPercent();
	
	/*if (PressureLoaded && GasCoeff > 1.e-6) {
		//if (GasCoeff == 0) GasCoeff = 1;
		OptReionAccount = TRUE;//automatic when gas loaded
		OptThickNeutralization = TRUE;
		SetNeutrCurrents();
		SetReionPercent();
	}
	else {
		OptReionAccount = FALSE;//automatic when gas loaded
		OptReionStop = TRUE;
		OptThickNeutralization = FALSE;
		SetNeutrCurrents();
		SetReionPercent();
	}*/
	OnShow();//	OnDataActive();
}

void CBTRDoc::OnOptionsNBIconfig() 
{
	if (OptFree) return;
	CNBIconfDlg dlg;
	dlg.doc = this;
	dlg.m_CalculWidth = 0;
	dlg.m_CalOpen = !OptCalOpen;
	dlg.m_NeutrChannels = (int)NeutrChannels;
	dlg.m_RIDChannels = (int)RIDChannels;
	dlg.m_NeutrGapIn = NeutrInW *1000;
	dlg.m_NeutrGapOut = NeutrOutW *1000;
	dlg.m_NeutrThickIn = NeutrInTh *1000;
	dlg.m_NeutrThickOut = NeutrOutTh *1000;
	dlg.m_RIDGapIn = RIDInW *1000;
	dlg.m_RIDGapOut = RIDOutW * 1000;
	dlg.m_RIDThick = RIDTh * 1000;
	dlg.m_Volt = RIDU;

	if (dlg.DoModal() == IDOK) {
		NeutrChannels = dlg.m_NeutrChannels;
		RIDChannels = dlg.m_RIDChannels;
		
		NeutrInW =	dlg.m_NeutrGapIn * 0.001;
		NeutrOutW = dlg.m_NeutrGapOut * 0.001;
		NeutrInTh = dlg.m_NeutrThickIn * 0.001;
		NeutrOutTh = dlg.m_NeutrThickOut * 0.001;
		RIDInW = dlg.m_RIDGapIn * 0.001;
		RIDOutW = dlg.m_RIDGapOut * 0.001;
		RIDTh = dlg.m_RIDThick * 0.001;
		RIDU = dlg.m_Volt;
		OptCalOpen = !(dlg.m_CalOpen);
		//	RIDField->Set();
		if (!OptCalOpen) CalOutW = 0.0;
		else CalOutW = CalInW;
	
		CheckData();
		//InitPlasma();
		//SetPlates();

		ClearAllPlates();
		InitPlasma();
		if (!OptFree) SetPlates(); // create again//SetPlasma() is called from SetPlatesNBI;
		else ModifyArea(TRUE);
		
		OnShow();//	OnDataActive();
	}
	

}

void CBTRDoc::OnOptionsSurfacesEnabledisableall() 
{
	// SelectAllPlates();
	
	if (OptParallel) { //parallel
		CalculateAllLoads(FALSE); // no replace - keep existing
	}//parallel

	else //!(pDoc->OptParallel
		SelectAllPlates();

}

void CBTRDoc::SetDefaultMesh() // mesh + part opt
{
	//CNeutrDlg dlg;
	//dlg.m_Thin = OptThickNeutralization ? 1 : 0;
	DefLoadDlg dlg;
	dlg.m_OptN = DefLoadOptN ? 0 : 1; // TRUE - appr size / False - fixed step
	dlg.NX = DefLoadNX;
	dlg.NY = DefLoadNY;
	dlg.Round = DefLoadStepRound; // round step if optN == TRUE (size)
	dlg.m_StepX = DefLoadStepX;
	dlg.m_StepY = DefLoadStepY;

	dlg.m_OptAtom = (BOOL) OptAtomPower;
	dlg.m_OptPos = (BOOL) OptPosIonPower;
	dlg.m_OptNeg = (BOOL) OptNegIonPower;
	
	if (dlg.DoModal() == IDOK) {
		DefLoadOptN = (dlg.m_OptN == 0);
		DefLoadNX = dlg.NX;
		DefLoadNY = dlg.NY;
		DefLoadStepRound = dlg.Round;
		DefLoadStepX = dlg.m_StepX;
		DefLoadStepY = dlg.m_StepY;

		OptAtomPower = dlg.m_OptAtom;
		OptPosIonPower = dlg.m_OptPos;
		OptNegIonPower = dlg.m_OptNeg;
	}
}

void CBTRDoc::CalculateAllLoads(BOOL replace)
{
	PtrList & List = PlatesList;
	CPlate * plate;
	CString S;

	SetDefaultMesh();

	SetLoadArray(NULL, FALSE);
	POSITION pos = List.GetHeadPosition();
	OptCombiPlot = -1; //no map selected
	S.Format("Include zero loaded maps to the list? "); // incl zero
	//int res = AfxMessageBox(S, MB_ICONQUESTION | MB_YESNOCANCEL); // question removed
	int res = AfxMessageBox("Calculate All non-zero maps", MB_ICONEXCLAMATION | MB_OKCANCEL); // question removed!
	//int res = IDNO;
	if (res != IDCANCEL) {
		CWaitCursor wait;
		while (pos != NULL) {
			plate = List.GetNext(pos);
			if (plate->Touched == TRUE) { // only non-zero loads 
			//if (res == IDYES || plate->Touched == TRUE) {
				SetNullLoad(plate); // to change - add params for steps applying 
				P_CalculateLoad(plate);
				SetLoadArray(plate, TRUE);
			}
		}
		ShowStatus();
		//InvalidateRect(NULL, TRUE);
	} // YES

}

int OldPDPexe(char * name)
{
	CString S;
	int size;
	unsigned long sizeH[1024];
//	FILE * f = fopen(name, "r");
	size = GetCompressedFileSize(name, sizeH);
//	size = GetFileSize(f, sizeH);
//	fclose(f);
	
	if (size != 278528){//PDP10 - 279040
		S.Format("BTR warning:\nFile Size (%d byte) \n not matching the last-known PDP version!", size);
		AfxMessageBox(S);
		return 1; // OLD
	}
	else return 0;// NEW ?
}

void CBTRDoc::OnTasksPDP() 
{
	char OpenDirName[1024];
	char name[1024];// exe
	char iname[1024];
	char bname[1024];
	CString S;

//	CFileDialog dlg(TRUE, "exe; exe", "PDP executable");
	CFileDialog dlg(TRUE, "exe | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"PDP executable (*.exe) | *.exe; *.EXE | All Files (*.*) | *.*||", NULL);
	
	if (dlg.DoModal() == IDOK) {
		strcpy(name, dlg.GetPathName());
		::GetCurrentDirectory(1024, OpenDirName);
		CurrentDirName = OpenDirName; 
//		SetTitle(OpenDirName);
//		SetTitle(name);
		strcpy(iname, "_Input_PDP_BTR.txt"); //PDPgeomFileName); // default name!
			
		BOOL OldExec = OldPDPexe(name);
		BOOL OldInput = OldPDPinput(iname);

		if (OldInput < 0) {
			AfxMessageBox("Error: PDP-Input failed!"); return;
		}

	/*	if (OldExec && OldInput)  S.Format("OLD versions of PDP-code and PDP-input file!\n\n Continue?");
		if (OldExec && !OldInput) S.Format("Versions mismatch!\n OLD pdp.exe\n and NEW pdp-Input file!\n\n Continue?");
		if (!OldExec && OldInput) S.Format("Versions mismatch!\n NEW pdp.exe\n and OLD pdp-Input file!\n\n Continue?");
*/
		if (OldExec || OldInput) {
			S.Format("BTR warning:\n Versions of PDP.exe and PDP-input\n may not fit each other!\n\n Run PDP Anyhow?");  
			int res = AfxMessageBox(S, 3);
			if (res != IDYES && res != IDOK) return;
		}

	/*	CPreviewDlg pdlg;
		pdlg.m_Filename = iname;//PDPgeomFileName;
		if (pdlg.DoModal() == IDCANCEL) return;
	*/
		PDPgeomLoaded = FALSE;
	
		if (ReadPDPinput(iname) == 0) {
				AfxMessageBox("PDP-input cancelled"); return; 
		} //fail
	
		else { // data loaded
			PDPgeomLoaded = TRUE; // scanned
			CheckData();
			if (!OptFree) { AdjustAreaLimits();	SetPlates();}
			SetReionPercent();
			OnShow();
			ShowFileText(iname); 	
		}


		OptSINGAP = TRUE; // 
		
	    int res = 0;
		strcpy(bname, "_Beamlet_Regular_Array.txt");
		
		res = ReadBeamletsNew(bname);
		if (res != 0) {
			SINGAPLoaded = TRUE;  
		//	ShowFileText(bname);	
		}
		//ReadSINGAP(); //->SINGAPLoaded + Regularity Check
		SetSINGAP();
	if (!OptSINGAP) { // MAMuG
		SetBeam(); 
		for (int i = 0; i < (int)NofChannelsHor; i++) ActiveCh[i] = TRUE;
		for (int j = 0; j < (int)NofChannelsVert; j++) ActiveRow[j] = TRUE;
		SetStatus(); 
	}

	if ((int)BeamSplitType ==0) SetPolarBeamletCommon(); //SetBeamletAt(0);
		else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ);
				
		OnShow();

		OptPDP = TRUE;
	/*	int res = CorrectPDPInput();
		if (res)*/
		CorrectFile(iname);//remove comments from PDP-input
		RunPDP(name); // PDP.exe
		OptPDP = FALSE;
	
	}
}

int CBTRDoc:: RunPDP(char * name)
///	BOOL RUN_SELECTED_APP(int n) from APPEAL.CPP
{
	STARTUPINFO st;
	PROCESS_INFORMATION pi;
	// const int MY_MESS = 1000;
	HANDLE HActiveProcess = NULL;
	//HICON Icon;

	BOOL i = 0;
	st.cb = 68;
	st.lpReserved = 0;
	st.lpDesktop = 0;
	st.lpTitle = 0; // 0- for windows app, name - for console app
	st.dwFlags = STARTF_USESHOWWINDOW | STARTF_USEPOSITION | STARTF_USESIZE | STARTF_USEFILLATTRIBUTE;
	st.dwX = 50;
	st.dwY = 100;
	st.dwXSize = 800;
	st.dwYSize = 800;
	st.cbReserved2 = 0;
	st.lpReserved2 = 0;
	st.wShowWindow = SW_SHOWDEFAULT;//SW_SHOWNORMAL;
	st.dwFillAttribute = FOREGROUND_INTENSITY |// FOREGROUND_BLUE | FOREGROUND_RED | 
		BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE | BACKGROUND_INTENSITY;//red text on white bk

	if (HActiveProcess == NULL) { // No process started	

			/*	i = CreateProcess(NULL, "D:\\Users\\Jane\\BTR ITER\\Release\\BTR.exe", 0,0,0,0,0,
								"D:\\Users\\Jane\\BTR ITER\\Release", &st, &pi);*/
		/*	i = CreateProcess(NULL, name, 0,0,0,0,0, CurrentDirName, &st, &pi);
			HActiveProcess = pi.hProcess;*/
			
		/*	i = CreateProcess(NULL, "A_pdp_LR.exe", 0,0,0,
				CREATE_NEW_CONSOLE,0, NULL, &st, &pi);*/
			i = CreateProcess(NULL, name, 0,0,0, CREATE_NEW_CONSOLE,0, NULL, &st, &pi);
			HActiveProcess = pi.hProcess;
		
			WaitMessage();
		
			OptPDP = TRUE;


	/*	case 1: 
			i = CreateProcess(NULL, "C:\\Program Files\\Far\\Far.exe", 0,0,0, CREATE_NEW_CONSOLE,0,
								"C:\\Program Files\\Far", &st, &pi);
			HActiveProcess = pi.hProcess;
			break;*/
//	}
	}

	else { // HActiveProcess != NULL Process Exists 
	//	GetExitCodeProcess(HActiveProcess, ExitCode);
	//	if (*ExitCode != 0) 
		
		TerminateProcess(HActiveProcess, 0);
		
		HActiveProcess = NULL;
//		OptPDP = FALSE;
		
	}
	
	BOOL finished = FALSE;
	DWORD lpEC;
	MSG message; 

//	WaitForSingleObject(HActiveProcess, INFINITE); // suspends parent process!
	while (!finished) {
	//	WaitMessage();
		::PeekMessage(&message, NULL, 0,0, PM_REMOVE); 
		::TranslateMessage(&message);
		::DispatchMessage(&message);
		GetExitCodeProcess(HActiveProcess, &lpEC);
  				//HANDLE hProcess,     // handle to the process
				//LPDWORD lpExitCode   // address to receive termination status
		if (lpEC != STILL_ACTIVE) finished = TRUE; 
	}
		
	
	ShowFileText("1_Hnbl_dat.txt"); // Show PDP Output file "1_Hnbl_dat.txt"

	
	return i;
	
}

void CBTRDoc::ShowBPdata(int n, int lines, int pos, int angle, int power) // show selected options
{
	m_Text.Empty();// = "";
	CString S, s, Ssort;
	COLORREF color;
	vector <minATTR> & arr = m_GlobalVector;// m_AttrVector[MaxThreadNumber - 1];
	C3Point Pgl, Ploc, Vat;
	double PowerW;
	Ssort = " ";
	if (OptAtomPower) Ssort += "ATOMS";
	if (OptNegIonPower) Ssort += " / NEG";
	if (OptPosIonPower) Ssort += " / POS";
	if (n >= 0)	S.Format("Particles data on Surf %d (in local CS) (%s) - %d lines\n", n, Ssort, lines);
	else S.Format("Particles data (in local CS) across ALL surfs (%s) - %d lines \n", Ssort, lines);
	//if (n >= 0)	S.Format("Particles data on Surf %d (in local CS) - %d lines\n", n, lines);
	//else S.Format("Particles data (in local CS) across ALL surfs  - %d lines \n", lines);
	m_Text += S;
	S.Format("Xlocal, Ylocal are in [m]\t  AXfall = VXloc / modV, AYfall = VYloc / modV \n\n");
	m_Text += S;

	CPlate * plateN = pMarkedPlate;// if selected (n > 0)
	CPlate * plate;// not selected -> all
	//Pgl = plate->GetGlobalPoint(Ploc);
	//S.Format("Num  Sort\t Xlocal  Ylocal\t AXfall  AYfall\t Power,W\t #surf\n");
	S = "  Num   Sort\t";
	if (pos == 1 || pos == 2) S += " Xlocal Ylocal  "; // 1 - local 3 - global 
	if (pos == 2 || pos == 3) S += " Xglob Yglob Zglob "; // 2 - local + global pos
	//if (angle == 1) S += "Polar Angle\t";
	if (angle > 0) S += " AXfall AYfall   ";
	if (power > 0) S += " Power,W\t ";
	S += " #surf\n";
	m_Text += S;

	int arrsize = (int)arr.size();
	int lim = min(lines, arrsize);
	if (lim < 1) {
		S.Format("\n ----------- No data found ---------------\n");
		m_Text += S;
	}

	int i = 0; // written lines
	int k = -1; // array index
	while (i < lim && k < arrsize -1) {
		k++;
		minATTR &tattr = arr[k];
		if (n >= 0 && tattr.Nfall != n) {// single surf selected
			continue;
		}
		else { // all plates or true number
			if (!OptAtomPower && tattr.Charge == 0) continue;
			if (!OptNegIonPower && tattr.Charge < 0) continue;
			if (!OptPosIonPower && tattr.Charge > 0) continue;
			
			PowerW = tattr.PowerW;
			Ploc.X = tattr.Xmm * 0.001;// plate->GetLocal(Pgl);
			Ploc.Y = tattr.Ymm * 0.001;
			Ploc.Z = 0;
			Vat.X = tattr.AXmrad * 0.001;
			Vat.Y = tattr.AYmrad * 0.001;
			Vat.Z = 1;
			
			if (n >=0) 
				Pgl = plateN->GetGlobalPoint(Ploc);// one
			else { // all plates
				plate = GetPlateByNumber(tattr.Nfall);
				if (plate == NULL) Pgl = C3Point(-1, -1, 0); // undefined
				else Pgl = plate->GetGlobalPoint(Ploc);
			}

			switch (tattr.Charge) {
			case -1: color = RGB(0, 255, 0); Ssort = "NEG "; break;
			case  0: color = RGB(0, 0, 255); Ssort = "ATOM"; break;
			case  1: color = RGB(255, 0, 0); Ssort = "POS "; break;
			default: color = RGB(0, 0, 0); Ssort = "UNDEFINED PARTICLE";
			}

			S = " ";
			//S.Format("%5d  %s\t %6.3f %6.3f\t %6.3f %6.3f\t %9.2e\t %3d\n",
				//i, Ssort, Ploc.X, Ploc.Y, Vat.X, Vat.Y, PowerW, tattr.Nfall);
			s.Format("%5d  %s\t", i, Ssort); // "Num   Sort\t";
			S += s;
			if (pos == 1 || pos == 2) {
				s.Format("%6.3f %6.3f\t", Ploc.X, Ploc.Y); // " Xlocal   Ylocal\t "; // 1 - local pos
				S += s;   
			}
			if (pos == 2 || pos == 3) {
				s.Format("%6.3f %6.3f %6.3f\t", Pgl.X, Pgl.Y, Pgl.Z); // " Xglob   Yglob\t "; // 1 - local pos
				S += s;   
			}
			if (angle > 0) {
				s.Format("%6.3f %6.3f\t", Vat.X, Vat.Y); // " AXfall  AYfall\t ";
				S += s;
			}
			if (power > 0) {
				s.Format("   %9.2e\t", PowerW); //" Power,W\t ";
				S += s;
			}
			s.Format("%  3d\n", tattr.Nfall); // " #surf\n";
			S += s;
			m_Text += S;
			
			i++; // line written

		} // nfall = plate number
				 
	} // Global vector size 

	pDataView->m_rich.SetFont(&pDataView->font, TRUE);
	pDataView->m_rich.SetBackgroundColor(FALSE, RGB(255, 187, 130)); // (250, 250, 180)); // G230
	pDataView->m_rich.SetWindowText(m_Text);
	pDataView->m_rich.SetModify(FALSE);
}


void CBTRDoc::ShowBPdata(int n, int lines) // show statistics on Marked Surf in orange panel
{
	m_Text.Empty();// = "";
	CString S, Ssort;
	COLORREF color;
	
	vector <minATTR> & arr = m_GlobalVector;// m_AttrVector[MaxThreadNumber - 1];
		
	C3Point Pgl, Ploc, Vat;
	double power;
	//CPlate * plate = pMarkedPlate;
	//if (plate == NULL) return;
	Ssort = " ";
	if (OptAtomPower) Ssort += "ATOMS";
	if (OptNegIonPower) Ssort += " / NEG";
	if (OptPosIonPower) Ssort += " / POS";
	if (n >= 0)	S.Format("Particles data on Surf %d (in local CS) (%s) - %d lines\n", n, Ssort, lines);
	else S.Format("Particles data (in local CS) across ALL surfs (%s) - %d lines \n", Ssort, lines);
	m_Text += S;
	S.Format("Xlocal, Ylocal are in [m]\t  AXfall = VXloc / modV, AYfall = VYloc / modV \n\n");
	m_Text += S;
	S.Format("Num  Sort\t Xlocal  Ylocal\t AXfall  AYfall\t Power,W\t #surf\n");
	m_Text += S;
	int arrsize = (int)arr.size();
	int lim = min(lines, arrsize);
	if (lim < 1) {
		S.Format("\n ----------- No data found ---------------\n");
		m_Text += S;
	
	}

		
	//for (int i = 0; i < lim; i++) {
	int i = 0; // written lines
	int k = -1; // array index
	while (i < lim && k < arrsize-1) {
		k++;
		minATTR &tattr = arr[k];
		if (n >= 0 && tattr.Nfall != n) {// single surf selected
			continue;
		}
		else { // all plates or true number
			if (!OptAtomPower && tattr.Charge == 0) {
				continue;
			}
			if (!OptNegIonPower && tattr.Charge < 0) {
				continue;
			}
			if (!OptPosIonPower && tattr.Charge > 0) {
				continue;
			}
			power = tattr.PowerW;
			Ploc.X = tattr.Xmm * 0.001;// plate->GetLocal(Pgl);
			Ploc.Y = tattr.Ymm * 0.001;
			Ploc.Z = 0;
			Vat.X = tattr.AXmrad * 0.001;
			Vat.Y = tattr.AYmrad * 0.001;
			Vat.Z = 1;

			switch (tattr.Charge) {
			case -1: color = RGB(0, 255, 0); Ssort = "NEG "; break;
			case  0: color = RGB(0, 0, 255); Ssort = "ATOM"; break;
			case  1: color = RGB(255, 0, 0); Ssort = "POS "; break;
			default: color = RGB(0, 0, 0); Ssort = "UNDEFINED PARTICLE";
			}

			S.Format("%5d  %s\t %6.3f %6.3f\t %6.3f %6.3f\t %9.2e\t %3d\n",
				i, Ssort, Ploc.X, Ploc.Y, Vat.X, Vat.Y, power, tattr.Nfall);
			m_Text += S;
			i++; // line written

		} // nfall = plate number

		/*if (::PeekMessage(&message, NULL, 0, 0, PM_REMOVE)) {
			::TranslateMessage(&message);
			::DispatchMessage(&message);
		}*/
	} // Global vector size 
	  
	pDataView->m_rich.SetFont(&pDataView->font, TRUE);
	pDataView->m_rich.SetBackgroundColor(FALSE, RGB(255, 187, 130)); // (250, 250, 180)); // G230
	pDataView->m_rich.SetWindowText(m_Text);
	pDataView->m_rich.SetModify(FALSE);
}

void CBTRDoc::ShowLogFile(int lines) // show log part. if lines == 0 -> show all
{
	m_Text.Empty();// = "";
	//m_Text += "--- press F2 to return to BTR Input list! ---\n\n";
	/*while (!feof(fin)) {
		fgets(buf, 1024, fin);
		if (!feof(fin))	m_Text += buf;
	}
	fclose(fin);
	SetTitle(name);*/
	m_Text += "PROGRESS...\n\n";
	CString S;
	
	int sz = m_GlobalLog.size();
	int imin = max(sz-lines, 0); // to display
	if (imin >= sz) imin = 0;// if lines == 0
	for (int i = sz - 1; i >= imin; i--) {
		S.Format(" %s", m_GlobalLog[i]);
		m_Text += S;// m_GlobalLog[i];
	}
	pDataView->m_rich.SetFont(&pDataView->font, TRUE);
	pDataView->m_rich.SetBackgroundColor(FALSE, RGB(250, 250, 180)); // G230
	pDataView->m_rich.SetWindowText(m_Text);
	pDataView->m_rich.SetModify(FALSE);
}

void CBTRDoc:: ShowFileText(char * fname)
{
	FILE * f;
	//	char * fname = "1_Hnbl_dat.txt";
		char buf[1024];
		f = fopen(fname, "r");
		if (f == NULL) return;
		m_Text.Empty();// = "";
		m_Text += "...... press F2 to return to BTR Input list! .......\n\n";
		m_Text += "***** ";
		m_Text += fname;
		m_Text += " **********\n";
		while (!feof(f)) {
			fgets(buf, 1024, f);
			if (!feof(f))	m_Text += buf;
		}
		fclose(f);
		pDataView->m_rich.SetFont(&pDataView->font, TRUE);
		pDataView->m_rich.SetBackgroundColor(FALSE, RGB(255, 187, 130)); //RGB(250,180,180));
		pDataView->m_rich.SetWindowText(m_Text);
		pDataView->m_rich.SetModify(FALSE);
		SetTitle(fname);
}

void CBTRDoc::ReadPlasmaPSI()
{
	char name[1024];
	CString S;
	CFileDialog dlg(TRUE, "txt; dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"EQDSK format (*.txt);(*.dat) | *.txt; *.TXT; *.dat; *.DAT| All Files (*.*) | *.*||", NULL);

	if (dlg.DoModal() == IDOK) {
		strcpy(name, dlg.GetPathName());
		CWaitCursor wait;
		CPreviewDlg pdlg;
		pdlg.m_Filename = name;
		if (pdlg.DoModal() == IDCANCEL) return;
		SetTitle(name);// + TaskName);

		BOOL isread = pPlasma->ReadPSI(name);
		if (!isread) {
			AfxMessageBox("PSI not read");
			pPlasma->PSIloaded = FALSE; // use simple model R/Rnorm
			return;
		}

		//CPlate * plate0 = new CPlate();
		double stepR = pPlasma->StepR;
		double stepZ = pPlasma->StepZ;
		double DR = pPlasma->Rmax - pPlasma->Rmin;
		double DZ = pPlasma->Zmax - pPlasma->Zmin;
		//S.Format("R/Z steps %g /%g   DR/DZ  %g /%g", stepR, stepZ, DR, DZ);	AfxMessageBox(S);

		CLoad * load = new CLoad(DR, DZ, stepR, stepZ);
		//S.Format("load limits Nx %d Ny %d", load->Nx, load->Ny);	AfxMessageBox(S);

		load->Val = pPlasma->PSI;
		load->SetSumMax();
		if (load->MaxVal < 1.e-10) {
			AfxMessageBox("Zero load (PSI array)");
			return;
		}
		//S.Format("PSImax = %g", load->MaxVal);	AfxMessageBox(S);
		load->iProf = (int)(0.5 * load->iMaxVal);
		load->jProf = (int)(0.5 * load->jMaxVal);
		pMarkedPlate = new CPlate();
		C3Point LB(1000, pPlasma->Rmin, pPlasma->Zmin);
		C3Point RT(1000, pPlasma->Rmax, pPlasma->Zmax);
		pMarkedPlate->SetFromLimits(LB, RT);
		pMarkedPlate->Load = load;
		//pMarkedPlate->Load->SetSumMax();
		pMarkedPlate->Number = 1000;
		pMarkedPlate->Selected = TRUE;
		pMarkedPlate->Loaded = TRUE;
		pMarkedPlate->SmLoad = new CLoad(DR, DZ, stepR, stepZ);
		pMarkedPlate->SmoothDegree = SmoothDegree;
		pMarkedPlate->filename = name;
		pMarkedPlate->Comment = "PSI(R,Z)";
		OptParallel = 0;
		OptCombiPlot = 0;
		pLoadView->Cross.X = load->iProf * load->StepX;
		pLoadView->Cross.Y = load->jProf * load->StepY;
		ShowFileText(name);
		//load.DrawLoad();
		ShowProfiles = TRUE;
		pMarkedPlate->ShowLoadState();
		//	if (pLoadView->ShowLoad == TRUE) pLoadView->InvalidateRect(NULL, TRUE);
		pSetView->InvalidateRect(NULL, TRUE);//	OnPlotMaxprofiles();
	} // dlg OK
	else {
		AfxMessageBox("PSI read cancelled\n Simplified model activated");
		pPlasma->PSIloaded = FALSE; // use simple model R/Rnorm
		return;
	}
}

void CBTRDoc::OnUpdateTasksPDP(CCmdUI*) 
{
//	pCmdUI->SetCheck(OptPDP);
}

void CBTRDoc::OnResultsPdpoutputTable() 
{
	CLoadView * pLV = (CLoadView *) pLoadView;
	CLoad * load = NULL;
	char name[1024];
//	CFileDialog dlg(TRUE, "txt; *txt", "PDP load table");
	CFileDialog dlg(TRUE, "txt; dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Tabular data (*.txt);(*.dat) | *.txt; *.TXT; *.dat; *.DAT| All Files (*.*) | *.*||", NULL);
	
	if (dlg.DoModal() == IDOK) {
	
		strcpy(name, dlg.GetPathName());
		CWaitCursor wait;
		CPreviewDlg dlg;
		dlg.m_Filename = name;
		if (dlg.DoModal() == IDCANCEL) return;
		SetTitle(name);// + TaskName);
		OptPDP = TRUE;
	
		ReadEQDSKtable(name); // test
		//return;
		//load = ReadPDPLoadTable(name);
		//load = pTorCrossPlate->Load;
		load = pMarkedPlate->Load;
		if (load != NULL && load->MaxVal >1.e-10) {
		//	pLV->ShowLoad = TRUE;
		//	pLV->SetLoad_Plate(load, pMarkedPlate);
		//	pLV->Contours = FALSE;
			pLV->Cross.X = pMarkedPlate->Load->iProf * pMarkedPlate->Load->StepX;
			pLV->Cross.Y = pMarkedPlate->Load->jProf * pMarkedPlate->Load->StepY;
		//	ShowProfiles = TRUE;
			pMarkedPlate->ShowLoadState();
			//pMarkedPlate->ShowLoad();
		} // load != NULL
		else {
			pLV->ShowLoad = FALSE;
			pSetView->Load = NULL;
		}

		pMainView->InvalidateRect(NULL, TRUE);
		//pLV->InvalidateRect(NULL, TRUE);
		//pSetView->InvalidateRect(NULL, TRUE);
		ShowFileText(name);
	} // if IDOK

	OptParallel = FALSE;//  - to be found 

}

CLoad * CBTRDoc:: ReadPDPLoadTable(char * name)
{
//	CPlate * plate; 
	CPlate * plate0 = new CPlate();
	CLoad * load;// = new CLoad();
	
	int Nx = 0, Ny = 0, SmoothDegree = 0;
	double StepH = 0, StepV = 0, Hmin, Vmin, Hmax, Vmax, Zmax, Scell;
	C3Point Orig, OrtX, OrtY;

	FILE * fin;
	if ( (fin= fopen(name, "r")) == NULL) {
		CString S ="Can't find/open ";
		S+=  name;
		AfxMessageBox(S, MB_ICONSTOP | MB_OK);
		return NULL;
	}

	char buf[1024];
	int i, j, result;
	C3Point lb(1000,1000,1000), rt(1000,1000,1000);
	CString line;
	CString axisX, axisY;

	if (fgets(buf,1024,fin) == NULL) { AfxMessageBox("Problem with line 1"); fclose(fin); return NULL; }
		result = sscanf(buf, "%d %d", &Nx, &Ny); 
		if (result != 2) {
			while (!feof(fin) && result != 2) {
				fgets(buf, 1024, fin);
				result = sscanf(buf, "%d %d", &Nx, &Ny);
			}
			if (feof(fin)) { AfxMessageBox("Invalid Format of 1-st line", MB_ICONSTOP | MB_OK); fclose(fin); return NULL;}
			if (Nx*Ny <= 1.e-6) {AfxMessageBox("Invalid numbers Nx, Ny", MB_ICONSTOP | MB_OK); fclose(fin); return NULL;}
		}
		line = buf;
		int pos = line.Find("#");
		if (pos < 0) {
			plate0->Comment = "Enjoy the Picture!";// "NO COMMENT";
		}

		else {
			if (pos >= 0) line = line.Mid(pos+1);
			pos = line.Find("\n");
			if (pos > 0) line = line.Left(pos);
			plate0->Comment += line;
		}

		if (fgets(buf,1024,fin) == NULL) { AfxMessageBox("Problem with line 2"); fclose(fin); return NULL; }
		result = sscanf(buf, "%le %le", &Hmin, &StepH); 
		if (result != 2) {AfxMessageBox("Invalid line 2"); fclose(fin); return NULL;}
		if (StepH < 1.e-6) {AfxMessageBox("Hor. Step = 0!",MB_ICONSTOP | MB_OK); fclose(fin); return NULL;}
		axisX = buf;

		if (fgets(buf,1024,fin) == NULL) { AfxMessageBox("Problem with line 3"); fclose(fin); return NULL; }
		result = sscanf(buf, "%le %le", &Vmin, &StepV); 
		if (result != 2) {AfxMessageBox("Invalid line 3"); fclose(fin); return NULL;}
		if (StepV < 1.e-6) {AfxMessageBox("Vert. StepY = 0!",MB_ICONSTOP | MB_OK); fclose(fin); return NULL;}
		axisY = buf;
		
		if (fgets(buf,1024,fin) == NULL) { AfxMessageBox("Problem with line 4"); fclose(fin); return NULL; }
		result = sscanf(buf, "%le %le", &Scell, &Zmax); 
		if (result != 2) {AfxMessageBox("Invalid line 4"); fclose(fin); return NULL;}
		if (Zmax < 1.e-12) {AfxMessageBox("Zmax < 1.e-12",MB_ICONSTOP | MB_OK); fclose(fin); return NULL;}
	
	Hmax = Hmin + Nx*StepH;
	Vmax = Vmin + Ny*StepV;
	
	pos = axisX.Find("#");
	if (pos < 0) { 
		AfxMessageBox("Horizontal Axis not defined\n (# not found)");
		OrtX = C3Point(0,1,0);
		lb = C3Point(1000,Hmin,Vmin); 
		rt = C3Point(1000,Hmax, Vmax);
	}
	else { 
		axisX = axisX.Mid(pos+1);
		if (axisX.Find("X") >= 0) {
			OrtX = C3Point(1,0,0);
			lb.X = Hmin;
			rt.X = Hmax;
		}
		if (axisX.Find("Y") >= 0) {
			OrtX = C3Point(0,1,0); 
			lb.Y = Hmin; 
			rt.Y = Hmax;
		}
		if (axisX.Find("Z") >= 0) { 
			OrtX = C3Point(0,0,1); 
			lb.Z = Hmin; 
			rt.Z = Hmax;
		}
	}// # found

	pos = axisY.Find("#");
	if (pos < 0) {
		AfxMessageBox("Vertical Axis not defined\n (# not found)");
		OrtY = C3Point(0,0,1);
		lb = C3Point(1000,Hmin,Vmin); 
		rt = C3Point(1000,Hmax, Vmax);
	}
	else {
		axisY = axisY.Mid(pos+1);
		if (axisY.Find("X") >= 0) { 
			OrtY = C3Point(1,0,0); 
			lb.X = Vmin; 
			rt.X = Vmax; 
		}
		if (axisY.Find("Y") >= 0) { 
			OrtY = C3Point(0,1,0); 
			lb.Y = Vmin; 
			rt.Y = Vmax; 
		}
		if (axisY.Find("Z") >= 0) {
			OrtY = C3Point(0,0,1);
			lb.Z = Vmin; 
			rt.Z = Vmax; 
		}
	} // # found
	
	plate0->SetFromLimits(lb, rt);//SetOrts();
	//plate0->OrtX = OrtX; plate0->OrtY = OrtY; plate0->OrtZ = VectProd(OrtX, OrtY); 
	
	load = new CLoad(Hmax-Hmin, Vmax-Vmin, StepH, StepV);
	
	plate0->Load = load;
	load->Comment = plate0->Comment;
	int scenario = 0;
	if (plate0->Comment.Find("Poloidal") >= 0) {
		if (plate0->Comment.Find("cenario 4") >= 0)	scenario = 4;
		if (plate0->Comment.Find("cenario 2") >= 0)	scenario = 2;
	}

	
	CString text = "";

	while (!feof(fin)) {
			fgets(buf, 1024, fin);
			if (!feof(fin))	text += buf;
		}

	char *buff, *nptr, *endptr;
	double val, newval;

	double PSIc, PSIx;
	switch (scenario) { // scenario > 0  -> PSI table
		case 2: PSIc = 12.0375224; PSIx = -0.406686479; break; // scenario 2
		case 4: PSIc = 8.9614899;  PSIx = 3.238912; break; // scenario 4
		default : break; // PDP table
	}

	int length = text.GetLength()*2;
	buff = (char *)calloc(length, sizeof(char));
	strcpy(buff, text);
	
	nptr = buff;

	for (j = 0; j <= Ny; j++)
	for (i = 0; i <= Nx; i++) {
		val = strtod(nptr,&endptr);
		
		if (scenario > 0) { // PSI table
			val = (val - PSIc) / (PSIx - PSIc); // EQDSK
			if (val > 1 || val < 0) val = -0.01;
			//newval = GetPlasmaTeNe(val).Z; // Ne
		} // PSI

		// else -> PDP table

		plate0->Load->Val[i][j] = val;
		if (nptr == endptr) nptr++; //catch special case
		else nptr = endptr;
	}
	//SetDecayInPlasma();
	fclose(fin);
	
	load->SetSumMax();
	if (Scell > 1.e-12)	load->Sum = load->Sum / StepH / StepV * Scell;// PAA email 25.12.09

		plate0->Selected = TRUE;
		plate0->Loaded = TRUE;
		plate0->Load = load;
		plate0->SmLoad = new CLoad(Hmax-Hmin, Vmax-Vmin, StepH, StepV);
		plate0->SmoothDegree = SmoothDegree;
		plate0->filename = name;
		plate0->Number = 1000;
	//	SetLoadArray(plate0, TRUE); // changes plate->Number!
	//	AddPlate(plate0);
		pMarkedPlate = plate0;
		if (scenario >0 ) pTorCrossPlate = plate0;
		else pTorCrossPlate = NULL;
		//OptParallel = FALSE;// not parallel calculation
		OptCombiPlot = 0; 

 return (load);

}

void CBTRDoc::ReadEQDSKtable(char * name)
/*// format is taken from A.Dnestrovsky message 08/11/2017
write(lun_geqdsk,2000) geqdsk_lbl,idum, nh(Nx), nv(Ny)

write(lun_geqdsk,2001) rdim(DR),zdim(DZ),rcentr,rleft(Rmin),zmid(Zmid)
write(lun_geqdsk,2001) rmaxis,zmaxis,zpsimag(PSIc),zpsibdy(PSIx),bcentr
write(lun_geqdsk,2001) pcur,zpsimag(PSIc),xdum,rmaxis,xdum
write(lun_geqdsk,2001) zmaxis,xdum,zpsibdy(PSIx),xdum,xdum

write(lun_geqdsk,2001) (fpol(i),i=1,nh) // f = Bt*R
write(lun_geqdsk,2001) (pres(i),i=1,nh) // pressure N/m**2
write(lun_geqdsk,2001) (ffprime(i),i=1,nh) // smth on flux grid
write(lun_geqdsk,2001) (pprime(i),i=1,nh)  // smth on flux grid

write(lun_geqdsk,2001) ((psirz(i,j),i=1,nh),j=1,nv) // PSI table [Nx,Ny]

write(lun_geqdsk,2001) (qpsi(i),i=1,nh)
write(lun_geqdsk,2002) nb,nblim
write(lun_geqdsk,2001) (rbdy(i),zbdy(i),i=1,nb)
write(lun_geqdsk,2001) (rlim(i),zlim(i),i=1,nblim)

//next part - from Kuyan 01/11/2010
Rmax = Rmin + DR
Zmin = Zmid - DZ/2
Zmax = Zmid + DZ/2
B0 = bcentr * rcentr / rmaxis // B on mag axis?

DO i1 = 1 , Nx
Rw(i1) = Rmin + (Rmax-Rmin)*(i1-1)/(Nx-1)
END DO
DO i2 = 1 , Ny
Z(i2) = Zmin + (Zmax-Zmin)*(i2-1)/(Ny-1)
END DO

! ���������� � ���� �� ��������� ���
DO i2 = 1 , Ny
DO i1 = 1 , Nx
psirz(i1,i2) = psirz(i1,i2) - PSIc
END DO
END DO
PSIx = PSIx - PSIc // �� �����������
*/
//val = (val - PSIc) / (PSIx - PSIc); //-> psi = psirz / PSIx

{
	PSIvolume.RemoveAll();
	for (int k = 0; k < MagSurfDim; k++) PSIvolume.Add(0.001);

	FILE * fin;
	CString S;
	if ((fin = fopen(name, "r")) == NULL) {
		S = "Can't find/open ";
		S += name;
		AfxMessageBox(S, MB_ICONSTOP | MB_OK);
		return;
	}

	char buf[1024];
	int idum, Nx, Ny;
	char s[255];

	// line 1 : geqdsk_lbl,idum, nh(Nx), nv(Ny)
	if (fgets(buf, 1024, fin) == NULL) { 
		AfxMessageBox("Problem with line 1"); 
		fclose(fin); 
		return;
	}

	int res = sscanf(buf, "%s %d %d %d", s, &idum, &Nx, &Ny);
	if (res != 4) {
		AfxMessageBox("Invalid format in line 1", MB_ICONSTOP | MB_OK);
		fclose(fin);
		return;
	}
	if (Nx*Ny <= 1.e-6) {
		AfxMessageBox("Invalid numbers Nx, Ny", MB_ICONSTOP | MB_OK); 
		fclose(fin); 
		return;
	}

//	S.Format("Nx = %d Ny = %d", Nx, Ny);
//	AfxMessageBox(S);
	double val;
		
	// line 2 : rdim(DR),zdim(DZ),rcentr,rleft(Rmin),zmid(Zmid)
	double DR, DZ, Rmin, Zmid; //read
	double Rmax, Zmin, Zmax;   // calculated
	if (fgets(buf, 1024, fin) == NULL) {
		AfxMessageBox("Problem with line 2");
		fclose(fin);
		return;
	}
	
	res = sscanf(buf, "%le %le %le %le %le", &DR, &DZ, &val, &Rmin, &Zmid);
	if (res != 5) {
		AfxMessageBox("Invalid format in line 2", MB_ICONSTOP | MB_OK);
		fclose(fin);
		return;
	}
	if (DR*DZ <= 1.e-6) {
		AfxMessageBox("Invalid dimensions DR, DZ", MB_ICONSTOP | MB_OK);
		fclose(fin);
		return;
	}
	//S.Format("Rmin = %le Zmid = %le", Rmin, Zmid);
	//AfxMessageBox(S);
	Rmax = Rmin + DR;
	Zmin = Zmid - 0.5*DZ;
	Zmax = Zmid + 0.5*DZ;
	
	// line 3 : rmaxis,zmaxis,zpsimag(PSIc),zpsibdy(PSIx),bcentr
	double v1, v2; // read but not used
	double PSIc, PSIx;
	if (fgets(buf, 1024, fin) == NULL) {
		AfxMessageBox("Problem with line 3");
		fclose(fin);
		return;
	}

	res = sscanf(buf, "%le %le %le %le %le", &v1, &v2, &PSIc, &PSIx, &val);
	if (res != 5) {
		AfxMessageBox("Invalid format in line 3", MB_ICONSTOP | MB_OK);
		fclose(fin);
		return;
	}
	if (fabs(PSIc*PSIx) <= 1.e-6) {
		AfxMessageBox("PSIc or PSIx too small", MB_ICONSTOP | MB_OK);
		
	}
	S.Format("PSIc = %le PSIx = %le", PSIc, PSIx);
	AfxMessageBox(S);

	// line 4 : read but not used ( pcur,zpsimag(PSIc),xdum,rmaxis,xdum )
	if (fgets(buf, 1024, fin) == NULL) {
		AfxMessageBox("Problem with line 4");
		fclose(fin);
		return;
	}
	// line 5 : read but not used  ( zmaxis,xdum,zpsibdy(PSIx),xdum,xdum )
	if (fgets(buf, 1024, fin) == NULL) {
		AfxMessageBox("Problem with line 5");
		fclose(fin);
		return;
	}

	// read arrays
	char *buff, *nptr, *endptr;
	CString text = "";

	while (!feof(fin)) { // read total text in file
		fgets(buf, 1024, fin);
		if (!feof(fin))	text += buf;
	}
	
	int size = text.GetLength();
	
	// parse text
	int length = text.GetLength() * 2;
	buff = (char *)calloc(length, sizeof(char));
	strcpy(buff, text);
	nptr = buff;
/*	int count = 0;
	int len = (int)strlen(nptr);//sizeof(nptr);
	while (len > 0) { //!feof(fin)) {
		val = strtod(nptr, &endptr);
		count++;
		//plate0->Load->Val[i][j] = val;
		if (nptr == endptr) nptr++; //catch special case
		else nptr = endptr;
		len = (int)strlen(nptr);// sizeof(nptr);
	}
	S.Format("%d chars\n %d values", size, count);
	AfxMessageBox(S);
*/

// read 4 arrays [Nx]
	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < Nx; i++) {
			val = strtod(nptr, &endptr);
			if (nptr == endptr) nptr++; //catch special case
			else nptr = endptr;
		}
	}

	double PSI;
	int kpsi;
	double PSIxn = PSIx - PSIc; // �� �����������
	CPlate * plate0 = new CPlate();
	CLoad * load;
	double stepR = DR / (Nx - 1);
	double stepZ = DZ / (Ny - 1);
	C3Point lb = C3Point(1000, Rmin, Zmin);
	C3Point rt = C3Point(1000, Rmax, Zmax);
	plate0->SetFromLimits(lb, rt);//SetOrts();
								  //plate0->OrtX = OrtX; plate0->OrtY = OrtY; plate0->OrtZ = VectProd(OrtX, OrtY); 

	load = new CLoad(DR, DZ, stepR, stepZ);
	
// read pol flux array [Nx, Ny]	
	int count = 0;
	for (int j = 0; j < Ny; j++) {
		for (int i = 0; i < Nx; i++) {
			val = strtod(nptr, &endptr);
			count++;
			//val = (val - PSIc) / (PSIx - PSIc); //-> psi = psirz / PSIx
			PSI = (val - PSIc) / PSIxn; // normalised
			load->Val[i][j] = PSI; //-> psi = psirz / PSIxval;
			if (nptr == endptr) nptr++; //catch special case
			else nptr = endptr;
			kpsi = (int)floor(PSI / StepPSI);
			if (kpsi >= 0 && kpsi < MagSurfDim)	PSIvolume[kpsi] += 1;// stepR*stepZ
		}
	}
	// next lines - not used 
	fclose(fin);

	S.Format("%d psi values read /n Nx %d Ny %d", count, Nx, Ny);
	AfxMessageBox(S);

	load->SetSumMax();
	load->iProf = (int)(0.5 * load->iMaxVal);
	load->jProf = (int)(0.5 * load->jMaxVal);
	plate0->Selected = TRUE;
	plate0->Loaded = TRUE;
	plate0->Load = load;
	plate0->SmLoad = new CLoad(DR, DZ, stepR, stepZ);
	plate0->SmoothDegree = 0;// SmoothDegree;
	plate0->filename = name;
	plate0->Number = 1000;
	//	SetLoadArray(plate0, TRUE); // changes plate->Number!
	//	AddPlate(plate0);
	pMarkedPlate = plate0;
	pMarkedPlate->Load = load;
	pTorCrossPlate = plate0;
	pTorCrossPlate->Load = load;

	PSILoaded = TRUE;
	if (ProfLoaded) PlasmaLoaded = TRUE;
	else PlasmaLoaded = FALSE;

	//if (scenario >0) pTorCrossPlate = plate0; else pTorCrossPlate = NULL;
	//OptParallel = FALSE;// not parallel calculation
	OptCombiPlot = 0;
}


void CBTRDoc::OnDataImportSingapBeam() 
{
	OnPdpBeamlets();
	
}

void CBTRDoc::OnDataImportMamugBeam() 
{

	OnPdpBeamlets();
}

void CBTRDoc::OnPdpBeamlets() 
{
	if (!STOP) {
		AfxMessageBox("Stop calculations before reading new data! \n (RED CROSS stop button on the Toolbar)");
		return ;
	}
	OptSINGAP = TRUE; // 
	ReadSINGAP(); //->SINGAPLoaded + Regularity Check
	SetSINGAP();
	if (!OptSINGAP) { // MAMuG
		SetBeam(); 
		for (int i = 0; i < (int)NofChannelsHor; i++) ActiveCh[i] = TRUE;
		for (int j = 0; j < (int)NofChannelsVert; j++) ActiveRow[j] = TRUE;
		//SetStatus(); 
	}
	SetStatus(); // for SINGAP as well
	if ((int)BeamSplitType ==0) SetPolarBeamletCommon(); //SetBeamletAt(0);
		else SetGaussBeamlet(BeamCoreDivY, BeamCoreDivZ);
		
	//OnShow();
}

void CBTRDoc::OnDataExportPDPgeom() 
{
	//AfxMessageBox("Sorry, not available now\n Can be switched ON by request");
	//return;

	/*char name[1024];
	FormDataText(TRUE);// include internal names of parameters
	CFileDialog dlg(FALSE, "dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"BTR Output file (*.dat) | *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
		if (dlg.DoModal() == IDOK) {
			FILE * fout;
			strcpy(name, dlg.GetPathName());
			fout = fopen(name, "w");
			fprintf(fout, m_Text);
			fclose(fout);
			SetTitle(name);// + TaskName);
		}
		delete dlg;
*/
	char name[1024];// = "_Input_PDP_BTR.txt";
	strcpy(name,"_Input_PDP_BTR.txt");
//	char title[1024];
//	char newname[1024];
	FILE * fin;
	CString S;

	CFileDialog dlg(FALSE, "txt; bak | * ", name, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"PDP INPUT file (*.txt); (*.bak) | *.txt; *.TXT; *.bak; *.BAK | All Files (*.*) | *.*||", NULL);
	if (dlg.DoModal() == IDOK) {
			strcpy(name, dlg.GetPathName());
		//	strcpy(title, dlg.GetFileTitle());
		//	strcpy(newname, title);
		//	strcat(newname, ".bak");
			

	/*	if ((fin = fopen(name, "r")) != 0) {// already exists
			fclose(fin);
			DeleteFile(newname);
			MoveFile(name, newname);
			S.Format("Old data are kept in file %s", newname); 
			AfxMessageBox(S);
		}*/
	
		WritePDPinput(name);
		
		/* CPreviewDlg pdlg;
		pdlg.m_Filename = name;
		if (pdlg.DoModal() == IDCANCEL) { // return back
			DeleteFile(name);
			MoveFile(newname, name);
			S.Format("Old data are kept in file %s", name); 
			AfxMessageBox(S);
		}*/

	} // file dlg OK
	
}

void CBTRDoc::OnDataExportRegularBeam() 
{
	//char * name = "_Beamlet_Regular_Array.txt";
	char name[1024];// = "_Input_PDP_BTR.txt";
	strcpy(name,"_Beamlet_Regular_Array.txt");
//	char title[1024];
//	char newname[1024];
	FILE * fin;
	CString S;

	CFileDialog dlg(FALSE, "txt; bak | * ", name, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Beamlets file (*.txt); (*.bak) | *.txt; *.TXT; *.bak; *.BAK | All Files (*.*) | *.*||", NULL);
	if (dlg.DoModal() == IDOK) {
			strcpy(name, dlg.GetPathName());
		//	strcpy(title, dlg.GetFileTitle());
		//	strcpy(newname, title);
		//	strcat(newname, ".bak");

	/*	if ((fin = fopen(name, "r")) != 0) {// already exists
			fclose(fin);
			DeleteFile(newname);
			MoveFile(name, newname);
			S.Format("Old data are kept in file %s", newname); 
			AfxMessageBox(S);
		} */
	
		//WriteRegularBeam(name);
		WriteSingapBeam(name);
		
	/*	CPreviewDlg pdlg;
		pdlg.m_Filename = name;
		if (pdlg.DoModal() == IDCANCEL) { // return back
			DeleteFile(name);
			MoveFile(newname, name);
			S.Format("Old data are kept in file %s", name); 
			AfxMessageBox(S);
		}
*/
	} // file dlg OK
	
	
}

void CBTRDoc::WriteSingapBeam(char * name)
{
	FILE * fout;
	CString S;
	BEAMLET_ENTRY be;
	int kmax = BeamEntry_Array.GetUpperBound();

	fout = fopen(name, "w"); 
	fprintf(fout, "  Beam array data, created by BTR 4.14\n");

	fprintf(fout, "  Y,mm\t AlfY,mrad DivY,mrad\t\t Z,mm\t Alfz,mrad DivZ,mrad\t\t Fract\t column\t row\n");
	
	for (int k = 0; k <= kmax; k++) {
		be = BeamEntry_Array[k];

		be.AlfY -= BeamMisHor; //mrad -> rad
		be.AlfZ -= BeamMisVert + BeamVertTilt;
		if  (!OptFree) be.AlfZ -= VertInclin; // NBI standard
		fprintf(fout, " %g\t %g\t %g\t\t\t %g\t %g\t %g\t\t %g\t %d\t %d\n", 
		1000 * be.PosY, 1000 * be.AlfY, 1000 * be.DivY, 1000 * be.PosZ, 1000 * be.AlfZ, 1000 * be.DivZ, 
		be.Fraction, be.i, be.j);
	}

	/*  be.Active = TRUE;
		be.PosY = BeamletPosHor[i*Ny + ii]; // MAMuG
		be.PosZ = BeamletPosVert[j*Nz + jj]; // MAMuG
		be.AlfY = BeamletAngleHor[i*Ny + ii];
		be.AlfZ = BeamletAngleVert[j*Nz + jj];
		be.DivY = BeamCoreDivY;
		be.DivZ = BeamCoreDivZ;
		be.Fraction = 1;
		be.i = i; be.j = j;*/
		
	fclose(fout);

}

void CBTRDoc:: WriteRegularBeam(char * name)
{
	FILE * fout;
	CString S;

	fout = fopen(name, "w"); //("PDP_input.dat", "w");
	fprintf(fout, "  Regular beam array (for PDP-code), created by BTR 1.7\n");

	fprintf(fout, "  Yo,mm  Ay,mrad  Acy,mrad    Zo,mm  Az,mrad  Acz,mrad   FrI   column (I)   row (J) \n");
	double Y0, Ay, Acy, Z0, Az, Acz, FrI;
	int iy, jz;
	int NtotalHor = (int)(NofChannelsHor * (NofBeamletsHor));
	int NtotalVert = (int)(NofChannelsVert * (NofBeamletsVert));

/*	double *	NofChannelsHor;// Beam Source
	double *	NofChannelsVert;
	double *	NofBeamletsHor;
	double *	NofBeamletsVert; 
	double *	SegmStepHor;
	double *	SegmStepVert;
	double *	BeamAimHor; 
	double *	BeamAimVert;
	double *	AppertStepHor;
	double *	AppertStepVert;
	double *	AppertAimHor; 
	double *	AppertAimVert;*/
		
	Acy = BeamCoreDivY * 1000; // rad -> mrad
	Acz = BeamCoreDivZ * 1000;
	FrI = 1;

	for (iy = 1; iy <= NtotalHor; iy++) {

		Y0 = BeamletPosHor[iy-1] * 1000; // m -> mm
		Ay = 1000 * (BeamletAngleHor[iy-1] - BeamMisHor); // rad -> mrad

		for (jz = 1; jz <= NtotalVert; jz++) {

			double VInclin = 0;
			if (!OptFree) VInclin = VertInclin;
			Z0 = BeamletPosVert[jz-1] * 1000; // m -> mm
			Az = 1000 *(BeamletAngleVert[jz-1] - (BeamMisVert + VInclin + BeamVertTilt)); // rad -> mrad

//			fprintf(fout, " %g   %g   %g         %g   %g   %g        %g     %d   %d\n", Y0, Ay, Acy, Z0, Az, Acz, FrI, iy, jz);
			fprintf(fout, " %g   %4.4f   %g         %g   %4.4f   %g        %g     %d   %d\n", Y0, Ay, Acy, Z0, Az, Acz, FrI, iy, jz);
	
		} // jz

	} // iy


	fclose(fout);
}

void CBTRDoc::OnPlotReionPower()
{
	CMultiPlotDlg dlg;
	//dlg.pDoc = this;
	dlg.InitPlot(this);

	if (dlg.DoModal() == IDOK) return;
}

void CBTRDoc::OnSurfacesSort()
{
	// TODO: Add your command handler code here
	SortLoadArrayAlongX();
}

void CBTRDoc::OnUpdatePlotReionPower(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	double Sum = 0;
	for (int k = 0; k < SumReiPowerX.GetSize(); k++) Sum += SumReiPowerX[k];
	pCmdUI->Enable(Sum > 1.e-12);
}

void CBTRDoc::ClearArrays()
{
	for (int i = 0; i < ThreadNumber; i++) {
		m_AttrVector[i].clear();
	//	m_AttrVector[i].shrink_to_fit();
		m_ExitVector[i].clear();
	//	m_ExitVector[i].shrink_to_fit();
		m_FallVector[i].clear();
	//	m_FallVector[i].shrink_to_fit();
		m_Log[i].clear();
		//m_Log[i].shrink_to_fit();
	}
	m_GlobalVector.clear();// size -> 0
	//m_GlobalVector.shrink_to_fit();
	//m_GlobalDeque.clear();// size -> 0
	//m_GlobalDeque.shrink_to_fit();/// not valid
	m_GlobalLog.clear();
	//m_GlobalLog.shrink_to_fit();

}
bool CBTRDoc::AddLog(std::vector<CString> * log)
{
	vector<CString>::iterator it = m_GlobalLog.end();
	TRY{
		m_GlobalLog.insert(it, log->begin(), log->end());
	} CATCH(CMemoryException, e) {
		return FALSE;
	} END_CATCH;

	//m_GlobalLog.shrink_to_fit();
	return TRUE;

}

bool CBTRDoc::AddFalls(int tid, int isrc,  std::vector<minATTR> * tattr)
{
	if (STOP) return FALSE;
	vector<minATTR>::iterator it= m_GlobalVector.end();
	//deque<SATTR>::iterator it= m_GlobalDeque.end();
	 
	CString S, Slog;
	minATTR a;
	TRY {
		//tattr->reserve(sz);
		m_GlobalVector.insert(it, tattr->begin(), tattr->end());//append Bml to global vect
		//m_GlobalDeque.insert(it, tattr->begin(), tattr->end());
		
	} CATCH (CMemoryException, e) {
		S.Format("Thread %d\n FAILED to add Falls! \n Last bml -  %d", tid, NofCalculated);
		AfxMessageBox(S);
		STOP = TRUE;
		//OnStop();
		
	} END_CATCH;
	
	if (STOP) { 
		Slog.Format("AddFalls: Thread %d\n Bml %d is stopped\n", tid, NofCalculated +1);
		m_GlobalLog.push_back(Slog);
		OnStop();
		//for (int i = 0; i < ThreadNumber; i++)		m_Tracer[i].SetContinue(FALSE);
		return FALSE;
	}

/*	a = tattr->at(0);

	Slog.Format("Src %d Pos= (%d  %d)mm  Vy/V= %d Vz/V= %d BPpower = %4.3fW charge = %d\n", 
				a.Nfall, a.Xmm, a.Ymm, a.AXmrad, a.AYmrad, a.PowerW, a.Charge);
	m_GlobalLog.push_back(Slog);*/

	Slog.Format("{%d}  Src %4d Bml %4d - done (AddFalls success)\n", tid, isrc, NofCalculated+1); // NofCalculated++ after calling this func 
	m_GlobalLog.push_back(Slog);
	//m_GlobalLog.shrink_to_fit();
	return TRUE;
	
}

void CBTRDoc:: InitTracers()
{
	//if (ParticlesFile != NULL) fclose(ParticlesFile);
	//ParticlesFile = fopen("Particles.txt", "w");
	//fprintf(ParticlesFile, " n  q   P.X, P.Y, P.Z    power   current   alfa\n" );
	CString S;
	if (NofBeamlets < 1) { AfxMessageBox("N of beamlets = 0?"); return; }
	
	if (NofBeamlets < ThreadNumber) { 
		ThreadNumber = 1; //NofBeamlets;
	}
	//ThreadNumber = 1;
	S.Format("Threads = %d", ThreadNumber);
	AfxMessageBox(S);
	
	int numb = NofBeamlets / ThreadNumber; // beamlets per thread
	int Nattr = Attr_Array.GetSize();
	int Nmin, Nmax;
	int res = 0; // nfalls sum
	
	ClearArrays();// size -> 0
	for (int i = 0; i < ThreadNumber; i++)
		{
			m_Tracer[i].SetID(i + 1);
			m_Tracer[i].SetDocument(this);
			m_Tracer[i].SetAttrArray(&m_AttrVector[i]);
		//	m_Tracer[i].SetExitArray(&m_ExitVector[i]);
		//	m_Tracer[i].SetFallArray(&m_FallVector[i]);
			m_Tracer[i].SetLogArray(&m_Log[i]);
			m_Tracer[i].SetViewWnd(pMainView);
			m_Tracer[i].SetContinue(FALSE);// continue = FALSE
			Nmin = i*numb; Nmax = (i+1)*numb - 1;
			if (i == ThreadNumber-1) Nmax = Max(Nmax, NofBeamlets - 1); // last thread takes all remained
			m_Tracer[i].SetLimits(Nmin, Nmax);
			m_Tracer[i].SetStartPoint(Nmin);
			m_Tracer[i].SetStartVP(0);
			m_Tracer[i].ClearArrays();
			m_pTraceThread[i] = NULL;
						
		}
	
	MemFallReserved = FALSE;
	Exit_Array.RemoveAll();
	//for (int k = 0; k < ThreadNumber; k++) m_pTraceThread[k] = NULL;

	//SetPlasma(); // set beam-tor geometry, plasma Rminor/Rmajor, Xmin/Xmax
				 // recreate all plasma Arrays

	//pBeamHorPlane->Load->Clear(); // created in SetPlatesNBI
	//pBeamVertPlane->Load->Clear();// created in SetPlatesNBI
	//NofCalculated = 0;// to check if everything works!!!
	//S.Format("reserved %d falls (Threads = %d)", res, ThreadNumber);
	//AfxMessageBox(S);
		
}

UINT CBTRDoc:: ThreadFunc(LPVOID pParam)
{
	CTracer * pTrace =(CTracer*) pParam;
	
	while (pTrace->GetContinue()) //(TRUE)//
		//pTrace->ClearArrays();
		pTrace->Draw();
		//pTrace->TestMem();
		//pTrace->TraceAll(); // new!!
	
	return 0;
}

void CBTRDoc::SuspendTracer(int iIndex, bool bRun)
{
	if (!bRun) //stop
	{
		if (m_pTraceThread[iIndex])
		{
			CTracer::cs.Lock();
			m_pTraceThread[iIndex]->SuspendThread();
			CTracer::cs.Unlock();
		}
	}

	else //run
	{
		m_Tracer[iIndex].SetDraw(OptDrawPart);
		
		if (m_pTraceThread[iIndex])
		{
			m_pTraceThread[iIndex]->ResumeThread();
		}
		else m_pTraceThread[iIndex] = AfxBeginThread(ThreadFunc, &m_Tracer[iIndex]);

		//if (thread != NULL)
		//m_pTraceThread[iIndex]->SetThreadPriority(-1);
	

	}
}

void CBTRDoc::SuspendAll(bool bRun)
{
	for (int i = 0; i < ThreadNumber; i++) SuspendTracer(i, bRun);

}

void CBTRDoc:: P_CalculateAngularProf(CPlate * plate) // not called- replaced by ShowBPdata
{
	if (plate == NULL) return;

	CLimitsDlg dlg; 
	dlg.m_StrMin = "Min, mrad";
	dlg.m_StrMax = "Max, mrad";
	dlg.m_Sstep = "Step, mrad";
	dlg.m_Xmin = plate->MinAngle; 
	dlg.m_Xmax = plate->MaxAngle;
	dlg.m_Step = plate->StepAngle;
	if (dlg.DoModal() == IDOK) {
		plate->MinAngle = (double) dlg.m_Xmin;
		plate->MaxAngle = (double) dlg.m_Xmax;
		plate->StepAngle = (double) dlg.m_Step;
		//Xmax = (double) dlg.m_Xmax;
	} 

	double power;
	CString S1, S2, S3;
	float AXmrad, AYmrad, amrad;
	vector<minATTR> & arr = m_GlobalVector;// m_AttrVector[MaxThreadNumber - 1];

	plate->InitAngleArray(plate->MinAngle, plate->MaxAngle, plate->StepAngle);

	//for (int k = 0; k < ThreadNumber; k++) {
		//arr = m_AttrVector[k];
		if (arr.size() < 1) return;
		for (int i = 0; i < (int)arr.size(); i++) {
			minATTR &tattr = arr[i];
			if (tattr.Nfall == plate->Number) {
				if (!OptAtomPower && tattr.Charge == 0) continue;
				if (!OptNegIonPower && tattr.Charge < 0) continue;
				if (!OptPosIonPower && tattr.Charge > 0) continue;
				power = (double) tattr.PowerW;
				AXmrad = tattr.AXmrad;
				AYmrad = tattr.AYmrad;
				amrad = sqrt(AXmrad * AXmrad + AYmrad * AYmrad);
				plate->DistributeAngle(amrad, power);
			} // equal numbers
		} // i
	//} //k
	S1 = ""; S2 = ""; S3 = "";
	if (OptAtomPower) S1 = "Atoms";
	if (OptNegIonPower) S2 = " Neg";
	if (OptPosIonPower) S3 = " Pos";
	if (plate->Load != NULL) plate->Load->Particles = S1 + S2 + S3;
	return;
}

void CBTRDoc::SetNullLoad(CPlate * plate) // create zero load with default mesh options
{ 
	int gridNX = DefLoadNX;
	int gridNY = DefLoadNY;
	C3Point H;
	double hx, hy;
	if (DefLoadOptN) { // fixed mesh size
		hx = plate->Xmax / gridNX;
		hy = plate->Ymax / gridNY;

		if (DefLoadStepRound) { // round gridsteps
			H = GetMantOrder(plate->Xmax / gridNX);
			hx = H.X * H.Z;
			H = GetMantOrder(plate->Ymax / gridNY);
			hy = H.X * H.Z;
		}
	}
	else { // fixed step
		hx = DefLoadStepX;
		hy = DefLoadStepY;
	}

	plate->ApplyLoad(TRUE, hx, hy); //delete + create new array (Loaded >> TRUE)
}

void CBTRDoc:: P_CalculateLoad(CPlate * plate)
{
	if (plate == NULL) return;// -1;
	//plate->Loaded = TRUE;
	CLoad * L = plate->Load;
	pSetView->Load = L;
	vector<minATTR> & arr = m_GlobalVector;// m_AttrVector[MaxThreadNumber - 1];
	C3Point Pgl, Ploc;
	double power;
	CString S1, S2, S3;
	//for (int k = 0; k < ThreadNumber; k++) {
		//arr = m_AttrVector[k];
	
		for (int i = 0; i < (int)arr.size(); i++) {
			minATTR &tattr = arr[i];
			if (tattr.Nfall == plate->Number) {
				//if (OptIonPower && tattr.Charge == 0) continue;
				if (!OptAtomPower && tattr.Charge == 0) continue;
				if (!OptNegIonPower && tattr.Charge < 0 ) continue;
				if (!OptPosIonPower && tattr.Charge > 0) continue;
				//Pgl.X = tattr.X; Pgl.Y = tattr.Y; Pgl.Z = tattr.Z;
				power = tattr.PowerW;
				Ploc.X = tattr.Xmm * 0.001;// plate->GetLocal(Pgl);
				Ploc.Y = tattr.Ymm * 0.001;
				Ploc.Z = 0;
				if (plate->WithinPoly(Ploc)) 
					plate->Load->Distribute(Ploc.X, Ploc.Y, power);
					
			} // Nfall == plate Num
		} // i
	//} //k
	plate->Load->SetSumMax();
	S1 = ""; S2 = ""; S3 = "";
	if (OptAtomPower) S1 = "Atoms";
	if (OptNegIonPower) S2 = " Neg";
	if (OptPosIonPower) S3 = " Pos";
	plate->Load->Particles = S1 + S2 + S3;
	
}

void CBTRDoc:: P_CalculateCombi(bool update) // not active now - must be rewritten
// calculate maps + proect them on the marked (combi-)plate
{
	CWaitCursor wait;
	CPlate * Plate = pMarkedPlate;//
	if (Plate == NULL) return;// -1;
	if (OptCombiPlot > 1) Plate->Load->Clear();
	
	//CCriticalSection cs;
	//STOP = FALSE;
	CPlate * plate;
	double CombiSum = 0, CombiMax = 0;
	C3Point local, Local, Global;
	double power;
	double stepX;// = Plate->Load->StepX;
	double stepY;// = Plate->Load->StepY;
	POSITION pos = PlatesList.GetHeadPosition();
		while (pos != NULL) {// calc load on selected plates
			plate = PlatesList.GetNext(pos);
			if (!plate->Selected) continue;
			//if (OptCombiPlot > 1 && !plate->Solid) continue;

			if (plate->Loaded == TRUE) { // LOAD already exists
				stepX = Plate->Load->StepX;
				stepY = Plate->Load->StepY;
				if (OptParallel && update) { // recalculate load
					plate->Load->Clear();
					plate->ApplyLoad(TRUE, stepX, stepY); 
					P_CalculateLoad(plate); 
				}
				//else keep the existing load
			}
			
			else //(plate->Loaded == FALSE) { // not calculated yet
			{ 
					
					stepX = 0; stepY = 0;
					plate->ApplyLoad(TRUE, stepX, stepY); // optimize grid 
					P_CalculateLoad(plate); // with new grid steps
					SetLoadArray(plate, TRUE);
					
			}
			
			stepX = Plate->Load->StepX;
			stepY = Plate->Load->StepY;
		
			//plate->ApplyLoad(TRUE, Plate->Load->StepX, Plate->Load->StepY); // optimize grid 
			//P_CalculateLoad(plate); // with new grid steps

			CombiSum += plate->Load->Sum;
			CombiMax = Max(CombiMax, plate->Load->MaxVal);
			C3Point p0, p1, p2, p3, P1, P2;
			C3Point Size = plate->ProectCorners(Plate, p0, p1, p2, p3);
			if (Size.X * Size.Y < 1.e-6) continue;

			double Xmin = Min(Min(p0.X, p1.X), Min(p2.X, p3.X));
			double Xmax = Max(Max(p0.X, p1.X), Max(p2.X, p3.X));
			double Ymin = Min(Min(p0.Y, p1.Y), Min(p2.Y, p3.Y));
			double Ymax = Max(Max(p0.Y, p1.Y), Max(p2.Y, p3.Y));
			// double Zmax = Max(Max(fabs(p0.Z), fabs(p1.Z)), Max(fabs(p2.Z), fabs(p3.Z)));

			//Xmin = Max(0, Xmin); Xmax = Min(Xmax, Plate->Xmax);
			//Ymin = Max(0, Ymin); Ymax = Min(Ymax, Plate->Ymax);

			for (int i = 0; i <= Plate->Load->Nx; i++) {
				Local.X = i * stepX;
				if (Local.X < Xmin || Local.X > Xmax + 0.5 * stepX) continue;
				for (int j = 0; j <= Plate->Load->Ny; j++) {
				Local.Y = j * stepY;
				if (Local.Y < Ymin || Local.Y > Ymax + 0.5 * stepY) continue;
				Local.Z = -10; P1 = Plate->GetGlobalPoint(Local);
				Local.Z = 10; P2 = Plate->GetGlobalPoint(Local);
				local = plate->FindLocalCross(P1, P2);
				if (plate->WithinPoly(local))
				Plate->Load->Val[i][j] = plate->Load->GetVal(local.X, local.Y); 
				} // j
			} //i

		} // calc load on selected plates and distribute on combi

	ShowProfiles = TRUE;
	Plate->Loaded = TRUE;
	Plate->Load->SetSumMax();
	Plate->Load->Sum = CombiSum;
	Plate->Load->MaxVal = CombiMax;
	pSetView->Load = Plate->Load;
	CString S1, S2, S3;
	S1 = ""; S2 = ""; S3 = "";
	if (OptAtomPower) S1 = "Atoms";
	if (OptNegIonPower) S2 = " Neg";
	if (OptPosIonPower) S3 = " Pos";
	Plate->Load->Particles = S1 + S2 + S3;

	pLoadView->SetLoad_Plate(Plate->Load, Plate);
//	pLoadView->ShowLoad = TRUE;
	
}

void CBTRDoc::OnUpdatePlateSelect(CCmdUI *pCmdUI)
{
	// TODO: Add your command update UI handler code here
	//pMainView->OnUpdatePlateSelect(pCmdUI);
	if (OptParallel) pCmdUI->SetText("Calculate");
	else pCmdUI->SetText("Select / Unselect");
}

void CBTRDoc::OnUpdateSurfacesSortincr(CCmdUI *pCmdUI) // disable
{
	pCmdUI->Enable(FALSE);
}

void CBTRDoc::OnUpdateOptionsSurfacesAdd(CCmdUI *pCmdUI) // disable
{
	pCmdUI->Enable(TRUE);
}



void CBTRDoc::OnPlateClearSelect()
{
	//if (OptCombiPlot > 0) return;// = FALSE;
	CPlate * plate;
	POSITION pos = PlatesList.GetHeadPosition();
		while (pos != NULL) {
			plate = PlatesList.GetNext(pos);
			plate->Selected = FALSE;
		}
		
		
		if (pMarkedPlate != NULL) {
			pMarkedPlate->Selected = TRUE;
			OptCombiPlot = 0;
		}
		else 
			OptCombiPlot = -1; ///-1 - no load, 0 - map is calculated, >0 - selected but not calculated
	//	OnShow();
}

CString  GetMachine()
{
	unsigned long Size1 = MAX_COMPUTERNAME_LENGTH + 1;
	char machine[MAX_COMPUTERNAME_LENGTH + 1];
	CString CompName = "";
	if (::GetComputerName(machine, &Size1)!= 0) {
		CompName = machine; CompName.MakeUpper();
	}
	return CompName;
}

CString  GetUser()
{
	unsigned long Size2 = MAX_COMPUTERNAME_LENGTH + 1;
	char user[MAX_COMPUTERNAME_LENGTH + 1];
	CString UserName = "";
	if (::GetUserName(user, &Size2)!= 0) {
		UserName = user; UserName.MakeUpper();
	}
	return UserName;
}

void CBTRDoc::ShowPlasmaCut(int icut) // 0- horiz, 1- vert, 2 - inclined
{
	//CPlate * plate0 = new CPlate();
	C3Point Step = pPlasma->Step;
	C3Point Orig = pPlasma->Orig;
	int Nx = pPlasma->Nx;
	int Ny = pPlasma->Ny;
	int Nz = pPlasma->Nz;
	double dX = Nx * Step.X;
	double dY = Ny * Step.Y;
	double dZ = Nz * Step.Z;
	double dS = dY; // default - horizontal
	double stepS = Step.Y;
	CString S;
	if (icut == 1) {
		dS = dZ;
		stepS = Step.Z;
	}
	C3Point dP(0, dY, 0);
	if (icut == 1) dP = C3Point(0, 0, dZ);
	C3Point LB(Orig);
	C3Point RT = LB + dP + C3Point(dX, 0, 0); //Orig + C3Point(dX, 0, 0) + dP * 0.5;
	pMarkedPlate = new CPlate();
	pMarkedPlate->SetFromLimits(LB, RT);
	//S.Format("R/Z steps %g /%g   DR/DZ  %g /%g", stepR, stepZ, DR, DZ);	AfxMessageBox(S);
	pMarkedPlate->Load = new CLoad(dX, dS, Step.X, stepS);
	
	if (icut == 0) pMarkedPlate->Load->SetValArray(pPlasma->CutHor, Nx, Ny); //load->Val = pPlasma->CutHor; //PSI;
	else pMarkedPlate->Load->SetValArray(pPlasma->CutVert, Nx, Nz);
	pMarkedPlate->Load->SetSumMax();
	if (pMarkedPlate->Load->MaxVal < 1.e-10) {
		AfxMessageBox("Zero power along cut plane");
		return;
	}
	pMarkedPlate->Load->iProf = (int)(1.0 * pMarkedPlate->Load->iMaxVal);
	pMarkedPlate->Load->jProf = (int)(1.0 * pMarkedPlate->Load->jMaxVal);
	pMarkedPlate->Number = 2000;
	pMarkedPlate->Selected = TRUE;
	pMarkedPlate->Loaded = TRUE;
	pMarkedPlate->SmoothDegree = SmoothDegree;
	pMarkedPlate->Comment = "Plasma Cut";
	if (icut == 1) pMarkedPlate->Comment += " - Vertical";
	else pMarkedPlate->Comment += " - Horizontal";
	OptParallel = 0;
	OptCombiPlot = 0;
	pLoadView->Cross.X = pMarkedPlate->Load->iProf * pMarkedPlate->Load->StepX;
	pLoadView->Cross.Y = pMarkedPlate->Load->jProf * pMarkedPlate->Load->StepY;

	ShowProfiles = TRUE;
	pMarkedPlate->ShowLoadState();
	pSetView->InvalidateRect(NULL, TRUE);//	OnPlotMaxprofiles();
}

void CBTRDoc::ShowPlasmaCutDiagonal() // not called  0- horiz, 1- vert, 2 - inclined
{
	//CPlate * plate0 = new CPlate();
	double StepX = pPlasma->CutStepX;
	double StepY = pPlasma->CutStepY;
	C3Point Orig = pPlasma->CutOrig;
	C3Point Dest = pPlasma->CutDest;
	int Nx = pPlasma->CutNx;
	int Ny = pPlasma->CutNy;
	
	double dX = Nx * StepX;
	double dY = Ny * StepY;
	
	CString S;
		
	C3Point LB = Orig;
	C3Point RT = Dest; //Orig + C3Point(dX, 0, 0) + dP * 0.5;
	pMarkedPlate = new CPlate();
	pMarkedPlate->SetFromLimits(LB, RT);
	//S.Format("R/Z steps %g /%g   DR/DZ  %g /%g", stepR, stepZ, DR, DZ);	AfxMessageBox(S);
	pMarkedPlate->Load = new CLoad(dX, dY, StepX, StepY);

	pMarkedPlate->Load->SetValArray(pPlasma->CutDiag, Nx, Ny); //load->Val = pPlasma->CutHor; //PSI;
	pMarkedPlate->Load->SetSumMax();
	if (pMarkedPlate->Load->MaxVal < 1.e-10) {
		AfxMessageBox("Zero power along diag cut plane");
		return;
	}
	pMarkedPlate->Load->iProf = (int)(1.0 * pMarkedPlate->Load->iMaxVal);
	pMarkedPlate->Load->jProf = (int)(1.0 * pMarkedPlate->Load->jMaxVal);
	pMarkedPlate->Number = 2000;
	pMarkedPlate->Selected = TRUE;
	pMarkedPlate->Loaded = TRUE;
	pMarkedPlate->SmoothDegree = SmoothDegree;
	pMarkedPlate->Comment = "Plasma Cut";
	pMarkedPlate->Comment += " - Diagonal";
	
	OptParallel = 0;
	OptCombiPlot = 0;
	pLoadView->Cross.X = pMarkedPlate->Load->iProf * pMarkedPlate->Load->StepX;
	pLoadView->Cross.Y = pMarkedPlate->Load->jProf * pMarkedPlate->Load->StepY;

	ShowProfiles = TRUE;
	pMarkedPlate->ShowLoadState();
	pSetView->InvalidateRect(NULL, TRUE);//	OnPlotMaxprofiles();
}

void CBTRDoc::OnBeaminplasmaVerticalplane()
{
	if (pPlasma->Nrays > 0) {
		ShowPlasmaCut(1);
		return;
	} //
	else {
		if (TracksCalculated == 0)	CalculateTracks();
		ShowPlasmaCut(1);
	/*	pMarkedPlate = pBeamVertPlane;
		pMarkedPlate->Load->SetSumMax();
		OptCombiPlot = 0;
		OnPlotMaxprofiles();
		pMarkedPlate->ShowLoadState(); // show summary (info)*/
	}

}

void CBTRDoc::OnBeaminplasmaHorizontalplane()
{
	
	if (pPlasma->Nrays >= 0) {
		ShowPlasmaCut(0);//ShowPlasmaCutDiagonal();
		return;
	}//	
	else {
		if (TracksCalculated == 0)	CalculateTracks();
		ShowPlasmaCut(0);
	/*	pMarkedPlate = pBeamHorPlane;
		pMarkedPlate->Load->SetSumMax();
		OptCombiPlot = 0;
		OnPlotMaxprofiles();
		pMarkedPlate->ShowLoadState(); // show summary (info)	*/
	}
}

void CBTRDoc:: WriteExitVector()
{
	CString name = "RID_ions.txt"; 
	C3Point P0, P1, V;
	EXIT_RAY ray;
	double t, power, vel;
	double Sum = 0;
	long count = 0;
	CWaitCursor wait;
	FILE * fout;
	fout = fopen(name, "w");
	if (fout == NULL) {
			AfxMessageBox("failed to create file \n" + name, MB_ICONSTOP | MB_OK);
			return;
	}
	fprintf(fout, "Dumped Ions position, velocity & Power (RID plate)\n");
	fprintf(fout, " N \t\t X\t\tY\t\tZ\t\tVx/V\t\tVy/V\t\tVz/V\t\t Power, W \n");

	vector <EXIT_RAY> & vect = m_ExitVector[MaxThreadNumber-1];
			
	for (int k = 0; k < ThreadNumber; k++) {
		vect = m_ExitVector[k];
		for (int i = 0; i < (long)vect.size(); i++) {
			EXIT_RAY &ray = vect[i];
			P0 = ray.Position;
			V = ray.Velocity;
			vel = ModVect(V);
			power = ray.Power; 
			count++;
			Sum += power;
			if (power > 1.e-12)	fprintf(fout, " %ld \t %le %le %le\t %le %le %le\t %le \n", 
											count, P0.X, P0.Y, P0.Z, V.X/vel, V.Y/vel, V.Z/vel, power);
		
		}//i
	}//k

	fprintf(fout, "\n  Totally dumped  %le W \n %d rays ", Sum, count);
		
	fclose(fout);
} 

void CBTRDoc:: CalculateTracks() // called by OnBeaminplasmaVerticalplane()
{
	CalculateThickFocused();// actual beam axes
	TracksCalculated = 1;
	//SetDecayInPlasma();
/*	C3Point P0, P1, V;
	EXIT_RAY ray;
	double t, power, vel;
	CWaitCursor wait;
	
	pBeamHorPlane->Load->Clear();
	pBeamVertPlane->Load->Clear();*/

	//vector <EXIT_RAY> & vect = m_ExitVector[MaxThreadNumber-1];
				
/*	for (int k = 0; k < ThreadNumber; k++) {
		vector <EXIT_RAY> * vect = m_Tracer[k].exitarr;
		//vect = m_ExitVector[k];
		if (vect->size() < 1) continue;
		for (int i = 0; i < (long)vect->size(); i++) {
			EXIT_RAY ray = vect->at(i);
			P0 = ray.Position;
			V = ray.Velocity;
			vel = fabs(V.X); // ModVect(V);
			t =  fabs(PlasmaXmax - P0.X) / V.X;
			P1.X = PlasmaXmax;
			P1.Y = P0.Y + V.Y * t;
			P1.Z = P0.Z + V.Z * t;
			power = ray.Power; 
			
			GetFillDecayBetween(P0, P1, power);
			//CalculatePowerTrack(P0, P1, power, vel);
		}
	}*/

	//SetBeamDecay(); // calls GetFillDecayBetween
	
/*	double dL = 0.1;
	CArray<double, double> * Parr = pPlasma->GetPowerDecayArray(P0, P1, dL);
	int Nmax = Parr->GetSize();
	//decay = Parr->GetAt(Nmax - 1);

	//distribute Power to Hor/Vert Planes
	double Xloc, Yloc, Power;
	C3Point P;
	double PathLen = ModVect(P1 - P0);
	int N = (int)ceil(PathLen / dL);
	C3Point PathVect = (P1 - P0) / PathLen;
	for (int i = 0; i < Nmax; i++) {
		P = P0 + PathVect * (i * dL);
		Power = Parr->GetAt(i);
		Xloc = P.X - pBeamHorPlane->Orig.X;
		Yloc = P.Y - pBeamHorPlane->Orig.Y;
		pBeamHorPlane->Load->Distribute(Xloc, Yloc, Power);
		Xloc = P.X - pBeamVertPlane->Orig.X;
		Yloc = P.Z - pBeamVertPlane->Orig.Z;
		pBeamVertPlane->Load->Distribute(Xloc, Yloc, Power);
	}*/
	pBeamHorPlane->Load->SetSumMax();
	pBeamVertPlane->Load->SetSumMax();
	//pMarkedPlate->Load->SetSumMax();
}

void CBTRDoc:: CalculatePowerTrack(C3Point Start, C3Point Finish, double StartPower, double Vel) 
// project power track on plane
{
	if (OptCombiPlot == -1) return; //(pMarkedPlate == NULL) return;
	CPlate * plate = pMarkedPlate; // vert or hor plane in plasma
	double stepZ = 0.1; // the layer thickness
	double stepX = plate->Load->StepX;
	double stepY = plate->Load->StepY;
	double Vol = stepX * stepY * stepZ; // cell volume
	double stepL = stepX;// along X   // 0.5 * sqrt(stepX*stepX + stepY*stepY);//Min(stepX, stepY) * 0.5; // track step
	double dt = stepL / Vel; //both along X  
	double l = 0, lmax = (Finish - Start).X;// along X    // GetDistBetween(Start, Finish);
	C3Point dL = (Finish - Start) * stepL / lmax;//along track
	double power;
	C3Point Ploc;
	C3Point P = Start;

/*	while (l <= lmax) {
		power = StartPower * GetDecay(P);
		Ploc = plate->GetLocal(P);
		if (fabs(Ploc.Z) < 0.5*stepZ)	plate->Load->Distribute(Ploc.X, Ploc.Y, power * dt / Vol);
		l += stepL;//along track
		P = P + dL;
	}
*/
}
void CBTRDoc::OnDataSaveaddsurf()
{
	char name[1024];
	if (AddPlatesNumber > 0) {
			int reply = AfxMessageBox("Save the List of Additional Surfaces?", 3);
			if (reply != IDYES) return;

		CFileDialog dlg1(FALSE, "dat | * ", "", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Additional Surfaces data file (*.dat) | *.dat; *.DAT | All Files (*.*) | *.*||", NULL);
		if (dlg1.DoModal() == IDOK) {
			strcpy(name, dlg1.GetPathName());
			WriteAddPlates(name);
		}
	}
}

void CBTRDoc::OnDataReadaddsurf()
{
	//ReadAddPlates();
	//CPlate::AbsYmin = 1000; CPlate::AbsYmax = -1000;
	//CPlate::AbsZmin = 1000; CPlate::AbsZmax = -1000;
	int added = ReadAddPlates();
	AddPlatesNumber += added;
	CString S;
	S.Format("Total addSurf %d (added %d) ", AddPlatesNumber, added);
	AfxMessageBox(S);
	
	OnShow();
}

void CBTRDoc::OnUpdateDataSaveaddsurf(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(AddPlatesNumber > 0);
}

void CBTRDoc::OnPlasmaPsi()
{
	//if (!OptBeamInPlasma) return;
	ReadPlasmaPSI();//v 4.5
	//OnResultsPdpoutputTable(); // in v4.0

}

void CBTRDoc::OnUpdateTasksBeamplasma(CCmdUI *pCmdUI)
{
	/*if (MaxPlasmaDensity * MaxPlasmaTe < 1.e-6) //|| pTorCrossPlate == NULL) 
		pCmdUI->Enable(FALSE);
	else */pCmdUI->Enable(TRUE);
}

void CBTRDoc::OnUpdatePlotPenetration(CCmdUI *pCmdUI)
{
	/*if (MaxPlasmaDensity * MaxPlasmaTe < 1.e-6)// || pTorCrossPlate == NULL) 
		pCmdUI->Enable(FALSE);
	else*/ pCmdUI->Enable(TRUE);
}

void CBTRDoc::OnTraceBigAtom()
{		
	CAtomDlg dlg;
	dlg.m_Option = "get reionised";
	dlg.m_PosX = SingleBPpos.X;
	dlg.m_PosY = SingleBPpos.Y;
	dlg.m_PosZ = SingleBPpos.Z;
	dlg.m_Vx = SingleBPvel.X;
	dlg.m_Vy = SingleBPvel.Y;
	dlg.m_Vz = SingleBPvel.Z;
	dlg.m_Step = SingleBPstep;
	dlg.m_OptReion = !OptReionStop;
	dlg.m_Energy = SingleBPenergy;

	if (dlg.DoModal() == IDOK) {
		OptReionStop = !dlg.m_OptReion;
		C3Point Pos = C3Point(dlg.m_PosX, dlg.m_PosY, dlg.m_PosZ);
		C3Point V = C3Point(dlg.m_Vx, dlg.m_Vy, dlg.m_Vz);
		TraceSingleParticle(ATOM, Pos, V, dlg.m_Step, dlg.m_Energy);
		OptTraceSingle = TRUE;
		SingleBP = ATOM;
		SingleBPpos = Pos;
		SingleBPvel = V;
		SingleBPstep = dlg.m_Step;
		SingleBPenergy = dlg.m_Energy;
	}
}

void CBTRDoc::OnTraceBigIon()
{
	CAtomDlg dlg;
	dlg.m_Option = " no option ";
	dlg.m_PosX = SingleBPpos.X;
	dlg.m_PosY = SingleBPpos.Y;
	dlg.m_PosZ = SingleBPpos.Z;
	dlg.m_Vx = SingleBPvel.X;
	dlg.m_Vy = SingleBPvel.Y;
	dlg.m_Vz = SingleBPvel.Z;
	dlg.m_Step = SingleBPstep;
	dlg.m_Energy = SingleBPenergy;

	if (dlg.DoModal() == IDOK) {
		C3Point Pos = C3Point(dlg.m_PosX, dlg.m_PosY, dlg.m_PosZ);
		C3Point V = C3Point(dlg.m_Vx, dlg.m_Vy, dlg.m_Vz);
		TraceSingleParticle(POSION, Pos, V, dlg.m_Step, dlg.m_Energy);	
		OptTraceSingle = TRUE;
		SingleBP = POSION;
		SingleBPpos = Pos;
		SingleBPvel = V;
		SingleBPstep = dlg.m_Step;
		SingleBPenergy = dlg.m_Energy;
	}
}

void CBTRDoc::OnTraceBigElectron()
{
	CAtomDlg dlg;
	dlg.m_Option = "relativistic";
	dlg.m_PosX = SingleBPpos.X;
	dlg.m_PosY = SingleBPpos.Y;
	dlg.m_PosZ = SingleBPpos.Z;
	dlg.m_Vx = SingleBPvel.X;
	dlg.m_Vy = SingleBPvel.Y;
	dlg.m_Vz = SingleBPvel.Z;
	dlg.m_Step = SingleBPstep;
	dlg.m_Energy = SingleBPenergy;
	if (SingleBP == RELECTRON) dlg.m_OptReion = TRUE;
	else dlg.m_OptReion = FALSE;

	if (dlg.DoModal() == IDOK) {
		
		C3Point Pos = C3Point(dlg.m_PosX, dlg.m_PosY, dlg.m_PosZ);
		C3Point V = C3Point(dlg.m_Vx, dlg.m_Vy, dlg.m_Vz);
		if (dlg.m_OptReion) TraceSingleParticle(RELECTRON, Pos, V, dlg.m_Step,dlg.m_Energy);	
		else TraceSingleParticle(ELECTRON, Pos, V, dlg.m_Step, dlg.m_Energy);	
		OptTraceSingle = TRUE;
		SingleBP = ELECTRON;
		if (dlg.m_OptReion) SingleBP = RELECTRON;
		SingleBPpos = Pos;
		SingleBPvel = V;
		SingleBPstep = dlg.m_Step;
		SingleBPenergy = dlg.m_Energy;
	}
}

void CBTRDoc:: TraceSingleAgain(double X, double Y)
{
	SingleBPpos.X = X;
	SingleBPpos.Y = Y;
	TraceSingleParticle(SingleBP, SingleBPpos, SingleBPvel, SingleBPstep, SingleBPenergy);

}

void CBTRDoc:: TraceSingleParticle(int state, C3Point pos, C3Point v, double step, double energy)
{
	C3Point Pos, V;
	double Step = step;
	double Energy = energy; // eV
	Pos = pos; //C3Point(part.Attr.X, part.Attr.Y, part.Attr.Z);
	V = v; //C3Point(part.Attr.Vx, part.Attr.Vy, part.Attr.Vz);
	OptParallel = TRUE;
	OptCalcNeutralizer = TRUE;
	OptCalcRID = TRUE;
	OptCalcDuct = TRUE;
	CalcLimitXmin = 0;
	CalcLimitXmax = AreaLong + 1;
	
	if (!STOP) OnStop();
	for (int k = 0; k < ThreadNumber; k++) m_pTraceThread[k] = NULL;
	SetTitle("Single BP");
	//pMarkedPlate = NULL;
	OptCombiPlot = -1;
	ClearAllPlates();
	//ShowStatus();
	if (LoadSelected > 0)  SelectAllPlates();	
	//pMarkedPlate->Selected = FALSE; //OnShow();}
	
	NofBeamlets = 1;
	OptDrawPart = TRUE;
	InitTracers();//ThreadNumber = NofBeamlets;
	for (int i = 0; i < ThreadNumber; i++) {
	
	//m_Tracer[i].SetSingleAtom(Pos, V);
	m_Tracer[i].SetSingleParticle(state, Pos, V, Step, Energy);
	m_Tracer[i].SetLimits(0,-1);
	m_Tracer[i].SetDraw(TRUE);
		
	}

	STOP = FALSE;
	for (int i = 0; i < ThreadNumber; i++) m_Tracer[i].SetContinue(TRUE);
	SuspendAll(TRUE); // run = TRUE

	//OnStop();
	//for (int i = 0; i < ThreadNumber; i++)	m_Tracer[i].SetContinue(FALSE);
	//	SuspendAll(TRUE);
	//	WaitForSingleObject(m_pTraceThread[i]->m_hThread, 1000); //INFINITE);
	//	m_pTraceThread[i] = NULL;

	//	NofCalculated = 0;
		SetTitle("STOPPED");

}

double CBTRDoc:: GetIonStep(double x)
{
	if (x >= Xspec0 && x <= Xspec1) return IonStepLspec;
	else return IonStepL;
}

void CBTRDoc::OnOptionsPlasma()
{
	OnPlotPenetration();
	//AfxMessageBox("Under construction");
	return;

	if (!OptBeamInPlasma) return;
	CPlasmaDlg dlg;
	dlg.doc = this;
	dlg.m_Hw = PlasmaWeightH; dlg.m_H = (dlg.m_Hw > 1.e-6);
	dlg.m_Dw = PlasmaWeightD; dlg.m_D = (dlg.m_Dw > 1.e-6);
	dlg.m_Tw = PlasmaWeightT; dlg.m_T = (dlg.m_Tw > 1.e-6);

	dlg.m_HeW = PlasmaImpurW[0]; dlg.m_He = (dlg.m_HeW > 1.e-6);
	dlg.m_LiW = PlasmaImpurW[1]; dlg.m_Li = (dlg.m_LiW > 1.e-6);
	dlg.m_BeW = PlasmaImpurW[2]; dlg.m_Be = (dlg.m_BeW > 1.e-6);
	dlg.m_Bw = PlasmaImpurW[3];  dlg.m_B = (dlg.m_Bw > 1.e-6);
	dlg.m_Cw = PlasmaImpurW[4];  dlg.m_C = (dlg.m_Cw > 1.e-6);
	dlg.m_Nw = PlasmaImpurW[5];  dlg.m_N = (dlg.m_Nw > 1.e-6);
	dlg.m_Ow = PlasmaImpurW[6];  dlg.m_O = (dlg.m_Ow > 1.e-6);
	dlg.m_FeW = PlasmaImpurW[7]; dlg.m_Fe = (dlg.m_FeW > 1.e-6);
	
	if (dlg.DoModal() == IDOK) {
		 PlasmaWeightH = dlg.m_Hw;
		 PlasmaWeightD = dlg.m_Dw;
		 PlasmaWeightT = dlg.m_Tw;
		 PlasmaImpurW[0] = dlg.m_HeW;
		 PlasmaImpurW[1] = dlg.m_LiW;
		 PlasmaImpurW[2] = dlg.m_BeW;
		 PlasmaImpurW[3] = dlg.m_Bw;
		 PlasmaImpurW[4] = dlg.m_Cw;
		 PlasmaImpurW[5] = dlg.m_Nw;
		 PlasmaImpurW[6] = dlg.m_Ow;
		 PlasmaImpurW[7] = dlg.m_FeW;
		 SetImpurNumber();
	
	}
}

void CBTRDoc::OnResultsSavesummary()
{
	// TODO: Add your command handler code here
	OnResultsSaveList();

}

void CBTRDoc:: WriteFallVector()
{
	CString name = "Falls.txt"; 
	C3Point P;
	FALL_ATTR fall;
	int q, n;
	double alfa, power, alfdeg;
	double Sum = 0;
	long count = 0;

	CWaitCursor wait;
	FILE * fout;
	fout = fopen(name, "w");
	if (fout == NULL) {
			AfxMessageBox("failed to create file \n" + name, MB_ICONSTOP | MB_OK);
			return;
	}

	fprintf(fout, "N   Q    X,m   Y,m    Zm \t   Power,W     Alfa,rad \t  Alfa, deg\n" );
	
	vector <FALL_ATTR> & vect = m_FallVector[MaxThreadNumber-1];
			
	for (int k = 0; k < ThreadNumber; k++) {
		vect = m_FallVector[k];
		for (int i = 0; i < (long)vect.size(); i++) {
			FALL_ATTR &fall = vect[i];
			n = fall.Nfall;
			q = fall.Charge;
			P = fall.Position;
			alfa = fall.Angle;
			alfdeg = alfa / PI * 180;
			power = fall.Power; 
			count++;
			Sum += power;
			fprintf(fout, "%d  %d   %g  %g  %g       %g    %g    %f\n",  n, q, P.X, P.Y, P.Z, power, alfa, alfdeg);
					
		}//i
	}//k

	fprintf(fout, "\n  Total %g W, count %d \n", Sum, count);
		
	fclose(fout);
} 

void CBTRDoc::OnUpdateOptionsNbiconfig(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(!OptFree);
}

void CBTRDoc::OnInputFree()
{
	OptFree = TRUE;
	//ClearData();
	//InitData();
	
	OnShow();
}

void CBTRDoc::OnInputStandard()
{
	OptFree = FALSE;
	//ClearData();
	//InitData();
	
	OnShow();
}

void CBTRDoc::OnUpdateInputFree(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(OptFree);
}

void CBTRDoc::OnUpdateInputStandard(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(!OptFree);
}

void CBTRDoc::OnSurfacesRead()
{
	OnDataReadaddsurf();
}

void CBTRDoc::OnOptionInput()
{
	/*OptFree = !OptFree;
	CString S;
	if (OptFree) S = "Free Geom Input is ON";
	else S = "Standard NBL Geometry is ON";
	SetPlates();
	SetBeam();*/

	//OnShow();
}

void CBTRDoc::OnOptionsInput()
{
	/*OptFree = !OptFree;
	CString S;
	if (OptFree) S = "Free Geom Input is ON";
	else S = "Standard NBL Geometry is ON";
	SetPlates();
	SetBeam();*/

	//OnShow();
}


void CBTRDoc::OnPlateSelect() // add /remove to load list
{
	/*if (OptCombiPlot == -1) { //|| !(pDoc->pMarkedPlate->Loaded)) {
		ShowStatus(); return;
	}*/
	CPlate * plate = pMarkedPlate;
	if (plate == NULL) {
		AfxMessageBox("Plate not selected");
		return;
	}
	if (plate->Loaded == FALSE) { // not calculated yet
		SetNullLoad(plate);//plate->ApplyLoad(TRUE, 0, 0); // optimize grid //CreateBaseSingle();
						   // set new pMarkedPlate!!! OptCombiPlot >> 0
		SetLoadArray(plate, TRUE);
		OptCombiPlot = 0;
		P_CalculateLoad(plate);
	}

	//if (plate->Loaded) { //(OptCombiPlot == 0) { // base plate already exists
	//OnPlotMaxprofiles();
	//plate->ShowLoadState();
	
	OnPlateClearSelect();// unselect all excepting this plate
		
	//OnShow();

}

void CBTRDoc::OnPlateModify()
{
	CSurfDlg dlg;
	CPlate * plate0 = pMarkedPlate;
	if (plate0 == NULL) return;

	C3Point P0, P1, P2, P3;
		dlg.m_Solid = 0;
		if (plate0->Solid == FALSE) dlg.m_Solid = 1;
		dlg.m_X1 = plate0->Corn[0].X; dlg.m_Y1 = plate0->Corn[0].Y; dlg.m_Z1 = plate0->Corn[0].Z;
		dlg.m_X2 = plate0->Corn[1].X; dlg.m_Y2 = plate0->Corn[1].Y; dlg.m_Z2 = plate0->Corn[1].Z;
		dlg.m_X3 = plate0->Corn[2].X; dlg.m_Y3 = plate0->Corn[2].Y; dlg.m_Z3 = plate0->Corn[2].Z;
		dlg.m_X4 = plate0->Corn[3].X; dlg.m_Y4 = plate0->Corn[3].Y; dlg.m_Z4 = plate0->Corn[3].Z;
		dlg.m_N = plate0->Number;
		dlg.m_Comment = plate0->Comment;

		int res = dlg.DoModal();
		if (res == IDOK) {
			plate0->Solid = FALSE;
			if (dlg.m_Solid == 0) plate0->Solid = TRUE;
			plate0->Visible = plate0->Solid;
			P0.X = dlg.m_X1; P0.Y = dlg.m_Y1; P0.Z = dlg.m_Z1;
			P1.X = dlg.m_X2; P1.Y = dlg.m_Y2; P1.Z = dlg.m_Z2;
			P2.X = dlg.m_X4; P2.Y = dlg.m_Y4; P2.Z = dlg.m_Z4;
			P3.X = dlg.m_X3; P3.Y = dlg.m_Y3; P3.Z = dlg.m_Z3;
			plate0->SetLocals(P0, P1, P2, P3); //SetArbitrary(P1, P2, P3, P4);
			plate0->Number = dlg.m_N;
			plate0->Comment = dlg.m_Comment;
			OnShow();
			return;
		} // OK
		
		else if (res == IDCANCEL) {//
			if (!dlg.OptRead) return;
			int added = ReadAddPlates();
			AddPlatesNumber += added;
			CString S;
			S.Format("Total addSurf %d (added %d) ", AddPlatesNumber, added);
			AfxMessageBox(S);
			
			if (AfxMessageBox("Replace the selected Surf?", MB_ICONQUESTION | MB_YESNOCANCEL) == IDYES)
				pMainView->OnPlateDelete(); // delete pMarkedPlate

			OnShow();
			return;
		}
}

void CBTRDoc::OnPlateDeleteAllFree()
{
	CString S;
	S.Format("Delete ALL free surfaces?");
	if (AfxMessageBox(S, MB_ICONQUESTION | MB_YESNO) == IDYES) InitAddPlates();
	SetPlates();
	OnShow();
	//ShowStatus();
}

void CBTRDoc::OnPlateShowFile()
{
	FILE * fin;
	char name[1024];
	char buf [1024];
	if (pMarkedPlate == NULL) {
		AfxMessageBox("Load not specified"); return; }
	if (pMarkedPlate->filename == "") {
		AfxMessageBox("File not found"); return; }
	strcpy(name, pMarkedPlate->filename);
	ShowFileText(name);

/*	fin = fopen(name, "r");
	m_Text.Empty();// = "";
	while (!feof(fin)) {
		fgets(buf, 1024, fin);
		if (!feof(fin))	m_Text += buf;
	}
	fclose(fin);

		SetTitle(name);
		pDataView->m_rich.SetFont(&pDataView->font, TRUE);
		pDataView->m_rich.SetBackgroundColor(FALSE, RGB(250,230,180));
		pDataView->m_rich.SetWindowText(m_Text);
		pDataView->m_rich.SetModify(FALSE); */
}




void CBTRDoc::OnOptionsThreads()
{
	// here we detect number of processors present in the system (for unknown purposes)
	SYSTEM_INFO si;
	::GetSystemInfo(&si);
	int num_proc = si.dwNumberOfProcessors;
	CThreadsDlg dlg;

		dlg.Nproc = num_proc;
		dlg.Nthreads = ThreadNumber;
	/*	dlg.m_CalcNeutr = OptCalcNeutralizer;
		dlg.m_CalcRID = OptCalcRID;
		dlg.m_CalcDuct = OptCalcDuct;
		dlg.m_Xmin = CalcLimitXmin;
		dlg.m_Xmax = CalcLimitXmax;*/

		if (dlg.DoModal() == IDOK) {
			
			ThreadNumber = dlg.Nthreads;
			if (ThreadNumber > 8) {
				ThreadNumber = 8;
				AfxMessageBox("Number of threads has DED-limit = 8\n (for easier debug)");
			}
		/*	OptCalcNeutralizer = dlg.m_CalcNeutr;
			OptCalcRID = dlg.m_CalcRID;
			OptCalcDuct = dlg.m_CalcDuct;
			CalcLimitXmin = dlg.m_Xmin;
			CalcLimitXmax = dlg.m_Xmax;

			InitTracers();
						
			if (LoadSelected > 0) SelectAllPlates();
			SuspendedSpan = 0;
			StartTime = CTime::GetCurrentTime();
			OnShow(); */
			//if (InvUser) SendReport(TRUE); // include input
		}
		else return; // cancel */
}

void CBTRDoc::OnPlotSumReionX()
{
	char name[1024];
	CMultiPlotDlg dlg;
	dlg.DataY = &SumReiPowerX;
	
	dlg.InitPlot(this);
	dlg.plotcolor = RGB(200,0,0);

	if (dlg.DoModal() == IDOK) { //return;
		CFileDialog fdlg(FALSE, "txt | * ", "Sum_ReiX.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.txt) | *.TXT | All Files (*.*) | *.*||", NULL);
		if (fdlg.DoModal() == IDOK) {
			strcpy(name, fdlg.GetPathName());
			WriteSumReiPowerX(name, (float) dlg.Xmin, (float) dlg.Xmax);//"Sum_ReiX.dat");
			//AfxMessageBox("Data is written to file \n Sum_ReiX.dat");
			delete fdlg;
		} // filedialog OK
	} // OK
}

void CBTRDoc::OnPlotSumAtomX()
{
	char name[1024];
	CMultiPlotDlg dlg;
	dlg.DataY = &SumAtomPowerX;
	
	dlg.InitPlot(this);
	dlg.plotcolor = RGB(0,0,200);

	if (dlg.DoModal() == IDOK) { //return;
		CFileDialog fdlg(FALSE, "txt | * ", "Sum_AtomX.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.txt) | *.TXT | All Files (*.*) | *.*||", NULL);
		if (fdlg.DoModal() == IDOK) {
			strcpy(name, fdlg.GetPathName());
			WriteSumAtomPowerX(name, (float) dlg.Xmin, (float) dlg.Xmax);//"Sum_AtomX.dat");
			//AfxMessageBox("Data is written to file \n Sum_AtomX.dat");
			delete fdlg;
		} // filedialog OK
	} // OK
}

	//WriteSumReiPowerX("Sum_ReiX.dat");
	//WriteSumAtomPowerX("Sum_AtomX.dat");

void CBTRDoc::OnPlotAngulardistr() // calls statistics
{
	//if (OptCombiPlot == -1  || pMarkedPlate == NULL) return;
/*	int n = -1; // all falls
	int lines = 10000;
	if (pMarkedPlate != NULL) n = pMarkedPlate->Number;
	CStatOutDlg dlg;
	dlg.m_Lines = lines;
	if (dlg.DoModal() == IDOK) {
		lines = dlg.m_Lines;
	}
	ShowBPdata(n, lines);*/

	OnStatisticsSet();

/*	P_CalculateAngularProf(pMarkedPlate); //set limits, step

	int kmax = pMarkedPlate->AngularProfile.GetSize();
	double step = pMarkedPlate->StepAngle;
	double Amin = pMarkedPlate->MinAngle;
	double Amax = pMarkedPlate->MaxAngle;

	CArray<double, double>  ArrX; 
	CArray<double, double>  ArrY;
	CString S = pMarkedPlate->Comment;
	if (pMarkedPlate->Load != NULL) S += " " + pMarkedPlate->Load->Particles;
		
	PLOTINFO AnglePlot;
	AnglePlot.Caption =
		"Power vs Angle (from Normal) at "+ S; //pMarkedPlate->Comment;
	
	AnglePlot.LabelX = "Angle, mrad";
	AnglePlot.LabelY = "Power Density [W/mrad]";
	AnglePlot.LimitX = 0;//90;//ReionXmax;
	AnglePlot.LimitY = 0;//1.e20;
	AnglePlot.CrossX = 0;//100;
	AnglePlot.CrossY = 0;
	AnglePlot.Line = 1;
	AnglePlot.Interp = 1;
	AnglePlot.PosNegY = FALSE;
	AnglePlot.PosNegX = FALSE;

	double x, y;
	// double amin = 0;
	// double amax = 90;
	char name[1024];
	int k;
	 
	for (k = 0; k < kmax; k++) {
		x = Amin + step * (k+0.5);
		ArrX.Add(x);
		y = pMarkedPlate->AngularProfile[k];
		ArrY.Add(y);
		
	}

	AnglePlot.N = ArrX.GetSize();
	
	AnglePlot.DataX = &ArrX;
	AnglePlot.DataY = &ArrY;
	
	CPlotDlg dlg;
	dlg.Plot = &AnglePlot;

	dlg.InitPlot(Amin, Amax, step); 

	if (dlg.DoModal() == IDOK) {
		CFileDialog fdlg(FALSE, "txt | * ", "Angular_data.txt", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Text file (*.txt) | *.TXT | All Files (*.*) | *.*||", NULL);
		if (fdlg.DoModal() == IDOK) {
			FILE * fout;
			strcpy(name, fdlg.GetPathName());
			fout = fopen(name, "w");
			
			fprintf(fout, "Angular Distribution of Power \n at " + S);
			
			fprintf(fout, "\n Aver Angle, mrad    Power, W/mrad \n");
			for (k = 0; k < kmax-1; k++) {
				x = ArrX[k];
				y = ArrY[k];
				fprintf(fout, "\t  %g \t\t %g \n", x, y); 
			}
			fclose(fout);
			delete fdlg;
		} // filedialog OK
	} // Plot.DoModal

	ArrX.RemoveAll();
	ArrY.RemoveAll();
	*/
}

void CBTRDoc::OnUpdatePlotAngulardistr(CCmdUI *pCmdUI)
{
	//pCmdUI->Enable(OptCombiPlot != -1 && pMarkedPlate != NULL);
}

void CBTRDoc::OnNeutralizationCurrents()
{
	PlotCurrentRates(0); 
}

void CBTRDoc::OnNeutralizationRates()
{
	PlotCurrentRates(1); 
}


void CBTRDoc::OnLogView()
{
	ShowLogFile(0);
}


void CBTRDoc::OnLogSave()
{
	ShowLogFile(10);
	AfxMessageBox("Log settings will be added here");
}


void CBTRDoc::OnStatisticsView() //= Show ALL (all stat options -> ON)
{
	int n = -1; // all surf if not Selected
	int lines = 100000;
	if (pMarkedPlate != NULL && pMarkedPlate->Selected && OptCombiPlot > -1) 
		n = pMarkedPlate->Number;

	ShowBPdata(n, lines); // all data on selected surf (or ALL)
}


void CBTRDoc::OnStatisticsSet()
{
	int n = -1; // all falls
	int lines = 100; // to show
	int power, posloc, posglob, angle, pos; // options for output
	if (pMarkedPlate != NULL && pMarkedPlate->Selected && OptCombiPlot > -1)
		n = pMarkedPlate->Number;
	
	CStatOutDlg dlg;
	dlg.m_Lines = lines;
	dlg.m_Atoms = OptAtomPower;
	dlg.m_PosIons = OptPosIonPower;
	dlg.m_NegIons = OptNegIonPower;
	dlg.m_Power = 1; //  1 - [W]
	dlg.m_PosLoc = 1; // 1 - local
	dlg.m_PosGlob = 1; // 1 - global
	dlg.m_Afall = 2; // 2 - both angles
	if (dlg.DoModal() == IDOK) {
		lines = dlg.m_Lines;
		power = dlg.m_Power;
		posloc = dlg.m_PosLoc;
		posglob = dlg.m_PosGlob;
		angle = dlg.m_Afall;
		OptAtomPower = dlg.m_Atoms;
		OptPosIonPower = dlg.m_PosIons;
		OptNegIonPower = dlg.m_NegIons;
		pos = 0;
		if (posloc > 0 && posglob == 0) pos = 1;
		if (posloc > 0 && posglob > 0) pos = 2;
		if (posloc == 0 && posglob > 0) pos = 3;
		ShowBPdata(n, lines, pos, angle, power); // show selected options
		//ShowBPdata(n, lines); // show all
	}
	
}


void CBTRDoc::OnSurfacesMesh() // set global opt from main menu 
{
	SetDefaultMesh();
}


void CBTRDoc::OnUpdatePlateFile(CCmdUI *pCmdUI)
{
	//BOOL found = TRUE;
	//if (pMarkedPlate == NULL) found = FALSE; 
	//else if (pMarkedPlate->filename == "") found = FALSE;
	pCmdUI->Enable(pMarkedPlate != NULL && pMarkedPlate->filename != "");
}


void CBTRDoc::OnPlateLoadOptRecalc() // set plate opt in pop-up menu
{
	int n = -1;
	if (pMarkedPlate != NULL && pMarkedPlate->Selected && OptCombiPlot > -1)
		n = pMarkedPlate->Number;
	if (n < 0) {
		SetDefaultMesh();
		AfxMessageBox("No plate selected\n Settings will be applied next to all recalculated loads");
		return;
	}
	CPlate * plate = pMarkedPlate;
	if (plate->Touched == FALSE) { 		// non-zero loads 
		AfxMessageBox("Not loaded");
		return;
	}

	if (plate->Loaded == FALSE) { // touched but not calculated yet
		SetNullLoad(plate); // create zero load with default mesh options
		//P_CalculateLoad(plate);
		//SetLoadArray(plate, TRUE);
	}

	DefLoadDlg dlg; // set new opt
	dlg.m_OptN = 1; // fixed step
	dlg.NX = DefLoadNX;
	dlg.NY = DefLoadNY;
	dlg.Round = DefLoadStepRound; // round step if optN == TRUE (size)
	dlg.m_StepX = plate->Load->StepX;// DefLoadStepX;
	dlg.m_StepY = plate->Load->StepY;// DefLoadStepY;

		dlg.m_OptAtom = OptAtomPower;
		dlg.m_OptPos = OptPosIonPower;
		dlg.m_OptNeg = OptNegIonPower;

		if (dlg.DoModal() == IDOK) {
			DefLoadOptN = (dlg.m_OptN == 0);
			DefLoadNX = dlg.NX;
			DefLoadNY = dlg.NY;
			DefLoadStepRound = dlg.Round;
			DefLoadStepX = dlg.m_StepX;
			DefLoadStepY = dlg.m_StepY;

			OptAtomPower = dlg.m_OptAtom;
			OptPosIonPower = dlg.m_OptPos;
			OptNegIonPower = dlg.m_OptNeg;
		}
		SetNullLoad(plate); // create zero load with default mesh options
		P_CalculateLoad(plate);
		SetLoadArray(plate, TRUE);
	
		OnPlotMaxprofiles();
		plate->ShowLoadState(); // show summary (info)	
	
}


void CBTRDoc::OnEditCrossSect()
{
	if (!OptBeamInPlasma) return;
	
	char s[1024];
	CGasDlg dlg;
	dlg.m_Head1 = "Energy, keV/amu";
	dlg.m_Head2 = "StopCS, cm2"; // CS(10keV) = 10, CS(1000) = 0.1-0.2 (Suzuki)
//	dlg.m_Filename = CSFileName;
	dlg.m_X.Empty();
	dlg.m_Y.Empty();
	dlg.Arr = &CSarray;//
	dlg.m_Caption = "Stopping Cross-section data";

	double x, p, xmax = 0, pmax = 0, xmin = 1000;
	int i;
	for (i = 0; i <= CSarray.GetUpperBound(); i++) {
		x = CSarray[i].X; //E [keV/nu] 
		p = CSarray[i].Y;//SigmaStop [cm2]
		sprintf(s, "%f\r\n", x); dlg.m_X += s;
		sprintf(s, "%le\r\n", p); dlg.m_Y += s;
	}

	if (dlg.DoModal() == IDCANCEL) return;

	for (i = 0; i <= dlg.Arr->GetUpperBound(); i++) {
		x = dlg.Arr->GetAt(i).X;
		p = dlg.Arr->GetAt(i).Y;
		xmax = Max(xmax, x);
		pmax = Max(pmax, p);
		xmin = Min(xmin, x);
	}
/*
	GField->Pmax = pmax;
	GField->Xmax = xmax;
	GField->Xmin = xmin;
	GField->Nx = dlg.Arr->GetSize();

	GasFileName = dlg.m_Filename;
	PressureLoaded = TRUE;
	PressureDim = 1;
	GasCoeff = 1;
	OptReionAccount = TRUE;//automatic when gas loaded
	OptThickNeutralization = TRUE;
	SetReionPercent();
	SetNeutrCurrents(); */
	//OnShow();
}
